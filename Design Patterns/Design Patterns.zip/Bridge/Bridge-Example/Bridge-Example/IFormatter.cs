namespace Bridge_Example
{
    public interface IFormatter
    {
        string Format(string key, string value);
    }
}