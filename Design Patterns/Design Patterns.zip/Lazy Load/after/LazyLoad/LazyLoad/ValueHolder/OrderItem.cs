namespace LazyLoad.ValueHolder
{
    public class OrderItem
    {

    }
}