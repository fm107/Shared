namespace LazyLoad.Ghosts
{
    public class OrderItem 
    {
    }
}