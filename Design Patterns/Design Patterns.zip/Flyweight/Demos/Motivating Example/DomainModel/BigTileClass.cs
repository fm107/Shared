﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DomainModel
{
    public class BigTileClass
    {
        public int TileTypes
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public int XCoordinates
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public int YCoordinates
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public int WCoordinates
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public int HCoordinates
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public int ColorBrushes
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public void Draw()
        {
            throw new System.NotImplementedException();
        }
    }
}
