﻿namespace WeatherServices
{
    public class WeatherService
    {
        public double GetTempFarenheit(double latitude, double longitude)
        {
            return 86.5;
        }
    }
}
