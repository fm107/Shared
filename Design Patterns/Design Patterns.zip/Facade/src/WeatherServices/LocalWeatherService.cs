namespace WeatherServices
{
    public class LocalWeatherService
    {
        public double GetTempFarenheit(double latitude, double longitude)
        {
            return 84.8;
        }
    }
}