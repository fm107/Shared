﻿namespace LoggingDemo.Commands
{
    public interface ICommand
    {
        void Execute();
    }
}