﻿namespace ProxyDemo.Entities
{
    public class CustomerEntity
    {
        public int Id;
        public string Name;
        public int[] Orders;
    }
}