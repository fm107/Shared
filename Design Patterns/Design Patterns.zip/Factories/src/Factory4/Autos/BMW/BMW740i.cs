namespace Factory4.Autos.BMW
{
    public class BMW740i : BMWBase
    {
        public override string Name
        {
            get { return "BMW 740i"; }
        }
    }
}