namespace Factory4.Autos.BMW
{
    public class BMW328i : BMWBase
    {
        public override string Name
        {
            get { return "BMW 328i"; }
        }
    }
}