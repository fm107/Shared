namespace Factory4.Autos
{
    public interface IAutomobile
    {
        void TurnOn();
        void TurnOff();
    }
}