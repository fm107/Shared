﻿namespace FileLoggerSample.Interfaces
{
    public interface IFileLoggerFactory
    {
        IFileLogger Create();
    }
}