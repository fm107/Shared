﻿namespace FileLoggerSample.Impl.FileLoggers
{
    /// <summary>
    /// A non-singleton implementation of a file logger
    /// </summary>
    public class FileLogger : BaseFileLogger
    {
        public FileLogger()
        {
        }
    }
}