﻿using System;

namespace Examples.DependancyInjection
{
    public interface ILogging
    {
        void Debug(string message);
    }
}
