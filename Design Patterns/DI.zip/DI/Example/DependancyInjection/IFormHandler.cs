﻿using System;

namespace Examples.DependancyInjection
{
    interface IFormHandler
    {
        void Handle(string toAddress);
    }
}
