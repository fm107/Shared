﻿using System;
using System.Collections.Generic;
using System.Text;

namespace pdfforge.PDFCreator.Utilities.Tokens
{
    /// <summary>
    ///     class with method to replace Tokens (see -> ReplaceTokens) previously added in its private TokenDict (see ->
    ///     AddToken)
    /// </summary>
    public class TokenReplacer
    {
        #region Constants

        private const char TokenOpenChar = '<';
        private const char TokenCloseChar = '>';
        private const string TokenSplitString = ":";

        #endregion

        private readonly Dictionary<string, IToken> _tokenDict = new Dictionary<string, IToken>();

        #region Methods

        /// <summary>
        ///     Replace valid Token-names (previously added into the private TokenDict -> see AddToken) in the InputString by their
        ///     values.
        ///     Optional use of C#-format, declared behind a colon behind the Token-name.
        /// </summary>
        /// <param name="InputString">InputString which may contain Tokens, that will be replaced</param>
        /// <returns>
        ///     Returns the InputString with formated values of valid Tokens.
        /// </returns>
        /// <example>
        ///     <code lang="C#"><![CDATA[
        /// TokenReplacer tr = new TokenReplacer();
        /// tr.AddToken(new StringToken("Author", "NameOfAuthor"));
        /// string s = tr.ReplaceToken("<Author> becomes NameOfAuthor"));
        /// //output: s = "NameOfAuthor becomes NameOfAuthor"
        /// tr.AddToken(new NumberToken("Counter", 23));
        /// s = tr.ReplaceToken("NumberToken with Format <Counter:0000>");
        /// //output: s = "NumberToken with Format 0023"
        /// s = tr.ReplaceToken("<Non-added Token Name> <Counter>");
        /// //output: s = "<Non-added Token Name> 23"
        /// ]]>
        /// </code>
        /// </example>
        public string ReplaceTokens(string InputString)
        {
            int BeginOfToken, EndOfToken, LastIndexOfToken; //Memorize Indexes 
            bool Begin = false; //Flag for the beginning of a Token 

            BeginOfToken = InputString.IndexOf(TokenOpenChar);
            LastIndexOfToken = InputString.LastIndexOf(TokenCloseChar);

            if (BeginOfToken == -1 || LastIndexOfToken == -1) //No pair of <> included
            {
                return InputString;
            }
            var OutputString = new StringBuilder();

            if (BeginOfToken > 0) //Add part ahead of the first TokenOpenChar
            {
                OutputString.Append(InputString.Substring(0, BeginOfToken));
            }

            Begin = true; //Flag for an opened Token
            EndOfToken = BeginOfToken + 1; //First possible Position for a TokenCloseChar

            for (int i = BeginOfToken + 1; i <= LastIndexOfToken; i++)
            {
                if ((InputString[i] == TokenOpenChar) && (!Begin)) //Regular opening of Token
                {
                    //check for text in between
                    if (i > EndOfToken + 1)
                    {
                        OutputString.Append(InputString.Substring(EndOfToken + 1, i - EndOfToken - 1));
                            //Append text between Tokens
                    }

                    BeginOfToken = i;
                    Begin = true;
                }
                else if (InputString[i] == TokenOpenChar) //(&& Begin) //second TokenOpenChar without previous closing 
                {
                    OutputString.Append(InputString.Substring(BeginOfToken, i - BeginOfToken));
                        //add substring from the last BeginOfToken to the new TokenOpenChar
                    BeginOfToken = i;
                }
                else if ((InputString[i] == TokenCloseChar) && (Begin)) //regular closing of an opened Token
                {
                    Begin = false;
                    EndOfToken = i;

                    string ExtractedTokenString = InputString.Substring(BeginOfToken, i - BeginOfToken + 1);
                        //Extract Token from Input String

                    if (ExtractedTokenString.Contains(TokenSplitString)
                        &&
                        _tokenDict.ContainsKey(
                            ExtractedTokenString.Substring(1, ExtractedTokenString.IndexOf(':') - 1).ToUpper()))
                        //Token contains a format and TokenName (without <>) is Key in the TokenDict
                    {
                        IToken token =
                            _tokenDict[ExtractedTokenString.Substring(1, ExtractedTokenString.IndexOf(':') - 1).ToUpper()
                                ];

                        try
                        {
                            ExtractedTokenString =
                                token.GetValueWithFormat(
                                    ExtractedTokenString.Substring(ExtractedTokenString.IndexOf(':') + 1,
                                        ExtractedTokenString.Length - 1 - ExtractedTokenString.IndexOf(':') - 1));
                            //If the Format is valid, replace the string with the formated value of Token
                        }
                        catch
                        {
                            ExtractedTokenString = token.GetValue();
                            //If the format is not valid, replace the string with the non-formated value of Token
                        }
                        OutputString.Append(ExtractedTokenString);
                    }
                    else if (
                        _tokenDict.ContainsKey(
                            InputString.Substring(BeginOfToken + 1, i - BeginOfToken - 1).ToUpper()))
                        //Tokenname (without <>) is Key in the TokenDict
                    {
                        OutputString.Append(
                            _tokenDict[InputString.Substring(BeginOfToken + 1, i - BeginOfToken - 1).ToUpper()]
                                .GetValue());
                    }
                    else //Tokenname (without <>) is not Key in the TokenDict
                    {
                        OutputString.Append(InputString.Substring(BeginOfToken, i - BeginOfToken + 1));
                            //add the non-valid Tokenname (with <>)
                    }
                }
                else if (InputString[i] == TokenCloseChar) //&& !Begin //closing of Token without opening
                {
                    OutputString.Append(InputString.Substring(EndOfToken + 1, i - EndOfToken));
                        //add part from the last regular closing to the actual irregular closing 
                    EndOfToken = i;
                }
            }

            if (LastIndexOfToken < InputString.Length) //Add part behind the last TokenCloseChar
            {
                OutputString.Append(InputString.Substring(LastIndexOfToken + 1,
                    InputString.Length - LastIndexOfToken - 1));
            }

            return OutputString.ToString();
        }

        public string[] GetTokenNames()
        {
            return GetTokenNames(true);
        }

        public string[] GetTokenNames(bool withDelimiters)
        {
            var tokens = new List<string>();

            foreach (IToken t in _tokenDict.Values)
            {
                if (withDelimiters)
                {
                    tokens.Add(TokenOpenChar + t.GetName() + TokenCloseChar);
                }
                else
                {
                    tokens.Add(t.GetName());
                }
            }

            return tokens.ToArray();
        }

        public IToken GetToken(string name)
        {
            if (name == null)
                throw new ArgumentNullException("name");

            try
            {
                return _tokenDict[name.ToUpper()];
            }
            catch (KeyNotFoundException)
            {
                return null;
            }
        }

        /// <summary>
        ///     Add new Token to the private TokenDict for replacing the token-name with its value (-> see ReplaceToken).
        /// </summary>
        /// <param name="NewToken">Token (implements IToken)</param>
        public void AddToken(IToken NewToken)
        {
            _tokenDict[NewToken.GetName().ToUpper()] = NewToken;
        }

        /// <summary>
        ///     Comfort function to add a string token
        /// </summary>
        /// <param name="name">name of the token (without brackets)</param>
        /// <param name="value">the value that will be inserted</param>
        public void AddStringToken(string name, string value)
        {
            AddToken(new StringToken(name, value));
        }

        /// <summary>
        ///     Comfort function to add a date token
        /// </summary>
        /// <param name="name">name of the token (without brackets)</param>
        /// <param name="value">the value that will be inserted</param>
        public void AddDateToken(string name, DateTime value)
        {
            AddToken(new DateToken(name, value));
        }

        /// <summary>
        ///     Comfort function to add a number token
        /// </summary>
        /// <param name="name">name of the token (without brackets)</param>
        /// <param name="value">the value that will be inserted</param>
        public void AddNumberToken(string name, int value)
        {
            AddToken(new NumberToken(name, value));
        }

        /// <summary>
        ///     Comfort function to add a list token
        /// </summary>
        /// <param name="name">name of the token (without brackets)</param>
        /// <param name="value">the value that will be inserted</param>
        public void AddListToken(string name, IList<string> value)
        {
            AddToken(new ListToken(name, value));
        }

        #endregion
    }
}