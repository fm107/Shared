﻿using System.Windows.Controls;

namespace pdfforge.PDFCreator.Views.UserControls
{
    public partial class ApiServicesTab : UserControl
    {
        public ApiServicesTab()
        {
            InitializeComponent();
        }
    }
}