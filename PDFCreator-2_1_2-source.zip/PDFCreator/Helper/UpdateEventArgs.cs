﻿using System;

namespace pdfforge.PDFCreator.Helper
{
    class UpdateEventArgs : EventArgs
    {
        public bool SetNewUpdateTime;
    }
}