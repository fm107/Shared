# External Libraries

PDFCreator uses printer driver files from Windows 8.

## Required

 - Windows8\PS_SCHM.GDL
 - Windows8\PSCRIPT.HLP
 - Windows8\x64\PS5UI.DLL
 - Windows8\x64\PSCRIPT.NTF
 - Windows8\x64\PSCRIPT5.DLL
 - Windows8\x86\PS5UI.DLL
 - Windows8\x86\PSCRIPT.NTF
 - Windows8\x86\PSCRIPT5.DLL
 