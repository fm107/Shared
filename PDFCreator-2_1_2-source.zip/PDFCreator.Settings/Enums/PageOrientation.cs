﻿namespace pdfforge.PDFCreator.Core.Settings.Enums
{
    public enum PageOrientation     
    {
        Automatic
        ,Portrait
        ,Landscape
    }
}
