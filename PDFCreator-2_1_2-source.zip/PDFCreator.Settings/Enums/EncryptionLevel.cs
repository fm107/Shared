﻿namespace pdfforge.PDFCreator.Core.Settings.Enums
{
    public enum EncryptionLevel
    {
        Rc40Bit
        , Rc128Bit
        , Aes128Bit
    }
}
