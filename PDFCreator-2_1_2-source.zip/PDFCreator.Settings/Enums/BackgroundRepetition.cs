﻿namespace pdfforge.PDFCreator.Core.Settings.Enums
{
    public enum BackgroundRepetition
    {
        NoRepetition,
        RepeatAllPages,
        RepeatLastPage
    }
}
