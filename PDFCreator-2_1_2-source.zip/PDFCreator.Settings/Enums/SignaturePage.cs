﻿namespace pdfforge.PDFCreator.Core.Settings.Enums
{
    public enum SignaturePage
    {
        FirstPage,
        LastPage,
        CustomPage
    }
}
