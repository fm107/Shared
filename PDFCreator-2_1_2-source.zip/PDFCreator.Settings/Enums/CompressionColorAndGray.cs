﻿namespace pdfforge.PDFCreator.Core.Settings.Enums
{
    public enum CompressionColorAndGray
    {
        Automatic,
        JpegMaximum,
        JpegHigh,
        JpegMedium,
        JpegLow,
        JpegMinimum,
        JpegManual,
        Zip
    }
}
