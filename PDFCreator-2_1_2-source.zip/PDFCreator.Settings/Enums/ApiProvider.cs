﻿namespace pdfforge.PDFCreator.Core.Settings.Enums
{
    public enum ApiProvider
    {
        AttachMe
        , Dropbox
    }
}
