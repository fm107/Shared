﻿namespace pdfforge.PDFCreator.Core.Settings.Enums
{
    public enum PageView
    {
        OnePage
        ,OneColumn
        ,TwoColumnsOddLeft
        ,TwoColumnsOddRight
        ,TwoPagesOddLeft
        ,TwoPagesOddRight
    }
}
