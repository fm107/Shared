﻿namespace pdfforge.PDFCreator.Core.Settings.Enums
{
    public enum DuplexPrint
    {
        Disable,
        LongEdge,
        ShortEdge
    }
}
