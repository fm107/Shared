using System;

internal enum f
{
	a,
	b
}