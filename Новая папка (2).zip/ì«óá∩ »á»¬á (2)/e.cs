using System;
using System.IO;

internal class e
{
	private static bool a;

	private static bool b;

	private static DateTime c;

	private static bool d;

	private static string e;

	private static string f;

	private static string g;

	static e()
	{
		e.a = true;
		e.b = false;
		e.c = new DateTime(2015, 7, 31);
		e.d = true;
		e.e = "Compound File .NET 2.0 evaluation version, www.independentsoft.com.";
		e.f = "Compound File .NET 2.0 evaluation version, www.independentsoft.com. Evaluation version has expired.";
		e.g = "Compound File .NET 2.0 evaluation version, www.independentsoft.com. Please contact Independentsoft to obtain extended evaluation version dll file.";
	}

	internal static void a()
	{
		if (!e.a)
		{
			if (DateTime.Now.CompareTo(e.c) > 0)
			{
				throw new ApplicationException(e.f);
			}
			if (!e.d)
			{
				Console.WriteLine(e.e);
			}
			if (!e.b)
			{
				string str = string.Concat(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "\\.cpd");
				if (!File.Exists(str))
				{
					try
					{
						File.Create(str);
					}
					catch
					{
						if (DateTime.Now.Day < 8 && DateTime.Now.DayOfWeek == DayOfWeek.Tuesday || DateTime.Now.Day > 23 && DateTime.Now.DayOfWeek == DayOfWeek.Tuesday)
						{
							Console.Out.WriteLine(e.g);
							Console.Error.WriteLine(e.g);
							throw new ApplicationException(e.g);
						}
					}
				}
				else
				{
					DateTime creationTime = File.GetCreationTime(str);
					if (DateTime.Now.CompareTo(creationTime.AddMonths(1)) > 0)
					{
						Console.Out.WriteLine(e.f);
						Console.Error.WriteLine(e.f);
						throw new ApplicationException(e.f);
					}
				}
			}
		}
	}
}