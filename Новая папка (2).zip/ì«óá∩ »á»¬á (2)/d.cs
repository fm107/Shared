using System;
using System.IO;

internal class d
{
	private static bool a;

	private static bool b;

	private static DateTime c;

	private static bool d;

	private static string e;

	private static string f;

	private static string g;

	static d()
	{
		d.a = false;
		d.b = false;
		d.c = new DateTime(2016, 12, 31);
		d.d = false;
		d.e = "MSG .NET 2.0 evaluation version, www.independentsoft.com.";
		d.f = "MSG .NET 2.0 evaluation version, www.independentsoft.com. Evaluation version has expired.";
		d.g = "MSG .NET 2.0 evaluation version, www.independentsoft.com. Please contact Independentsoft to obtain extended evaluation version dll file.";
	}

	internal static void a()
	{
		if (!d.a)
		{
			if (DateTime.Now.CompareTo(d.c) > 0)
			{
				throw new ApplicationException(d.f);
			}
			if (!d.d)
			{
				Console.WriteLine(d.e);
			}
			if (!d.b)
			{
				string str = string.Concat(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "\\.msg");
				if (!File.Exists(str))
				{
					try
					{
						File.Create(str);
					}
					catch
					{
						if (DateTime.Now.Day < 8 && DateTime.Now.DayOfWeek == DayOfWeek.Tuesday)
						{
							Console.Out.WriteLine(d.g);
							Console.Error.WriteLine(d.g);
							throw new ApplicationException(d.g);
						}
					}
				}
				else
				{
					DateTime creationTime = File.GetCreationTime(str);
					if (DateTime.Now.CompareTo(creationTime.AddMonths(1)) > 0)
					{
						Console.Out.WriteLine(d.f);
						Console.Error.WriteLine(d.f);
						throw new ApplicationException(d.f);
					}
				}
			}
		}
	}
}