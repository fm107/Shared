using Independentsoft.Msg;
using System;
using System.Collections.Generic;

internal class h
{
	internal static short a(Gender A_0)
	{
		if (A_0 == Gender.Female)
		{
			return 1;
		}
		if (A_0 == Gender.Male)
		{
			return 2;
		}
		return 0;
	}

	internal static uint a(LastVerbExecuted A_0)
	{
		if (A_0 == LastVerbExecuted.ReplyToSender)
		{
			return (uint)102;
		}
		if (A_0 == LastVerbExecuted.ReplyToAll)
		{
			return (uint)103;
		}
		if (A_0 == LastVerbExecuted.Forward)
		{
			return (uint)104;
		}
		return (uint)0;
	}

	internal static uint a(ObjectType A_0)
	{
		if (A_0 == ObjectType.MessageStore)
		{
			return (uint)1;
		}
		if (A_0 == ObjectType.AddressBook)
		{
			return (uint)2;
		}
		if (A_0 == ObjectType.Folder)
		{
			return (uint)3;
		}
		if (A_0 == ObjectType.AddressBookContainer)
		{
			return (uint)4;
		}
		if (A_0 == ObjectType.Message)
		{
			return (uint)5;
		}
		if (A_0 == ObjectType.MailUser)
		{
			return (uint)6;
		}
		if (A_0 == ObjectType.Attachment)
		{
			return (uint)7;
		}
		if (A_0 == ObjectType.DistributionList)
		{
			return (uint)8;
		}
		if (A_0 == ObjectType.ProfileSelection)
		{
			return (uint)9;
		}
		if (A_0 == ObjectType.Status)
		{
			return (uint)10;
		}
		if (A_0 == ObjectType.Session)
		{
			return (uint)11;
		}
		if (A_0 == ObjectType.Form)
		{
			return (uint)12;
		}
		return (uint)0;
	}

	internal static uint a(IList<StoreSupportMask> A_0)
	{
		uint num = 0;
		for (int i = 0; i < A_0.Count; i++)
		{
			StoreSupportMask item = A_0[i];
			if (item == StoreSupportMask.Ansi)
			{
				num = num + 131072;
			}
			else if (item == StoreSupportMask.Attachments)
			{
				num = num + 32;
			}
			else if (item == StoreSupportMask.Categorize)
			{
				num = num + 1024;
			}
			else if (item == StoreSupportMask.Create)
			{
				num = num + 16;
			}
			else if (item == StoreSupportMask.Html)
			{
				num = num + 65536;
			}
			else if (item == StoreSupportMask.Html)
			{
				num = num + 65536;
			}
			else if (item == StoreSupportMask.ItemProc)
			{
				num = num + 2097152;
			}
			else if (item == StoreSupportMask.LocalStore)
			{
				num = num + 524288;
			}
			else if (item == StoreSupportMask.Modify)
			{
				num = num + 8;
			}
			else if (item == StoreSupportMask.MultiValueProperties)
			{
				num = num + 512;
			}
			else if (item == StoreSupportMask.Notify)
			{
				num = num + 256;
			}
			else if (item == StoreSupportMask.Ole)
			{
				num = num + 64;
			}
			else if (item == StoreSupportMask.PublicFolders)
			{
				num = num + 16384;
			}
			else if (item == StoreSupportMask.Pusher)
			{
				num = num + 8388608;
			}
			else if (item == StoreSupportMask.ReadOnly)
			{
				num = num + 2;
			}
			else if (item == StoreSupportMask.Restrictions)
			{
				num = num + 4096;
			}
			else if (item == StoreSupportMask.Rtf)
			{
				num = num + 2048;
			}
			else if (item == StoreSupportMask.Search)
			{
				num = num + 4;
			}
			else if (item == StoreSupportMask.Sort)
			{
				num = num + 8192;
			}
			else if (item == StoreSupportMask.Submit)
			{
				num = num + 128;
			}
			else if (item == StoreSupportMask.UncompressedRtf)
			{
				num = num + 32768;
			}
			else if (item == StoreSupportMask.Unicode)
			{
				num = num + 262144;
			}
		}
		return num;
	}

	internal static uint a(IList<MessageFlag> A_0)
	{
		uint num = 0;
		for (int i = 0; i < A_0.Count; i++)
		{
			MessageFlag item = A_0[i];
			if (item == MessageFlag.Associated)
			{
				num = num + 64;
			}
			else if (item == MessageFlag.FromMe)
			{
				num = num + 32;
			}
			else if (item == MessageFlag.HasAttachment)
			{
				num = num + 16;
			}
			else if (item == MessageFlag.NonReadReportPending)
			{
				num = num + 512;
			}
			else if (item == MessageFlag.OriginInternet)
			{
				num = num + 8192;
			}
			else if (item == MessageFlag.OriginMiscExternal)
			{
				num = num + 32768;
			}
			else if (item == MessageFlag.OriginX400)
			{
				num = num + 4096;
			}
			else if (item == MessageFlag.Read)
			{
				num++;
			}
			else if (item == MessageFlag.Resend)
			{
				num = num + 128;
			}
			else if (item == MessageFlag.ReadReportPending)
			{
				num = num + 256;
			}
			else if (item == MessageFlag.Submit)
			{
				num = num + 4;
			}
			else if (item == MessageFlag.Unmodified)
			{
				num = num + 2;
			}
			else if (item == MessageFlag.Unsent)
			{
				num = num + 8;
			}
		}
		return num;
	}

	internal static RecurrenceEndType a(int A_0)
	{
		if (A_0 == 8225)
		{
			return RecurrenceEndType.EndAfterDate;
		}
		if (A_0 == 8226)
		{
			return RecurrenceEndType.EndAfterNOccurrences;
		}
		return RecurrenceEndType.NeverEnd;
	}

	internal static CalendarType a(short A_0)
	{
		if (A_0 == 1)
		{
			return CalendarType.Gregorian;
		}
		if (A_0 == 2)
		{
			return CalendarType.GregorianUS;
		}
		if (A_0 == 3)
		{
			return CalendarType.JapaneseEmperorEra;
		}
		if (A_0 == 4)
		{
			return CalendarType.Taiwan;
		}
		if (A_0 == 5)
		{
			return CalendarType.KoreanTangunEra;
		}
		if (A_0 == 6)
		{
			return CalendarType.Hijri;
		}
		if (A_0 == 7)
		{
			return CalendarType.Thai;
		}
		if (A_0 == 8)
		{
			return CalendarType.HebrewLunar;
		}
		if (A_0 == 9)
		{
			return CalendarType.GregorianMiddleEastFrench;
		}
		if (A_0 == 10)
		{
			return CalendarType.GregorianArabic;
		}
		if (A_0 == 11)
		{
			return CalendarType.GregorianTransliteratedEnglish;
		}
		if (A_0 == 12)
		{
			return CalendarType.GregorianTransliteratedFrench;
		}
		if (A_0 == 14)
		{
			return CalendarType.JapaneseLunar;
		}
		if (A_0 == 15)
		{
			return CalendarType.ChineseLunar;
		}
		if (A_0 == 16)
		{
			return CalendarType.SakaEra;
		}
		if (A_0 == 17)
		{
			return CalendarType.LunarETOChinese;
		}
		if (A_0 == 18)
		{
			return CalendarType.LunarETOKorean;
		}
		if (A_0 == 19)
		{
			return CalendarType.LunarRokuyou;
		}
		if (A_0 == 20)
		{
			return CalendarType.KoreanLunar;
		}
		if (A_0 == 23)
		{
			return CalendarType.UmAlQura;
		}
		return CalendarType.None;
	}

	internal static uint a(FlagIcon A_0)
	{
		if (A_0 == FlagIcon.Purple)
		{
			return (uint)1;
		}
		if (A_0 == FlagIcon.Orange)
		{
			return (uint)2;
		}
		if (A_0 == FlagIcon.Green)
		{
			return (uint)3;
		}
		if (A_0 == FlagIcon.Yellow)
		{
			return (uint)4;
		}
		if (A_0 == FlagIcon.Blue)
		{
			return (uint)5;
		}
		if (A_0 == FlagIcon.Red)
		{
			return (uint)6;
		}
		return (uint)0;
	}

	internal static uint a(SelectedMailingAddress A_0)
	{
		if (A_0 == SelectedMailingAddress.Home)
		{
			return (uint)1;
		}
		if (A_0 == SelectedMailingAddress.Business)
		{
			return (uint)2;
		}
		if (A_0 == SelectedMailingAddress.Other)
		{
			return (uint)3;
		}
		return (uint)0;
	}

	internal static uint a(FlagStatus A_0)
	{
		if (A_0 == FlagStatus.Complete)
		{
			return (uint)1;
		}
		if (A_0 == FlagStatus.Marked)
		{
			return (uint)2;
		}
		return (uint)0;
	}

	internal static uint a(DisplayType A_0)
	{
		if (A_0 == DisplayType.MailUser)
		{
			return (uint)0;
		}
		if (A_0 == DisplayType.DistributionList)
		{
			return (uint)1;
		}
		if (A_0 == DisplayType.Forum)
		{
			return (uint)2;
		}
		if (A_0 == DisplayType.Agent)
		{
			return (uint)3;
		}
		if (A_0 == DisplayType.Organization)
		{
			return (uint)4;
		}
		if (A_0 == DisplayType.PrivateDistributionList)
		{
			return (uint)5;
		}
		if (A_0 == DisplayType.RemoteMailUser)
		{
			return (uint)6;
		}
		if (A_0 == DisplayType.Folder)
		{
			return (uint)16777216;
		}
		if (A_0 == DisplayType.FolderLink)
		{
			return (uint)33554432;
		}
		if (A_0 == DisplayType.FolderSpecial)
		{
			return (uint)67108864;
		}
		if (A_0 == DisplayType.Modifiable)
		{
			return (uint)65536;
		}
		if (A_0 == DisplayType.GlobalAddressBook)
		{
			return (uint)131072;
		}
		if (A_0 == DisplayType.LocalAddressBook)
		{
			return (uint)196608;
		}
		if (A_0 == DisplayType.WideAreaNetworkAddressBook)
		{
			return (uint)262144;
		}
		if (A_0 == DisplayType.NotSpecific)
		{
			return (uint)327680;
		}
		return (uint)0;
	}

	internal static uint a(NoteColor A_0)
	{
		if (A_0 == NoteColor.Blue)
		{
			return (uint)0;
		}
		if (A_0 == NoteColor.Green)
		{
			return (uint)1;
		}
		if (A_0 == NoteColor.Pink)
		{
			return (uint)2;
		}
		if (A_0 == NoteColor.Yellow)
		{
			return (uint)3;
		}
		if (A_0 == NoteColor.White)
		{
			return (uint)4;
		}
		return (uint)0;
	}

	internal static uint a(RecipientType A_0)
	{
		if (A_0 == RecipientType.To)
		{
			return (uint)1;
		}
		if (A_0 == RecipientType.Cc)
		{
			return (uint)2;
		}
		if (A_0 == RecipientType.Bcc)
		{
			return (uint)3;
		}
		if (A_0 == RecipientType.P1)
		{
			return (uint)268435456;
		}
		return (uint)0;
	}

	internal static uint a(Priority A_0)
	{
		if (A_0 == Priority.Low)
		{
			return (uint)-1;
		}
		if (A_0 == Priority.High)
		{
			return (uint)1;
		}
		return (uint)0;
	}

	internal static uint a(Sensitivity A_0)
	{
		if (A_0 == Sensitivity.Personal)
		{
			return (uint)1;
		}
		if (A_0 == Sensitivity.Private)
		{
			return (uint)2;
		}
		if (A_0 == Sensitivity.Confidential)
		{
			return (uint)3;
		}
		return (uint)0;
	}

	internal static uint a(Importance A_0)
	{
		if (A_0 == Importance.Normal)
		{
			return (uint)1;
		}
		if (A_0 == Importance.High)
		{
			return (uint)2;
		}
		if (A_0 == Importance.Low)
		{
			return (uint)0;
		}
		return (uint)1;
	}

	internal static uint a(TaskOwnership A_0)
	{
		if (A_0 == TaskOwnership.New)
		{
			return (uint)0;
		}
		if (A_0 == TaskOwnership.Delegated)
		{
			return (uint)1;
		}
		if (A_0 == TaskOwnership.Own)
		{
			return (uint)2;
		}
		return (uint)0;
	}

	internal static uint a(TaskDelegationState A_0)
	{
		if (A_0 == TaskDelegationState.Owned)
		{
			return (uint)0;
		}
		if (A_0 == TaskDelegationState.OwnNew)
		{
			return (uint)1;
		}
		if (A_0 == TaskDelegationState.Accepted)
		{
			return (uint)2;
		}
		if (A_0 == TaskDelegationState.Declined)
		{
			return (uint)3;
		}
		if (A_0 == TaskDelegationState.NoMatch)
		{
			return (uint)4;
		}
		return (uint)0;
	}

	internal static uint a(BusyStatus A_0)
	{
		if (A_0 == BusyStatus.Free)
		{
			return (uint)0;
		}
		if (A_0 == BusyStatus.Tentative)
		{
			return (uint)1;
		}
		if (A_0 == BusyStatus.Busy)
		{
			return (uint)2;
		}
		if (A_0 == BusyStatus.OutOfOffice)
		{
			return (uint)3;
		}
		return (uint)0;
	}

	internal static uint a(RecurrenceType A_0)
	{
		if (A_0 == RecurrenceType.Daily)
		{
			return (uint)1;
		}
		if (A_0 == RecurrenceType.Weekly)
		{
			return (uint)2;
		}
		if (A_0 == RecurrenceType.Monthly)
		{
			return (uint)3;
		}
		if (A_0 == RecurrenceType.Yearly)
		{
			return (uint)4;
		}
		if (A_0 == RecurrenceType.MonthNth)
		{
			return (uint)5;
		}
		if (A_0 == RecurrenceType.YearNth)
		{
			return (uint)6;
		}
		return (uint)0;
	}

	internal static uint a(ResponseStatus A_0)
	{
		if (A_0 == ResponseStatus.Organized)
		{
			return (uint)1;
		}
		if (A_0 == ResponseStatus.Tentative)
		{
			return (uint)2;
		}
		if (A_0 == ResponseStatus.Accepted)
		{
			return (uint)3;
		}
		if (A_0 == ResponseStatus.Declined)
		{
			return (uint)4;
		}
		if (A_0 == ResponseStatus.NotResponded)
		{
			return (uint)5;
		}
		return (uint)0;
	}

	internal static uint a(MeetingStatus A_0)
	{
		if (A_0 == MeetingStatus.NonMeeting)
		{
			return (uint)0;
		}
		if (A_0 == MeetingStatus.Meeting)
		{
			return (uint)1;
		}
		if (A_0 == MeetingStatus.Received)
		{
			return (uint)3;
		}
		if (A_0 == MeetingStatus.CanceledOrganizer)
		{
			return (uint)4;
		}
		if (A_0 == MeetingStatus.Canceled)
		{
			return (uint)5;
		}
		return (uint)0;
	}

	internal static uint a(TaskStatus A_0)
	{
		if (A_0 == TaskStatus.NotStarted)
		{
			return (uint)0;
		}
		if (A_0 == TaskStatus.InProgress)
		{
			return (uint)1;
		}
		if (A_0 == TaskStatus.Completed)
		{
			return (uint)2;
		}
		if (A_0 == TaskStatus.WaitingOnOthers)
		{
			return (uint)3;
		}
		if (A_0 == TaskStatus.Deferred)
		{
			return (uint)4;
		}
		return (uint)0;
	}

	internal static uint a(AttachmentMethod A_0)
	{
		if (A_0 == AttachmentMethod.NoAttachment)
		{
			return (uint)0;
		}
		if (A_0 == AttachmentMethod.AttachByValue)
		{
			return (uint)1;
		}
		if (A_0 == AttachmentMethod.AttachByReference)
		{
			return (uint)2;
		}
		if (A_0 == AttachmentMethod.AttachByReferenceResolve)
		{
			return (uint)3;
		}
		if (A_0 == AttachmentMethod.AttachByReferenceOnly)
		{
			return (uint)4;
		}
		if (A_0 == AttachmentMethod.EmbeddedMessage)
		{
			return (uint)5;
		}
		if (A_0 == AttachmentMethod.Ole)
		{
			return (uint)6;
		}
		return (uint)0;
	}

	internal static uint a(AttachmentFlags A_0)
	{
		if (A_0 == AttachmentFlags.InvisibleInHtml)
		{
			return (uint)1;
		}
		if (A_0 == AttachmentFlags.InvisibleInRtf)
		{
			return (uint)2;
		}
		return (uint)0;
	}

	internal static PropertyType a(uint A_0)
	{
		PropertyType propertyType;
		ushort a0 = (ushort)(A_0 & 65535);
		ushort num = (ushort)(a0 & 4095);
		if ((a0 & 61440) != 0)
		{
			if (num == 2)
			{
				propertyType = PropertyType.MultipleInteger16;
			}
			else if (num == 3)
			{
				propertyType = PropertyType.MultipleInteger32;
			}
			else if (num == 4)
			{
				propertyType = PropertyType.MultipleFloating32;
			}
			else if (num == 5)
			{
				propertyType = PropertyType.MultipleFloating64;
			}
			else if (num == 6)
			{
				propertyType = PropertyType.MultipleCurrency;
			}
			else if (num == 7)
			{
				propertyType = PropertyType.MultipleFloatingTime;
			}
			else if (num == 20)
			{
				propertyType = PropertyType.MultipleInteger64;
			}
			else if (num == 30)
			{
				propertyType = PropertyType.MultipleString8;
			}
			else if (num == 31)
			{
				propertyType = PropertyType.MultipleString;
			}
			else if (num == 64)
			{
				propertyType = PropertyType.MultipleTime;
			}
			else if (num != 72)
			{
				propertyType = (num != 258 ? PropertyType.MultipleString : PropertyType.MultipleBinary);
			}
			else
			{
				propertyType = PropertyType.MultipleGuid;
			}
		}
		else if (num == 2)
		{
			propertyType = PropertyType.Integer16;
		}
		else if (num == 3)
		{
			propertyType = PropertyType.Integer32;
		}
		else if (num == 4)
		{
			propertyType = PropertyType.Floating32;
		}
		else if (num == 5)
		{
			propertyType = PropertyType.Floating64;
		}
		else if (num == 6)
		{
			propertyType = PropertyType.Currency;
		}
		else if (num == 7)
		{
			propertyType = PropertyType.FloatingTime;
		}
		else if (num == 7)
		{
			propertyType = PropertyType.ErrorCode;
		}
		else if (num == 11)
		{
			propertyType = PropertyType.Boolean;
		}
		else if (num == 13)
		{
			propertyType = PropertyType.Object;
		}
		else if (num == 20)
		{
			propertyType = PropertyType.Integer64;
		}
		else if (num == 30)
		{
			propertyType = PropertyType.String8;
		}
		else if (num == 31)
		{
			propertyType = PropertyType.String;
		}
		else if (num == 64)
		{
			propertyType = PropertyType.Time;
		}
		else if (num != 72)
		{
			propertyType = (num != 258 ? PropertyType.String : PropertyType.Binary);
		}
		else
		{
			propertyType = PropertyType.Guid;
		}
		return propertyType;
	}

	internal static Independentsoft.Msg.DayOfWeek b(int A_0)
	{
		if (A_0 == 0)
		{
			return Independentsoft.Msg.DayOfWeek.Sunday;
		}
		if (A_0 == 1)
		{
			return Independentsoft.Msg.DayOfWeek.Monday;
		}
		if (A_0 == 2)
		{
			return Independentsoft.Msg.DayOfWeek.Tuesday;
		}
		if (A_0 == 3)
		{
			return Independentsoft.Msg.DayOfWeek.Wednesday;
		}
		if (A_0 == 4)
		{
			return Independentsoft.Msg.DayOfWeek.Thursday;
		}
		if (A_0 == 5)
		{
			return Independentsoft.Msg.DayOfWeek.Friday;
		}
		return Independentsoft.Msg.DayOfWeek.Saturday;
	}

	internal static RecurrencePatternType b(short A_0)
	{
		if (A_0 == 0)
		{
			return RecurrencePatternType.Day;
		}
		if (A_0 == 1)
		{
			return RecurrencePatternType.Week;
		}
		if (A_0 == 2)
		{
			return RecurrencePatternType.Month;
		}
		if (A_0 == 3)
		{
			return RecurrencePatternType.MonthEnd;
		}
		if (A_0 == 4)
		{
			return RecurrencePatternType.MonthNth;
		}
		if (A_0 == 8202)
		{
			return RecurrencePatternType.HijriMonth;
		}
		if (A_0 == 8203)
		{
			return RecurrencePatternType.HijriMonthEnd;
		}
		return RecurrencePatternType.HijriMonthNth;
	}

	internal static AttachmentFlags b(uint A_0)
	{
		if (A_0 == 1)
		{
			return AttachmentFlags.InvisibleInHtml;
		}
		if (A_0 == 2)
		{
			return AttachmentFlags.InvisibleInRtf;
		}
		return AttachmentFlags.None;
	}

	internal static RecurrencePatternFrequency c(short A_0)
	{
		if (A_0 == 8202)
		{
			return RecurrencePatternFrequency.Daily;
		}
		if (A_0 == 8203)
		{
			return RecurrencePatternFrequency.Weekly;
		}
		if (A_0 == 8204)
		{
			return RecurrencePatternFrequency.Monthly;
		}
		return RecurrencePatternFrequency.Yearly;
	}

	internal static AttachmentMethod c(uint A_0)
	{
		if (A_0 == 0)
		{
			return AttachmentMethod.NoAttachment;
		}
		if (A_0 == 1)
		{
			return AttachmentMethod.AttachByValue;
		}
		if (A_0 == 2)
		{
			return AttachmentMethod.AttachByReference;
		}
		if (A_0 == 3)
		{
			return AttachmentMethod.AttachByReferenceResolve;
		}
		if (A_0 == 4)
		{
			return AttachmentMethod.AttachByReferenceOnly;
		}
		if (A_0 == 5)
		{
			return AttachmentMethod.EmbeddedMessage;
		}
		if (A_0 == 6)
		{
			return AttachmentMethod.Ole;
		}
		return AttachmentMethod.None;
	}

	internal static Gender d(short A_0)
	{
		if (A_0 == 1)
		{
			return Gender.Female;
		}
		if (A_0 == 2)
		{
			return Gender.Male;
		}
		return Gender.None;
	}

	internal static TaskStatus d(uint A_0)
	{
		if (A_0 == 0)
		{
			return TaskStatus.NotStarted;
		}
		if (A_0 == 1)
		{
			return TaskStatus.InProgress;
		}
		if (A_0 == 2)
		{
			return TaskStatus.Completed;
		}
		if (A_0 == 3)
		{
			return TaskStatus.WaitingOnOthers;
		}
		if (A_0 == 4)
		{
			return TaskStatus.Deferred;
		}
		return TaskStatus.None;
	}

	internal static MeetingStatus e(uint A_0)
	{
		if (A_0 == 0)
		{
			return MeetingStatus.NonMeeting;
		}
		if (A_0 == 1)
		{
			return MeetingStatus.Meeting;
		}
		if (A_0 == 3)
		{
			return MeetingStatus.Received;
		}
		if (A_0 == 4)
		{
			return MeetingStatus.CanceledOrganizer;
		}
		if (A_0 == 5)
		{
			return MeetingStatus.Canceled;
		}
		return MeetingStatus.None;
	}

	internal static ResponseStatus f(uint A_0)
	{
		if (A_0 == 1)
		{
			return ResponseStatus.Organized;
		}
		if (A_0 == 2)
		{
			return ResponseStatus.Tentative;
		}
		if (A_0 == 3)
		{
			return ResponseStatus.Accepted;
		}
		if (A_0 == 4)
		{
			return ResponseStatus.Declined;
		}
		if (A_0 == 5)
		{
			return ResponseStatus.NotResponded;
		}
		return ResponseStatus.None;
	}

	internal static RecurrenceType g(uint A_0)
	{
		if (A_0 == 1)
		{
			return RecurrenceType.Daily;
		}
		if (A_0 == 2)
		{
			return RecurrenceType.Weekly;
		}
		if (A_0 == 3)
		{
			return RecurrenceType.Monthly;
		}
		if (A_0 == 4)
		{
			return RecurrenceType.Yearly;
		}
		if (A_0 == 5)
		{
			return RecurrenceType.MonthNth;
		}
		if (A_0 == 6)
		{
			return RecurrenceType.YearNth;
		}
		return RecurrenceType.None;
	}

	internal static BusyStatus h(uint A_0)
	{
		if (A_0 == 0)
		{
			return BusyStatus.Free;
		}
		if (A_0 == 1)
		{
			return BusyStatus.Tentative;
		}
		if (A_0 == 2)
		{
			return BusyStatus.Busy;
		}
		if (A_0 == 3)
		{
			return BusyStatus.OutOfOffice;
		}
		return BusyStatus.None;
	}

	internal static TaskDelegationState i(uint A_0)
	{
		if (A_0 == 0)
		{
			return TaskDelegationState.Owned;
		}
		if (A_0 == 1)
		{
			return TaskDelegationState.OwnNew;
		}
		if (A_0 == 2)
		{
			return TaskDelegationState.Accepted;
		}
		if (A_0 == 3)
		{
			return TaskDelegationState.Declined;
		}
		if (A_0 == 4)
		{
			return TaskDelegationState.NoMatch;
		}
		return TaskDelegationState.None;
	}

	internal static TaskOwnership j(uint A_0)
	{
		if (A_0 == 0)
		{
			return TaskOwnership.New;
		}
		if (A_0 == 1)
		{
			return TaskOwnership.Delegated;
		}
		if (A_0 == 2)
		{
			return TaskOwnership.Own;
		}
		return TaskOwnership.None;
	}

	internal static Importance k(uint A_0)
	{
		if (A_0 == 1)
		{
			return Importance.Normal;
		}
		if (A_0 == 2)
		{
			return Importance.High;
		}
		if (A_0 == 0)
		{
			return Importance.Low;
		}
		return Importance.None;
	}

	internal static Sensitivity l(uint A_0)
	{
		if (A_0 == 1)
		{
			return Sensitivity.Personal;
		}
		if (A_0 == 2)
		{
			return Sensitivity.Private;
		}
		if (A_0 == 3)
		{
			return Sensitivity.Confidential;
		}
		return Sensitivity.None;
	}

	internal static Priority m(uint A_0)
	{
		if (A_0 == -1)
		{
			return Priority.Low;
		}
		if (A_0 == 1)
		{
			return Priority.High;
		}
		if (A_0 == 0)
		{
			return Priority.Normal;
		}
		return Priority.None;
	}

	internal static RecipientType n(uint A_0)
	{
		if (A_0 == 1)
		{
			return RecipientType.To;
		}
		if (A_0 == 2)
		{
			return RecipientType.Cc;
		}
		if (A_0 == 3)
		{
			return RecipientType.Bcc;
		}
		if (A_0 == 268435456)
		{
			return RecipientType.P1;
		}
		return RecipientType.None;
	}

	internal static NoteColor o(uint A_0)
	{
		if (A_0 == 0)
		{
			return NoteColor.Blue;
		}
		if (A_0 == 1)
		{
			return NoteColor.Green;
		}
		if (A_0 == 2)
		{
			return NoteColor.Pink;
		}
		if (A_0 == 3)
		{
			return NoteColor.Yellow;
		}
		if (A_0 == 4)
		{
			return NoteColor.White;
		}
		return NoteColor.None;
	}

	internal static DisplayType p(uint A_0)
	{
		if (A_0 == 0)
		{
			return DisplayType.MailUser;
		}
		if (A_0 == 1)
		{
			return DisplayType.DistributionList;
		}
		if (A_0 == 2)
		{
			return DisplayType.Forum;
		}
		if (A_0 == 3)
		{
			return DisplayType.Agent;
		}
		if (A_0 == 4)
		{
			return DisplayType.Organization;
		}
		if (A_0 == 5)
		{
			return DisplayType.PrivateDistributionList;
		}
		if (A_0 == 6)
		{
			return DisplayType.RemoteMailUser;
		}
		if (A_0 == 16777216)
		{
			return DisplayType.Folder;
		}
		if (A_0 == 33554432)
		{
			return DisplayType.FolderLink;
		}
		if (A_0 == 67108864)
		{
			return DisplayType.FolderSpecial;
		}
		if (A_0 == 65536)
		{
			return DisplayType.Modifiable;
		}
		if (A_0 == 131072)
		{
			return DisplayType.GlobalAddressBook;
		}
		if (A_0 == 196608)
		{
			return DisplayType.LocalAddressBook;
		}
		if (A_0 == 262144)
		{
			return DisplayType.WideAreaNetworkAddressBook;
		}
		if (A_0 == 327680)
		{
			return DisplayType.NotSpecific;
		}
		return DisplayType.None;
	}

	internal static FlagStatus q(uint A_0)
	{
		if (A_0 == 1)
		{
			return FlagStatus.Complete;
		}
		if (A_0 == 2)
		{
			return FlagStatus.Marked;
		}
		return FlagStatus.None;
	}

	internal static SelectedMailingAddress r(uint A_0)
	{
		if (A_0 == 1)
		{
			return SelectedMailingAddress.Home;
		}
		if (A_0 == 2)
		{
			return SelectedMailingAddress.Business;
		}
		if (A_0 == 3)
		{
			return SelectedMailingAddress.Other;
		}
		return SelectedMailingAddress.None;
	}

	internal static FlagIcon s(uint A_0)
	{
		if (A_0 == 1)
		{
			return FlagIcon.Purple;
		}
		if (A_0 == 2)
		{
			return FlagIcon.Orange;
		}
		if (A_0 == 3)
		{
			return FlagIcon.Green;
		}
		if (A_0 == 4)
		{
			return FlagIcon.Yellow;
		}
		if (A_0 == 5)
		{
			return FlagIcon.Blue;
		}
		if (A_0 == 6)
		{
			return FlagIcon.Red;
		}
		return FlagIcon.None;
	}

	internal static IList<MessageFlag> t(uint A_0)
	{
		IList<MessageFlag> messageFlags = new List<MessageFlag>();
		if ((A_0 & 64) == 64)
		{
			messageFlags.Add(MessageFlag.Associated);
		}
		if ((A_0 & 32) == 32)
		{
			messageFlags.Add(MessageFlag.FromMe);
		}
		if ((A_0 & 16) == 16)
		{
			messageFlags.Add(MessageFlag.HasAttachment);
		}
		if ((A_0 & 512) == 512)
		{
			messageFlags.Add(MessageFlag.NonReadReportPending);
		}
		if ((A_0 & 8192) == 8192)
		{
			messageFlags.Add(MessageFlag.OriginInternet);
		}
		if ((A_0 & 32768) == 32768)
		{
			messageFlags.Add(MessageFlag.OriginMiscExternal);
		}
		if ((A_0 & 4096) == 4096)
		{
			messageFlags.Add(MessageFlag.OriginX400);
		}
		if ((A_0 & 1) == 1)
		{
			messageFlags.Add(MessageFlag.Read);
		}
		if ((A_0 & 128) == 128)
		{
			messageFlags.Add(MessageFlag.Resend);
		}
		if ((A_0 & 256) == 256)
		{
			messageFlags.Add(MessageFlag.ReadReportPending);
		}
		if ((A_0 & 4) == 4)
		{
			messageFlags.Add(MessageFlag.Submit);
		}
		if ((A_0 & 2) == 2)
		{
			messageFlags.Add(MessageFlag.Unmodified);
		}
		if ((A_0 & 8) == 8)
		{
			messageFlags.Add(MessageFlag.Unsent);
		}
		return messageFlags;
	}

	internal static IList<StoreSupportMask> u(uint A_0)
	{
		IList<StoreSupportMask> storeSupportMasks = new List<StoreSupportMask>();
		if ((A_0 & 131072) == 131072)
		{
			storeSupportMasks.Add(StoreSupportMask.Ansi);
		}
		if ((A_0 & 32) == 32)
		{
			storeSupportMasks.Add(StoreSupportMask.Attachments);
		}
		if ((A_0 & 1024) == 1024)
		{
			storeSupportMasks.Add(StoreSupportMask.Categorize);
		}
		if ((A_0 & 16) == 16)
		{
			storeSupportMasks.Add(StoreSupportMask.Create);
		}
		if ((A_0 & 65536) == 65536)
		{
			storeSupportMasks.Add(StoreSupportMask.Html);
		}
		if ((A_0 & 2097152) == 2097152)
		{
			storeSupportMasks.Add(StoreSupportMask.ItemProc);
		}
		if ((A_0 & 524288) == 524288)
		{
			storeSupportMasks.Add(StoreSupportMask.LocalStore);
		}
		if ((A_0 & 8) == 8)
		{
			storeSupportMasks.Add(StoreSupportMask.Modify);
		}
		if ((A_0 & 512) == 512)
		{
			storeSupportMasks.Add(StoreSupportMask.MultiValueProperties);
		}
		if ((A_0 & 256) == 256)
		{
			storeSupportMasks.Add(StoreSupportMask.Notify);
		}
		if ((A_0 & 64) == 64)
		{
			storeSupportMasks.Add(StoreSupportMask.Ole);
		}
		if ((A_0 & 16384) == 16384)
		{
			storeSupportMasks.Add(StoreSupportMask.PublicFolders);
		}
		if ((A_0 & 8388608) == 8388608)
		{
			storeSupportMasks.Add(StoreSupportMask.Pusher);
		}
		if ((A_0 & 2) == 2)
		{
			storeSupportMasks.Add(StoreSupportMask.ReadOnly);
		}
		if ((A_0 & 4096) == 4096)
		{
			storeSupportMasks.Add(StoreSupportMask.Restrictions);
		}
		if ((A_0 & 2048) == 2048)
		{
			storeSupportMasks.Add(StoreSupportMask.Rtf);
		}
		if ((A_0 & 4) == 4)
		{
			storeSupportMasks.Add(StoreSupportMask.Search);
		}
		if ((A_0 & 8192) == 8192)
		{
			storeSupportMasks.Add(StoreSupportMask.Sort);
		}
		if ((A_0 & 128) == 128)
		{
			storeSupportMasks.Add(StoreSupportMask.Submit);
		}
		if ((A_0 & 32768) == 32768)
		{
			storeSupportMasks.Add(StoreSupportMask.UncompressedRtf);
		}
		if ((A_0 & 262144) == 262144)
		{
			storeSupportMasks.Add(StoreSupportMask.Unicode);
		}
		return storeSupportMasks;
	}

	internal static ObjectType v(uint A_0)
	{
		if (A_0 == 1)
		{
			return ObjectType.MessageStore;
		}
		if (A_0 == 2)
		{
			return ObjectType.AddressBook;
		}
		if (A_0 == 3)
		{
			return ObjectType.Folder;
		}
		if (A_0 == 4)
		{
			return ObjectType.AddressBookContainer;
		}
		if (A_0 == 5)
		{
			return ObjectType.Message;
		}
		if (A_0 == 6)
		{
			return ObjectType.MailUser;
		}
		if (A_0 == 7)
		{
			return ObjectType.Attachment;
		}
		if (A_0 == 8)
		{
			return ObjectType.DistributionList;
		}
		if (A_0 == 9)
		{
			return ObjectType.ProfileSelection;
		}
		if (A_0 == 10)
		{
			return ObjectType.Status;
		}
		if (A_0 == 11)
		{
			return ObjectType.Session;
		}
		if (A_0 == 12)
		{
			return ObjectType.Form;
		}
		return ObjectType.None;
	}

	internal static LastVerbExecuted w(uint A_0)
	{
		if (A_0 == 102)
		{
			return LastVerbExecuted.ReplyToSender;
		}
		if (A_0 == 103)
		{
			return LastVerbExecuted.ReplyToAll;
		}
		if (A_0 == 104)
		{
			return LastVerbExecuted.Forward;
		}
		return LastVerbExecuted.None;
	}
}