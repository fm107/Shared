using System;

internal enum g
{
	a,
	b
}