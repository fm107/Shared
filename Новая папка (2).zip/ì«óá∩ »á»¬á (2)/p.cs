using System;

internal class p
{
	internal static bool a(byte[] A_0, int A_1)
	{
		int num = 0;
		int num1 = 0;
		while (num < A_1)
		{
			if (!p.a(A_0, num, A_1, ref num1))
			{
				return false;
			}
			num = num + num1;
		}
		return true;
	}

	internal static bool a(byte[] A_0, int A_1, int A_2, ref int A_3)
	{
		if (A_2 > (int)A_0.Length)
		{
			throw new ArgumentException("Invalid length");
		}
		if (A_1 > A_2 - 1)
		{
			A_3 = 0;
			return true;
		}
		byte a0 = A_0[A_1];
		if (a0 <= 127)
		{
			A_3 = 1;
			return true;
		}
		if (a0 >= 194 && a0 <= 223)
		{
			if (A_1 >= A_2 - 2)
			{
				A_3 = 0;
				return false;
			}
			if (A_0[A_1 + 1] >= 128 && A_0[A_1 + 1] <= 191)
			{
				A_3 = 2;
				return true;
			}
			A_3 = 0;
			return false;
		}
		if (a0 == 224)
		{
			if (A_1 >= A_2 - 3)
			{
				A_3 = 0;
				return false;
			}
			if (A_0[A_1 + 1] >= 160 && A_0[A_1 + 1] <= 191 && A_0[A_1 + 2] >= 128 && A_0[A_1 + 2] <= 191)
			{
				A_3 = 3;
				return true;
			}
			A_3 = 0;
			return false;
		}
		if (a0 >= 225 && a0 <= 239)
		{
			if (A_1 >= A_2 - 3)
			{
				A_3 = 0;
				return false;
			}
			if (A_0[A_1 + 1] >= 128 && A_0[A_1 + 1] <= 191 && A_0[A_1 + 2] >= 128 && A_0[A_1 + 2] <= 191)
			{
				A_3 = 3;
				return true;
			}
			A_3 = 0;
			return false;
		}
		if (a0 == 240)
		{
			if (A_1 >= A_2 - 4)
			{
				A_3 = 0;
				return false;
			}
			if (A_0[A_1 + 1] >= 144 && A_0[A_1 + 1] <= 191 && A_0[A_1 + 2] >= 128 && A_0[A_1 + 2] <= 191 && A_0[A_1 + 3] >= 128 && A_0[A_1 + 3] <= 191)
			{
				A_3 = 4;
				return true;
			}
			A_3 = 0;
			return false;
		}
		if (a0 == 244)
		{
			if (A_1 >= A_2 - 4)
			{
				A_3 = 0;
				return false;
			}
			if (A_0[A_1 + 1] >= 128 && A_0[A_1 + 1] <= 143 && A_0[A_1 + 2] >= 128 && A_0[A_1 + 2] <= 191 && A_0[A_1 + 3] >= 128 && A_0[A_1 + 3] <= 191)
			{
				A_3 = 4;
				return true;
			}
			A_3 = 0;
			return false;
		}
		if (a0 < 241 || a0 > 243)
		{
			return false;
		}
		if (A_1 >= A_2 - 4)
		{
			A_3 = 0;
			return false;
		}
		if (A_0[A_1 + 1] >= 128 && A_0[A_1 + 1] <= 191 && A_0[A_1 + 2] >= 128 && A_0[A_1 + 2] <= 191 && A_0[A_1 + 3] >= 128 && A_0[A_1 + 3] <= 191)
		{
			A_3 = 4;
			return true;
		}
		A_3 = 0;
		return false;
	}
}