using System;

internal class c
{
	private uint a;

	private string b;

	private byte[] c;

	private g d = g.b;

	public c()
	{
	}

	public uint a()
	{
		return this.a;
	}

	public void a(uint A_0)
	{
		this.a = A_0;
	}

	public void a(string A_0)
	{
		this.b = A_0;
	}

	public void a(byte[] A_0)
	{
		this.c = A_0;
	}

	public void a(g A_0)
	{
		this.d = A_0;
	}

	public byte[] b()
	{
		return this.c;
	}

	public g c()
	{
		return this.d;
	}

	public string d()
	{
		return this.b;
	}
}