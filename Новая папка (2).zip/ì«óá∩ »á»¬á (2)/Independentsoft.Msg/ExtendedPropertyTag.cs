using System;

namespace Independentsoft.Msg
{
	/// <summary>
	/// Class ExtendedPropertyTag.
	/// </summary>
	public abstract class ExtendedPropertyTag
	{
		internal byte[] a;

		internal PropertyType b = PropertyType.String;

		/// <summary>
		/// Gets or sets the unique identifier.
		/// </summary>
		/// <value>The unique identifier.</value>
		public byte[] Guid
		{
			get
			{
				return this.a;
			}
			set
			{
				this.a = value;
			}
		}

		/// <summary>
		/// Gets or sets the type.
		/// </summary>
		/// <value>The type.</value>
		public PropertyType Type
		{
			get
			{
				return this.b;
			}
			set
			{
				this.b = value;
			}
		}

		protected ExtendedPropertyTag()
		{
		}
	}
}