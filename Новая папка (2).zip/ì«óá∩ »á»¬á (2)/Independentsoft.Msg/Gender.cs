using System;

namespace Independentsoft.Msg
{
	/// <summary>
	/// Enum Gender
	/// </summary>
	public enum Gender
	{
		Female,
		Male,
		None
	}
}