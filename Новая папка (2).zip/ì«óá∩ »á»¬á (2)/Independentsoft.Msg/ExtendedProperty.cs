using System;
using System.IO;
using System.Text;

namespace Independentsoft.Msg
{
	/// <summary>
	/// Class ExtendedProperty.
	/// </summary>
	public class ExtendedProperty
	{
		private ExtendedPropertyTag a;

		private byte[] b;

		/// <summary>
		/// Gets or sets the tag.
		/// </summary>
		/// <value>The tag.</value>
		public ExtendedPropertyTag Tag
		{
			get
			{
				return this.a;
			}
			set
			{
				this.a = value;
			}
		}

		/// <summary>
		/// Gets or sets the value.
		/// </summary>
		/// <value>The value.</value>
		public byte[] Value
		{
			get
			{
				return this.b;
			}
			set
			{
				this.b = value;
			}
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Msg.ExtendedProperty" /> class.
		/// </summary>
		public ExtendedProperty()
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Msg.ExtendedProperty" /> class.
		/// </summary>
		/// <param name="tag">The tag.</param>
		public ExtendedProperty(ExtendedPropertyTag tag)
		{
			this.a = tag;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Msg.ExtendedProperty" /> class.
		/// </summary>
		/// <param name="tag">The tag.</param>
		/// <param name="value">The value.</param>
		/// <exception cref="T:System.ArgumentNullException">
		/// tag
		/// or
		/// value
		/// </exception>
		public ExtendedProperty(ExtendedPropertyTag tag, string value)
		{
			if (tag == null)
			{
				throw new ArgumentNullException("tag");
			}
			if (value == null)
			{
				throw new ArgumentNullException("value");
			}
			this.a = tag;
			if (tag.Type == PropertyType.String)
			{
				this.b = Encoding.Unicode.GetBytes(value);
				return;
			}
			this.b = Encoding.UTF8.GetBytes(value);
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Msg.ExtendedProperty" /> class.
		/// </summary>
		/// <param name="tag">The tag.</param>
		/// <param name="value">The value.</param>
		public ExtendedProperty(ExtendedPropertyTag tag, short value)
		{
			this.a = tag;
			this.b = BitConverter.GetBytes(value);
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Msg.ExtendedProperty" /> class.
		/// </summary>
		/// <param name="tag">The tag.</param>
		/// <param name="value">The value.</param>
		public ExtendedProperty(ExtendedPropertyTag tag, int value)
		{
			this.a = tag;
			this.b = BitConverter.GetBytes(value);
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Msg.ExtendedProperty" /> class.
		/// </summary>
		/// <param name="tag">The tag.</param>
		/// <param name="value">The value.</param>
		public ExtendedProperty(ExtendedPropertyTag tag, long value)
		{
			this.a = tag;
			this.b = BitConverter.GetBytes(value);
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Msg.ExtendedProperty" /> class.
		/// </summary>
		/// <param name="tag">The tag.</param>
		/// <param name="value">The value.</param>
		public ExtendedProperty(ExtendedPropertyTag tag, double value)
		{
			this.a = tag;
			this.b = BitConverter.GetBytes(value);
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Msg.ExtendedProperty" /> class.
		/// </summary>
		/// <param name="tag">The tag.</param>
		/// <param name="value">if set to <c>true</c> [value].</param>
		public ExtendedProperty(ExtendedPropertyTag tag, bool value)
		{
			this.a = tag;
			this.b = BitConverter.GetBytes(value);
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Msg.ExtendedProperty" /> class.
		/// </summary>
		/// <param name="tag">The tag.</param>
		/// <param name="value">The value.</param>
		public ExtendedProperty(ExtendedPropertyTag tag, DateTime value)
		{
			this.a = tag;
			DateTime dateTime = new DateTime(1601, 1, 1);
			TimeSpan timeSpan = value.ToUniversalTime().Subtract(dateTime);
			this.b = BitConverter.GetBytes(timeSpan.Ticks);
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Msg.ExtendedProperty" /> class.
		/// </summary>
		/// <param name="tag">The tag.</param>
		/// <param name="value">The value.</param>
		/// <exception cref="T:System.ArgumentNullException">
		/// tag
		/// or
		/// value
		/// </exception>
		public ExtendedProperty(ExtendedPropertyTag tag, string[] value)
		{
			if (tag == null)
			{
				throw new ArgumentNullException("tag");
			}
			if (value == null)
			{
				throw new ArgumentNullException("value");
			}
			this.a = tag;
			if (value != null && (int)value.Length > 0)
			{
				MemoryStream memoryStream = new MemoryStream();
				using (memoryStream)
				{
					uint length = (uint)value.Length;
					byte[] bytes = BitConverter.GetBytes(length);
					memoryStream.Write(bytes, 0, (int)bytes.Length);
					for (int i = 0; (long)i < (ulong)length; i++)
					{
						if (tag.Type != PropertyType.String)
						{
							byte[] numArray = Encoding.UTF8.GetBytes(value[i]);
							byte[] bytes1 = BitConverter.GetBytes((int)numArray.Length);
							memoryStream.Write(bytes1, 0, (int)bytes1.Length);
							memoryStream.Write(numArray, 0, (int)numArray.Length);
						}
						else
						{
							byte[] numArray1 = Encoding.Unicode.GetBytes(value[i]);
							byte[] bytes2 = BitConverter.GetBytes((int)numArray1.Length);
							memoryStream.Write(bytes2, 0, (int)bytes2.Length);
							memoryStream.Write(numArray1, 0, (int)numArray1.Length);
						}
					}
					this.b = memoryStream.ToArray();
				}
			}
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Msg.ExtendedProperty" /> class.
		/// </summary>
		/// <param name="tag">The tag.</param>
		/// <param name="value">The value.</param>
		public ExtendedProperty(ExtendedPropertyTag tag, byte[] value)
		{
			this.a = tag;
			this.b = value;
		}

		/// <summary>
		/// Gets the boolean value.
		/// </summary>
		/// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
		public bool GetBooleanValue()
		{
			if (this.b == null)
			{
				return false;
			}
			if (this.a.Type != PropertyType.Boolean || (int)this.b.Length != 2)
			{
				return false;
			}
			return BitConverter.ToBoolean(this.b, 0);
		}

		/// <summary>
		/// Gets the date time value.
		/// </summary>
		/// <returns>DateTime.</returns>
		public DateTime GetDateTimeValue()
		{
			DateTime localTime;
			if (this.b == null)
			{
				return DateTime.MinValue;
			}
			if (this.a.Type != PropertyType.Time && this.a.Type != PropertyType.FloatingTime || (int)this.b.Length != 8)
			{
				return DateTime.MinValue;
			}
			uint num = BitConverter.ToUInt32(this.b, 0);
			ulong num1 = (ulong)BitConverter.ToUInt32(this.b, 4);
			if (num1 > (long)0)
			{
				long num2 = (long)((ulong)num + (num1 << 32));
				DateTime dateTime = new DateTime(1601, 1, 1);
				try
				{
					localTime = dateTime.AddTicks(num2).ToLocalTime();
				}
				catch (Exception exception)
				{
					return DateTime.MinValue;
				}
				return localTime;
			}
			return DateTime.MinValue;
		}

		/// <summary>
		/// Gets the double value.
		/// </summary>
		/// <returns>System.Double.</returns>
		public double GetDoubleValue()
		{
			if (this.b == null)
			{
				return double.MinValue;
			}
			if (this.a.Type != PropertyType.Floating64 || (int)this.b.Length != 8)
			{
				return double.MinValue;
			}
			return BitConverter.ToDouble(this.b, 0);
		}

		/// <summary>
		/// Gets the float value.
		/// </summary>
		/// <returns>System.Single.</returns>
		public float GetFloatValue()
		{
			if (this.b == null)
			{
				return float.MinValue;
			}
			if (this.a.Type != PropertyType.Floating32 || (int)this.b.Length != 4)
			{
				return float.MinValue;
			}
			return BitConverter.ToSingle(this.b, 0);
		}

		/// <summary>
		/// Gets the integer value.
		/// </summary>
		/// <returns>System.Int32.</returns>
		public int GetIntegerValue()
		{
			if (this.b == null)
			{
				return -2147483648;
			}
			if (this.a.Type != PropertyType.Integer32 || (int)this.b.Length != 4)
			{
				return -2147483648;
			}
			return BitConverter.ToInt32(this.b, 0);
		}

		/// <summary>
		/// Gets the long value.
		/// </summary>
		/// <returns>System.Int64.</returns>
		public long GetLongValue()
		{
			if (this.b == null)
			{
				return -9223372036854775808L;
			}
			if (this.a.Type != PropertyType.Integer64 || (int)this.b.Length != 8)
			{
				return -9223372036854775808L;
			}
			return BitConverter.ToInt64(this.b, 0);
		}

		/// <summary>
		/// Gets the short value.
		/// </summary>
		/// <returns>System.Int16.</returns>
		public short GetShortValue()
		{
			if (this.b == null)
			{
				return -32768;
			}
			if (this.a.Type != PropertyType.Integer16 || (int)this.b.Length != 2)
			{
				return -32768;
			}
			return BitConverter.ToInt16(this.b, 0);
		}

		/// <summary>
		/// Gets the string array value.
		/// </summary>
		/// <returns>System.String[][].</returns>
		public string[] GetStringArrayValue()
		{
			if (this.b == null)
			{
				return null;
			}
			if (this.a.Type == PropertyType.MultipleString)
			{
				return m.a(this.b, Encoding.Unicode);
			}
			if (this.a.Type != PropertyType.MultipleString8)
			{
				return new string[0];
			}
			return m.a(this.b, Encoding.UTF8);
		}

		/// <summary>
		/// Gets the string value.
		/// </summary>
		/// <returns>System.String.</returns>
		public string GetStringValue()
		{
			if (this.b == null)
			{
				return null;
			}
			if (this.a.Type == PropertyType.String)
			{
				return Encoding.Unicode.GetString(this.b, 0, (int)this.b.Length);
			}
			if (this.a.Type != PropertyType.String8)
			{
				return null;
			}
			return Encoding.UTF8.GetString(this.b, 0, (int)this.b.Length);
		}
	}
}