using System;

namespace Independentsoft.Msg
{
	/// <summary>
	/// Class ExtendedPropertyName.
	/// </summary>
	public class ExtendedPropertyName : ExtendedPropertyTag
	{
		private string a;

		/// <summary>
		/// Gets or sets the name.
		/// </summary>
		/// <value>The name.</value>
		public string Name
		{
			get
			{
				return this.a;
			}
			set
			{
				this.a = value;
			}
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Msg.ExtendedPropertyName" /> class.
		/// </summary>
		public ExtendedPropertyName()
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Msg.ExtendedPropertyName" /> class.
		/// </summary>
		/// <param name="name">The name.</param>
		/// <param name="guid">The unique identifier.</param>
		public ExtendedPropertyName(string name, byte[] guid)
		{
			this.a = name;
			this.a = guid;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Msg.ExtendedPropertyName" /> class.
		/// </summary>
		/// <param name="name">The name.</param>
		/// <param name="guid">The unique identifier.</param>
		/// <param name="type">The type.</param>
		public ExtendedPropertyName(string name, byte[] guid, PropertyType type)
		{
			this.a = name;
			this.a = guid;
			this.b = type;
		}

		/// <summary>
		/// Returns a <see cref="T:System.String" /> that represents this instance.
		/// </summary>
		/// <returns>A <see cref="T:System.String" /> that represents this instance.</returns>
		public override string ToString()
		{
			return this.a;
		}
	}
}