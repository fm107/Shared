using System;

namespace Independentsoft.Msg
{
	public enum RecurrenceEndType
	{
		EndAfterDate,
		EndAfterNOccurrences,
		NeverEnd
	}
}