using System;

namespace Independentsoft.Msg
{
	/// <summary>
	/// Class ExtendedPropertyId.
	/// </summary>
	public class ExtendedPropertyId : ExtendedPropertyTag
	{
		private int a;

		/// <summary>
		/// Gets or sets the identifier.
		/// </summary>
		/// <value>The identifier.</value>
		public int Id
		{
			get
			{
				return this.a;
			}
			set
			{
				this.a = value;
			}
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Msg.ExtendedPropertyId" /> class.
		/// </summary>
		public ExtendedPropertyId()
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Msg.ExtendedPropertyId" /> class.
		/// </summary>
		/// <param name="id">The identifier.</param>
		/// <param name="guid">The unique identifier.</param>
		public ExtendedPropertyId(int id, byte[] guid)
		{
			this.a = id;
			this.a = guid;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Msg.ExtendedPropertyId" /> class.
		/// </summary>
		/// <param name="id">The identifier.</param>
		/// <param name="guid">The unique identifier.</param>
		/// <param name="type">The type.</param>
		public ExtendedPropertyId(int id, byte[] guid, PropertyType type)
		{
			this.a = id;
			this.a = guid;
			this.b = type;
		}

		/// <summary>
		/// Returns a <see cref="T:System.String" /> that represents this instance.
		/// </summary>
		/// <returns>A <see cref="T:System.String" /> that represents this instance.</returns>
		public override string ToString()
		{
			return this.a.ToString();
		}
	}
}