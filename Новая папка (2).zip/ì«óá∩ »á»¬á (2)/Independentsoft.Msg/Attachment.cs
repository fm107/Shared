using Independentsoft.IO.StructuredStorage;
using System;
using System.IO;

namespace Independentsoft.Msg
{
	/// <summary>
	/// Represents an attachment to a message.
	/// </summary>
	public class Attachment
	{
		private byte[] a;

		private string b;

		private string c;

		private string d;

		private string e;

		private byte[] f;

		private byte[] g;

		private byte[] h;

		private byte[] i;

		private string j;

		private string k;

		private AttachmentFlags l = AttachmentFlags.None;

		private string m;

		private string n;

		private AttachmentMethod o = AttachmentMethod.AttachByValue;

		private uint p;

		private string q;

		private string r;

		private byte[] s;

		private uint t;

		private uint u;

		private byte[] v;

		private string w;

		private string x;

		private Message y;

		private Independentsoft.Msg.ObjectType z = Independentsoft.Msg.ObjectType.None;

		private bool aa;

		private bool ab;

		private DateTime ac;

		private DateTime ad;

		private Storage ae;

		private Independentsoft.IO.StructuredStorage.Stream af;

		/// <summary>
		/// Provides file type information for a non-Windows attachment.
		/// </summary>
		/// <value>The additional information.</value>
		public byte[] AdditionalInfo
		{
			get
			{
				return this.a;
			}
			set
			{
				this.a = value;
			}
		}

		/// <summary>
		/// Contains the content base header of a MIME message attachment.
		/// </summary>
		/// <value>The content base.</value>
		public string ContentBase
		{
			get
			{
				return this.b;
			}
			set
			{
				this.b = value;
			}
		}

		/// <summary>
		/// Contains the content disposition header of a MIME message attachment.
		/// </summary>
		/// <value>The content disposition.</value>
		public string ContentDisposition
		{
			get
			{
				return this.e;
			}
			set
			{
				this.e = value;
			}
		}

		/// <summary>
		/// Contains the content identification header of a MIME message attachment.
		/// </summary>
		/// <value>The content identifier.</value>
		public string ContentId
		{
			get
			{
				return this.c;
			}
			set
			{
				this.c = value;
			}
		}

		/// <summary>
		/// Contains the content location header of a MIME message attachment.
		/// </summary>
		/// <value>The content location.</value>
		public string ContentLocation
		{
			get
			{
				return this.d;
			}
			set
			{
				this.d = value;
			}
		}

		/// <summary>
		/// Contains the creation date and time of the attachment.
		/// </summary>
		/// <value>The creation time.</value>
		public DateTime CreationTime
		{
			get
			{
				return this.ac;
			}
			set
			{
				this.ac = value;
			}
		}

		/// <summary>
		/// Contains binary attachment data.
		/// </summary>
		/// <value>The data.</value>
		public byte[] Data
		{
			get
			{
				return this.f;
			}
			set
			{
				this.f = value;
			}
		}

		/// <summary>
		/// Contains attachment's data as embedded object.
		/// </summary>
		/// <value>The data object.</value>
		public byte[] DataObject
		{
			get
			{
				return this.g;
			}
			set
			{
				this.g = value;
			}
		}

		/// <summary>
		/// Gets or sets the data object storage.
		/// </summary>
		/// <value>The data object storage.</value>
		public Storage DataObjectStorage
		{
			get
			{
				return this.ae;
			}
			set
			{
				this.ae = value;
			}
		}

		/// <summary>
		/// Contains the display name of the attachment.
		/// </summary>
		/// <value>The display name.</value>
		public string DisplayName
		{
			get
			{
				return this.x;
			}
			set
			{
				this.x = value;
			}
		}

		/// <summary>
		/// Contains <see cref="T:Independentsoft.Msg.Message" /> object if the attachment is an embedded Message.
		/// </summary>
		/// <value>The embedded message.</value>
		public Message EmbeddedMessage
		{
			get
			{
				return this.y;
			}
			set
			{
				if (value != null)
				{
					this.y = value;
					this.y.IsEmbedded = true;
				}
			}
		}

		/// <summary>
		/// Contains the encoding for an attachment.
		/// </summary>
		/// <value>The encoding.</value>
		public byte[] Encoding
		{
			get
			{
				return this.h;
			}
			set
			{
				this.h = value;
			}
		}

		/// <summary>
		/// Contains a file name extension that indicates the document type of an attachment.
		/// </summary>
		/// <value>The extension.</value>
		public string Extension
		{
			get
			{
				return this.j;
			}
			set
			{
				this.j = value;
			}
		}

		/// <summary>
		/// Contains an attachment's base file name and extension, excluding path.
		/// </summary>
		/// <value>The name of the file.</value>
		public string FileName
		{
			get
			{
				return this.k;
			}
			set
			{
				this.k = value;
			}
		}

		/// <summary>
		/// Contains flags for an attachment.
		/// </summary>
		/// <value>The flags.</value>
		public AttachmentFlags Flags
		{
			get
			{
				return this.l;
			}
			set
			{
				this.l = value;
			}
		}

		/// <summary>
		/// Indicates whether this attachment is a contact photo.
		/// </summary>
		/// <value><c>true</c> if this instance is contact photo; otherwise, <c>false</c>.</value>
		public bool IsContactPhoto
		{
			get
			{
				return this.ab;
			}
			set
			{
				this.ab = value;
			}
		}

		/// <summary>
		/// Indicates whether an attachment is hidden from the end user.
		/// </summary>
		/// <value><c>true</c> if this instance is hidden; otherwise, <c>false</c>.</value>
		public bool IsHidden
		{
			get
			{
				return this.aa;
			}
			set
			{
				this.aa = value;
			}
		}

		/// <summary>
		/// Contains the date and time when the attachment was last modified.
		/// </summary>
		/// <value>The last modification time.</value>
		public DateTime LastModificationTime
		{
			get
			{
				return this.ad;
			}
			set
			{
				this.ad = value;
			}
		}

		/// <summary>
		/// Contains an attachment's long filename and extension, excluding path.
		/// </summary>
		/// <value>The long name of the file.</value>
		public string LongFileName
		{
			get
			{
				return this.m;
			}
			set
			{
				this.m = value;
			}
		}

		/// <summary>
		/// Contains an attachment's fully-qualified long path and filename.
		/// </summary>
		/// <value>The long name of the path.</value>
		public string LongPathName
		{
			get
			{
				return this.n;
			}
			set
			{
				this.n = value;
			}
		}

		/// <summary>
		/// Contains a MAPI-defined constant representing the way the contents of an attachment can be accessed.
		/// </summary>
		/// <value>The method.</value>
		public AttachmentMethod Method
		{
			get
			{
				return this.o;
			}
			set
			{
				this.o = value;
			}
		}

		/// <summary>
		/// Contains the MIME sequence number of a MIME message attachment.
		/// </summary>
		/// <value>The MIME sequence.</value>
		public long MimeSequence
		{
			get
			{
				return (long)this.p;
			}
			set
			{
				this.p = (uint)value;
			}
		}

		/// <summary>
		/// Contains formatting information about a MIME attachment.
		/// </summary>
		/// <value>The MIME tag.</value>
		public string MimeTag
		{
			get
			{
				return this.q;
			}
			set
			{
				this.q = value;
			}
		}

		/// <summary>
		/// Contains the type of the attachment.
		/// </summary>
		/// <value>The type of the object.</value>
		public Independentsoft.Msg.ObjectType ObjectType
		{
			get
			{
				return this.z;
			}
			set
			{
				this.z = value;
			}
		}

		/// <summary>
		/// Contains an attachment's fully-qualified path and filename.
		/// </summary>
		/// <value>The name of the path.</value>
		public string PathName
		{
			get
			{
				return this.r;
			}
			set
			{
				this.r = value;
			}
		}

		internal Independentsoft.IO.StructuredStorage.Stream PropertiesStream
		{
			get
			{
				return this.af;
			}
			set
			{
				this.af = value;
			}
		}

		/// <summary>
		/// Contains the record key for an attachment.
		/// </summary>
		/// <value>The record key.</value>
		public byte[] RecordKey
		{
			get
			{
				return this.i;
			}
			set
			{
				this.i = value;
			}
		}

		/// <summary>
		/// Contains a Microsoft Windows metafile with rendering information for an attachment.
		/// </summary>
		/// <value>The rendering.</value>
		public byte[] Rendering
		{
			get
			{
				return this.s;
			}
			set
			{
				this.s = value;
			}
		}

		/// <summary>
		/// Contains rendering position index.
		/// </summary>
		/// <value>The rendering position.</value>
		public long RenderingPosition
		{
			get
			{
				return (long)this.t;
			}
			set
			{
				this.t = (uint)value;
			}
		}

		/// <summary>
		/// Contains attachment's size in bytes.
		/// </summary>
		/// <value>The size.</value>
		public long Size
		{
			get
			{
				return (long)this.u;
			}
			set
			{
				this.u = (uint)value;
			}
		}

		/// <summary>
		/// Contains an object identifier specifying the application that supplied an attachment.
		/// </summary>
		/// <value>The tag.</value>
		public byte[] Tag
		{
			get
			{
				return this.v;
			}
			set
			{
				this.v = value;
			}
		}

		/// <summary>
		/// Contains the name of an attachment file modified so that it can be associated with TNEF messages.
		/// </summary>
		/// <value>The name of the transport.</value>
		public string TransportName
		{
			get
			{
				return this.w;
			}
			set
			{
				this.w = value;
			}
		}

		/// <summary>
		/// Initializes a new instance of the Attachment class.
		/// </summary>
		public Attachment()
		{
		}

		/// <summary>
		/// Initializes a new instance of the Attachment class based on the supplied file.
		/// </summary>
		/// <param name="filePath">File path.</param>
		public Attachment(string filePath)
		{
			this.a(filePath);
		}

		/// <summary>
		/// Initializes a new instance of the Attachment class based on the supplied stream.
		/// </summary>
		/// <param name="fileName">Attachment file name.</param>
		/// <param name="stream">A stream.</param>
		public Attachment(string fileName, System.IO.Stream stream)
		{
			this.a(fileName, stream);
		}

		/// <summary>
		/// Initializes a new instance of the Attachment class based on the supplied byte array.
		/// </summary>
		/// <param name="fileName">Attachment file name.</param>
		/// <param name="buffer">A byte array.</param>
		public Attachment(string fileName, byte[] buffer)
		{
			this.a(fileName, buffer);
		}

		private void a(string A_0)
		{
			FileInfo fileInfo = new FileInfo(A_0);
			FileStream fileStream = new FileStream(A_0, FileMode.Open, FileAccess.Read);
			using (fileStream)
			{
				this.a(fileInfo.Name, fileStream);
			}
		}

		private void a(string A_0, System.IO.Stream A_1)
		{
			this.k = A_0;
			MemoryStream memoryStream = new MemoryStream();
			byte[] numArray = new byte[8192];
			int num = 0;
			using (memoryStream)
			{
				while (true)
				{
					int num1 = A_1.Read(numArray, 0, (int)numArray.Length);
					num = num1;
					if (num1 <= 0)
					{
						break;
					}
					memoryStream.Write(numArray, 0, num);
				}
				this.f = memoryStream.ToArray();
			}
		}

		private void a(string A_0, byte[] A_1)
		{
			this.k = A_0;
			this.f = A_1;
		}

		/// <summary>
		/// Gets bytes to read from this attachment.
		/// </summary>
		/// <returns>Attachment as a byte array.</returns>
		public byte[] GetBuffer()
		{
			if (this.f != null)
			{
				return this.f;
			}
			if (this.g == null)
			{
				return null;
			}
			return this.g;
		}

		/// <summary>
		/// Gets bytes to read from this attachment.
		/// </summary>
		/// <returns>Attachment as a byte array.</returns>
		public byte[] GetBytes()
		{
			if (this.f != null)
			{
				return this.f;
			}
			if (this.g == null)
			{
				return null;
			}
			return this.g;
		}

		/// <summary>
		/// Gets stream to read from this attachment.
		/// </summary>
		/// <returns>A stream.</returns>
		public System.IO.Stream GetStream()
		{
			if (this.f != null)
			{
				return new MemoryStream(this.f);
			}
			if (this.g == null)
			{
				return null;
			}
			return new MemoryStream(this.g);
		}

		/// <summary>
		/// Saves this attachment to the specified file.
		/// </summary>
		/// <param name="filePath">File path.</param>
		public void Save(string filePath)
		{
			this.Save(filePath, false);
		}

		/// <summary>
		/// Saves this attachment to the specified file.
		/// </summary>
		/// <param name="filePath">File path.</param>
		/// <param name="overwrite">True to overwrite existing file, otherwise false.</param>
		public void Save(string filePath, bool overwrite)
		{
			if (this.f != null && (int)this.f.Length > 0)
			{
				FileMode fileMode = FileMode.CreateNew;
				if (overwrite)
				{
					fileMode = FileMode.Create;
				}
				FileStream fileStream = new FileStream(filePath, fileMode, FileAccess.Write);
				using (fileStream)
				{
					if (this.f != null && (int)this.f.Length > 0)
					{
						fileStream.Write(this.f, 0, (int)this.f.Length);
					}
					else if (this.g != null && (int)this.g.Length > 0)
					{
						fileStream.Write(this.g, 0, (int)this.g.Length);
					}
				}
			}
		}

		/// <summary>
		/// Saves this attachment to the specified stream.
		/// </summary>
		/// <param name="stream">A stream.</param>
		/// <exception cref="T:System.ArgumentNullException">stream</exception>
		public void Save(System.IO.Stream stream)
		{
			if (stream == null)
			{
				throw new ArgumentNullException("stream");
			}
			if (this.f != null && (int)this.f.Length > 0)
			{
				stream.Write(this.f, 0, (int)this.f.Length);
				return;
			}
			if (this.g != null && (int)this.g.Length > 0)
			{
				stream.Write(this.g, 0, (int)this.g.Length);
			}
		}
	}
}