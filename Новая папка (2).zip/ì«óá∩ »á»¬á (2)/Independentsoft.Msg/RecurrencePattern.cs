using System;
using System.Collections.Generic;

namespace Independentsoft.Msg
{
	/// <summary>
	/// Class RecurrencePattern.
	/// </summary>
	public class RecurrencePattern
	{
		private RecurrencePatternFrequency a;

		private RecurrencePatternType b;

		private Independentsoft.Msg.CalendarType c = Independentsoft.Msg.CalendarType.None;

		private int d;

		private IList<Independentsoft.Msg.DayOfWeek> e = new List<Independentsoft.Msg.DayOfWeek>();

		private Independentsoft.Msg.DayOfWeekIndex f = Independentsoft.Msg.DayOfWeekIndex.None;

		private int g;

		private RecurrenceEndType h = RecurrenceEndType.NeverEnd;

		private int i;

		private Independentsoft.Msg.DayOfWeek j;

		private int k;

		private IList<DateTime> l = new List<DateTime>();

		private int m;

		private IList<DateTime> n = new List<DateTime>();

		private DateTime o;

		private DateTime p;

		/// <summary>
		/// Gets the type of the calendar.
		/// </summary>
		/// <value>The type of the calendar.</value>
		public Independentsoft.Msg.CalendarType CalendarType
		{
			get
			{
				return this.c;
			}
		}

		/// <summary>
		/// Gets the day of month.
		/// </summary>
		/// <value>The day of month.</value>
		public int DayOfMonth
		{
			get
			{
				return this.g;
			}
		}

		/// <summary>
		/// Gets the day of week.
		/// </summary>
		/// <value>The day of week.</value>
		public IList<Independentsoft.Msg.DayOfWeek> DayOfWeek
		{
			get
			{
				return this.e;
			}
		}

		/// <summary>
		/// Gets the index of the day of week.
		/// </summary>
		/// <value>The index of the day of week.</value>
		public Independentsoft.Msg.DayOfWeekIndex DayOfWeekIndex
		{
			get
			{
				return this.f;
			}
		}

		/// <summary>
		/// Gets the deleted instance count.
		/// </summary>
		/// <value>The deleted instance count.</value>
		public int DeletedInstanceCount
		{
			get
			{
				return this.k;
			}
		}

		/// <summary>
		/// Gets the deleted instance dates.
		/// </summary>
		/// <value>The deleted instance dates.</value>
		public IList<DateTime> DeletedInstanceDates
		{
			get
			{
				return this.l;
			}
		}

		/// <summary>
		/// Gets the end date.
		/// </summary>
		/// <value>The end date.</value>
		public DateTime EndDate
		{
			get
			{
				return this.p;
			}
		}

		/// <summary>
		/// Gets the end type.
		/// </summary>
		/// <value>The end type.</value>
		public RecurrenceEndType EndType
		{
			get
			{
				return this.h;
			}
		}

		/// <summary>
		/// Gets the first day of week.
		/// </summary>
		/// <value>The first day of week.</value>
		public Independentsoft.Msg.DayOfWeek FirstDayOfWeek
		{
			get
			{
				return this.j;
			}
		}

		/// <summary>
		/// Gets the frequency.
		/// </summary>
		/// <value>The frequency.</value>
		public RecurrencePatternFrequency Frequency
		{
			get
			{
				return this.a;
			}
		}

		/// <summary>
		/// Gets the modified instance count.
		/// </summary>
		/// <value>The modified instance count.</value>
		public int ModifiedInstanceCount
		{
			get
			{
				return this.m;
			}
		}

		/// <summary>
		/// Gets the modified instance dates.
		/// </summary>
		/// <value>The modified instance dates.</value>
		public IList<DateTime> ModifiedInstanceDates
		{
			get
			{
				return this.n;
			}
		}

		/// <summary>
		/// Gets the occurence count.
		/// </summary>
		/// <value>The occurence count.</value>
		public int OccurenceCount
		{
			get
			{
				return this.i;
			}
		}

		/// <summary>
		/// Gets the period.
		/// </summary>
		/// <value>The period.</value>
		public int Period
		{
			get
			{
				return this.d;
			}
		}

		/// <summary>
		/// Gets the start date.
		/// </summary>
		/// <value>The start date.</value>
		public DateTime StartDate
		{
			get
			{
				return this.o;
			}
		}

		/// <summary>
		/// Gets the type.
		/// </summary>
		/// <value>The type.</value>
		public RecurrencePatternType Type
		{
			get
			{
				return this.b;
			}
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Msg.RecurrencePattern" /> class.
		/// </summary>
		public RecurrencePattern()
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Msg.RecurrencePattern" /> class.
		/// </summary>
		/// <param name="buffer">The buffer.</param>
		public RecurrencePattern(byte[] buffer)
		{
			this.a(buffer);
		}

		private void a(byte[] A_0)
		{
			if ((int)A_0.Length < 22)
			{
				return;
			}
			short num = BitConverter.ToInt16(A_0, 4);
			this.a = h.c(num);
			short num1 = BitConverter.ToInt16(A_0, 6);
			this.b = h.b(num1);
			short num2 = BitConverter.ToInt16(A_0, 8);
			this.c = h.a(num2);
			BitConverter.ToInt16(A_0, 10);
			this.d = BitConverter.ToInt16(A_0, 14);
			int num3 = 22;
			if (this.b != RecurrencePatternType.Day)
			{
				if (this.b == RecurrencePatternType.Week)
				{
					int num4 = BitConverter.ToInt32(A_0, num3);
					num3 = num3 + 4;
					IList<Independentsoft.Msg.DayOfWeek> dayOfWeeks = new List<Independentsoft.Msg.DayOfWeek>();
					if ((num4 & 1) == 1)
					{
						dayOfWeeks.Add(Independentsoft.Msg.DayOfWeek.Sunday);
					}
					if ((num4 & 2) == 2)
					{
						dayOfWeeks.Add(Independentsoft.Msg.DayOfWeek.Monday);
					}
					if ((num4 & 4) == 4)
					{
						dayOfWeeks.Add(Independentsoft.Msg.DayOfWeek.Tuesday);
					}
					if ((num4 & 8) == 8)
					{
						dayOfWeeks.Add(Independentsoft.Msg.DayOfWeek.Wednesday);
					}
					if ((num4 & 16) == 16)
					{
						dayOfWeeks.Add(Independentsoft.Msg.DayOfWeek.Thursday);
					}
					if ((num4 & 32) == 32)
					{
						dayOfWeeks.Add(Independentsoft.Msg.DayOfWeek.Friday);
					}
					if ((num4 & 64) == 64)
					{
						dayOfWeeks.Add(Independentsoft.Msg.DayOfWeek.Saturday);
					}
					this.e = new Independentsoft.Msg.DayOfWeek[dayOfWeeks.Count];
					for (int i = 0; i < dayOfWeeks.Count; i++)
					{
						this.e[i] = dayOfWeeks[i];
					}
				}
				else if (this.b == RecurrencePatternType.Month || this.b == RecurrencePatternType.HijriMonth)
				{
					this.g = BitConverter.ToInt32(A_0, num3);
					num3 = num3 + 4;
				}
				else if (this.b == RecurrencePatternType.MonthEnd || this.b == RecurrencePatternType.HijriMonthEnd || this.b == RecurrencePatternType.MonthNth || this.b == RecurrencePatternType.HijriMonthNth)
				{
					if ((int)A_0.Length < 50)
					{
						return;
					}
					int num5 = BitConverter.ToInt32(A_0, num3);
					num3 = num3 + 4;
					int num6 = BitConverter.ToInt32(A_0, num3);
					num3 = num3 + 4;
					IList<Independentsoft.Msg.DayOfWeek> dayOfWeeks1 = new List<Independentsoft.Msg.DayOfWeek>();
					if ((num5 & 1) == 1)
					{
						dayOfWeeks1.Add(Independentsoft.Msg.DayOfWeek.Sunday);
					}
					if ((num5 & 2) == 2)
					{
						dayOfWeeks1.Add(Independentsoft.Msg.DayOfWeek.Monday);
					}
					if ((num5 & 4) == 4)
					{
						dayOfWeeks1.Add(Independentsoft.Msg.DayOfWeek.Tuesday);
					}
					if ((num5 & 8) == 8)
					{
						dayOfWeeks1.Add(Independentsoft.Msg.DayOfWeek.Wednesday);
					}
					if ((num5 & 16) == 16)
					{
						dayOfWeeks1.Add(Independentsoft.Msg.DayOfWeek.Thursday);
					}
					if ((num5 & 32) == 32)
					{
						dayOfWeeks1.Add(Independentsoft.Msg.DayOfWeek.Friday);
					}
					if ((num5 & 64) == 64)
					{
						dayOfWeeks1.Add(Independentsoft.Msg.DayOfWeek.Saturday);
					}
					this.e = new Independentsoft.Msg.DayOfWeek[dayOfWeeks1.Count];
					for (int j = 0; j < dayOfWeeks1.Count; j++)
					{
						this.e[j] = dayOfWeeks1[j];
					}
					if (num6 == 1)
					{
						this.f = Independentsoft.Msg.DayOfWeekIndex.First;
					}
					else if (num6 == 2)
					{
						this.f = Independentsoft.Msg.DayOfWeekIndex.Second;
					}
					else if (num6 == 3)
					{
						this.f = Independentsoft.Msg.DayOfWeekIndex.Third;
					}
					else if (num6 == 4)
					{
						this.f = Independentsoft.Msg.DayOfWeekIndex.Fourth;
					}
					else if (num6 == 5)
					{
						this.f = Independentsoft.Msg.DayOfWeekIndex.Last;
					}
				}
			}
			int num7 = BitConverter.ToInt32(A_0, num3);
			num3 = num3 + 4;
			this.h = h.a(num7);
			this.i = BitConverter.ToInt32(A_0, num3);
			num3 = num3 + 4;
			int num8 = BitConverter.ToInt32(A_0, num3);
			num3 = num3 + 4;
			this.j = h.b(num8);
			this.k = BitConverter.ToInt32(A_0, num3);
			num3 = num3 + 4;
			if (this.k > 0)
			{
				this.l = new DateTime[this.k];
				for (int k = 0; k < this.k; k++)
				{
					if ((int)A_0.Length < num3 + 4)
					{
						return;
					}
					int num9 = BitConverter.ToInt32(A_0, num3);
					num3 = num3 + 4;
					this.l[k] = m.a(num9);
				}
			}
			this.m = BitConverter.ToInt32(A_0, num3);
			num3 = num3 + 4;
			if (this.m > 0)
			{
				this.n = new DateTime[this.m];
				for (int l = 0; l < this.m; l++)
				{
					if ((int)A_0.Length < num3 + 4)
					{
						return;
					}
					int num10 = BitConverter.ToInt32(A_0, num3);
					num3 = num3 + 4;
					this.n[l] = m.a(num10);
				}
			}
			if ((int)A_0.Length < num3 + 4)
			{
				return;
			}
			int num11 = BitConverter.ToInt32(A_0, num3);
			num3 = num3 + 4;
			this.o = m.a(num11);
			int num12 = BitConverter.ToInt32(A_0, num3);
			this.p = m.a(num12);
		}
	}
}