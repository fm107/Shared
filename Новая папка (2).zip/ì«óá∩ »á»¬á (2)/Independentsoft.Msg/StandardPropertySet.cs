using System;

namespace Independentsoft.Msg
{
	/// <summary>
	/// Class StandardPropertySet.
	/// </summary>
	public class StandardPropertySet
	{
		public readonly static byte[] Mapi;

		public readonly static byte[] PublicStrings;

		public readonly static byte[] InternetHeaders;

		public readonly static byte[] Appointment;

		public readonly static byte[] Task;

		public readonly static byte[] Address;

		public readonly static byte[] Common;

		public readonly static byte[] Note;

		public readonly static byte[] Journal;

		static StandardPropertySet()
		{
			StandardPropertySet.Mapi = new byte[] { 40, 3, 2, 0, 0, 0, 0, 0, 192, 0, 0, 0, 0, 0, 0, 70 };
			StandardPropertySet.PublicStrings = new byte[] { 41, 3, 2, 0, 0, 0, 0, 0, 192, 0, 0, 0, 0, 0, 0, 70 };
			StandardPropertySet.InternetHeaders = new byte[] { 134, 3, 2, 0, 0, 0, 0, 0, 192, 0, 0, 0, 0, 0, 0, 70 };
			StandardPropertySet.Appointment = new byte[] { 2, 32, 6, 0, 0, 0, 0, 0, 192, 0, 0, 0, 0, 0, 0, 70 };
			StandardPropertySet.Task = new byte[] { 3, 32, 6, 0, 0, 0, 0, 0, 192, 0, 0, 0, 0, 0, 0, 70 };
			StandardPropertySet.Address = new byte[] { 4, 32, 6, 0, 0, 0, 0, 0, 192, 0, 0, 0, 0, 0, 0, 70 };
			StandardPropertySet.Common = new byte[] { 8, 32, 6, 0, 0, 0, 0, 0, 192, 0, 0, 0, 0, 0, 0, 70 };
			StandardPropertySet.Note = new byte[] { 14, 32, 6, 0, 0, 0, 0, 0, 192, 0, 0, 0, 0, 0, 0, 70 };
			StandardPropertySet.Journal = new byte[] { 10, 32, 6, 0, 0, 0, 0, 0, 192, 0, 0, 0, 0, 0, 0, 70 };
		}

		public StandardPropertySet()
		{
		}
	}
}