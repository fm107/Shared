using Independentsoft.Email.Mime;
using Independentsoft.IO.StructuredStorage;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Independentsoft.Msg
{
	/// <summary>
	/// Represents Outlook message file.
	/// </summary>
	public class Message
	{
		private IDictionary<string, q> a;

		private string b = "IPM.Note";

		private string c;

		private string d;

		private string e;

		private string f;

		private string g;

		private string h;

		private string i;

		private string j;

		private string k;

		private string l;

		private byte[] m;

		private byte[] n;

		private byte[] o;

		private byte[] p;

		private byte[] q;

		private byte[] r;

		private DateTime s;

		private DateTime t;

		private DateTime u;

		private DateTime v;

		private DateTime w;

		private DateTime x;

		private DateTime y;

		private string z;

		private string aa;

		private string ab;

		private string ac;

		private string ad;

		private string ae;

		private uint af;

		private uint ag;

		private uint ah;

		private uint ai;

		private byte[] aj;

		private bool ak;

		private bool al;

		private bool am;

		private bool an;

		private bool ao;

		private bool ap;

		private bool aq;

		private bool ar;

		private byte[] @as;

		private Independentsoft.Msg.Sensitivity at = Independentsoft.Msg.Sensitivity.None;

		private Independentsoft.Msg.Importance au = Independentsoft.Msg.Importance.None;

		private Independentsoft.Msg.Priority av = Independentsoft.Msg.Priority.None;

		private Independentsoft.Msg.FlagIcon aw;

		private Independentsoft.Msg.FlagStatus ax = Independentsoft.Msg.FlagStatus.None;

		private Independentsoft.Msg.ObjectType ay = Independentsoft.Msg.ObjectType.None;

		private string az;

		private string a0;

		private byte[] a1;

		private string a2;

		private byte[] a3;

		private string a4;

		private string a5;

		private byte[] a6;

		private string a7;

		private byte[] a8;

		private string a9;

		private string ba;

		private byte[] bb;

		private string bc;

		private byte[] bd;

		private string be;

		private string bf;

		private byte[] bg;

		private string bh;

		private byte[] bi;

		private string bj;

		private DateTime bk;

		private Independentsoft.Msg.LastVerbExecuted bl;

		private IList<MessageFlag> bm = new List<MessageFlag>();

		private IList<StoreSupportMask> bn = new List<StoreSupportMask>();

		private string bo;

		private uint bp;

		private DateTime bq;

		private DateTime br;

		private DateTime bs;

		private bool bt;

		private DateTime bu;

		private uint bv;

		private IList<string> bw = new List<string>();

		private IList<string> bx = new List<string>();

		private IList<string> by = new List<string>();

		private string bz;

		private string b0;

		private string b1;

		private bool b2;

		private bool b3;

		private bool b4;

		private bool b5;

		private string b6;

		private DateTime b7;

		private DateTime b8;

		private bool b9;

		private string ca;

		private Independentsoft.Msg.BusyStatus cb = Independentsoft.Msg.BusyStatus.None;

		private Independentsoft.Msg.MeetingStatus cc = Independentsoft.Msg.MeetingStatus.None;

		private Independentsoft.Msg.ResponseStatus cd = Independentsoft.Msg.ResponseStatus.None;

		private Independentsoft.Msg.RecurrenceType ce = Independentsoft.Msg.RecurrenceType.None;

		private string cf;

		private string cg;

		private string ch;

		internal Independentsoft.Msg.RecurrencePattern ci;

		private byte[] cj;

		private int ck = -1;

		private uint cl;

		private DateTime cm;

		private DateTime cn;

		private string co;

		private string cp;

		private double cq;

		private uint cr;

		private uint cs;

		private bool ct;

		private bool cu;

		private DateTime cv;

		private Independentsoft.Msg.TaskStatus cw = Independentsoft.Msg.TaskStatus.None;

		private Independentsoft.Msg.TaskOwnership cx = Independentsoft.Msg.TaskOwnership.None;

		private Independentsoft.Msg.TaskDelegationState cy = Independentsoft.Msg.TaskDelegationState.None;

		private uint cz;

		private uint c0;

		private uint c1;

		private uint c2;

		private Independentsoft.Msg.NoteColor c3 = Independentsoft.Msg.NoteColor.None;

		private DateTime c4;

		private DateTime c5;

		private string c6;

		private string c7;

		private uint c8;

		private DateTime c9;

		private IList<string> da = new List<string>();

		private string db;

		private string dc;

		private string dd;

		private string de;

		private string df;

		private string dg;

		private string dh;

		private string di;

		private string dj;

		private string dk;

		private string dl;

		private string dm;

		private string dn;

		private string @do;

		private string dp;

		private string dq;

		private string dr;

		private string ds;

		private string dt;

		private string du;

		private string dv;

		private string dw;

		private string dx;

		private string dy;

		private string dz;

		private string d0;

		private string d1;

		private string d2;

		private string d3;

		private string d4;

		private string d5;

		private string d6;

		private string d7;

		private string d8;

		private string d9;

		private string ea;

		private string eb;

		private string ec;

		private string ed;

		private string ee;

		private string ef;

		private string eg;

		private string eh;

		private string ei;

		private string ej;

		private string ek;

		private string el;

		private string em;

		private string en;

		private string eo;

		private string ep;

		private string eq;

		private string er;

		private string es;

		private string et;

		private string eu;

		private string ev;

		private string ew;

		private string ex;

		private string ey;

		private DateTime ez;

		private Independentsoft.Msg.Gender e0 = Independentsoft.Msg.Gender.None;

		private Independentsoft.Msg.SelectedMailingAddress e1 = Independentsoft.Msg.SelectedMailingAddress.None;

		private bool e2;

		private string e3;

		private string e4;

		private string e5;

		private string e6;

		private string e7;

		private string e8;

		private string e9;

		private string fa;

		private string fb;

		private string fc;

		private string fd;

		private string fe;

		private string ff;

		private string fg;

		private string fh;

		private string fi;

		private string fj;

		private string fk;

		private byte[] fl;

		private byte[] fm;

		private byte[] fn;

		private IList<Recipient> fo = new List<Recipient>();

		private IList<Independentsoft.Msg.Attachment> fp = new List<Independentsoft.Msg.Attachment>();

		private ExtendedPropertyList fq = new ExtendedPropertyList();

		private IList<c> fr = new List<c>();

		private string fs = "001E";

		private uint ft = 30;

		private string fu = "101E";

		private uint fv = 4126;

		private System.Text.Encoding fw = System.Text.Encoding.UTF8;

		private bool fx;

		/// <summary>
		/// Contains the actual effort (in minutes) spent on the task.
		/// </summary>
		/// <value>The actual work.</value>
		public long ActualWork
		{
			get
			{
				return (long)this.cr;
			}
			set
			{
				this.cr = (uint)value;
			}
		}

		/// <summary>
		/// Contains appointment's the end date and time.
		/// </summary>
		/// <value>The appointment end time.</value>
		public DateTime AppointmentEndTime
		{
			get
			{
				return this.b8;
			}
			set
			{
				this.b8 = value;
			}
		}

		/// <summary>
		/// Contains appointment's message class.
		/// </summary>
		/// <value>The appointment message class.</value>
		public string AppointmentMessageClass
		{
			get
			{
				return this.cf;
			}
			set
			{
				this.cf = value;
			}
		}

		/// <summary>
		/// Contains appointment's the start date and time.
		/// </summary>
		/// <value>The appointment start time.</value>
		public DateTime AppointmentStartTime
		{
			get
			{
				return this.b7;
			}
			set
			{
				this.b7 = value;
			}
		}

		/// <summary>
		/// Contains the name of assistent of the contact.
		/// </summary>
		/// <value>The name of the assistent.</value>
		public string AssistentName
		{
			get
			{
				return this.db;
			}
			set
			{
				this.db = value;
			}
		}

		/// <summary>
		/// Contains assistent's phone number of the contact.
		/// </summary>
		/// <value>The assistent phone.</value>
		public string AssistentPhone
		{
			get
			{
				return this.dc;
			}
			set
			{
				this.dc = value;
			}
		}

		/// <summary>
		/// Contains collection of attachments.
		/// </summary>
		/// <value>The attachments.</value>
		public IList<Independentsoft.Msg.Attachment> Attachments
		{
			get
			{
				return this.fp;
			}
		}

		/// <summary>
		/// Contains the billing information associated with a message.
		/// </summary>
		/// <value>The billing information.</value>
		public string BillingInformation
		{
			get
			{
				return this.bz;
			}
			set
			{
				this.bz = value;
			}
		}

		/// <summary>
		/// Contains the birthday date for the contact.
		/// </summary>
		/// <value>The birthday.</value>
		public DateTime Birthday
		{
			get
			{
				return this.c9;
			}
			set
			{
				this.c9 = value;
			}
		}

		/// <summary>
		/// Contains the message text.
		/// </summary>
		/// <value>The body.</value>
		public string Body
		{
			get
			{
				return this.l;
			}
			set
			{
				this.l = value;
			}
		}

		/// <summary>
		/// Contains the Hypertext Markup Language (HTML) version of the message text.
		/// </summary>
		/// <value>The body HTML.</value>
		public byte[] BodyHtml
		{
			get
			{
				if (this.@as != null || this.BodyRtf == null)
				{
					return this.@as;
				}
				a _a = m.b(this.BodyRtf);
				if (_a == null || _a.a() == null)
				{
					return null;
				}
				return System.Text.Encoding.UTF8.GetBytes(_a.a());
			}
			set
			{
				this.@as = value;
			}
		}

		/// <summary>
		/// Contains the Hypertext Markup Language (HTML) version of the message text.
		/// </summary>
		/// <value>The body HTML text.</value>
		public string BodyHtmlText
		{
			get
			{
				if (this.@as == null)
				{
					byte[] bodyRtf = this.BodyRtf;
					if (bodyRtf != null && (int)bodyRtf.Length > 0)
					{
						a _a = m.b(bodyRtf);
						if (_a != null)
						{
							return _a.a();
						}
					}
					return null;
				}
				System.Text.Encoding encoding = null;
				try
				{
					encoding = System.Text.Encoding.GetEncoding((int)this.ai);
				}
				catch
				{
				}
				if (this.ai > 0 && encoding != null)
				{
					string str = encoding.GetString(this.@as, 0, (int)this.@as.Length);
					return str;
				}
				if (p.a(this.@as, (int)this.@as.Length))
				{
					System.Text.Encoding uTF8 = System.Text.Encoding.UTF8;
					string str1 = uTF8.GetString(this.@as, 0, (int)this.@as.Length);
					return str1;
				}
				string str2 = this.fw.GetString(this.@as, 0, (int)this.@as.Length);
				System.Text.Encoding uTF7 = System.Text.Encoding.UTF7;
				int num = str2.IndexOf("charset=");
				if (num > 0)
				{
					int num1 = str2.IndexOf("\"", num);
					if (num1 != -1)
					{
						string str3 = str2.Substring(num + 8, num1 - num - 8);
						uTF7 = System.Text.Encoding.GetEncoding(str3);
					}
				}
				str2 = uTF7.GetString(this.@as, 0, (int)this.@as.Length);
				return str2;
			}
			set
			{
				if (value != null)
				{
					this.@as = System.Text.Encoding.UTF8.GetBytes(value);
				}
			}
		}

		/// <summary>
		/// Contains the Rich Text Format (RTF) version of the message text.
		/// </summary>
		/// <value>The body RTF.</value>
		public byte[] BodyRtf
		{
			get
			{
				if (this.m == null || (int)this.m.Length <= 0)
				{
					return null;
				}
				return m.a(this.m);
			}
			set
			{
				if (value != null)
				{
					using (MemoryStream memoryStream = new MemoryStream((int)value.Length))
					{
						BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
						binaryWriter.Write((uint)((int)value.Length + 12));
						binaryWriter.Write((uint)((int)value.Length));
						binaryWriter.Write(1095517517);
						j _j = new j();
						_j.a(value, 0, (int)value.Length);
						binaryWriter.Write(_j.a());
						binaryWriter.Write(value);
						this.m = new byte[checked((IntPtr)memoryStream.Length)];
						Array.Copy(memoryStream.ToArray(), 0, this.m, 0, (int)this.m.Length);
						this.RtfInSync = true;
					}
				}
			}
		}

		/// <summary>
		/// Contains the whole, unparsed business address for the contact.
		/// </summary>
		/// <value>The business address.</value>
		public string BusinessAddress
		{
			get
			{
				return this.e6;
			}
			set
			{
				this.e6 = value;
			}
		}

		/// <summary>
		/// Contains the city name portion of the business address for the contact.
		/// </summary>
		/// <value>The business address city.</value>
		public string BusinessAddressCity
		{
			get
			{
				return this.el;
			}
			set
			{
				this.el = value;
			}
		}

		/// <summary>
		/// Contains the country/region code portion of the business address for the contact.
		/// </summary>
		/// <value>The business address country.</value>
		public string BusinessAddressCountry
		{
			get
			{
				return this.ek;
			}
			set
			{
				this.ek = value;
			}
		}

		/// <summary>
		/// Contains the postal code (zip code) portion of the business address for the contact.
		/// </summary>
		/// <value>The business address postal code.</value>
		public string BusinessAddressPostalCode
		{
			get
			{
				return this.em;
			}
			set
			{
				this.em = value;
			}
		}

		/// <summary>
		/// Contains the post office box number portion of the business address for the contact.
		/// </summary>
		/// <value>The business address post office box.</value>
		public string BusinessAddressPostOfficeBox
		{
			get
			{
				return this.en;
			}
			set
			{
				this.en = value;
			}
		}

		/// <summary>
		/// Contains the state code portion of the business address for the contact.
		/// </summary>
		/// <value>The state of the business address.</value>
		public string BusinessAddressState
		{
			get
			{
				return this.eo;
			}
			set
			{
				this.eo = value;
			}
		}

		/// <summary>
		/// Contains the street address portion of the business address for the contact.
		/// </summary>
		/// <value>The business address street.</value>
		public string BusinessAddressStreet
		{
			get
			{
				return this.ep;
			}
			set
			{
				this.ep = value;
			}
		}

		/// <summary>
		/// Contains the business fax number for the contact.
		/// </summary>
		/// <value>The business fax.</value>
		public string BusinessFax
		{
			get
			{
				return this.df;
			}
			set
			{
				this.df = value;
			}
		}

		/// <summary>
		/// Contains the url of the business Web page for the contact.
		/// </summary>
		/// <value>The business home page.</value>
		public string BusinessHomePage
		{
			get
			{
				return this.dg;
			}
			set
			{
				this.dg = value;
			}
		}

		/// <summary>
		/// Contains the first business telephone number for the contact.
		/// </summary>
		/// <value>The business phone.</value>
		public string BusinessPhone
		{
			get
			{
				return this.dd;
			}
			set
			{
				this.dd = value;
			}
		}

		/// <summary>
		/// Contains the second business telephone number for the contact.
		/// </summary>
		/// <value>The business phone2.</value>
		public string BusinessPhone2
		{
			get
			{
				return this.de;
			}
			set
			{
				this.de = value;
			}
		}

		/// <summary>
		/// Contains appointment's busy status.
		/// </summary>
		/// <value>The busy status.</value>
		public Independentsoft.Msg.BusyStatus BusyStatus
		{
			get
			{
				return this.cb;
			}
			set
			{
				this.cb = value;
			}
		}

		/// <summary>
		/// Contains the callback telephone number for the contact.
		/// </summary>
		/// <value>The callback phone.</value>
		public string CallbackPhone
		{
			get
			{
				return this.dh;
			}
			set
			{
				this.dh = value;
			}
		}

		/// <summary>
		/// Contains the car telephone number for the contact.
		/// </summary>
		/// <value>The car phone.</value>
		public string CarPhone
		{
			get
			{
				return this.di;
			}
			set
			{
				this.di = value;
			}
		}

		/// <summary>
		/// Contains the categories associated with a message.
		/// </summary>
		/// <value>The categories.</value>
		public IList<string> Categories
		{
			get
			{
				return this.by;
			}
		}

		/// <summary>
		/// Contains the mobile telephone number for the contact.
		/// </summary>
		/// <value>The cellular phone.</value>
		public string CellularPhone
		{
			get
			{
				return this.dj;
			}
			set
			{
				this.dj = value;
			}
		}

		/// <summary>
		/// Contains a change key of a message.
		/// </summary>
		/// <value>The change key.</value>
		public byte[] ChangeKey
		{
			get
			{
				return this.o;
			}
			set
			{
				this.o = value;
			}
		}

		/// <summary>
		/// Contains the names of the children of the contact.
		/// </summary>
		/// <value>The children names.</value>
		public IList<string> ChildrenNames
		{
			get
			{
				return this.da;
			}
		}

		/// <summary>
		/// Contains the date and time the message sender submitted a message.
		/// </summary>
		/// <value>The client submit time.</value>
		public DateTime ClientSubmitTime
		{
			get
			{
				return this.v;
			}
			set
			{
				this.v = value;
			}
		}

		/// <summary>
		/// Contains the end date and time of a message.
		/// </summary>
		/// <value>The common end time.</value>
		public DateTime CommonEndTime
		{
			get
			{
				return this.br;
			}
			set
			{
				this.br = value;
			}
		}

		/// <summary>
		/// Contains the start date and time of a message.
		/// </summary>
		/// <value>The common start time.</value>
		public DateTime CommonStartTime
		{
			get
			{
				return this.bq;
			}
			set
			{
				this.bq = value;
			}
		}

		/// <summary>
		/// Contains the names of the companies associated with the contact item.
		/// </summary>
		/// <value>The companies.</value>
		public IList<string> Companies
		{
			get
			{
				return this.bw;
			}
		}

		/// <summary>
		/// Contains the company main telephone number for the contact.
		/// </summary>
		/// <value>The company main phone.</value>
		public string CompanyMainPhone
		{
			get
			{
				return this.dk;
			}
			set
			{
				this.dk = value;
			}
		}

		/// <summary>
		/// Contains the company name for the contact.
		/// </summary>
		/// <value>The name of the company.</value>
		public string CompanyName
		{
			get
			{
				return this.dl;
			}
			set
			{
				this.dl = value;
			}
		}

		/// <summary>
		/// Contains the name of the computer network for the contact.
		/// </summary>
		/// <value>The name of the computer network.</value>
		public string ComputerNetworkName
		{
			get
			{
				return this.dm;
			}
			set
			{
				this.dm = value;
			}
		}

		/// <summary>
		/// Contains true if the contact has picture.
		/// </summary>
		/// <value><c>true</c> if [contact has picture]; otherwise, <c>false</c>.</value>
		public bool ContactHasPicture
		{
			get
			{
				return this.e2;
			}
			set
			{
				this.e2 = value;
			}
		}

		/// <summary>
		/// Contains the names of the contacts associated with the item.
		/// </summary>
		/// <value>The contact names.</value>
		public IList<string> ContactNames
		{
			get
			{
				return this.bx;
			}
		}

		/// <summary>
		/// Contains a binary value that indicates the relative position of this message within a conversation thread.
		/// </summary>
		/// <value>The index of the conversation.</value>
		public byte[] ConversationIndex
		{
			get
			{
				return this.aj;
			}
			set
			{
				this.aj = value;
			}
		}

		/// <summary>
		/// Contains the topic of the first message in a conversation thread.
		/// </summary>
		/// <value>The conversation topic.</value>
		/// <remarks>A conversation thread represents a series of messages and replies. These properties are set for the first message in a thread, usually to the <see cref="P:Independentsoft.Msg.Message.NormalizedSubject" /> property. Subsequent messages in the thread should use the same topic without modification.</remarks>
		public string ConversationTopic
		{
			get
			{
				return this.e;
			}
			set
			{
				this.e = value;
			}
		}

		/// <summary>
		/// Contains the creation date and time of the message.
		/// </summary>
		/// <value>The creation time.</value>
		/// <remarks>A message store sets this property for each message that it creates.</remarks>
		public DateTime CreationTime
		{
			get
			{
				return this.s;
			}
			set
			{
				this.s = value;
			}
		}

		/// <summary>
		/// Contains name of the person who created message.
		/// </summary>
		/// <value>The name of the creator.</value>
		public string CreatorName
		{
			get
			{
				return this.aa;
			}
			set
			{
				this.aa = value;
			}
		}

		/// <summary>
		/// Contains the customer ID for the contact.
		/// </summary>
		/// <value>The customer identifier.</value>
		public string CustomerId
		{
			get
			{
				return this.dn;
			}
			set
			{
				this.dn = value;
			}
		}

		/// <summary>
		/// Contains the completion date of the task.
		/// </summary>
		/// <value>The date completed.</value>
		public DateTime DateCompleted
		{
			get
			{
				return this.cv;
			}
			set
			{
				this.cv = value;
			}
		}

		/// <summary>
		/// Contains the date and time when a message sender wants a message delivered.
		/// </summary>
		/// <value>The deferred delivery time.</value>
		public DateTime DeferredDeliveryTime
		{
			get
			{
				return this.w;
			}
			set
			{
				this.w = value;
			}
		}

		/// <summary>
		/// Contains task's delegator name.
		/// </summary>
		/// <value>The delegator.</value>
		public string Delegator
		{
			get
			{
				return this.cp;
			}
			set
			{
				this.cp = value;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether [delivery report requested].
		/// </summary>
		/// <value><c>true</c> if [delivery report requested]; otherwise, <c>false</c>.</value>
		public bool DeliveryReportRequested
		{
			get
			{
				return this.ar;
			}
			set
			{
				this.ar = value;
			}
		}

		/// <summary>
		/// Contains the department name for the contact.
		/// </summary>
		/// <value>The name of the department.</value>
		public string DepartmentName
		{
			get
			{
				return this.@do;
			}
			set
			{
				this.@do = value;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether [disable full fidelity].
		/// </summary>
		/// <value><c>true</c> if [disable full fidelity]; otherwise, <c>false</c>.</value>
		public bool DisableFullFidelity
		{
			get
			{
				return this.an;
			}
			set
			{
				this.an = value;
			}
		}

		/// <summary>
		/// Contains an ASCII list of the display names of any blind carbon copy (BCC) message recipients, separated by semicolons (;).
		/// </summary>
		/// <value>The display BCC.</value>
		public string DisplayBcc
		{
			get
			{
				return this.f;
			}
			set
			{
				this.f = value;
			}
		}

		/// <summary>
		/// Contains an ASCII list of the display names of any carbon copy (CC) message recipients, separated by semicolons (;).
		/// </summary>
		/// <value>The display cc.</value>
		public string DisplayCc
		{
			get
			{
				return this.g;
			}
			set
			{
				this.g = value;
			}
		}

		/// <summary>
		/// Contains display name.
		/// </summary>
		/// <value>The display name.</value>
		public string DisplayName
		{
			get
			{
				return this.dp;
			}
			set
			{
				this.dp = value;
			}
		}

		/// <summary>
		/// Contains display name prefix.
		/// </summary>
		/// <value>The display name prefix.</value>
		public string DisplayNamePrefix
		{
			get
			{
				return this.dq;
			}
			set
			{
				this.dq = value;
			}
		}

		/// <summary>
		/// Contains a list of the display names of the primary (To) message recipients, separated by semicolons (;).
		/// </summary>
		/// <value>The display to.</value>
		public string DisplayTo
		{
			get
			{
				return this.h;
			}
			set
			{
				this.h = value;
			}
		}

		/// <summary>
		/// Contains appointment's duration in minutes.
		/// </summary>
		/// <value>The duration.</value>
		public long Duration
		{
			get
			{
				return (long)this.cl;
			}
			set
			{
				this.cl = (uint)value;
			}
		}

		/// <summary>
		/// Contains the e-mail address of the first e-mail entry for the contact.
		/// </summary>
		/// <value>The email1 address.</value>
		public string Email1Address
		{
			get
			{
				return this.e9;
			}
			set
			{
				this.e9 = value;
			}
		}

		/// <summary>
		/// Contains the display as name of the first e-mail address for the contact.
		/// </summary>
		/// <value>The email1 display as.</value>
		public string Email1DisplayAs
		{
			get
			{
				return this.ff;
			}
			set
			{
				this.ff = value;
			}
		}

		/// <summary>
		/// Contains the display name of the first e-mail address for the contact.
		/// </summary>
		/// <value>The display name of the email1.</value>
		public string Email1DisplayName
		{
			get
			{
				return this.fc;
			}
			set
			{
				this.fc = value;
			}
		}

		/// <summary>
		/// Contains the entry ID of the first e-mail address for the contact.
		/// </summary>
		/// <value>The email1 entry identifier.</value>
		public byte[] Email1EntryId
		{
			get
			{
				return this.fl;
			}
			set
			{
				this.fl = value;
			}
		}

		/// <summary>
		/// Contains the type of the first e-mail address for the contact.
		/// </summary>
		/// <value>The type of the email1.</value>
		public string Email1Type
		{
			get
			{
				return this.fi;
			}
			set
			{
				this.fi = value;
			}
		}

		/// <summary>
		/// Contains the e-mail address of the second e-mail entry for the contact.
		/// </summary>
		/// <value>The email2 address.</value>
		public string Email2Address
		{
			get
			{
				return this.fa;
			}
			set
			{
				this.fa = value;
			}
		}

		/// <summary>
		/// Contains the display as name of the second e-mail address for the contact.
		/// </summary>
		/// <value>The email2 display as.</value>
		public string Email2DisplayAs
		{
			get
			{
				return this.fg;
			}
			set
			{
				this.fg = value;
			}
		}

		/// <summary>
		/// Contains the display name of the second e-mail address for the contact.
		/// </summary>
		/// <value>The display name of the email2.</value>
		public string Email2DisplayName
		{
			get
			{
				return this.fd;
			}
			set
			{
				this.fd = value;
			}
		}

		/// <summary>
		/// Contains the entry ID of the second e-mail address for the contact.
		/// </summary>
		/// <value>The email2 entry identifier.</value>
		public byte[] Email2EntryId
		{
			get
			{
				return this.fm;
			}
			set
			{
				this.fm = value;
			}
		}

		/// <summary>
		/// Contains the type of the second e-mail address for the contact.
		/// </summary>
		/// <value>The type of the email2.</value>
		public string Email2Type
		{
			get
			{
				return this.fj;
			}
			set
			{
				this.fj = value;
			}
		}

		/// <summary>
		/// Contains the e-mail address of the third e-mail entry for the contact.
		/// </summary>
		/// <value>The email3 address.</value>
		public string Email3Address
		{
			get
			{
				return this.fb;
			}
			set
			{
				this.fb = value;
			}
		}

		/// <summary>
		/// Contains the display as name of the third e-mail address for the contact.
		/// </summary>
		/// <value>The email3 display as.</value>
		public string Email3DisplayAs
		{
			get
			{
				return this.fh;
			}
			set
			{
				this.fh = value;
			}
		}

		/// <summary>
		/// Contains the display name of the third e-mail address for the contact.
		/// </summary>
		/// <value>The display name of the email3.</value>
		public string Email3DisplayName
		{
			get
			{
				return this.fe;
			}
			set
			{
				this.fe = value;
			}
		}

		/// <summary>
		/// Contains the entry ID of the third e-mail address for the contact.
		/// </summary>
		/// <value>The email3 entry identifier.</value>
		public byte[] Email3EntryId
		{
			get
			{
				return this.fn;
			}
			set
			{
				this.fn = value;
			}
		}

		/// <summary>
		/// Contains the type of the third e-mail address for the contact.
		/// </summary>
		/// <value>The type of the email3.</value>
		public string Email3Type
		{
			get
			{
				return this.fk;
			}
			set
			{
				this.fk = value;
			}
		}

		/// <summary>
		/// Gets or sets message encoding. Default is UTF8 encoding.
		/// </summary>
		/// <value>The encoding.</value>
		/// <example>
		/// In order to save message as Unicode use:
		///   <code>
		/// message.Encoding = System.Text.Encoding.Unicode;
		///   </code>
		///   </example>
		public System.Text.Encoding Encoding
		{
			get
			{
				return this.fw;
			}
			set
			{
				this.fw = value;
			}
		}

		/// <summary>
		/// Contains a MAPI entry identifier used to open and edit properties of a particular MAPI object.
		/// </summary>
		/// <value>The entry identifier.</value>
		public byte[] EntryId
		{
			get
			{
				return this.p;
			}
			set
			{
				this.p = value;
			}
		}

		/// <summary>
		/// Contains collection of extended (custom) properties.
		/// </summary>
		/// <value>The extended properties.</value>
		public ExtendedPropertyList ExtendedProperties
		{
			get
			{
				return this.fq;
			}
		}

		/// <summary>
		/// Contains the default keyword string assigned to the contact when it is filed.
		/// </summary>
		/// <value>The file as.</value>
		public string FileAs
		{
			get
			{
				return this.e3;
			}
			set
			{
				this.e3 = value;
			}
		}

		/// <summary>
		/// Contains the date and time specifying the date by which an e-mail message is due.
		/// </summary>
		/// <value>The flag due by.</value>
		public DateTime FlagDueBy
		{
			get
			{
				return this.bs;
			}
			set
			{
				this.bs = value;
			}
		}

		/// <summary>
		/// Specifies the flag icon of the message object.
		/// </summary>
		/// <value>The flag icon.</value>
		public Independentsoft.Msg.FlagIcon FlagIcon
		{
			get
			{
				return this.aw;
			}
			set
			{
				this.aw = value;
			}
		}

		/// <summary>
		/// Specifies the flag state of the message object.
		/// </summary>
		/// <value>The flag status.</value>
		public Independentsoft.Msg.FlagStatus FlagStatus
		{
			get
			{
				return this.ax;
			}
			set
			{
				this.ax = value;
			}
		}

		/// <summary>
		/// Contains the FTP site entry for the contact.
		/// </summary>
		/// <value>The FTP site.</value>
		public string FtpSite
		{
			get
			{
				return this.dr;
			}
			set
			{
				this.dr = value;
			}
		}

		/// <summary>
		/// Contains the gender of the contact.
		/// </summary>
		/// <value>The gender.</value>
		public Independentsoft.Msg.Gender Gender
		{
			get
			{
				return this.e0;
			}
			set
			{
				this.e0 = value;
			}
		}

		/// <summary>
		/// Contains the generation for the contact.
		/// </summary>
		/// <value>The generation.</value>
		public string Generation
		{
			get
			{
				return this.ds;
			}
			set
			{
				this.ds = value;
			}
		}

		/// <summary>
		/// Contains the given name for the contact.
		/// </summary>
		/// <value>The name of the given.</value>
		public string GivenName
		{
			get
			{
				return this.dt;
			}
			set
			{
				this.dt = value;
			}
		}

		/// <summary>
		/// Contains the government ID number for the contact.
		/// </summary>
		/// <value>The government identifier.</value>
		public string GovernmentId
		{
			get
			{
				return this.du;
			}
			set
			{
				this.du = value;
			}
		}

		/// <summary>
		/// Contains message's global unique id.
		/// </summary>
		/// <value>The unique identifier.</value>
		public byte[] Guid
		{
			get
			{
				return this.cj;
			}
			set
			{
				this.cj = value;
			}
		}

		/// <summary>
		/// Contains true if a message contains at least one attachment.
		/// </summary>
		/// <value><c>true</c> if this instance has attachment; otherwise, <c>false</c>.</value>
		public bool HasAttachment
		{
			get
			{
				return this.ao;
			}
			set
			{
				this.ao = value;
			}
		}

		/// <summary>
		/// Contains the hobby names for the contact.
		/// </summary>
		/// <value>The hobbies.</value>
		public string Hobbies
		{
			get
			{
				return this.dv;
			}
			set
			{
				this.dv = value;
			}
		}

		/// <summary>
		/// Contains the whole, unparsed home address for the contact.
		/// </summary>
		/// <value>The home address.</value>
		public string HomeAddress
		{
			get
			{
				return this.e7;
			}
			set
			{
				this.e7 = value;
			}
		}

		/// <summary>
		/// Contains the city portion of the home address for the contact.
		/// </summary>
		/// <value>The home address city.</value>
		public string HomeAddressCity
		{
			get
			{
				return this.dx;
			}
			set
			{
				this.dx = value;
			}
		}

		/// <summary>
		/// Contains the country/region portion of the home address for the contact.
		/// </summary>
		/// <value>The home address country.</value>
		public string HomeAddressCountry
		{
			get
			{
				return this.dy;
			}
			set
			{
				this.dy = value;
			}
		}

		/// <summary>
		/// Contains the postal code portion of the home address for the contact.
		/// </summary>
		/// <value>The home address postal code.</value>
		public string HomeAddressPostalCode
		{
			get
			{
				return this.dz;
			}
			set
			{
				this.dz = value;
			}
		}

		/// <summary>
		/// Contains the post office box number portion of the home address for the contact.
		/// </summary>
		/// <value>The home address post office box.</value>
		public string HomeAddressPostOfficeBox
		{
			get
			{
				return this.d0;
			}
			set
			{
				this.d0 = value;
			}
		}

		/// <summary>
		/// Contains the state portion of the home address for the contact.
		/// </summary>
		/// <value>The state of the home address.</value>
		public string HomeAddressState
		{
			get
			{
				return this.d1;
			}
			set
			{
				this.d1 = value;
			}
		}

		/// <summary>
		/// Contains the street portion of the home address for the contact.
		/// </summary>
		/// <value>The home address street.</value>
		public string HomeAddressStreet
		{
			get
			{
				return this.d2;
			}
			set
			{
				this.d2 = value;
			}
		}

		/// <summary>
		/// Contains the home fax number for the contact.
		/// </summary>
		/// <value>The home fax.</value>
		public string HomeFax
		{
			get
			{
				return this.d3;
			}
			set
			{
				this.d3 = value;
			}
		}

		/// <summary>
		/// Contains the first home telephone number for the contact.
		/// </summary>
		/// <value>The home phone.</value>
		public string HomePhone
		{
			get
			{
				return this.d4;
			}
			set
			{
				this.d4 = value;
			}
		}

		/// <summary>
		/// Contains the second home telephone number for the contact.
		/// </summary>
		/// <value>The home phone2.</value>
		public string HomePhone2
		{
			get
			{
				return this.dw;
			}
			set
			{
				this.dw = value;
			}
		}

		/// <summary>
		/// Contains a number that indicates which icon to use when you display a group of e-mail objects.
		/// </summary>
		/// <value>The index of the icon.</value>
		public long IconIndex
		{
			get
			{
				return (long)this.ag;
			}
			set
			{
				this.ag = (uint)value;
			}
		}

		/// <summary>
		/// Contains a value that indicates the message sender's opinion of the importance of a message.
		/// </summary>
		/// <value>The importance.</value>
		public Independentsoft.Msg.Importance Importance
		{
			get
			{
				return this.au;
			}
			set
			{
				this.au = value;
			}
		}

		/// <summary>
		/// Contains the initials for the contact.
		/// </summary>
		/// <value>The initials.</value>
		public string Initials
		{
			get
			{
				return this.d5;
			}
			set
			{
				this.d5 = value;
			}
		}

		/// <summary>
		/// Contains the identifier of the message to which this message is a reply.
		/// </summary>
		/// <value>The in reply to.</value>
		public string InReplyTo
		{
			get
			{
				return this.ad;
			}
			set
			{
				this.ad = value;
			}
		}

		/// <summary>
		/// Contains the instant messenger address for the contact.
		/// </summary>
		/// <value>The instant messenger address.</value>
		public string InstantMessengerAddress
		{
			get
			{
				return this.e4;
			}
			set
			{
				this.e4 = value;
			}
		}

		/// <summary>
		/// Contains account name or email address.
		/// </summary>
		/// <value>The name of the internet account.</value>
		public string InternetAccountName
		{
			get
			{
				return this.b6;
			}
			set
			{
				this.b6 = value;
			}
		}

		/// <summary>
		/// Indicates the code page used for the <see cref="P:Independentsoft.Msg.Message.Body" /> or the <see cref="P:Independentsoft.Msg.Message.BodyHtml" /> properties.
		/// </summary>
		/// <value>The internet code page.</value>
		public long InternetCodePage
		{
			get
			{
				return (long)this.ai;
			}
			set
			{
				this.ai = (uint)value;
			}
		}

		/// <summary>
		/// Contains the url location of the user's free-busy information in vCard Free-Busy standard format.
		/// </summary>
		/// <value>The internet free busy address.</value>
		public string InternetFreeBusyAddress
		{
			get
			{
				return this.e5;
			}
			set
			{
				this.e5 = value;
			}
		}

		/// <summary>
		/// Contains unique ID for the message.
		/// </summary>
		/// <value>The internet message identifier.</value>
		public string InternetMessageId
		{
			get
			{
				return this.ac;
			}
			set
			{
				this.ac = value;
			}
		}

		/// <summary>
		/// Contains Internet reference ID for the message.
		/// </summary>
		/// <value>The internet references.</value>
		public string InternetReferences
		{
			get
			{
				return this.ae;
			}
			set
			{
				this.ae = value;
			}
		}

		/// <summary>
		/// Contains true if the appointment is all day event.
		/// </summary>
		/// <value><c>true</c> if this instance is all day event; otherwise, <c>false</c>.</value>
		public bool IsAllDayEvent
		{
			get
			{
				return this.b9;
			}
			set
			{
				this.b9 = value;
			}
		}

		/// <summary>
		/// Contains true if the task is complete.
		/// </summary>
		/// <value><c>true</c> if this instance is complete; otherwise, <c>false</c>.</value>
		public bool IsComplete
		{
			get
			{
				return this.cu;
			}
			set
			{
				this.cu = value;
			}
		}

		/// <summary>
		/// Contains the ISDN number for the contact.
		/// </summary>
		/// <value>The isdn.</value>
		public string Isdn
		{
			get
			{
				return this.d6;
			}
			set
			{
				this.d6 = value;
			}
		}

		/// <summary>
		/// Contains true if Message is embedded into another message object.
		/// </summary>
		/// <value><c>true</c> if this instance is embedded; otherwise, <c>false</c>.</value>
		public bool IsEmbedded
		{
			get
			{
				return this.fx;
			}
			set
			{
				this.fx = value;
			}
		}

		/// <summary>
		/// Contains true if message is invisible.
		/// </summary>
		/// <value><c>true</c> if this instance is hidden; otherwise, <c>false</c>.</value>
		public bool IsHidden
		{
			get
			{
				return this.ak;
			}
			set
			{
				this.ak = value;
			}
		}

		/// <summary>
		/// Contains true if message is marked as private.
		/// </summary>
		/// <value><c>true</c> if this instance is private; otherwise, <c>false</c>.</value>
		public bool IsPrivate
		{
			get
			{
				return this.b2;
			}
			set
			{
				this.b2 = value;
			}
		}

		/// <summary>
		/// Contains true if message is read only.
		/// </summary>
		/// <value><c>true</c> if this instance is read only; otherwise, <c>false</c>.</value>
		public bool IsReadOnly
		{
			get
			{
				return this.al;
			}
			set
			{
				this.al = value;
			}
		}

		/// <summary>
		/// Contains true if the task or appointment is recurring.
		/// </summary>
		/// <value><c>true</c> if this instance is recurring; otherwise, <c>false</c>.</value>
		public bool IsRecurring
		{
			get
			{
				return this.bt;
			}
			set
			{
				this.bt = value;
			}
		}

		/// <summary>
		/// Contains true if a reminder has been set for this appointment, e-mail item, or task.
		/// </summary>
		/// <value><c>true</c> if this instance is reminder set; otherwise, <c>false</c>.</value>
		public bool IsReminderSet
		{
			get
			{
				return this.b3;
			}
			set
			{
				this.b3 = value;
			}
		}

		/// <summary>
		/// Contains true if message is system message.
		/// </summary>
		/// <value><c>true</c> if this instance is system; otherwise, <c>false</c>.</value>
		public bool IsSystem
		{
			get
			{
				return this.am;
			}
			set
			{
				this.am = value;
			}
		}

		/// <summary>
		/// Contains true if the task is a team task.
		/// </summary>
		/// <value><c>true</c> if this instance is team task; otherwise, <c>false</c>.</value>
		public bool IsTeamTask
		{
			get
			{
				return this.ct;
			}
			set
			{
				this.ct = value;
			}
		}

		/// <summary>
		/// Contains journal's the duration in minutes.
		/// </summary>
		/// <value>The duration of the journal.</value>
		public long JournalDuration
		{
			get
			{
				return (long)this.c8;
			}
			set
			{
				this.c8 = (uint)value;
			}
		}

		/// <summary>
		/// Contains journal's the end date and time.
		/// </summary>
		/// <value>The journal end time.</value>
		public DateTime JournalEndTime
		{
			get
			{
				return this.c5;
			}
			set
			{
				this.c5 = value;
			}
		}

		/// <summary>
		/// Contains journal's the start date and time.
		/// </summary>
		/// <value>The journal start time.</value>
		public DateTime JournalStartTime
		{
			get
			{
				return this.c4;
			}
			set
			{
				this.c4 = value;
			}
		}

		/// <summary>
		/// Contains the type of the journal item.
		/// </summary>
		/// <value>The type of the journal.</value>
		public string JournalType
		{
			get
			{
				return this.c6;
			}
			set
			{
				this.c6 = value;
			}
		}

		/// <summary>
		/// Contains the type description of the journal item.
		/// </summary>
		/// <value>The journal type description.</value>
		public string JournalTypeDescription
		{
			get
			{
				return this.c7;
			}
			set
			{
				this.c7 = value;
			}
		}

		/// <summary>
		/// Contains the categories associated with a message.
		/// </summary>
		/// <value>The keywords.</value>
		public IList<string> Keywords
		{
			get
			{
				return this.by;
			}
		}

		/// <summary>
		/// Contains appointment's label color.
		/// </summary>
		/// <value>The label.</value>
		public long Label
		{
			get
			{
				return (long)this.ck;
			}
			set
			{
				this.ck = (int)value;
			}
		}

		/// <summary>
		/// Contains the date and time when the message was last modified.
		/// </summary>
		/// <value>The last modification time.</value>
		/// <remarks>This property is initially set to the same value as the <see cref="P:Independentsoft.Msg.Message.CreationTime" /> property.</remarks>
		public DateTime LastModificationTime
		{
			get
			{
				return this.t;
			}
			set
			{
				this.t = value;
			}
		}

		/// <summary>
		/// Contains name of the person who modified message.
		/// </summary>
		/// <value>The last name of the modifier.</value>
		public string LastModifierName
		{
			get
			{
				return this.ab;
			}
			set
			{
				this.ab = value;
			}
		}

		/// <summary>
		/// Contains the last verb executed.
		/// </summary>
		/// <value>The last verb executed.</value>
		public Independentsoft.Msg.LastVerbExecuted LastVerbExecuted
		{
			get
			{
				return this.bl;
			}
			set
			{
				this.bl = value;
			}
		}

		/// <summary>
		/// Contains the time when the last verb was executed.
		/// </summary>
		/// <value>The last verb execution time.</value>
		public DateTime LastVerbExecutionTime
		{
			get
			{
				return this.bk;
			}
			set
			{
				this.bk = value;
			}
		}

		/// <summary>
		/// Contains appointment's location.
		/// </summary>
		/// <value>The location.</value>
		public string Location
		{
			get
			{
				return this.ca;
			}
			set
			{
				this.ca = value;
			}
		}

		/// <summary>
		/// Contains the manager name for the contact.
		/// </summary>
		/// <value>The name of the manager.</value>
		public string ManagerName
		{
			get
			{
				return this.d7;
			}
			set
			{
				this.d7 = value;
			}
		}

		/// <summary>
		/// Contains the status of the meeting.
		/// </summary>
		/// <value>The meeting status.</value>
		public Independentsoft.Msg.MeetingStatus MeetingStatus
		{
			get
			{
				return this.cc;
			}
			set
			{
				this.cc = value;
			}
		}

		/// <summary>
		/// Contains a text string that identifies the sender-defined message class, such as IPM.Note.
		/// </summary>
		/// <value>The message class.</value>
		public string MessageClass
		{
			get
			{
				return this.b;
			}
			set
			{
				this.b = value;
			}
		}

		/// <summary>
		/// Contains the code page that is used for the message.
		/// </summary>
		/// <value>The message code page.</value>
		public long MessageCodePage
		{
			get
			{
				return (long)this.af;
			}
			set
			{
				this.af = (uint)value;
			}
		}

		/// <summary>
		/// Contains the date and time when a message was delivered.
		/// </summary>
		/// <value>The message delivery time.</value>
		/// <remarks>This property describes the time the message was stored at the server, rather than the download time when the transport provider copied the message from the server to the local store.</remarks>
		public DateTime MessageDeliveryTime
		{
			get
			{
				return this.u;
			}
			set
			{
				this.u = value;
			}
		}

		/// <summary>
		/// Contains a bitmask of flags that indicate the origin and current state of a message.
		/// </summary>
		/// <value>The message flags.</value>
		/// <remarks>This property is a nontransmittable message property exposed at both the sending and receiving ends of a transmission, with different values depending upon the client application or store provider involved. This property is initialized by the client or message store provider when a message is created and saved for the first time and then updated periodically by the message store provider, a transport provider, and the MAPI spooler as the message is processed and its state changes. This property exists on a message both before and after submission, and on all copies of the received message. Although it is not a recipient property, it is exposed differently to each recipient according to whether it has been read or modified by that recipient.</remarks>
		public IList<MessageFlag> MessageFlags
		{
			get
			{
				return this.bm;
			}
		}

		/// <summary>
		/// Contains the middle name for the contact.
		/// </summary>
		/// <value>The name of the middle.</value>
		public string MiddleName
		{
			get
			{
				return this.d8;
			}
			set
			{
				this.d8 = value;
			}
		}

		/// <summary>
		/// Contains free-form string value and can be used to store mileage information associated with the message.
		/// </summary>
		/// <value>The mileage.</value>
		public string Mileage
		{
			get
			{
				return this.b0;
			}
			set
			{
				this.b0 = value;
			}
		}

		/// <summary>
		/// Contains the nickname for the contact.
		/// </summary>
		/// <value>The nickname.</value>
		public string Nickname
		{
			get
			{
				return this.d9;
			}
			set
			{
				this.d9 = value;
			}
		}

		/// <summary>
		/// Contains the message subject with any prefix removed.
		/// </summary>
		/// <value>The normalized subject.</value>
		public string NormalizedSubject
		{
			get
			{
				return this.k;
			}
			set
			{
				this.k = value;
			}
		}

		/// <summary>
		/// Contains background color of the note item.
		/// </summary>
		/// <value>The color of the note.</value>
		public Independentsoft.Msg.NoteColor NoteColor
		{
			get
			{
				return this.c3;
			}
			set
			{
				this.c3 = value;
			}
		}

		/// <summary>
		/// Contains height of the note item.
		/// </summary>
		/// <value>The height of the note.</value>
		public long NoteHeight
		{
			get
			{
				return (long)this.c0;
			}
			set
			{
				this.c0 = (uint)value;
			}
		}

		/// <summary>
		/// Contains left position of the note item.
		/// </summary>
		/// <value>The note left.</value>
		public long NoteLeft
		{
			get
			{
				return (long)this.c1;
			}
			set
			{
				this.c1 = (uint)value;
			}
		}

		/// <summary>
		/// Contains top position of the note item.
		/// </summary>
		/// <value>The note top.</value>
		public long NoteTop
		{
			get
			{
				return (long)this.c2;
			}
			set
			{
				this.c2 = (uint)value;
			}
		}

		/// <summary>
		/// Contains width of the note item.
		/// </summary>
		/// <value>The width of the note.</value>
		public long NoteWidth
		{
			get
			{
				return (long)this.cz;
			}
			set
			{
				this.cz = (uint)value;
			}
		}

		/// <summary>
		/// Contains the type of an object.
		/// </summary>
		/// <value>The type of the object.</value>
		public Independentsoft.Msg.ObjectType ObjectType
		{
			get
			{
				return this.ay;
			}
			set
			{
				this.ay = value;
			}
		}

		/// <summary>
		/// Contains the specific office location for the contact.
		/// </summary>
		/// <value>The office location.</value>
		public string OfficeLocation
		{
			get
			{
				return this.ea;
			}
			set
			{
				this.ea = value;
			}
		}

		/// <summary>
		/// Contains a list of the display names of the primary (To) message recipients, separated by semicolons (;).
		/// </summary>
		/// <value>The original display to.</value>
		public string OriginalDisplayTo
		{
			get
			{
				return this.i;
			}
			set
			{
				this.i = value;
			}
		}

		/// <summary>
		/// Contains the whole, unparsed other address for the contact.
		/// </summary>
		/// <value>The other address.</value>
		public string OtherAddress
		{
			get
			{
				return this.e8;
			}
			set
			{
				this.e8 = value;
			}
		}

		/// <summary>
		/// Contains the city portion of the other address for the contact.
		/// </summary>
		/// <value>The other address city.</value>
		public string OtherAddressCity
		{
			get
			{
				return this.eb;
			}
			set
			{
				this.eb = value;
			}
		}

		/// <summary>
		/// Contains the country/region portion of the other address for the contact.
		/// </summary>
		/// <value>The other address country.</value>
		public string OtherAddressCountry
		{
			get
			{
				return this.ec;
			}
			set
			{
				this.ec = value;
			}
		}

		/// <summary>
		/// Contains the postal code portion of the other address for the contact.
		/// </summary>
		/// <value>The other address postal code.</value>
		public string OtherAddressPostalCode
		{
			get
			{
				return this.ed;
			}
			set
			{
				this.ed = value;
			}
		}

		/// <summary>
		/// Contains the state portion of the other address for the contact.
		/// </summary>
		/// <value>The state of the other address.</value>
		public string OtherAddressState
		{
			get
			{
				return this.ee;
			}
			set
			{
				this.ee = value;
			}
		}

		/// <summary>
		/// Contains the street portion of the other address for the contact.
		/// </summary>
		/// <value>The other address street.</value>
		public string OtherAddressStreet
		{
			get
			{
				return this.ef;
			}
			set
			{
				this.ef = value;
			}
		}

		/// <summary>
		/// Contains the other telephone number for the contact.
		/// </summary>
		/// <value>The other phone.</value>
		public string OtherPhone
		{
			get
			{
				return this.eg;
			}
			set
			{
				this.eg = value;
			}
		}

		/// <summary>
		/// Contains internal version number of Microsoft Office Outlook client.
		/// </summary>
		/// <value>The outlook internal version.</value>
		public long OutlookInternalVersion
		{
			get
			{
				return (long)this.bp;
			}
			set
			{
				this.bp = (uint)value;
			}
		}

		/// <summary>
		/// Contains version number of Microsoft Office Outlook client.
		/// </summary>
		/// <value>The outlook version.</value>
		public string OutlookVersion
		{
			get
			{
				return this.bo;
			}
			set
			{
				this.bo = value;
			}
		}

		/// <summary>
		/// Contains task's owner name.
		/// </summary>
		/// <value>The owner.</value>
		public string Owner
		{
			get
			{
				return this.co;
			}
			set
			{
				this.co = value;
			}
		}

		/// <summary>
		/// Contains the pager number for the contact.
		/// </summary>
		/// <value>The pager.</value>
		public string Pager
		{
			get
			{
				return this.eh;
			}
			set
			{
				this.eh = value;
			}
		}

		/// <summary>
		/// Contains the percentage of the task completed at the current date and time.
		/// </summary>
		/// <value>The percent complete.</value>
		public double PercentComplete
		{
			get
			{
				return this.cq;
			}
			set
			{
				this.cq = value;
			}
		}

		/// <summary>
		/// Contains the url of the personal Web page for the contact.
		/// </summary>
		/// <value>The personal home page.</value>
		public string PersonalHomePage
		{
			get
			{
				return this.ei;
			}
			set
			{
				this.ei = value;
			}
		}

		/// <summary>
		/// Contains the postal address for the contact.
		/// </summary>
		/// <value>The postal address.</value>
		public string PostalAddress
		{
			get
			{
				return this.ej;
			}
			set
			{
				this.ej = value;
			}
		}

		/// <summary>
		/// Contains the primary fax number for the contact.
		/// </summary>
		/// <value>The primary fax.</value>
		public string PrimaryFax
		{
			get
			{
				return this.eq;
			}
			set
			{
				this.eq = value;
			}
		}

		/// <summary>
		/// Contains the primary telephone number for the contact.
		/// </summary>
		/// <value>The primary phone.</value>
		public string PrimaryPhone
		{
			get
			{
				return this.er;
			}
			set
			{
				this.er = value;
			}
		}

		/// <summary>
		/// Contains the relative priority of a message.
		/// </summary>
		/// <value>The priority.</value>
		/// <remarks>This property and the <see cref="P:Independentsoft.Msg.Message.Importance" /> property should not be confused. Importance indicates a value to users, while priority indicates the order or speed at which the message should be sent by the messaging system software. Higher priority usually indicates a higher cost. Higher importance usually is associated with a different display by the user interface.</remarks>
		public Independentsoft.Msg.Priority Priority
		{
			get
			{
				return this.av;
			}
			set
			{
				this.av = value;
			}
		}

		/// <summary>
		/// Contains the profession for the contact.
		/// </summary>
		/// <value>The profession.</value>
		public string Profession
		{
			get
			{
				return this.es;
			}
			set
			{
				this.es = value;
			}
		}

		/// <summary>
		/// Contains the date and time the mail provider submitted a message.
		/// </summary>
		/// <value>The provider submit time.</value>
		public DateTime ProviderSubmitTime
		{
			get
			{
				return this.x;
			}
			set
			{
				this.x = value;
			}
		}

		/// <summary>
		/// Contains the radio telephone number for the contact.
		/// </summary>
		/// <value>The radio phone.</value>
		public string RadioPhone
		{
			get
			{
				return this.et;
			}
			set
			{
				this.et = value;
			}
		}

		/// <summary>
		/// Gets or sets the read receipt entry identifier.
		/// </summary>
		/// <value>The read receipt entry identifier.</value>
		public byte[] ReadReceiptEntryId
		{
			get
			{
				return this.q;
			}
			set
			{
				this.q = value;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether [read receipt requested].
		/// </summary>
		/// <value><c>true</c> if [read receipt requested]; otherwise, <c>false</c>.</value>
		public bool ReadReceiptRequested
		{
			get
			{
				return this.aq;
			}
			set
			{
				this.aq = value;
			}
		}

		/// <summary>
		/// Gets or sets the read receipt search key.
		/// </summary>
		/// <value>The read receipt search key.</value>
		public byte[] ReadReceiptSearchKey
		{
			get
			{
				return this.r;
			}
			set
			{
				this.r = value;
			}
		}

		/// <summary>
		/// Contains the e-mail address type, such as SMTP, for the messaging user who actually receives the message.
		/// </summary>
		/// <value>The type of the received by address.</value>
		public string ReceivedByAddressType
		{
			get
			{
				return this.a4;
			}
			set
			{
				this.a4 = value;
			}
		}

		/// <summary>
		/// Contains the e-mail address for the messaging user who receives the message.
		/// </summary>
		/// <value>The received by email address.</value>
		public string ReceivedByEmailAddress
		{
			get
			{
				return this.a5;
			}
			set
			{
				this.a5 = value;
			}
		}

		/// <summary>
		/// Contains the entry identifier of the messaging user who actually receives the message.
		/// </summary>
		/// <value>The received by entry identifier.</value>
		public byte[] ReceivedByEntryId
		{
			get
			{
				return this.a6;
			}
			set
			{
				this.a6 = value;
			}
		}

		/// <summary>
		/// Contains the display name of the messaging user who receives the message.
		/// </summary>
		/// <value>The name of the received by.</value>
		public string ReceivedByName
		{
			get
			{
				return this.a7;
			}
			set
			{
				this.a7 = value;
			}
		}

		/// <summary>
		/// Contains the search key of the messaging user who receives the message.
		/// </summary>
		/// <value>The received by search key.</value>
		public byte[] ReceivedBySearchKey
		{
			get
			{
				return this.a8;
			}
			set
			{
				this.a8 = value;
			}
		}

		/// <summary>
		/// Contains the address type for the messaging user who is represented by the user actually receiving the message.
		/// </summary>
		/// <value>The type of the received representing address.</value>
		public string ReceivedRepresentingAddressType
		{
			get
			{
				return this.az;
			}
			set
			{
				this.az = value;
			}
		}

		/// <summary>
		/// Contains the e-mail address for the messaging user who is represented by the receiving user.
		/// </summary>
		/// <value>The received representing email address.</value>
		public string ReceivedRepresentingEmailAddress
		{
			get
			{
				return this.a0;
			}
			set
			{
				this.a0 = value;
			}
		}

		/// <summary>
		/// Contains the entry identifier for the messaging user who is represented by the receiving user.
		/// </summary>
		/// <value>The received representing entry identifier.</value>
		public byte[] ReceivedRepresentingEntryId
		{
			get
			{
				return this.a1;
			}
			set
			{
				this.a1 = value;
			}
		}

		/// <summary>
		/// Contains the display name for the messaging user who is represented by the receiving user.
		/// </summary>
		/// <value>The name of the received representing.</value>
		public string ReceivedRepresentingName
		{
			get
			{
				return this.a2;
			}
			set
			{
				this.a2 = value;
			}
		}

		/// <summary>
		/// Contains the search key for the messaging user represented by the receiving user.
		/// </summary>
		/// <value>The received representing search key.</value>
		public byte[] ReceivedRepresentingSearchKey
		{
			get
			{
				return this.a3;
			}
			set
			{
				this.a3 = value;
			}
		}

		/// <summary>
		/// Contains collection of recipients.
		/// </summary>
		/// <value>The recipients.</value>
		public IList<Recipient> Recipients
		{
			get
			{
				return this.fo;
			}
		}

		/// <summary>
		/// Contains appoinmtment or task recurring pattern.
		/// </summary>
		/// <value>The recurrence pattern.</value>
		public Independentsoft.Msg.RecurrencePattern RecurrencePattern
		{
			get
			{
				return this.ci;
			}
		}

		/// <summary>
		/// Contains recurring pattern description.
		/// </summary>
		/// <value>The recurrence pattern description.</value>
		public string RecurrencePatternDescription
		{
			get
			{
				return this.ch;
			}
			set
			{
				this.ch = value;
			}
		}

		/// <summary>
		/// Contains the recurrence pattern type.
		/// </summary>
		/// <value>The type of the recurrence.</value>
		public Independentsoft.Msg.RecurrenceType RecurrenceType
		{
			get
			{
				return this.ce;
			}
			set
			{
				this.ce = value;
			}
		}

		/// <summary>
		/// Contains the number of minutes the reminder should occur prior to the start of the appointment.
		/// </summary>
		/// <value>The reminder minutes before start.</value>
		public long ReminderMinutesBeforeStart
		{
			get
			{
				return (long)this.bv;
			}
			set
			{
				this.bv = (uint)value;
			}
		}

		/// <summary>
		/// Contains true if the reminder overrides the default reminder behavior for the appointment, mail item, or task.
		/// </summary>
		/// <value><c>true</c> if [reminder override default]; otherwise, <c>false</c>.</value>
		public bool ReminderOverrideDefault
		{
			get
			{
				return this.b4;
			}
			set
			{
				this.b4 = value;
			}
		}

		/// <summary>
		/// Contains true if the reminder should play a sound when it occurs for this appointment or task.
		/// </summary>
		/// <value><c>true</c> if [reminder play sound]; otherwise, <c>false</c>.</value>
		public bool ReminderPlaySound
		{
			get
			{
				return this.b5;
			}
			set
			{
				this.b5 = value;
			}
		}

		/// <summary>
		/// Contains the path and file name of the sound file to play when the reminder occurs for the appointment, mail message, or task.
		/// </summary>
		/// <value>The reminder sound file.</value>
		public string ReminderSoundFile
		{
			get
			{
				return this.b1;
			}
			set
			{
				this.b1 = value;
			}
		}

		/// <summary>
		/// Contains the date and time at which the reminder should occur for the specified item.
		/// </summary>
		/// <value>The reminder time.</value>
		public DateTime ReminderTime
		{
			get
			{
				return this.bu;
			}
			set
			{
				this.bu = value;
			}
		}

		/// <summary>
		/// Contains reply to email address.
		/// </summary>
		/// <value>The reply to.</value>
		public string ReplyTo
		{
			get
			{
				return this.j;
			}
			set
			{
				this.j = value;
			}
		}

		/// <summary>
		/// Contains report text.
		/// </summary>
		/// <value>The report text.</value>
		public string ReportText
		{
			get
			{
				return this.z;
			}
			set
			{
				this.z = value;
			}
		}

		/// <summary>
		/// Contains the report date and time.
		/// </summary>
		/// <value>The report time.</value>
		public DateTime ReportTime
		{
			get
			{
				return this.y;
			}
			set
			{
				this.y = value;
			}
		}

		/// <summary>
		/// Contains the response to a meeting request.
		/// </summary>
		/// <value>The response status.</value>
		public Independentsoft.Msg.ResponseStatus ResponseStatus
		{
			get
			{
				return this.cd;
			}
			set
			{
				this.cd = value;
			}
		}

		/// <summary>
		/// Contains the Rich Text Format (RTF) version of the message text, usually in compressed form.
		/// </summary>
		/// <value>The RTF compressed.</value>
		public byte[] RtfCompressed
		{
			get
			{
				return this.m;
			}
			set
			{
				this.m = value;
			}
		}

		/// <summary>
		/// Contains true if the <see cref="P:Independentsoft.Msg.Message.RtfCompressed" /> property has the same text content as the <see cref="P:Independentsoft.Msg.Message.Body" /> property for this message.
		/// </summary>
		/// <value><c>true</c> if [RTF in synchronize]; otherwise, <c>false</c>.</value>
		public bool RtfInSync
		{
			get
			{
				return this.ap;
			}
			set
			{
				this.ap = value;
			}
		}

		/// <summary>
		/// Contains a binary-comparable key that identifies correlated objects for a search.
		/// </summary>
		/// <value>The search key.</value>
		public byte[] SearchKey
		{
			get
			{
				return this.n;
			}
			set
			{
				this.n = value;
			}
		}

		/// <summary>
		/// Contains the type of the mailing address for the contact.
		/// </summary>
		/// <value>The selected mailing address.</value>
		public Independentsoft.Msg.SelectedMailingAddress SelectedMailingAddress
		{
			get
			{
				return this.e1;
			}
			set
			{
				this.e1 = value;
			}
		}

		/// <summary>
		/// Contains the message sender's e-mail address type.
		/// </summary>
		/// <value>The type of the sender address.</value>
		public string SenderAddressType
		{
			get
			{
				return this.a9;
			}
			set
			{
				this.a9 = value;
			}
		}

		/// <summary>
		/// Contains the message sender's e-mail address.
		/// </summary>
		/// <value>The sender email address.</value>
		public string SenderEmailAddress
		{
			get
			{
				return this.ba;
			}
			set
			{
				this.ba = value;
			}
		}

		/// <summary>
		/// Contains the message sender's entry identifier.
		/// </summary>
		/// <value>The sender entry identifier.</value>
		public byte[] SenderEntryId
		{
			get
			{
				return this.bb;
			}
			set
			{
				this.bb = value;
			}
		}

		/// <summary>
		/// Contains the message sender's display name.
		/// </summary>
		/// <value>The name of the sender.</value>
		public string SenderName
		{
			get
			{
				return this.bc;
			}
			set
			{
				this.bc = value;
			}
		}

		/// <summary>
		/// Contains the message sender's search key.
		/// </summary>
		/// <value>The sender search key.</value>
		public byte[] SenderSearchKey
		{
			get
			{
				return this.bd;
			}
			set
			{
				this.bd = value;
			}
		}

		/// <summary>
		/// Contains a value that indicates the message sender's opinion of the sensitivity of a message.
		/// </summary>
		/// <value>The sensitivity.</value>
		public Independentsoft.Msg.Sensitivity Sensitivity
		{
			get
			{
				return this.at;
			}
			set
			{
				this.at = value;
			}
		}

		/// <summary>
		/// Contains the address type for the messaging user who is represented by the sender.
		/// </summary>
		/// <value>The type of the sent representing address.</value>
		public string SentRepresentingAddressType
		{
			get
			{
				return this.be;
			}
			set
			{
				this.be = value;
			}
		}

		/// <summary>
		/// Contains the e-mail address for the messaging user who is represented by the sender.
		/// </summary>
		/// <value>The sent representing email address.</value>
		public string SentRepresentingEmailAddress
		{
			get
			{
				return this.bf;
			}
			set
			{
				this.bf = value;
			}
		}

		/// <summary>
		/// Contains the entry identifier for the messaging user represented by the sender.
		/// </summary>
		/// <value>The sent representing entry identifier.</value>
		public byte[] SentRepresentingEntryId
		{
			get
			{
				return this.bg;
			}
			set
			{
				this.bg = value;
			}
		}

		/// <summary>
		/// Contains the display name for the messaging user represented by the sender.
		/// </summary>
		/// <value>The name of the sent representing.</value>
		public string SentRepresentingName
		{
			get
			{
				return this.bh;
			}
			set
			{
				this.bh = value;
			}
		}

		/// <summary>
		/// Contains the search key for the messaging user represented by the sender.
		/// </summary>
		/// <value>The sent representing search key.</value>
		public byte[] SentRepresentingSearchKey
		{
			get
			{
				return this.bi;
			}
			set
			{
				this.bi = value;
			}
		}

		/// <summary>
		/// Contains the size of the body, subject, sender, and attachments.
		/// </summary>
		/// <value>The size.</value>
		public long Size
		{
			get
			{
				return (long)this.ah;
			}
			set
			{
				this.ah = (uint)value;
			}
		}

		/// <summary>
		/// Contains the spouse name for the contact.
		/// </summary>
		/// <value>The name of the spouse.</value>
		public string SpouseName
		{
			get
			{
				return this.eu;
			}
			set
			{
				this.eu = value;
			}
		}

		/// <summary>
		/// Contains values that client applications should query to determine the characteristics of a message store.
		/// </summary>
		/// <value>The store support masks.</value>
		public IList<StoreSupportMask> StoreSupportMasks
		{
			get
			{
				return this.bn;
			}
		}

		/// <summary>
		/// Contains the full subject of a message.
		/// </summary>
		/// <value>The subject.</value>
		public string Subject
		{
			get
			{
				return this.c;
			}
			set
			{
				this.c = value;
			}
		}

		/// <summary>
		/// Contains a subject prefix that typically indicates some action on a message, such as "FW: " for forwarding.
		/// </summary>
		/// <value>The subject prefix.</value>
		public string SubjectPrefix
		{
			get
			{
				return this.d;
			}
			set
			{
				this.d = value;
			}
		}

		/// <summary>
		/// Contains the last name for the contact.
		/// </summary>
		/// <value>The surname.</value>
		public string Surname
		{
			get
			{
				return this.ev;
			}
			set
			{
				this.ev = value;
			}
		}

		/// <summary>
		/// Contains the delegation state of a task.
		/// </summary>
		/// <value>The state of the task delegation.</value>
		public Independentsoft.Msg.TaskDelegationState TaskDelegationState
		{
			get
			{
				return this.cy;
			}
			set
			{
				this.cy = value;
			}
		}

		/// <summary>
		/// Contains task's the due date and time.
		/// </summary>
		/// <value>The task due date.</value>
		public DateTime TaskDueDate
		{
			get
			{
				return this.cn;
			}
			set
			{
				this.cn = value;
			}
		}

		/// <summary>
		/// Contains the ownership state of the task.
		/// </summary>
		/// <value>The task ownership.</value>
		public Independentsoft.Msg.TaskOwnership TaskOwnership
		{
			get
			{
				return this.cx;
			}
			set
			{
				this.cx = value;
			}
		}

		/// <summary>
		/// Contains task's the start date and time.
		/// </summary>
		/// <value>The task start date.</value>
		public DateTime TaskStartDate
		{
			get
			{
				return this.cm;
			}
			set
			{
				this.cm = value;
			}
		}

		/// <summary>
		/// Contains the status of the task.
		/// </summary>
		/// <value>The task status.</value>
		public Independentsoft.Msg.TaskStatus TaskStatus
		{
			get
			{
				return this.cw;
			}
			set
			{
				this.cw = value;
			}
		}

		/// <summary>
		/// Contains the telex number for the contact.
		/// </summary>
		/// <value>The telex.</value>
		public string Telex
		{
			get
			{
				return this.ew;
			}
			set
			{
				this.ew = value;
			}
		}

		/// <summary>
		/// Contains appointment's time zone.
		/// </summary>
		/// <value>The time zone.</value>
		public string TimeZone
		{
			get
			{
				return this.cg;
			}
			set
			{
				this.cg = value;
			}
		}

		/// <summary>
		/// Contains the title for the contact.
		/// </summary>
		/// <value>The title.</value>
		public string Title
		{
			get
			{
				return this.ex;
			}
			set
			{
				this.ex = value;
			}
		}

		/// <summary>
		/// Contains the total work for the task.
		/// </summary>
		/// <value>The total work.</value>
		public long TotalWork
		{
			get
			{
				return (long)this.cs;
			}
			set
			{
				this.cs = (uint)value;
			}
		}

		/// <summary>
		/// Contains transport-specific message envelope information.
		/// </summary>
		/// <value>The transport message headers.</value>
		public string TransportMessageHeaders
		{
			get
			{
				return this.bj;
			}
			set
			{
				this.bj = value;
			}
		}

		/// <summary>
		/// Contains the TTY/TDD telephone number for the contact.
		/// </summary>
		/// <value>The tty TDD phone.</value>
		public string TtyTddPhone
		{
			get
			{
				return this.ey;
			}
			set
			{
				this.ey = value;
			}
		}

		/// <summary>
		/// Contains the wedding anniversary date for the contact.
		/// </summary>
		/// <value>The wedding anniversary.</value>
		public DateTime WeddingAnniversary
		{
			get
			{
				return this.ez;
			}
			set
			{
				this.ez = value;
			}
		}

		/// <summary>
		/// Initializes a new instance of the Message class.
		/// </summary>
		public Message()
		{
			this.bn.Add(StoreSupportMask.Attachments);
			this.bn.Add(StoreSupportMask.Categorize);
			this.bn.Add(StoreSupportMask.Create);
			this.bn.Add(StoreSupportMask.EntryIdUnique);
			this.bn.Add(StoreSupportMask.Html);
			this.bn.Add(StoreSupportMask.ItemProc);
			this.bn.Add(StoreSupportMask.Modify);
			this.bn.Add(StoreSupportMask.MultiValueProperties);
			this.bn.Add(StoreSupportMask.Notify);
			this.bn.Add(StoreSupportMask.Ole);
			this.bn.Add(StoreSupportMask.Pusher);
			this.bn.Add(StoreSupportMask.ReadOnly);
			this.bn.Add(StoreSupportMask.Restrictions);
			this.bn.Add(StoreSupportMask.Rtf);
			this.bn.Add(StoreSupportMask.Search);
			this.bn.Add(StoreSupportMask.Sort);
			this.bn.Add(StoreSupportMask.Submit);
			this.bn.Add(StoreSupportMask.UncompressedRtf);
			this.bn.Add(StoreSupportMask.Unicode);
		}

		/// <summary>
		/// Initializes a new instance of the Message class based on the supplied file.
		/// </summary>
		/// <param name="filePath">File path.</param>
		public Message(string filePath) : this()
		{
			this.Open(filePath);
		}

		/// <summary>
		/// Initializes a new instance of the Message class based on the supplied stream.
		/// </summary>
		/// <param name="stream">A stream.</param>
		public Message(System.IO.Stream stream) : this()
		{
			this.Open(stream);
		}

		/// <summary>
		/// Initializes a new instance of the Message class from the specified MIME message.
		/// </summary>
		/// <param name="mimeMessage">The MIME message.</param>
		public Message(Independentsoft.Email.Mime.Message mimeMessage) : this()
		{
			this.a(mimeMessage);
		}

		private Message(DirectoryEntryList A_0, bool A_1)
		{
			this.fx = A_1;
			this.a(A_0);
		}

		private void a(System.IO.Stream A_0)
		{
			d.a();
			CompoundFile compoundFile = new CompoundFile(A_0);
			Storage item = (Storage)compoundFile.Root.DirectoryEntries["__nameid_version1.0"];
			Independentsoft.IO.StructuredStorage.Stream stream = (Independentsoft.IO.StructuredStorage.Stream)item.DirectoryEntries["__substg1.0_00020102"];
			Independentsoft.IO.StructuredStorage.Stream item1 = (Independentsoft.IO.StructuredStorage.Stream)item.DirectoryEntries["__substg1.0_00030102"];
			Independentsoft.IO.StructuredStorage.Stream stream1 = (Independentsoft.IO.StructuredStorage.Stream)item.DirectoryEntries["__substg1.0_00040102"];
			IDictionary<string, string> strs = new Dictionary<string, string>();
			this.fr = new List<c>();
			if (item1 != null)
			{
				uint size = (uint)item1.Size / 8;
				byte[] buffer = item1.Buffer;
				for (int i = 0; (long)i < (ulong)size; i++)
				{
					uint num = BitConverter.ToUInt32(buffer, i * 8);
					uint num1 = BitConverter.ToUInt32(buffer, i * 8 + 4);
					ushort num2 = (ushort)(num1 >> 16);
					ushort num3 = (ushort)(num1 << 16 >> 16);
					ushort num4 = (ushort)(num3 >> 1);
					ushort num5 = (ushort)(num3 << 15);
					c _c = new c();
					if (num5 != 0)
					{
						int num6 = (int)num;
						byte[] numArray = stream1.Buffer;
						uint num7 = BitConverter.ToUInt32(numArray, num6);
						string str = System.Text.Encoding.Unicode.GetString(numArray, num6 + 4, (int)num7);
						_c.a(str);
						_c.a(g.b);
					}
					else
					{
						_c.a(num);
						_c.a(g.a);
					}
					if (num4 == 1)
					{
						_c.a(StandardPropertySet.Mapi);
					}
					else if (num4 == 2)
					{
						_c.a(StandardPropertySet.PublicStrings);
					}
					else if (num4 > 2)
					{
						int num8 = num4 - 3;
						byte[] buffer1 = stream.Buffer;
						byte[] numArray1 = new byte[16];
						Array.Copy(buffer1, num8 * 16, numArray1, 0, 16);
						_c.a(numArray1);
					}
					if (_c.a() > 0)
					{
						string str1 = m.a(_c.a(), _c.b());
						string str2 = string.Format("{0:X4}", 32768 + num2);
						if (!strs.ContainsKey(str1))
						{
							strs.Add(str1, str2);
						}
					}
					else if (_c.d() != null)
					{
						string str3 = m.a(_c.d(), _c.b());
						string str4 = string.Format("{0:X4}", 32768 + num2);
						if (!strs.ContainsKey(str3))
						{
							strs.Add(str3, str4);
						}
					}
					this.fr.Add(_c);
				}
			}
			for (int j = 0; j < this.fr.Count; j++)
			{
				c _c1 = this.fr[j];
				if (_c1.d() != null)
				{
					ExtendedPropertyName extendedPropertyName = new ExtendedPropertyName(_c1.d(), _c1.b());
					ExtendedProperty extendedProperty = new ExtendedProperty(extendedPropertyName);
					this.fq.Add(extendedProperty);
				}
				else if (_c1.a() > 0)
				{
					ExtendedPropertyId extendedPropertyId = new ExtendedPropertyId((int)_c1.a(), _c1.b());
					ExtendedProperty extendedProperty1 = new ExtendedProperty(extendedPropertyId);
					this.fq.Add(extendedProperty1);
				}
			}
			this.a(compoundFile.Root.DirectoryEntries, strs);
		}

		private void a(DirectoryEntryList A_0)
		{
			this.a(A_0, null);
		}

		private void a(DirectoryEntryList A_0, IDictionary<string, string> A_1)
		{
			DateTime dateTime;
			q item;
			q _q;
			q item1;
			q _q1;
			q item2;
			q _q2;
			q item3;
			q _q3;
			q item4;
			q _q4;
			q item5;
			q _q5;
			q item6;
			q _q6;
			q item7;
			q _q7;
			q item8;
			q _q8;
			q item9;
			q _q9;
			q item10;
			q _q10;
			q item11;
			q _q11;
			q item12;
			q _q12;
			q item13;
			q _q13;
			q item14;
			q _q14;
			q item15;
			q _q15;
			q item16;
			q _q16;
			q item17;
			q _q17;
			q item18;
			q _q18;
			q item19;
			q _q19;
			q item20;
			q _q20;
			q item21;
			q _q21;
			q item22;
			q _q22;
			q item23;
			q _q23;
			q item24;
			q _q24;
			q item25;
			q _q25;
			q item26;
			q _q26;
			q item27;
			q _q27;
			q item28;
			q _q28;
			q item29;
			q _q29;
			q item30;
			q _q30;
			q item31;
			q _q31;
			q item32;
			q _q32;
			q item33;
			q _q33;
			q item34;
			q _q34;
			q item35;
			q _q35;
			q item36;
			q _q36;
			q item37;
			q _q37;
			q item38;
			q _q38;
			q item39;
			q _q39;
			q item40;
			q _q40;
			q item41;
			q _q41;
			q item42;
			q _q42;
			q item43;
			q _q43;
			q item44;
			q _q44;
			q item45;
			q _q45;
			q item46;
			q _q46;
			q item47;
			q _q47;
			q item48;
			q _q48;
			q item49;
			q _q49;
			q item50;
			q _q50;
			q item51;
			q _q51;
			q item52;
			q _q52;
			q item53;
			q _q53;
			q item54;
			q _q54;
			q item55;
			q _q55;
			q item56;
			q _q56;
			q item57;
			q _q57;
			q item58;
			q _q58;
			q item59;
			q _q59;
			q item60;
			q _q60;
			q item61;
			q _q61;
			q item62;
			q _q62;
			q item63;
			q _q63;
			q item64;
			q _q64;
			q item65;
			q _q65;
			q item66;
			q _q66;
			q item67;
			int num = 24;
			this.a = new Dictionary<string, q>();
			Independentsoft.IO.StructuredStorage.Stream stream = (Independentsoft.IO.StructuredStorage.Stream)A_0["__properties_version1.0"];
			uint num1 = 0;
			uint num2 = 0;
			if (stream != null)
			{
				BitConverter.ToUInt32(stream.Buffer, 0);
				BitConverter.ToUInt32(stream.Buffer, 4);
				BitConverter.ToUInt32(stream.Buffer, 8);
				BitConverter.ToUInt32(stream.Buffer, 12);
				num1 = BitConverter.ToUInt32(stream.Buffer, 16);
				num2 = BitConverter.ToUInt32(stream.Buffer, 20);
			}
			if (!this.fx)
			{
				if (stream != null)
				{
					BitConverter.ToUInt32(stream.Buffer, 24);
					BitConverter.ToUInt32(stream.Buffer, 28);
				}
				num = 32;
			}
			if (stream != null && stream.Buffer != null)
			{
				for (int i = num; i < (int)stream.Buffer.Length; i = i + 16)
				{
					byte[] numArray = new byte[16];
					Array.Copy(stream.Buffer, i, numArray, 0, 16);
					q _q67 = new q(numArray);
					if (_q67.e() > 0)
					{
						string str = string.Concat("__substg1.0_", string.Format("{0:X8}", _q67.a()));
						Independentsoft.IO.StructuredStorage.Stream stream1 = (Independentsoft.IO.StructuredStorage.Stream)A_0[str];
						if (stream1 != null && stream1.Buffer != null && (int)stream1.Buffer.Length > 0)
						{
							_q67.b(new byte[(int)stream1.Buffer.Length]);
							Array.Copy(stream1.Buffer, 0, _q67.c(), 0, (int)_q67.c().Length);
						}
					}
					string str1 = string.Format("{0:X8}", _q67.a());
					try
					{
						this.a.Add(str1, _q67);
					}
					catch (ArgumentException argumentException)
					{
					}
				}
			}
			if (this.a.ContainsKey("3FDE0003"))
			{
				item = this.a["3FDE0003"];
			}
			else
			{
				item = null;
			}
			q _q68 = item;
			if (_q68 != null && _q68.c() != null)
			{
				this.ai = BitConverter.ToUInt32(_q68.c(), 0);
			}
			if (this.a.ContainsKey("3FFD0003"))
			{
				_q = this.a["3FFD0003"];
			}
			else
			{
				_q = null;
			}
			q _q69 = _q;
			if (_q69 != null && _q69.c() != null)
			{
				this.af = BitConverter.ToUInt32(_q69.c(), 0);
			}
			if (this.a.ContainsKey("340D0003"))
			{
				item1 = this.a["340D0003"];
			}
			else
			{
				item1 = null;
			}
			q _q70 = item1;
			if (_q70 != null && _q70.c() != null)
			{
				uint num3 = BitConverter.ToUInt32(_q70.c(), 0);
				this.bn = h.u(num3);
				if ((num3 & 262144) == 262144)
				{
					this.fw = System.Text.Encoding.Unicode;
					this.fs = "001F";
					this.ft = 31;
					this.fu = "101F";
					this.fv = 4127;
				}
			}
			else if (this.ai > 0)
			{
				try
				{
					this.fw = System.Text.Encoding.GetEncoding((int)this.ai);
				}
				catch
				{
				}
			}
			else if (this.af > 0)
			{
				try
				{
					this.fw = System.Text.Encoding.GetEncoding((int)this.af);
				}
				catch
				{
				}
			}
			if (this.a.ContainsKey("30070040"))
			{
				_q1 = this.a["30070040"];
			}
			else
			{
				_q1 = null;
			}
			q _q71 = _q1;
			if (_q71 != null && _q71.c() != null)
			{
				uint num4 = BitConverter.ToUInt32(_q71.c(), 0);
				ulong num5 = (ulong)BitConverter.ToUInt32(_q71.c(), 4);
				if (num5 > (long)0)
				{
					long num6 = (long)((ulong)num4 + (num5 << 32));
					DateTime dateTime1 = new DateTime(1601, 1, 1);
					try
					{
						dateTime = dateTime1.AddTicks(num6);
						this.s = dateTime.ToLocalTime();
					}
					catch (Exception exception)
					{
					}
				}
			}
			if (this.a.ContainsKey("30080040"))
			{
				item2 = this.a["30080040"];
			}
			else
			{
				item2 = null;
			}
			q _q72 = item2;
			if (_q72 != null && _q72.c() != null)
			{
				uint num7 = BitConverter.ToUInt32(_q72.c(), 0);
				ulong num8 = (ulong)BitConverter.ToUInt32(_q72.c(), 4);
				if (num8 > (long)0)
				{
					long num9 = (long)((ulong)num7 + (num8 << 32));
					DateTime dateTime2 = new DateTime(1601, 1, 1);
					try
					{
						dateTime = dateTime2.AddTicks(num9);
						this.t = dateTime.ToLocalTime();
					}
					catch (Exception exception1)
					{
					}
				}
			}
			if (this.a.ContainsKey("0E060040"))
			{
				_q2 = this.a["0E060040"];
			}
			else
			{
				_q2 = null;
			}
			q _q73 = _q2;
			if (_q73 != null && _q73.c() != null)
			{
				uint num10 = BitConverter.ToUInt32(_q73.c(), 0);
				ulong num11 = (ulong)BitConverter.ToUInt32(_q73.c(), 4);
				if (num11 > (long)0)
				{
					long num12 = (long)((ulong)num10 + (num11 << 32));
					DateTime dateTime3 = new DateTime(1601, 1, 1);
					try
					{
						dateTime = dateTime3.AddTicks(num12);
						this.u = dateTime.ToLocalTime();
					}
					catch (Exception exception2)
					{
					}
				}
			}
			if (this.a.ContainsKey("00390040"))
			{
				item3 = this.a["00390040"];
			}
			else
			{
				item3 = null;
			}
			q _q74 = item3;
			if (_q74 != null && _q74.c() != null)
			{
				uint num13 = BitConverter.ToUInt32(_q74.c(), 0);
				ulong num14 = (ulong)BitConverter.ToUInt32(_q74.c(), 4);
				if (num14 > (long)0)
				{
					long num15 = (long)((ulong)num13 + (num14 << 32));
					DateTime dateTime4 = new DateTime(1601, 1, 1);
					try
					{
						dateTime = dateTime4.AddTicks(num15);
						this.v = dateTime.ToLocalTime();
					}
					catch (Exception exception3)
					{
					}
				}
			}
			if (this.a.ContainsKey("000F0040"))
			{
				_q3 = this.a["000F0040"];
			}
			else
			{
				_q3 = null;
			}
			q _q75 = _q3;
			if (_q75 != null && _q75.c() != null)
			{
				uint num16 = BitConverter.ToUInt32(_q75.c(), 0);
				ulong num17 = (ulong)BitConverter.ToUInt32(_q75.c(), 4);
				if (num17 > (long)0)
				{
					long num18 = (long)((ulong)num16 + (num17 << 32));
					DateTime dateTime5 = new DateTime(1601, 1, 1);
					try
					{
						dateTime = dateTime5.AddTicks(num18);
						this.w = dateTime.ToLocalTime();
					}
					catch (Exception exception4)
					{
					}
				}
			}
			if (this.a.ContainsKey("00480040"))
			{
				item4 = this.a["00480040"];
			}
			else
			{
				item4 = null;
			}
			q _q76 = item4;
			if (_q76 != null && _q76.c() != null)
			{
				uint num19 = BitConverter.ToUInt32(_q76.c(), 0);
				ulong num20 = (ulong)BitConverter.ToUInt32(_q76.c(), 4);
				if (num20 > (long)0)
				{
					long num21 = (long)((ulong)num19 + (num20 << 32));
					DateTime dateTime6 = new DateTime(1601, 1, 1);
					try
					{
						dateTime = dateTime6.AddTicks(num21);
						this.x = dateTime.ToLocalTime();
					}
					catch (Exception exception5)
					{
					}
				}
			}
			if (this.a.ContainsKey("00320040"))
			{
				_q4 = this.a["00320040"];
			}
			else
			{
				_q4 = null;
			}
			q _q77 = _q4;
			if (_q77 != null && _q77.c() != null)
			{
				uint num22 = BitConverter.ToUInt32(_q77.c(), 0);
				ulong num23 = (ulong)BitConverter.ToUInt32(_q77.c(), 4);
				if (num23 > (long)0)
				{
					long num24 = (long)((ulong)num22 + (num23 << 32));
					DateTime dateTime7 = new DateTime(1601, 1, 1);
					try
					{
						dateTime = dateTime7.AddTicks(num24);
						this.y = dateTime.ToLocalTime();
					}
					catch (Exception exception6)
					{
					}
				}
			}
			if (this.a.ContainsKey("10820040"))
			{
				item5 = this.a["10820040"];
			}
			else
			{
				item5 = null;
			}
			q _q78 = item5;
			if (_q78 != null && _q78.c() != null)
			{
				uint num25 = BitConverter.ToUInt32(_q78.c(), 0);
				ulong num26 = (ulong)BitConverter.ToUInt32(_q78.c(), 4);
				if (num26 > (long)0)
				{
					long num27 = (long)((ulong)num25 + (num26 << 32));
					DateTime dateTime8 = new DateTime(1601, 1, 1);
					try
					{
						dateTime = dateTime8.AddTicks(num27);
						this.bk = dateTime.ToLocalTime();
					}
					catch (Exception exception7)
					{
					}
				}
			}
			if (this.a.ContainsKey("10800003"))
			{
				_q5 = this.a["10800003"];
			}
			else
			{
				_q5 = null;
			}
			q _q79 = _q5;
			if (_q79 != null && _q79.c() != null)
			{
				this.ag = BitConverter.ToUInt32(_q79.c(), 0);
			}
			if (this.a.ContainsKey("0E080003"))
			{
				item6 = this.a["0E080003"];
			}
			else
			{
				item6 = null;
			}
			q _q80 = item6;
			if (_q80 != null && _q80.c() != null)
			{
				this.ah = BitConverter.ToUInt32(_q80.c(), 0);
			}
			if (this.a.ContainsKey("0E070003"))
			{
				_q6 = this.a["0E070003"];
			}
			else
			{
				_q6 = null;
			}
			q _q81 = _q6;
			if (_q81 != null && _q81.c() != null)
			{
				uint num28 = BitConverter.ToUInt32(_q81.c(), 0);
				this.bm = h.t(num28);
			}
			if (this.a.ContainsKey("10F4000B"))
			{
				item7 = this.a["10F4000B"];
			}
			else
			{
				item7 = null;
			}
			q _q82 = item7;
			if (_q82 != null && _q82.c() != null && BitConverter.ToUInt16(_q82.c(), 0) > 0)
			{
				this.ak = true;
			}
			if (this.a.ContainsKey("10F6000B"))
			{
				_q7 = this.a["10F6000B"];
			}
			else
			{
				_q7 = null;
			}
			q _q83 = _q7;
			if (_q83 != null && _q83.c() != null && BitConverter.ToUInt16(_q83.c(), 0) > 0)
			{
				this.al = true;
			}
			if (this.a.ContainsKey("10F5000B"))
			{
				item8 = this.a["10F5000B"];
			}
			else
			{
				item8 = null;
			}
			q _q84 = item8;
			if (_q84 != null && _q84.c() != null && BitConverter.ToUInt16(_q84.c(), 0) > 0)
			{
				this.am = true;
			}
			if (this.a.ContainsKey("10F2000B"))
			{
				_q8 = this.a["10F2000B"];
			}
			else
			{
				_q8 = null;
			}
			q _q85 = _q8;
			if (_q85 != null && _q85.c() != null && BitConverter.ToUInt16(_q85.c(), 0) > 0)
			{
				this.an = true;
			}
			if (this.a.ContainsKey("0E1B000B"))
			{
				item9 = this.a["0E1B000B"];
			}
			else
			{
				item9 = null;
			}
			q _q86 = item9;
			if (_q86 != null && _q86.c() != null && BitConverter.ToUInt16(_q86.c(), 0) > 0)
			{
				this.ao = true;
			}
			if (this.a.ContainsKey("0E1F000B"))
			{
				_q9 = this.a["0E1F000B"];
			}
			else
			{
				_q9 = null;
			}
			q _q87 = _q9;
			if (_q87 != null && _q87.c() != null && BitConverter.ToUInt16(_q87.c(), 0) > 0)
			{
				this.ap = true;
			}
			if (this.a.ContainsKey("0029000B"))
			{
				item10 = this.a["0029000B"];
			}
			else
			{
				item10 = null;
			}
			q _q88 = item10;
			if (_q88 != null && _q88.c() != null && BitConverter.ToUInt16(_q88.c(), 0) > 0)
			{
				this.aq = true;
			}
			if (this.a.ContainsKey("0023000B"))
			{
				_q10 = this.a["0023000B"];
			}
			else
			{
				_q10 = null;
			}
			q _q89 = _q10;
			if (_q89 != null && _q89.c() != null && BitConverter.ToUInt16(_q89.c(), 0) > 0)
			{
				this.ar = true;
			}
			if (this.a.ContainsKey("00360003"))
			{
				item11 = this.a["00360003"];
			}
			else
			{
				item11 = null;
			}
			q _q90 = item11;
			if (_q90 != null && _q90.c() != null)
			{
				uint num29 = BitConverter.ToUInt32(_q90.c(), 0);
				this.at = h.l(num29);
			}
			if (this.a.ContainsKey("10810003"))
			{
				_q11 = this.a["10810003"];
			}
			else
			{
				_q11 = null;
			}
			q _q91 = _q11;
			if (_q91 != null && _q91.c() != null)
			{
				uint num30 = BitConverter.ToUInt32(_q91.c(), 0);
				this.bl = h.w(num30);
			}
			if (this.a.ContainsKey("00170003"))
			{
				item12 = this.a["00170003"];
			}
			else
			{
				item12 = null;
			}
			q _q92 = item12;
			if (_q92 != null && _q92.c() != null)
			{
				uint num31 = BitConverter.ToUInt32(_q92.c(), 0);
				this.au = h.k(num31);
			}
			if (this.a.ContainsKey("00260003"))
			{
				_q12 = this.a["00260003"];
			}
			else
			{
				_q12 = null;
			}
			q _q93 = _q12;
			if (_q93 != null && _q93.c() != null)
			{
				uint num32 = BitConverter.ToUInt32(_q93.c(), 0);
				this.av = h.m(num32);
			}
			if (this.a.ContainsKey("10950003"))
			{
				item13 = this.a["10950003"];
			}
			else
			{
				item13 = null;
			}
			q _q94 = item13;
			if (_q94 != null && _q94.c() != null)
			{
				uint num33 = BitConverter.ToUInt32(_q94.c(), 0);
				this.aw = h.s(num33);
			}
			if (this.a.ContainsKey("10900003"))
			{
				_q13 = this.a["10900003"];
			}
			else
			{
				_q13 = null;
			}
			q _q95 = _q13;
			if (_q95 != null && _q95.c() != null)
			{
				uint num34 = BitConverter.ToUInt32(_q95.c(), 0);
				this.ax = h.q(num34);
			}
			if (this.a.ContainsKey("0FFE0003"))
			{
				item14 = this.a["0FFE0003"];
			}
			else
			{
				item14 = null;
			}
			q _q96 = item14;
			if (_q96 != null && _q96.c() != null)
			{
				uint num35 = BitConverter.ToUInt32(_q96.c(), 0);
				this.ay = h.v(num35);
			}
			string str2 = m.a(34132, StandardPropertySet.Common);
			if (A_1 != null && A_1.ContainsKey(str2) && A_1[str2] != null)
			{
				string str3 = A_1[str2];
				str3 = string.Concat(str3, this.fs);
				if (this.a.ContainsKey(str3))
				{
					item67 = this.a[str3];
				}
				else
				{
					item67 = null;
				}
				q _q97 = item67;
				if (_q97 != null && _q97.c() != null)
				{
					this.bo = this.fw.GetString(_q97.c(), 0, (int)_q97.c().Length);
				}
			}
			string str4 = m.a(34130, StandardPropertySet.Common);
			if (A_1 != null && A_1.ContainsKey(str4) && A_1[str4] != null)
			{
				string str5 = A_1[str4];
				str5 = string.Concat(str5, "0003");
				if (this.a.ContainsKey(str5))
				{
					_q66 = this.a[str5];
				}
				else
				{
					_q66 = null;
				}
				q _q98 = _q66;
				if (_q98 != null && _q98.c() != null)
				{
					this.bp = BitConverter.ToUInt32(_q98.c(), 0);
				}
			}
			string str6 = m.a(34070, StandardPropertySet.Common);
			if (A_1 != null && A_1.ContainsKey(str6) && A_1[str6] != null)
			{
				string str7 = A_1[str6];
				str7 = string.Concat(str7, "0040");
				if (this.a.ContainsKey(str7))
				{
					item66 = this.a[str7];
				}
				else
				{
					item66 = null;
				}
				q _q99 = item66;
				if (_q99 != null && _q99.c() != null)
				{
					uint num36 = BitConverter.ToUInt32(_q99.c(), 0);
					ulong num37 = (ulong)BitConverter.ToUInt32(_q99.c(), 4);
					if (num37 > (long)0)
					{
						long num38 = (long)((ulong)num36 + (num37 << 32));
						DateTime dateTime9 = new DateTime(1601, 1, 1);
						try
						{
							dateTime = dateTime9.AddTicks(num38);
							this.bq = dateTime.ToLocalTime();
						}
						catch (Exception exception8)
						{
						}
					}
				}
			}
			string str8 = m.a(34071, StandardPropertySet.Common);
			if (A_1 != null && A_1.ContainsKey(str8) && A_1[str8] != null)
			{
				string str9 = A_1[str8];
				str9 = string.Concat(str9, "0040");
				if (this.a.ContainsKey(str9))
				{
					_q65 = this.a[str9];
				}
				else
				{
					_q65 = null;
				}
				q _q100 = _q65;
				if (_q100 != null && _q100.c() != null)
				{
					uint num39 = BitConverter.ToUInt32(_q100.c(), 0);
					ulong num40 = (ulong)BitConverter.ToUInt32(_q100.c(), 4);
					if (num40 > (long)0)
					{
						long num41 = (long)((ulong)num39 + (num40 << 32));
						DateTime dateTime10 = new DateTime(1601, 1, 1);
						try
						{
							dateTime = dateTime10.AddTicks(num41);
							this.br = dateTime.ToLocalTime();
						}
						catch (Exception exception9)
						{
						}
					}
				}
			}
			string str10 = m.a(34144, StandardPropertySet.Common);
			if (A_1 != null && A_1.ContainsKey(str10) && A_1[str10] != null)
			{
				string str11 = A_1[str10];
				str11 = string.Concat(str11, "0040");
				if (this.a.ContainsKey(str11))
				{
					item65 = this.a[str11];
				}
				else
				{
					item65 = null;
				}
				q _q101 = item65;
				if (_q101 != null && _q101.c() != null)
				{
					uint num42 = BitConverter.ToUInt32(_q101.c(), 0);
					ulong num43 = (ulong)BitConverter.ToUInt32(_q101.c(), 4);
					if (num43 > (long)0)
					{
						long num44 = (long)((ulong)num42 + (num43 << 32));
						DateTime dateTime11 = new DateTime(1601, 1, 1);
						try
						{
							dateTime = dateTime11.AddTicks(num44);
							this.bs = dateTime.ToLocalTime();
						}
						catch (Exception exception10)
						{
						}
					}
				}
			}
			string str12 = m.a(34105, StandardPropertySet.Common);
			if (A_1 != null && A_1.ContainsKey(str12) && A_1[str12] != null)
			{
				string str13 = A_1[str12];
				str13 = string.Concat(str13, this.fu);
				if (this.a.ContainsKey(str13))
				{
					_q64 = this.a[str13];
				}
				else
				{
					_q64 = null;
				}
				q _q102 = _q64;
				if (_q102 != null && _q102.c() != null)
				{
					uint num45 = _q102.e() / 4;
					this.bw = new List<string>();
					for (int j = 0; (long)j < (ulong)num45; j++)
					{
						string str14 = string.Concat("__substg1.0_", str13, "-", string.Format("{0:X8}", j));
						Independentsoft.IO.StructuredStorage.Stream stream2 = (Independentsoft.IO.StructuredStorage.Stream)A_0[str14];
						if (stream2 != null && stream2.Buffer != null)
						{
							this.bw.Add(this.fw.GetString(stream2.Buffer, 0, (int)stream2.Buffer.Length - (int)this.fw.GetBytes("\0").Length));
						}
					}
				}
			}
			string str15 = m.a(34106, StandardPropertySet.Common);
			if (A_1 != null && A_1.ContainsKey(str15) && A_1[str15] != null)
			{
				string str16 = A_1[str15];
				str16 = string.Concat(str16, this.fu);
				if (this.a.ContainsKey(str16))
				{
					item64 = this.a[str16];
				}
				else
				{
					item64 = null;
				}
				q _q103 = item64;
				if (_q103 != null && _q103.c() != null)
				{
					uint num46 = _q103.e() / 4;
					this.bx = new List<string>();
					for (int k = 0; (long)k < (ulong)num46; k++)
					{
						string str17 = string.Concat("__substg1.0_", str16, "-", string.Format("{0:X8}", k));
						Independentsoft.IO.StructuredStorage.Stream stream3 = (Independentsoft.IO.StructuredStorage.Stream)A_0[str17];
						if (stream3 != null && stream3.Buffer != null)
						{
							this.bx.Add(this.fw.GetString(stream3.Buffer, 0, (int)stream3.Buffer.Length - (int)this.fw.GetBytes("\0").Length));
						}
					}
				}
			}
			string str18 = m.a("Keywords", StandardPropertySet.PublicStrings);
			if (A_1 != null && A_1.ContainsKey(str18) && A_1[str18] != null)
			{
				string str19 = A_1[str18];
				str19 = string.Concat(str19, this.fu);
				if (this.a.ContainsKey(str19))
				{
					_q63 = this.a[str19];
				}
				else
				{
					_q63 = null;
				}
				q _q104 = _q63;
				if (_q104 != null && _q104.c() != null)
				{
					uint num47 = _q104.e() / 4;
					this.by = new List<string>();
					for (int l = 0; (long)l < (ulong)num47; l++)
					{
						string str20 = string.Concat("__substg1.0_", str19, "-", string.Format("{0:X8}", l));
						Independentsoft.IO.StructuredStorage.Stream stream4 = (Independentsoft.IO.StructuredStorage.Stream)A_0[str20];
						int length = (int)this.fw.GetBytes("\0").Length;
						if (stream4 != null && stream4.Buffer != null && (int)stream4.Buffer.Length >= length)
						{
							this.by.Add(this.fw.GetString(stream4.Buffer, 0, (int)stream4.Buffer.Length - length));
						}
					}
				}
			}
			string str21 = m.a(34101, StandardPropertySet.Common);
			if (A_1 != null && A_1.ContainsKey(str21) && A_1[str21] != null)
			{
				string str22 = A_1[str21];
				str22 = string.Concat(str22, this.fs);
				if (this.a.ContainsKey(str22))
				{
					item63 = this.a[str22];
				}
				else
				{
					item63 = null;
				}
				q _q105 = item63;
				if (_q105 != null && _q105.c() != null)
				{
					this.bz = this.fw.GetString(_q105.c(), 0, (int)_q105.c().Length);
				}
			}
			string str23 = m.a(34100, StandardPropertySet.Common);
			if (A_1 != null && A_1.ContainsKey(str23) && A_1[str23] != null)
			{
				string str24 = A_1[str23];
				str24 = string.Concat(str24, this.fs);
				if (this.a.ContainsKey(str24))
				{
					_q62 = this.a[str24];
				}
				else
				{
					_q62 = null;
				}
				q _q106 = _q62;
				if (_q106 != null && _q106.c() != null)
				{
					this.b0 = this.fw.GetString(_q106.c(), 0, (int)_q106.c().Length);
				}
			}
			string str25 = m.a(34176, StandardPropertySet.Common);
			if (A_1 != null && A_1.ContainsKey(str25) && A_1[str25] != null)
			{
				string str26 = A_1[str25];
				str26 = string.Concat(str26, this.fs);
				if (this.a.ContainsKey(str26))
				{
					item62 = this.a[str26];
				}
				else
				{
					item62 = null;
				}
				q _q107 = item62;
				if (_q107 != null && _q107.c() != null)
				{
					this.b6 = this.fw.GetString(_q107.c(), 0, (int)_q107.c().Length);
				}
			}
			string str27 = m.a(34079, StandardPropertySet.Common);
			if (A_1 != null && A_1.ContainsKey(str27) && A_1[str27] != null)
			{
				string str28 = A_1[str27];
				str28 = string.Concat(str28, this.fs);
				if (this.a.ContainsKey(str28))
				{
					_q61 = this.a[str28];
				}
				else
				{
					_q61 = null;
				}
				q _q108 = _q61;
				if (_q108 != null && _q108.c() != null)
				{
					this.b1 = this.fw.GetString(_q108.c(), 0, (int)_q108.c().Length);
				}
			}
			string str29 = m.a(34054, StandardPropertySet.Common);
			if (A_1 != null && A_1.ContainsKey(str29) && A_1[str29] != null)
			{
				string str30 = A_1[str29];
				str30 = string.Concat(str30, "000B");
				if (this.a.ContainsKey(str30))
				{
					item61 = this.a[str30];
				}
				else
				{
					item61 = null;
				}
				q _q109 = item61;
				if (_q109 != null && _q109.c() != null && BitConverter.ToUInt16(_q109.c(), 0) > 0)
				{
					this.b2 = true;
				}
			}
			string str31 = m.a(34076, StandardPropertySet.Common);
			if (A_1 != null && A_1.ContainsKey(str31) && A_1[str31] != null)
			{
				string str32 = A_1[str31];
				str32 = string.Concat(str32, "000B");
				if (this.a.ContainsKey(str32))
				{
					_q60 = this.a[str32];
				}
				else
				{
					_q60 = null;
				}
				q _q110 = _q60;
				if (_q110 != null && _q110.c() != null && BitConverter.ToUInt16(_q110.c(), 0) > 0)
				{
					this.b4 = true;
				}
			}
			string str33 = m.a(34078, StandardPropertySet.Common);
			if (A_1 != null && A_1.ContainsKey(str33) && A_1[str33] != null)
			{
				string str34 = A_1[str33];
				str34 = string.Concat(str34, "000B");
				if (this.a.ContainsKey(str34))
				{
					item60 = this.a[str34];
				}
				else
				{
					item60 = null;
				}
				q _q111 = item60;
				if (_q111 != null && _q111.c() != null && BitConverter.ToUInt16(_q111.c(), 0) > 0)
				{
					this.b5 = true;
				}
			}
			string str35 = m.a(33293, StandardPropertySet.Appointment);
			if (A_1 != null && A_1.ContainsKey(str35) && A_1[str35] != null)
			{
				string str36 = A_1[str35];
				str36 = string.Concat(str36, "0040");
				if (this.a.ContainsKey(str36))
				{
					_q59 = this.a[str36];
				}
				else
				{
					_q59 = null;
				}
				q _q112 = _q59;
				if (_q112 != null && _q112.c() != null)
				{
					uint num48 = BitConverter.ToUInt32(_q112.c(), 0);
					ulong num49 = (ulong)BitConverter.ToUInt32(_q112.c(), 4);
					if (num49 > (long)0)
					{
						long num50 = (long)((ulong)num48 + (num49 << 32));
						DateTime dateTime12 = new DateTime(1601, 1, 1);
						try
						{
							dateTime = dateTime12.AddTicks(num50);
							this.b7 = dateTime.ToLocalTime();
						}
						catch (Exception exception11)
						{
						}
					}
				}
			}
			string str37 = m.a(33294, StandardPropertySet.Appointment);
			if (A_1 != null && A_1.ContainsKey(str37) && A_1[str37] != null)
			{
				string str38 = A_1[str37];
				str38 = string.Concat(str38, "0040");
				if (this.a.ContainsKey(str38))
				{
					item59 = this.a[str38];
				}
				else
				{
					item59 = null;
				}
				q _q113 = item59;
				if (_q113 != null && _q113.c() != null)
				{
					uint num51 = BitConverter.ToUInt32(_q113.c(), 0);
					ulong num52 = (ulong)BitConverter.ToUInt32(_q113.c(), 4);
					if (num52 > (long)0)
					{
						long num53 = (long)((ulong)num51 + (num52 << 32));
						DateTime dateTime13 = new DateTime(1601, 1, 1);
						try
						{
							dateTime = dateTime13.AddTicks(num53);
							this.b8 = dateTime.ToLocalTime();
						}
						catch (Exception exception12)
						{
						}
					}
				}
			}
			string str39 = m.a(33288, StandardPropertySet.Appointment);
			if (A_1 != null && A_1.ContainsKey(str39) && A_1[str39] != null)
			{
				string str40 = A_1[str39];
				str40 = string.Concat(str40, this.fs);
				if (this.a.ContainsKey(str40))
				{
					_q58 = this.a[str40];
				}
				else
				{
					_q58 = null;
				}
				q _q114 = _q58;
				if (_q114 != null && _q114.c() != null)
				{
					this.ca = this.fw.GetString(_q114.c(), 0, (int)_q114.c().Length);
				}
			}
			string str41 = m.a(36, new byte[] { 144, 218, 216, 110, 11, 69, 27, 16, 152, 218, 0, 170, 0, 63, 19, 5 });
			if (A_1 != null && A_1.ContainsKey(str41) && A_1[str41] != null)
			{
				string str42 = A_1[str41];
				str42 = string.Concat(str42, this.fs);
				if (this.a.ContainsKey(str42))
				{
					item58 = this.a[str42];
				}
				else
				{
					item58 = null;
				}
				q _q115 = item58;
				if (_q115 != null && _q115.c() != null)
				{
					this.cf = this.fw.GetString(_q115.c(), 0, (int)_q115.c().Length);
				}
			}
			string str43 = m.a(33332, StandardPropertySet.Appointment);
			if (A_1 != null && A_1.ContainsKey(str43) && A_1[str43] != null)
			{
				string str44 = A_1[str43];
				str44 = string.Concat(str44, this.fs);
				if (this.a.ContainsKey(str44))
				{
					_q57 = this.a[str44];
				}
				else
				{
					_q57 = null;
				}
				q _q116 = _q57;
				if (_q116 != null && _q116.c() != null)
				{
					this.cg = this.fw.GetString(_q116.c(), 0, (int)_q116.c().Length);
				}
			}
			string str45 = m.a(33330, StandardPropertySet.Appointment);
			if (A_1 != null && A_1.ContainsKey(str45) && A_1[str45] != null)
			{
				string str46 = A_1[str45];
				str46 = string.Concat(str46, this.fs);
				if (this.a.ContainsKey(str46))
				{
					item57 = this.a[str46];
				}
				else
				{
					item57 = null;
				}
				q _q117 = item57;
				if (_q117 != null && _q117.c() != null)
				{
					this.ch = this.fw.GetString(_q117.c(), 0, (int)_q117.c().Length);
				}
			}
			string str47 = m.a(33302, StandardPropertySet.Appointment);
			if (A_1 != null && A_1.ContainsKey(str47) && A_1[str47] != null)
			{
				string str48 = A_1[str47];
				str48 = string.Concat(str48, "0102");
				if (this.a.ContainsKey(str48))
				{
					_q56 = this.a[str48];
				}
				else
				{
					_q56 = null;
				}
				q _q118 = _q56;
				if (_q118 != null && _q118.c() != null)
				{
					this.ci = new Independentsoft.Msg.RecurrencePattern(_q118.c());
				}
			}
			string str49 = m.a(33046, StandardPropertySet.Task);
			if (A_1 != null && A_1.ContainsKey(str49) && A_1[str49] != null)
			{
				string str50 = A_1[str49];
				str50 = string.Concat(str50, "0102");
				if (this.a.ContainsKey(str50))
				{
					item56 = this.a[str50];
				}
				else
				{
					item56 = null;
				}
				q _q119 = item56;
				if (_q119 != null && _q119.c() != null)
				{
					this.ci = new Independentsoft.Msg.RecurrencePattern(_q119.c());
				}
			}
			string str51 = m.a(33285, StandardPropertySet.Appointment);
			if (A_1 != null && A_1.ContainsKey(str51) && A_1[str51] != null)
			{
				string str52 = A_1[str51];
				str52 = string.Concat(str52, "0003");
				if (this.a.ContainsKey(str52))
				{
					_q55 = this.a[str52];
				}
				else
				{
					_q55 = null;
				}
				q _q120 = _q55;
				if (_q120 != null && _q120.c() != null)
				{
					uint num54 = BitConverter.ToUInt32(_q120.c(), 0);
					this.cb = h.h(num54);
				}
			}
			string str53 = m.a(33303, StandardPropertySet.Appointment);
			if (A_1 != null && A_1.ContainsKey(str53) && A_1[str53] != null)
			{
				string str54 = A_1[str53];
				str54 = string.Concat(str54, "0003");
				if (this.a.ContainsKey(str54))
				{
					item55 = this.a[str54];
				}
				else
				{
					item55 = null;
				}
				q _q121 = item55;
				if (_q121 != null && _q121.c() != null)
				{
					uint num55 = BitConverter.ToUInt32(_q121.c(), 0);
					this.cc = h.e(num55);
				}
			}
			string str55 = m.a(33304, StandardPropertySet.Appointment);
			if (A_1 != null && A_1.ContainsKey(str55) && A_1[str55] != null)
			{
				string str56 = A_1[str55];
				str56 = string.Concat(str56, "0003");
				if (this.a.ContainsKey(str56))
				{
					_q54 = this.a[str56];
				}
				else
				{
					_q54 = null;
				}
				q _q122 = _q54;
				if (_q122 != null && _q122.c() != null)
				{
					uint num56 = BitConverter.ToUInt32(_q122.c(), 0);
					this.cd = h.f(num56);
				}
			}
			string str57 = m.a(33329, StandardPropertySet.Appointment);
			if (A_1 != null && A_1.ContainsKey(str57) && A_1[str57] != null)
			{
				string str58 = A_1[str57];
				str58 = string.Concat(str58, "0003");
				if (this.a.ContainsKey(str58))
				{
					item54 = this.a[str58];
				}
				else
				{
					item54 = null;
				}
				q _q123 = item54;
				if (_q123 != null && _q123.c() != null)
				{
					uint num57 = BitConverter.ToUInt32(_q123.c(), 0);
					this.ce = h.g(num57);
				}
			}
			string str59 = m.a(3, new byte[] { 144, 218, 216, 110, 11, 69, 27, 16, 152, 218, 0, 170, 0, 63, 19, 5 });
			if (A_1 != null && A_1.ContainsKey(str59) && A_1[str59] != null)
			{
				string str60 = A_1[str59];
				str60 = string.Concat(str60, "0102");
				if (this.a.ContainsKey(str60))
				{
					_q53 = this.a[str60];
				}
				else
				{
					_q53 = null;
				}
				q _q124 = _q53;
				if (_q124 != null && _q124.c() != null)
				{
					this.cj = _q124.c();
				}
			}
			string str61 = m.a(33300, StandardPropertySet.Appointment);
			if (A_1 != null && A_1.ContainsKey(str61) && A_1[str61] != null)
			{
				string str62 = A_1[str61];
				str62 = string.Concat(str62, "0003");
				if (this.a.ContainsKey(str62))
				{
					item53 = this.a[str62];
				}
				else
				{
					item53 = null;
				}
				q _q125 = item53;
				if (_q125 != null && _q125.c() != null)
				{
					this.ck = BitConverter.ToInt32(_q125.c(), 0);
				}
			}
			string str63 = m.a(33299, StandardPropertySet.Appointment);
			if (A_1 != null && A_1.ContainsKey(str63) && A_1[str63] != null)
			{
				string str64 = A_1[str63];
				str64 = string.Concat(str64, "0003");
				if (this.a.ContainsKey(str64))
				{
					_q52 = this.a[str64];
				}
				else
				{
					_q52 = null;
				}
				q _q126 = _q52;
				if (_q126 != null && _q126.c() != null)
				{
					this.cl = BitConverter.ToUInt32(_q126.c(), 0);
				}
			}
			string str65 = m.a(33055, StandardPropertySet.Task);
			if (A_1 != null && A_1.ContainsKey(str65) && A_1[str65] != null)
			{
				string str66 = A_1[str65];
				str66 = string.Concat(str66, this.fs);
				if (this.a.ContainsKey(str66))
				{
					item52 = this.a[str66];
				}
				else
				{
					item52 = null;
				}
				q _q127 = item52;
				if (_q127 != null && _q127.c() != null)
				{
					this.co = this.fw.GetString(_q127.c(), 0, (int)_q127.c().Length);
				}
			}
			string str67 = m.a(33057, StandardPropertySet.Task);
			if (A_1 != null && A_1.ContainsKey(str67) && A_1[str67] != null)
			{
				string item68 = A_1[str67];
				item68 = string.Concat(item68, this.fs);
				if (this.a.ContainsKey(item68))
				{
					_q51 = this.a[item68];
				}
				else
				{
					_q51 = null;
				}
				q _q128 = _q51;
				if (_q128 != null && _q128.c() != null)
				{
					this.cp = this.fw.GetString(_q128.c(), 0, (int)_q128.c().Length);
				}
			}
			string str68 = m.a(33026, StandardPropertySet.Task);
			if (A_1 != null && A_1.ContainsKey(str68) && A_1[str68] != null)
			{
				string item69 = A_1[str68];
				item69 = string.Concat(item69, "0005");
				if (this.a.ContainsKey(item69))
				{
					item51 = this.a[item69];
				}
				else
				{
					item51 = null;
				}
				q _q129 = item51;
				if (_q129 != null && _q129.c() != null)
				{
					this.cq = BitConverter.ToDouble(_q129.c(), 0);
					this.cq = this.cq * 100;
				}
			}
			string str69 = m.a(33040, StandardPropertySet.Task);
			if (A_1 != null && A_1.ContainsKey(str69) && A_1[str69] != null)
			{
				string item70 = A_1[str69];
				item70 = string.Concat(item70, "0003");
				if (this.a.ContainsKey(item70))
				{
					_q50 = this.a[item70];
				}
				else
				{
					_q50 = null;
				}
				q _q130 = _q50;
				if (_q130 != null && _q130.c() != null)
				{
					this.cr = BitConverter.ToUInt32(_q130.c(), 0);
				}
			}
			string str70 = m.a(33041, StandardPropertySet.Task);
			if (A_1 != null && A_1.ContainsKey(str70) && A_1[str70] != null)
			{
				string item71 = A_1[str70];
				item71 = string.Concat(item71, "0003");
				if (this.a.ContainsKey(item71))
				{
					item50 = this.a[item71];
				}
				else
				{
					item50 = null;
				}
				q _q131 = item50;
				if (_q131 != null && _q131.c() != null)
				{
					this.cs = BitConverter.ToUInt32(_q131.c(), 0);
				}
			}
			string str71 = m.a(33027, StandardPropertySet.Task);
			if (A_1 != null && A_1.ContainsKey(str71) && A_1[str71] != null)
			{
				string item72 = A_1[str71];
				item72 = string.Concat(item72, "000B");
				if (this.a.ContainsKey(item72))
				{
					_q49 = this.a[item72];
				}
				else
				{
					_q49 = null;
				}
				q _q132 = _q49;
				if (_q132 != null && _q132.c() != null && BitConverter.ToUInt16(_q132.c(), 0) > 0)
				{
					this.ct = true;
				}
			}
			string str72 = m.a(33052, StandardPropertySet.Task);
			if (A_1 != null && A_1.ContainsKey(str72) && A_1[str72] != null)
			{
				string item73 = A_1[str72];
				item73 = string.Concat(item73, "000B");
				if (this.a.ContainsKey(item73))
				{
					item49 = this.a[item73];
				}
				else
				{
					item49 = null;
				}
				q _q133 = item49;
				if (_q133 != null && _q133.c() != null && BitConverter.ToUInt16(_q133.c(), 0) > 0)
				{
					this.cu = true;
				}
			}
			string str73 = m.a(33315, StandardPropertySet.Appointment);
			if (A_1 != null && A_1.ContainsKey(str73) && A_1[str73] != null)
			{
				string item74 = A_1[str73];
				item74 = string.Concat(item74, "000B");
				if (this.a.ContainsKey(item74))
				{
					_q48 = this.a[item74];
				}
				else
				{
					_q48 = null;
				}
				q _q134 = _q48;
				if (_q134 != null && _q134.c() != null && BitConverter.ToUInt16(_q134.c(), 0) > 0)
				{
					this.bt = true;
				}
			}
			string str74 = m.a(33301, StandardPropertySet.Appointment);
			if (A_1 != null && A_1.ContainsKey(str74) && A_1[str74] != null)
			{
				string item75 = A_1[str74];
				item75 = string.Concat(item75, "000B");
				if (this.a.ContainsKey(item75))
				{
					item48 = this.a[item75];
				}
				else
				{
					item48 = null;
				}
				q _q135 = item48;
				if (_q135 != null && _q135.c() != null && BitConverter.ToUInt16(_q135.c(), 0) > 0)
				{
					this.b9 = true;
				}
			}
			string str75 = m.a(34051, StandardPropertySet.Common);
			if (A_1 != null && A_1.ContainsKey(str75) && A_1[str75] != null)
			{
				string item76 = A_1[str75];
				item76 = string.Concat(item76, "000B");
				if (this.a.ContainsKey(item76))
				{
					_q47 = this.a[item76];
				}
				else
				{
					_q47 = null;
				}
				q _q136 = _q47;
				if (_q136 != null && _q136.c() != null && BitConverter.ToUInt16(_q136.c(), 0) > 0)
				{
					this.b3 = true;
				}
			}
			string str76 = m.a(34050, StandardPropertySet.Common);
			if (A_1 != null && A_1.ContainsKey(str76) && A_1[str76] != null)
			{
				string item77 = A_1[str76];
				item77 = string.Concat(item77, "0040");
				if (this.a.ContainsKey(item77))
				{
					item47 = this.a[item77];
				}
				else
				{
					item47 = null;
				}
				q _q137 = item47;
				if (_q137 != null && _q137.c() != null)
				{
					uint num58 = BitConverter.ToUInt32(_q137.c(), 0);
					ulong num59 = (ulong)BitConverter.ToUInt32(_q137.c(), 4);
					if (num59 > (long)0)
					{
						long num60 = (long)((ulong)num58 + (num59 << 32));
						DateTime dateTime14 = new DateTime(1601, 1, 1);
						try
						{
							dateTime = dateTime14.AddTicks(num60);
							this.bu = dateTime.ToLocalTime();
						}
						catch (Exception exception13)
						{
						}
					}
				}
			}
			string str77 = m.a(34049, StandardPropertySet.Common);
			if (A_1 != null && A_1.ContainsKey(str77) && A_1[str77] != null)
			{
				string item78 = A_1[str77];
				item78 = string.Concat(item78, "0003");
				if (this.a.ContainsKey(item78))
				{
					_q46 = this.a[item78];
				}
				else
				{
					_q46 = null;
				}
				q _q138 = _q46;
				if (_q138 != null && _q138.c() != null)
				{
					this.bv = BitConverter.ToUInt32(_q138.c(), 0);
				}
			}
			string str78 = m.a(33028, StandardPropertySet.Task);
			if (A_1 != null && A_1.ContainsKey(str78) && A_1[str78] != null)
			{
				string item79 = A_1[str78];
				item79 = string.Concat(item79, "0040");
				if (this.a.ContainsKey(item79))
				{
					item46 = this.a[item79];
				}
				else
				{
					item46 = null;
				}
				q _q139 = item46;
				if (_q139 != null && _q139.c() != null)
				{
					uint num61 = BitConverter.ToUInt32(_q139.c(), 0);
					ulong num62 = (ulong)BitConverter.ToUInt32(_q139.c(), 4);
					if (num62 > (long)0)
					{
						long num63 = (long)((ulong)num61 + (num62 << 32));
						DateTime dateTime15 = new DateTime(1601, 1, 1);
						try
						{
							dateTime = dateTime15.AddTicks(num63);
							this.cm = dateTime.ToLocalTime();
						}
						catch (Exception exception14)
						{
						}
					}
				}
			}
			string str79 = m.a(33029, StandardPropertySet.Task);
			if (A_1 != null && A_1.ContainsKey(str79) && A_1[str79] != null)
			{
				string item80 = A_1[str79];
				item80 = string.Concat(item80, "0040");
				if (this.a.ContainsKey(item80))
				{
					_q45 = this.a[item80];
				}
				else
				{
					_q45 = null;
				}
				q _q140 = _q45;
				if (_q140 != null && _q140.c() != null)
				{
					uint num64 = BitConverter.ToUInt32(_q140.c(), 0);
					ulong num65 = (ulong)BitConverter.ToUInt32(_q140.c(), 4);
					if (num65 > (long)0)
					{
						long num66 = (long)((ulong)num64 + (num65 << 32));
						DateTime dateTime16 = new DateTime(1601, 1, 1);
						try
						{
							dateTime = dateTime16.AddTicks(num66);
							this.cn = dateTime.ToLocalTime();
						}
						catch (Exception exception15)
						{
						}
					}
				}
			}
			string str80 = m.a(33039, StandardPropertySet.Task);
			if (A_1 != null && A_1.ContainsKey(str80) && A_1[str80] != null)
			{
				string item81 = A_1[str80];
				item81 = string.Concat(item81, "0040");
				if (this.a.ContainsKey(item81))
				{
					item45 = this.a[item81];
				}
				else
				{
					item45 = null;
				}
				q _q141 = item45;
				if (_q141 != null && _q141.c() != null)
				{
					uint num67 = BitConverter.ToUInt32(_q141.c(), 0);
					ulong num68 = (ulong)BitConverter.ToUInt32(_q141.c(), 4);
					if (num68 > (long)0)
					{
						long num69 = (long)((ulong)num67 + (num68 << 32));
						DateTime dateTime17 = new DateTime(1601, 1, 1);
						try
						{
							dateTime = dateTime17.AddTicks(num69);
							this.cv = dateTime.ToLocalTime();
						}
						catch (Exception exception16)
						{
						}
					}
				}
			}
			string str81 = m.a(33025, StandardPropertySet.Task);
			if (A_1 != null && A_1.ContainsKey(str81) && A_1[str81] != null)
			{
				string item82 = A_1[str81];
				item82 = string.Concat(item82, "0003");
				if (this.a.ContainsKey(item82))
				{
					_q44 = this.a[item82];
				}
				else
				{
					_q44 = null;
				}
				q _q142 = _q44;
				if (_q142 != null && _q142.c() != null)
				{
					uint num70 = BitConverter.ToUInt32(_q142.c(), 0);
					this.cw = h.d(num70);
				}
			}
			string str82 = m.a(33065, StandardPropertySet.Task);
			if (A_1 != null && A_1.ContainsKey(str82) && A_1[str82] != null)
			{
				string item83 = A_1[str82];
				item83 = string.Concat(item83, "0003");
				if (this.a.ContainsKey(item83))
				{
					item44 = this.a[item83];
				}
				else
				{
					item44 = null;
				}
				q _q143 = item44;
				if (_q143 != null && _q143.c() != null)
				{
					uint num71 = BitConverter.ToUInt32(_q143.c(), 0);
					this.cx = h.j(num71);
				}
			}
			string str83 = m.a(33066, StandardPropertySet.Task);
			if (A_1 != null && A_1.ContainsKey(str83) && A_1[str83] != null)
			{
				string item84 = A_1[str83];
				item84 = string.Concat(item84, "0003");
				if (this.a.ContainsKey(item84))
				{
					_q43 = this.a[item84];
				}
				else
				{
					_q43 = null;
				}
				q _q144 = _q43;
				if (_q144 != null && _q144.c() != null)
				{
					uint num72 = BitConverter.ToUInt32(_q144.c(), 0);
					this.cy = h.i(num72);
				}
			}
			string str84 = m.a(35589, StandardPropertySet.Note);
			if (A_1 != null && A_1.ContainsKey(str84) && A_1[str84] != null)
			{
				string item85 = A_1[str84];
				item85 = string.Concat(item85, "0003");
				if (this.a.ContainsKey(item85))
				{
					item43 = this.a[item85];
				}
				else
				{
					item43 = null;
				}
				q _q145 = item43;
				if (_q145 != null && _q145.c() != null)
				{
					this.c2 = BitConverter.ToUInt32(_q145.c(), 0);
				}
			}
			string str85 = m.a(35588, StandardPropertySet.Note);
			if (A_1 != null && A_1.ContainsKey(str85) && A_1[str85] != null)
			{
				string item86 = A_1[str85];
				item86 = string.Concat(item86, "0003");
				if (this.a.ContainsKey(item86))
				{
					_q42 = this.a[item86];
				}
				else
				{
					_q42 = null;
				}
				q _q146 = _q42;
				if (_q146 != null && _q146.c() != null)
				{
					this.c1 = BitConverter.ToUInt32(_q146.c(), 0);
				}
			}
			string str86 = m.a(35587, StandardPropertySet.Note);
			if (A_1 != null && A_1.ContainsKey(str86) && A_1[str86] != null)
			{
				string item87 = A_1[str86];
				item87 = string.Concat(item87, "0003");
				if (this.a.ContainsKey(item87))
				{
					item42 = this.a[item87];
				}
				else
				{
					item42 = null;
				}
				q _q147 = item42;
				if (_q147 != null && _q147.c() != null)
				{
					this.c0 = BitConverter.ToUInt32(_q147.c(), 0);
				}
			}
			string str87 = m.a(35586, StandardPropertySet.Note);
			if (A_1 != null && A_1.ContainsKey(str87) && A_1[str87] != null)
			{
				string item88 = A_1[str87];
				item88 = string.Concat(item88, "0003");
				if (this.a.ContainsKey(item88))
				{
					_q41 = this.a[item88];
				}
				else
				{
					_q41 = null;
				}
				q _q148 = _q41;
				if (_q148 != null && _q148.c() != null)
				{
					this.cz = BitConverter.ToUInt32(_q148.c(), 0);
				}
			}
			string str88 = m.a(35584, StandardPropertySet.Note);
			if (A_1 != null && A_1.ContainsKey(str88) && A_1[str88] != null)
			{
				string item89 = A_1[str88];
				item89 = string.Concat(item89, "0003");
				if (this.a.ContainsKey(item89))
				{
					item41 = this.a[item89];
				}
				else
				{
					item41 = null;
				}
				q _q149 = item41;
				if (_q149 != null && _q149.c() != null)
				{
					uint num73 = BitConverter.ToUInt32(_q149.c(), 0);
					this.c3 = h.o(num73);
				}
			}
			string str89 = m.a(34566, StandardPropertySet.Journal);
			if (A_1 != null && A_1.ContainsKey(str89) && A_1[str89] != null)
			{
				string item90 = A_1[str89];
				item90 = string.Concat(item90, "0040");
				if (this.a.ContainsKey(item90))
				{
					_q40 = this.a[item90];
				}
				else
				{
					_q40 = null;
				}
				q _q150 = _q40;
				if (_q150 != null && _q150.c() != null)
				{
					uint num74 = BitConverter.ToUInt32(_q150.c(), 0);
					ulong num75 = (ulong)BitConverter.ToUInt32(_q150.c(), 4);
					if (num75 > (long)0)
					{
						long num76 = (long)((ulong)num74 + (num75 << 32));
						DateTime dateTime18 = new DateTime(1601, 1, 1);
						try
						{
							dateTime = dateTime18.AddTicks(num76);
							this.c4 = dateTime.ToLocalTime();
						}
						catch (Exception exception17)
						{
						}
					}
				}
			}
			string str90 = m.a(34568, StandardPropertySet.Journal);
			if (A_1 != null && A_1.ContainsKey(str90) && A_1[str90] != null)
			{
				string item91 = A_1[str90];
				item91 = string.Concat(item91, "0040");
				if (this.a.ContainsKey(item91))
				{
					item40 = this.a[item91];
				}
				else
				{
					item40 = null;
				}
				q _q151 = item40;
				if (_q151 != null && _q151.c() != null)
				{
					uint num77 = BitConverter.ToUInt32(_q151.c(), 0);
					ulong num78 = (ulong)BitConverter.ToUInt32(_q151.c(), 4);
					if (num78 > (long)0)
					{
						long num79 = (long)((ulong)num77 + (num78 << 32));
						DateTime dateTime19 = new DateTime(1601, 1, 1);
						try
						{
							dateTime = dateTime19.AddTicks(num79);
							this.c5 = dateTime.ToLocalTime();
						}
						catch (Exception exception18)
						{
						}
					}
				}
			}
			string str91 = m.a(34560, StandardPropertySet.Journal);
			if (A_1 != null && A_1.ContainsKey(str91) && A_1[str91] != null)
			{
				string item92 = A_1[str91];
				item92 = string.Concat(item92, this.fs);
				if (this.a.ContainsKey(item92))
				{
					_q39 = this.a[item92];
				}
				else
				{
					_q39 = null;
				}
				q _q152 = _q39;
				if (_q152 != null && _q152.c() != null)
				{
					this.c6 = this.fw.GetString(_q152.c(), 0, (int)_q152.c().Length);
				}
			}
			string str92 = m.a(34578, StandardPropertySet.Journal);
			if (A_1 != null && A_1.ContainsKey(str92) && A_1[str92] != null)
			{
				string item93 = A_1[str92];
				item93 = string.Concat(item93, this.fs);
				if (this.a.ContainsKey(item93))
				{
					item39 = this.a[item93];
				}
				else
				{
					item39 = null;
				}
				q _q153 = item39;
				if (_q153 != null && _q153.c() != null)
				{
					this.c7 = this.fw.GetString(_q153.c(), 0, (int)_q153.c().Length);
				}
			}
			string str93 = m.a(34567, StandardPropertySet.Journal);
			if (A_1 != null && A_1.ContainsKey(str93) && A_1[str93] != null)
			{
				string item94 = A_1[str93];
				item94 = string.Concat(item94, "0003");
				if (this.a.ContainsKey(item94))
				{
					_q38 = this.a[item94];
				}
				else
				{
					_q38 = null;
				}
				q _q154 = _q38;
				if (_q154 != null && _q154.c() != null)
				{
					this.c8 = BitConverter.ToUInt32(_q154.c(), 0);
				}
			}
			if (this.a.ContainsKey("3A420040"))
			{
				_q14 = this.a["3A420040"];
			}
			else
			{
				_q14 = null;
			}
			q _q155 = _q14;
			if (_q155 != null && _q155.c() != null)
			{
				uint num80 = BitConverter.ToUInt32(_q155.c(), 0);
				ulong num81 = (ulong)BitConverter.ToUInt32(_q155.c(), 4);
				if (num81 > (long)0)
				{
					long num82 = (long)((ulong)num80 + (num81 << 32));
					DateTime dateTime20 = new DateTime(1601, 1, 1);
					try
					{
						dateTime = dateTime20.AddTicks(num82);
						this.c9 = dateTime.ToLocalTime();
					}
					catch (Exception exception19)
					{
					}
				}
			}
			if (this.a.ContainsKey(string.Concat("3A58", this.fu)))
			{
				item15 = this.a[string.Concat("3A58", this.fu)];
			}
			else
			{
				item15 = null;
			}
			q _q156 = item15;
			if (_q156 != null && _q156.c() != null)
			{
				uint num83 = _q156.e() / 4;
				this.da = new List<string>();
				for (int m = 0; (long)m < (ulong)num83; m++)
				{
					string str94 = string.Concat("__substg1.0_3A58", this.fu, "-", string.Format("{0:X8}", m));
					Independentsoft.IO.StructuredStorage.Stream stream5 = (Independentsoft.IO.StructuredStorage.Stream)A_0[str94];
					if (stream5 != null && stream5.Buffer != null)
					{
						this.da.Add(this.fw.GetString(stream5.Buffer, 0, (int)stream5.Buffer.Length - (int)this.fw.GetBytes("\0").Length));
					}
				}
			}
			if (this.a.ContainsKey("3A410040"))
			{
				_q15 = this.a["3A410040"];
			}
			else
			{
				_q15 = null;
			}
			q _q157 = _q15;
			if (_q157 != null && _q157.c() != null)
			{
				uint num84 = BitConverter.ToUInt32(_q157.c(), 0);
				ulong num85 = (ulong)BitConverter.ToUInt32(_q157.c(), 4);
				if (num85 > (long)0)
				{
					long num86 = (long)((ulong)num84 + (num85 << 32));
					DateTime dateTime21 = new DateTime(1601, 1, 1);
					try
					{
						dateTime = dateTime21.AddTicks(num86);
						this.ez = dateTime.ToLocalTime();
					}
					catch (Exception exception20)
					{
					}
				}
			}
			if (this.a.ContainsKey("3A4D0002"))
			{
				item16 = this.a["3A4D0002"];
			}
			else
			{
				item16 = null;
			}
			q _q158 = item16;
			if (_q158 != null && _q158.c() != null)
			{
				short num87 = BitConverter.ToInt16(_q158.c(), 0);
				this.e0 = h.d(num87);
			}
			string str95 = m.a(32802, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str95) && A_1[str95] != null)
			{
				string item95 = A_1[str95];
				item95 = string.Concat(item95, "0003");
				if (this.a.ContainsKey(item95))
				{
					item38 = this.a[item95];
				}
				else
				{
					item38 = null;
				}
				q _q159 = item38;
				if (_q159 != null && _q159.c() != null)
				{
					uint num88 = BitConverter.ToUInt32(_q159.c(), 0);
					this.e1 = h.r(num88);
				}
			}
			string str96 = m.a(32789, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str96) && A_1[str96] != null)
			{
				string item96 = A_1[str96];
				item96 = string.Concat(item96, "000B");
				if (this.a.ContainsKey(item96))
				{
					_q37 = this.a[item96];
				}
				else
				{
					_q37 = null;
				}
				q _q160 = _q37;
				if (_q160 != null && _q160.c() != null && BitConverter.ToUInt16(_q160.c(), 0) > 0)
				{
					this.e2 = true;
				}
			}
			string str97 = m.a(32773, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str97) && A_1[str97] != null)
			{
				string item97 = A_1[str97];
				item97 = string.Concat(item97, this.fs);
				if (this.a.ContainsKey(item97))
				{
					item37 = this.a[item97];
				}
				else
				{
					item37 = null;
				}
				q _q161 = item37;
				if (_q161 != null && _q161.c() != null)
				{
					this.e3 = this.fw.GetString(_q161.c(), 0, (int)_q161.c().Length);
				}
			}
			string str98 = m.a(32866, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str98) && A_1[str98] != null)
			{
				string item98 = A_1[str98];
				item98 = string.Concat(item98, this.fs);
				if (this.a.ContainsKey(item98))
				{
					_q36 = this.a[item98];
				}
				else
				{
					_q36 = null;
				}
				q _q162 = _q36;
				if (_q162 != null && _q162.c() != null)
				{
					this.e4 = this.fw.GetString(_q162.c(), 0, (int)_q162.c().Length);
				}
			}
			string str99 = m.a(32984, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str99) && A_1[str99] != null)
			{
				string item99 = A_1[str99];
				item99 = string.Concat(item99, this.fs);
				if (this.a.ContainsKey(item99))
				{
					item36 = this.a[item99];
				}
				else
				{
					item36 = null;
				}
				q _q163 = item36;
				if (_q163 != null && _q163.c() != null)
				{
					this.e5 = this.fw.GetString(_q163.c(), 0, (int)_q163.c().Length);
				}
			}
			string str100 = m.a(32795, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str100) && A_1[str100] != null)
			{
				string item100 = A_1[str100];
				item100 = string.Concat(item100, this.fs);
				if (this.a.ContainsKey(item100))
				{
					_q35 = this.a[item100];
				}
				else
				{
					_q35 = null;
				}
				q _q164 = _q35;
				if (_q164 != null && _q164.c() != null)
				{
					this.e6 = this.fw.GetString(_q164.c(), 0, (int)_q164.c().Length);
				}
			}
			string str101 = m.a(32837, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str101) && A_1[str101] != null)
			{
				string item101 = A_1[str101];
				item101 = string.Concat(item101, this.fs);
				if (this.a.ContainsKey(item101))
				{
					item35 = this.a[item101];
				}
				else
				{
					item35 = null;
				}
				q _q165 = item35;
				if (_q165 != null && _q165.c() != null)
				{
					this.ep = this.fw.GetString(_q165.c(), 0, (int)_q165.c().Length);
				}
			}
			string str102 = m.a(32838, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str102) && A_1[str102] != null)
			{
				string item102 = A_1[str102];
				item102 = string.Concat(item102, this.fs);
				if (this.a.ContainsKey(item102))
				{
					_q34 = this.a[item102];
				}
				else
				{
					_q34 = null;
				}
				q _q166 = _q34;
				if (_q166 != null && _q166.c() != null)
				{
					this.el = this.fw.GetString(_q166.c(), 0, (int)_q166.c().Length);
				}
			}
			string str103 = m.a(32839, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str103) && A_1[str103] != null)
			{
				string item103 = A_1[str103];
				item103 = string.Concat(item103, this.fs);
				if (this.a.ContainsKey(item103))
				{
					item34 = this.a[item103];
				}
				else
				{
					item34 = null;
				}
				q _q167 = item34;
				if (_q167 != null && _q167.c() != null)
				{
					this.eo = this.fw.GetString(_q167.c(), 0, (int)_q167.c().Length);
				}
			}
			string str104 = m.a(32840, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str104) && A_1[str104] != null)
			{
				string item104 = A_1[str104];
				item104 = string.Concat(item104, this.fs);
				if (this.a.ContainsKey(item104))
				{
					_q33 = this.a[item104];
				}
				else
				{
					_q33 = null;
				}
				q _q168 = _q33;
				if (_q168 != null && _q168.c() != null)
				{
					this.em = this.fw.GetString(_q168.c(), 0, (int)_q168.c().Length);
				}
			}
			string str105 = m.a(32841, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str105) && A_1[str105] != null)
			{
				string item105 = A_1[str105];
				item105 = string.Concat(item105, this.fs);
				if (this.a.ContainsKey(item105))
				{
					item33 = this.a[item105];
				}
				else
				{
					item33 = null;
				}
				q _q169 = item33;
				if (_q169 != null && _q169.c() != null)
				{
					this.ek = this.fw.GetString(_q169.c(), 0, (int)_q169.c().Length);
				}
			}
			string str106 = m.a(32794, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str106) && A_1[str106] != null)
			{
				string item106 = A_1[str106];
				item106 = string.Concat(item106, this.fs);
				if (this.a.ContainsKey(item106))
				{
					_q32 = this.a[item106];
				}
				else
				{
					_q32 = null;
				}
				q _q170 = _q32;
				if (_q170 != null && _q170.c() != null)
				{
					this.e7 = this.fw.GetString(_q170.c(), 0, (int)_q170.c().Length);
				}
			}
			string str107 = m.a(32796, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str107) && A_1[str107] != null)
			{
				string item107 = A_1[str107];
				item107 = string.Concat(item107, this.fs);
				if (this.a.ContainsKey(item107))
				{
					item32 = this.a[item107];
				}
				else
				{
					item32 = null;
				}
				q _q171 = item32;
				if (_q171 != null && _q171.c() != null)
				{
					this.e8 = this.fw.GetString(_q171.c(), 0, (int)_q171.c().Length);
				}
			}
			string str108 = m.a(32899, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str108) && A_1[str108] != null)
			{
				string item108 = A_1[str108];
				item108 = string.Concat(item108, this.fs);
				if (this.a.ContainsKey(item108))
				{
					_q31 = this.a[item108];
				}
				else
				{
					_q31 = null;
				}
				q _q172 = _q31;
				if (_q172 != null && _q172.c() != null)
				{
					this.e9 = this.fw.GetString(_q172.c(), 0, (int)_q172.c().Length);
				}
			}
			string str109 = m.a(32915, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str109) && A_1[str109] != null)
			{
				string item109 = A_1[str109];
				item109 = string.Concat(item109, this.fs);
				if (this.a.ContainsKey(item109))
				{
					item31 = this.a[item109];
				}
				else
				{
					item31 = null;
				}
				q _q173 = item31;
				if (_q173 != null && _q173.c() != null)
				{
					this.fa = this.fw.GetString(_q173.c(), 0, (int)_q173.c().Length);
				}
			}
			string str110 = m.a(32931, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str110) && A_1[str110] != null)
			{
				string item110 = A_1[str110];
				item110 = string.Concat(item110, this.fs);
				if (this.a.ContainsKey(item110))
				{
					_q30 = this.a[item110];
				}
				else
				{
					_q30 = null;
				}
				q _q174 = _q30;
				if (_q174 != null && _q174.c() != null)
				{
					this.fb = this.fw.GetString(_q174.c(), 0, (int)_q174.c().Length);
				}
			}
			string str111 = m.a(32900, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str111) && A_1[str111] != null)
			{
				string item111 = A_1[str111];
				item111 = string.Concat(item111, this.fs);
				if (this.a.ContainsKey(item111))
				{
					item30 = this.a[item111];
				}
				else
				{
					item30 = null;
				}
				q _q175 = item30;
				if (_q175 != null && _q175.c() != null)
				{
					this.fc = this.fw.GetString(_q175.c(), 0, (int)_q175.c().Length);
				}
			}
			string str112 = m.a(32916, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str112) && A_1[str112] != null)
			{
				string item112 = A_1[str112];
				item112 = string.Concat(item112, this.fs);
				if (this.a.ContainsKey(item112))
				{
					_q29 = this.a[item112];
				}
				else
				{
					_q29 = null;
				}
				q _q176 = _q29;
				if (_q176 != null && _q176.c() != null)
				{
					this.fd = this.fw.GetString(_q176.c(), 0, (int)_q176.c().Length);
				}
			}
			string str113 = m.a(32932, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str113) && A_1[str113] != null)
			{
				string item113 = A_1[str113];
				item113 = string.Concat(item113, this.fs);
				if (this.a.ContainsKey(item113))
				{
					item29 = this.a[item113];
				}
				else
				{
					item29 = null;
				}
				q _q177 = item29;
				if (_q177 != null && _q177.c() != null)
				{
					this.fe = this.fw.GetString(_q177.c(), 0, (int)_q177.c().Length);
				}
			}
			string str114 = m.a(32896, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str114) && A_1[str114] != null)
			{
				string item114 = A_1[str114];
				item114 = string.Concat(item114, this.fs);
				if (this.a.ContainsKey(item114))
				{
					_q28 = this.a[item114];
				}
				else
				{
					_q28 = null;
				}
				q _q178 = _q28;
				if (_q178 != null && _q178.c() != null)
				{
					this.ff = this.fw.GetString(_q178.c(), 0, (int)_q178.c().Length);
				}
			}
			string str115 = m.a(32912, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str115) && A_1[str115] != null)
			{
				string item115 = A_1[str115];
				item115 = string.Concat(item115, this.fs);
				if (this.a.ContainsKey(item115))
				{
					item28 = this.a[item115];
				}
				else
				{
					item28 = null;
				}
				q _q179 = item28;
				if (_q179 != null && _q179.c() != null)
				{
					this.fg = this.fw.GetString(_q179.c(), 0, (int)_q179.c().Length);
				}
			}
			string str116 = m.a(32928, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str116) && A_1[str116] != null)
			{
				string item116 = A_1[str116];
				item116 = string.Concat(item116, this.fs);
				if (this.a.ContainsKey(item116))
				{
					_q27 = this.a[item116];
				}
				else
				{
					_q27 = null;
				}
				q _q180 = _q27;
				if (_q180 != null && _q180.c() != null)
				{
					this.fh = this.fw.GetString(_q180.c(), 0, (int)_q180.c().Length);
				}
			}
			string str117 = m.a(32898, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str117) && A_1[str117] != null)
			{
				string item117 = A_1[str117];
				item117 = string.Concat(item117, this.fs);
				if (this.a.ContainsKey(item117))
				{
					item27 = this.a[item117];
				}
				else
				{
					item27 = null;
				}
				q _q181 = item27;
				if (_q181 != null && _q181.c() != null)
				{
					this.fi = this.fw.GetString(_q181.c(), 0, (int)_q181.c().Length);
				}
			}
			string str118 = m.a(32914, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str118) && A_1[str118] != null)
			{
				string item118 = A_1[str118];
				item118 = string.Concat(item118, this.fs);
				if (this.a.ContainsKey(item118))
				{
					_q26 = this.a[item118];
				}
				else
				{
					_q26 = null;
				}
				q _q182 = _q26;
				if (_q182 != null && _q182.c() != null)
				{
					this.fj = this.fw.GetString(_q182.c(), 0, (int)_q182.c().Length);
				}
			}
			string str119 = m.a(32930, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str119) && A_1[str119] != null)
			{
				string item119 = A_1[str119];
				item119 = string.Concat(item119, this.fs);
				if (this.a.ContainsKey(item119))
				{
					item26 = this.a[item119];
				}
				else
				{
					item26 = null;
				}
				q _q183 = item26;
				if (_q183 != null && _q183.c() != null)
				{
					this.fk = this.fw.GetString(_q183.c(), 0, (int)_q183.c().Length);
				}
			}
			string str120 = m.a(32901, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str120) && A_1[str120] != null)
			{
				string item120 = A_1[str120];
				item120 = string.Concat(item120, "0102");
				if (this.a.ContainsKey(item120))
				{
					_q25 = this.a[item120];
				}
				else
				{
					_q25 = null;
				}
				q _q184 = _q25;
				if (_q184 != null && _q184.c() != null)
				{
					this.fl = _q184.c();
				}
			}
			string str121 = m.a(32917, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str121) && A_1[str121] != null)
			{
				string item121 = A_1[str121];
				item121 = string.Concat(item121, "0102");
				if (this.a.ContainsKey(item121))
				{
					item25 = this.a[item121];
				}
				else
				{
					item25 = null;
				}
				q _q185 = item25;
				if (_q185 != null && _q185.c() != null)
				{
					this.fm = _q185.c();
				}
			}
			string str122 = m.a(32933, StandardPropertySet.Address);
			if (A_1 != null && A_1.ContainsKey(str122) && A_1[str122] != null)
			{
				string item122 = A_1[str122];
				item122 = string.Concat(item122, "0102");
				if (this.a.ContainsKey(item122))
				{
					_q24 = this.a[item122];
				}
				else
				{
					_q24 = null;
				}
				q _q186 = _q24;
				if (_q186 != null && _q186.c() != null)
				{
					this.fn = _q186.c();
				}
			}
			for (int n = 0; n < this.fq.Count; n++)
			{
				string str123 = null;
				if (!(this.fq[n].Tag is ExtendedPropertyId))
				{
					ExtendedPropertyName tag = (ExtendedPropertyName)this.fq[n].Tag;
					str123 = m.a(tag.Name, tag.Guid);
				}
				else
				{
					ExtendedPropertyId extendedPropertyId = (ExtendedPropertyId)this.fq[n].Tag;
					str123 = m.a((uint)extendedPropertyId.Id, extendedPropertyId.Guid);
				}
				if (A_1 != null && A_1.ContainsKey(str123) && A_1[str123] != null)
				{
					string item123 = A_1[str123];
					foreach (string key in this.a.Keys)
					{
						if (!key.StartsWith(item123))
						{
							continue;
						}
						q item124 = this.a[key];
						this.fq[n].Tag.Type = item124.d();
						if (this.fq[n].Tag.Type != PropertyType.MultipleBinary)
						{
							this.fq[n].Value = item124.c();
						}
						else
						{
							item123 = string.Concat(item123, "1102");
							if (item124 == null || item124.c() == null)
							{
								continue;
							}
							uint num89 = item124.e() / 8;
							IList<byte[]> numArrays = new List<byte[]>();
							for (int o = 0; (long)o < (ulong)num89; o++)
							{
								string str124 = string.Concat("__substg1.0_", item123, "-", string.Format("{0:X8}", o));
								Independentsoft.IO.StructuredStorage.Stream stream6 = (Independentsoft.IO.StructuredStorage.Stream)A_0[str124];
								if (stream6 != null && stream6.Buffer != null)
								{
									numArrays.Add(stream6.Buffer);
								}
							}
							if (numArrays.Count <= 0)
							{
								continue;
							}
							MemoryStream memoryStream = new MemoryStream();
							byte[] bytes = BitConverter.GetBytes(numArrays.Count);
							memoryStream.Write(bytes, 0, 4);
							int length1 = 0;
							for (int p = 0; p < numArrays.Count; p++)
							{
								byte[] numArray1 = numArrays[p];
								byte[] bytes1 = BitConverter.GetBytes(4 + numArrays.Count * 4 + length1);
								memoryStream.Write(bytes1, 0, (int)bytes1.Length);
								length1 = length1 + (int)numArray1.Length;
							}
							for (int q = 0; q < numArrays.Count; q++)
							{
								byte[] numArray2 = numArrays[q];
								memoryStream.Write(numArray2, 0, (int)numArray2.Length);
							}
							this.fq[n].Value = memoryStream.ToArray();
						}
					}
				}
			}
			Independentsoft.IO.StructuredStorage.Stream stream7 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_001A", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream8 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_0037", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream9 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_003D", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream10 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_0070", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream11 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_0E02", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream12 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_0E03", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream13 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_0E04", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream14 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_0074", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream15 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_0050", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream16 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_0E1D", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream17 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_1000", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream18 = (Independentsoft.IO.StructuredStorage.Stream)A_0["__substg1.0_10090102"];
			Independentsoft.IO.StructuredStorage.Stream stream19 = (Independentsoft.IO.StructuredStorage.Stream)A_0["__substg1.0_300B0102"];
			Independentsoft.IO.StructuredStorage.Stream stream20 = (Independentsoft.IO.StructuredStorage.Stream)A_0["__substg1.0_65E20102"];
			Independentsoft.IO.StructuredStorage.Stream stream21 = (Independentsoft.IO.StructuredStorage.Stream)A_0["__substg1.0_0FFF0102"];
			Independentsoft.IO.StructuredStorage.Stream stream22 = (Independentsoft.IO.StructuredStorage.Stream)A_0["__substg1.0_00460102"];
			Independentsoft.IO.StructuredStorage.Stream stream23 = (Independentsoft.IO.StructuredStorage.Stream)A_0["__substg1.0_00530102"];
			Independentsoft.IO.StructuredStorage.Stream stream24 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_1001", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream25 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3FF8", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream26 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3FFA", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream27 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_1035", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream28 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_1042", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream29 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_1039", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream30 = (Independentsoft.IO.StructuredStorage.Stream)A_0["__substg1.0_00710102"];
			Independentsoft.IO.StructuredStorage.Stream stream31 = (Independentsoft.IO.StructuredStorage.Stream)A_0["__substg1.0_10130102"];
			Independentsoft.IO.StructuredStorage.Stream stream32 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_1013", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream33 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_0077", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream34 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_0078", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream35 = (Independentsoft.IO.StructuredStorage.Stream)A_0["__substg1.0_00430102"];
			Independentsoft.IO.StructuredStorage.Stream stream36 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_0044", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream37 = (Independentsoft.IO.StructuredStorage.Stream)A_0["__substg1.0_00520102"];
			Independentsoft.IO.StructuredStorage.Stream stream38 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_0075", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream39 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_0076", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream40 = (Independentsoft.IO.StructuredStorage.Stream)A_0["__substg1.0_003F0102"];
			Independentsoft.IO.StructuredStorage.Stream stream41 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_0040", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream42 = (Independentsoft.IO.StructuredStorage.Stream)A_0["__substg1.0_00510102"];
			Independentsoft.IO.StructuredStorage.Stream stream43 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_0C1E", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream44 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_0C1F", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream45 = (Independentsoft.IO.StructuredStorage.Stream)A_0["__substg1.0_0C190102"];
			Independentsoft.IO.StructuredStorage.Stream stream46 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_0C1A", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream47 = (Independentsoft.IO.StructuredStorage.Stream)A_0["__substg1.0_0C1D0102"];
			Independentsoft.IO.StructuredStorage.Stream stream48 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_0064", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream49 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_0065", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream50 = (Independentsoft.IO.StructuredStorage.Stream)A_0["__substg1.0_00410102"];
			Independentsoft.IO.StructuredStorage.Stream stream51 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_0042", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream52 = (Independentsoft.IO.StructuredStorage.Stream)A_0["__substg1.0_003B0102"];
			Independentsoft.IO.StructuredStorage.Stream stream53 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_007D", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream54 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A30", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream55 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A2E", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream56 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A1B", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream57 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A24", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream58 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A51", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream59 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A02", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream60 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A1E", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream61 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A1C", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream62 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A57", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream63 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A16", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream64 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A49", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream65 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A4A", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream66 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A18", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream67 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3001", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream68 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A45", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream69 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A4C", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream70 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A05", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream71 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A06", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream72 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A07", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream73 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A43", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream74 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A2F", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream75 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A59", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream76 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A5A", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream77 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A5B", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream78 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A5E", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream79 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A5C", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream80 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A5D", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream81 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A25", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream82 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A09", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream83 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A0A", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream84 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A2D", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream85 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A4E", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream86 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A44", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream87 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A4F", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream88 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A19", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream89 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A08", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream90 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A5F", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream91 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A60", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream92 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A61", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream93 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A62", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream94 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A63", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream95 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A1F", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream96 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A21", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream97 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A50", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream98 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A15", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream99 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A27", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream100 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A26", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream101 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A2A", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream102 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A2B", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream103 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A28", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream104 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A29", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream105 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A23", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream106 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A1A", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream107 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A46", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream108 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A1D", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream109 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A48", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream110 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A11", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream111 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A2C", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream112 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A17", this.fs)];
			Independentsoft.IO.StructuredStorage.Stream stream113 = (Independentsoft.IO.StructuredStorage.Stream)A_0[string.Concat("__substg1.0_3A4B", this.fs)];
			if (stream7 != null && stream7.Buffer != null)
			{
				this.b = this.fw.GetString(stream7.Buffer, 0, (int)stream7.Buffer.Length);
			}
			if (stream8 != null && stream8.Buffer != null)
			{
				this.c = this.fw.GetString(stream8.Buffer, 0, (int)stream8.Buffer.Length);
			}
			if (stream9 != null && stream9.Buffer != null)
			{
				this.d = this.fw.GetString(stream9.Buffer, 0, (int)stream9.Buffer.Length);
			}
			if (stream10 != null && stream10.Buffer != null)
			{
				this.e = this.fw.GetString(stream10.Buffer, 0, (int)stream10.Buffer.Length);
			}
			if (stream11 != null && stream11.Buffer != null)
			{
				this.f = this.fw.GetString(stream11.Buffer, 0, (int)stream11.Buffer.Length);
			}
			if (stream12 != null && stream12.Buffer != null)
			{
				this.g = this.fw.GetString(stream12.Buffer, 0, (int)stream12.Buffer.Length);
			}
			if (stream13 != null && stream13.Buffer != null)
			{
				this.h = this.fw.GetString(stream13.Buffer, 0, (int)stream13.Buffer.Length);
			}
			if (stream14 != null && stream14.Buffer != null)
			{
				this.i = this.fw.GetString(stream14.Buffer, 0, (int)stream14.Buffer.Length);
			}
			if (stream15 != null && stream15.Buffer != null)
			{
				this.j = this.fw.GetString(stream15.Buffer, 0, (int)stream15.Buffer.Length);
			}
			if (stream16 != null && stream16.Buffer != null)
			{
				this.k = this.fw.GetString(stream16.Buffer, 0, (int)stream16.Buffer.Length);
			}
			if (stream17 != null && stream17.Buffer != null)
			{
				this.l = this.fw.GetString(stream17.Buffer, 0, (int)stream17.Buffer.Length);
			}
			if (stream18 != null && stream18.Buffer != null)
			{
				this.m = stream18.Buffer;
			}
			if (stream19 != null && stream19.Buffer != null)
			{
				this.n = stream19.Buffer;
			}
			if (stream20 != null && stream20.Buffer != null)
			{
				this.o = stream20.Buffer;
			}
			if (stream21 != null && stream21.Buffer != null)
			{
				this.p = stream21.Buffer;
			}
			if (stream22 != null && stream22.Buffer != null)
			{
				this.q = stream22.Buffer;
			}
			if (stream23 != null && stream23.Buffer != null)
			{
				this.r = stream23.Buffer;
			}
			if (stream24 != null && stream24.Buffer != null)
			{
				this.z = this.fw.GetString(stream24.Buffer, 0, (int)stream24.Buffer.Length);
			}
			if (stream25 != null && stream25.Buffer != null)
			{
				this.aa = this.fw.GetString(stream25.Buffer, 0, (int)stream25.Buffer.Length);
			}
			if (stream26 != null && stream26.Buffer != null)
			{
				this.ab = this.fw.GetString(stream26.Buffer, 0, (int)stream26.Buffer.Length);
			}
			if (stream27 != null && stream27.Buffer != null)
			{
				this.ac = this.fw.GetString(stream27.Buffer, 0, (int)stream27.Buffer.Length);
			}
			if (stream28 != null && stream28.Buffer != null)
			{
				this.ad = this.fw.GetString(stream28.Buffer, 0, (int)stream28.Buffer.Length);
			}
			if (stream29 != null && stream29.Buffer != null)
			{
				this.ae = this.fw.GetString(stream29.Buffer, 0, (int)stream29.Buffer.Length);
			}
			if (stream30 != null && stream30.Buffer != null)
			{
				this.aj = stream30.Buffer;
			}
			if (stream31 != null && stream31.Buffer != null)
			{
				this.@as = stream31.Buffer;
			}
			else if (stream32 != null && stream32.Buffer != null)
			{
				System.Text.Encoding encoding = null;
				try
				{
					encoding = System.Text.Encoding.GetEncoding((int)this.ai);
				}
				catch
				{
				}
				if (this.ai > 0 && encoding != null)
				{
					string str125 = encoding.GetString(stream32.Buffer, 0, (int)stream32.Buffer.Length);
					this.@as = encoding.GetBytes(str125);
				}
				else if (!p.a(stream32.Buffer, (int)stream32.Buffer.Length))
				{
					string str126 = this.fw.GetString(stream32.Buffer, 0, (int)stream32.Buffer.Length);
					System.Text.Encoding uTF7 = System.Text.Encoding.UTF7;
					int num90 = str126.IndexOf("charset=");
					if (num90 > 0)
					{
						int num91 = str126.IndexOf("\"", num90);
						if (num91 != -1)
						{
							string str127 = str126.Substring(num90 + 8, num91 - num90 - 8);
							uTF7 = System.Text.Encoding.GetEncoding(str127);
						}
					}
					str126 = uTF7.GetString(stream32.Buffer, 0, (int)stream32.Buffer.Length);
					this.@as = uTF7.GetBytes(str126);
				}
				else
				{
					System.Text.Encoding uTF8 = System.Text.Encoding.UTF8;
					string str128 = uTF8.GetString(stream32.Buffer, 0, (int)stream32.Buffer.Length);
					this.@as = uTF8.GetBytes(str128);
				}
			}
			if (stream33 != null && stream33.Buffer != null)
			{
				this.az = this.fw.GetString(stream33.Buffer, 0, (int)stream33.Buffer.Length);
			}
			if (stream34 != null && stream34.Buffer != null)
			{
				this.a0 = this.fw.GetString(stream34.Buffer, 0, (int)stream34.Buffer.Length);
			}
			if (stream35 != null && stream35.Buffer != null)
			{
				this.a1 = stream35.Buffer;
			}
			if (stream36 != null && stream36.Buffer != null)
			{
				this.a2 = this.fw.GetString(stream36.Buffer, 0, (int)stream36.Buffer.Length);
			}
			if (stream37 != null && stream37.Buffer != null)
			{
				this.a3 = stream37.Buffer;
			}
			if (stream38 != null && stream38.Buffer != null)
			{
				this.a4 = this.fw.GetString(stream38.Buffer, 0, (int)stream38.Buffer.Length);
			}
			if (stream39 != null && stream39.Buffer != null)
			{
				this.a5 = this.fw.GetString(stream39.Buffer, 0, (int)stream39.Buffer.Length);
			}
			if (stream40 != null && stream40.Buffer != null)
			{
				this.a6 = stream40.Buffer;
			}
			if (stream41 != null && stream41.Buffer != null)
			{
				this.a7 = this.fw.GetString(stream41.Buffer, 0, (int)stream41.Buffer.Length);
			}
			if (stream42 != null && stream42.Buffer != null)
			{
				this.a8 = stream42.Buffer;
			}
			if (stream43 != null && stream43.Buffer != null)
			{
				this.a9 = this.fw.GetString(stream43.Buffer, 0, (int)stream43.Buffer.Length);
			}
			if (stream44 != null && stream44.Buffer != null)
			{
				this.ba = this.fw.GetString(stream44.Buffer, 0, (int)stream44.Buffer.Length);
			}
			if (stream45 != null && stream45.Buffer != null)
			{
				this.bb = stream45.Buffer;
			}
			if (stream46 != null && stream46.Buffer != null)
			{
				this.bc = this.fw.GetString(stream46.Buffer, 0, (int)stream46.Buffer.Length);
			}
			if (stream47 != null && stream47.Buffer != null)
			{
				this.bd = stream47.Buffer;
			}
			if (stream48 != null && stream48.Buffer != null)
			{
				this.be = this.fw.GetString(stream48.Buffer, 0, (int)stream48.Buffer.Length);
			}
			if (stream49 != null && stream49.Buffer != null)
			{
				this.bf = this.fw.GetString(stream49.Buffer, 0, (int)stream49.Buffer.Length);
			}
			if (stream50 != null && stream50.Buffer != null)
			{
				this.bg = stream50.Buffer;
			}
			if (stream51 != null && stream51.Buffer != null)
			{
				this.bh = this.fw.GetString(stream51.Buffer, 0, (int)stream51.Buffer.Length);
			}
			if (stream52 != null && stream52.Buffer != null)
			{
				this.bi = stream52.Buffer;
			}
			if (stream53 != null && stream53.Buffer != null)
			{
				this.bj = this.fw.GetString(stream53.Buffer, 0, (int)stream53.Buffer.Length);
			}
			if (stream54 != null && stream54.Buffer != null)
			{
				this.db = this.fw.GetString(stream54.Buffer, 0, (int)stream54.Buffer.Length);
			}
			if (stream55 != null && stream55.Buffer != null)
			{
				this.dc = this.fw.GetString(stream55.Buffer, 0, (int)stream55.Buffer.Length);
			}
			if (stream56 != null && stream56.Buffer != null)
			{
				this.de = this.fw.GetString(stream56.Buffer, 0, (int)stream56.Buffer.Length);
			}
			if (stream57 != null && stream57.Buffer != null)
			{
				this.df = this.fw.GetString(stream57.Buffer, 0, (int)stream57.Buffer.Length);
			}
			if (stream58 != null && stream58.Buffer != null)
			{
				this.dg = this.fw.GetString(stream58.Buffer, 0, (int)stream58.Buffer.Length);
			}
			if (stream59 != null && stream59.Buffer != null)
			{
				this.dh = this.fw.GetString(stream59.Buffer, 0, (int)stream59.Buffer.Length);
			}
			if (stream60 != null && stream60.Buffer != null)
			{
				this.di = this.fw.GetString(stream60.Buffer, 0, (int)stream60.Buffer.Length);
			}
			if (stream61 != null && stream61.Buffer != null)
			{
				this.dj = this.fw.GetString(stream61.Buffer, 0, (int)stream61.Buffer.Length);
			}
			if (stream62 != null && stream62.Buffer != null)
			{
				this.dk = this.fw.GetString(stream62.Buffer, 0, (int)stream62.Buffer.Length);
			}
			if (stream63 != null && stream63.Buffer != null)
			{
				this.dl = this.fw.GetString(stream63.Buffer, 0, (int)stream63.Buffer.Length);
			}
			if (stream64 != null && stream64.Buffer != null)
			{
				this.dm = this.fw.GetString(stream64.Buffer, 0, (int)stream64.Buffer.Length);
			}
			if (stream100 != null && stream100.Buffer != null)
			{
				this.ek = this.fw.GetString(stream100.Buffer, 0, (int)stream100.Buffer.Length);
			}
			if (stream65 != null && stream65.Buffer != null)
			{
				this.dn = this.fw.GetString(stream65.Buffer, 0, (int)stream65.Buffer.Length);
			}
			if (stream66 != null && stream66.Buffer != null)
			{
				this.@do = this.fw.GetString(stream66.Buffer, 0, (int)stream66.Buffer.Length);
			}
			if (stream67 != null && stream67.Buffer != null)
			{
				this.dp = this.fw.GetString(stream67.Buffer, 0, (int)stream67.Buffer.Length);
			}
			if (stream68 != null && stream68.Buffer != null)
			{
				this.dq = this.fw.GetString(stream68.Buffer, 0, (int)stream68.Buffer.Length);
			}
			if (stream69 != null && stream69.Buffer != null)
			{
				this.dr = this.fw.GetString(stream69.Buffer, 0, (int)stream69.Buffer.Length);
			}
			if (stream70 != null && stream70.Buffer != null)
			{
				this.ds = this.fw.GetString(stream70.Buffer, 0, (int)stream70.Buffer.Length);
			}
			if (stream71 != null && stream71.Buffer != null)
			{
				this.dt = this.fw.GetString(stream71.Buffer, 0, (int)stream71.Buffer.Length);
			}
			if (stream72 != null && stream72.Buffer != null)
			{
				this.du = this.fw.GetString(stream72.Buffer, 0, (int)stream72.Buffer.Length);
			}
			if (stream73 != null && stream73.Buffer != null)
			{
				this.dv = this.fw.GetString(stream73.Buffer, 0, (int)stream73.Buffer.Length);
			}
			if (stream74 != null && stream74.Buffer != null)
			{
				this.dw = this.fw.GetString(stream74.Buffer, 0, (int)stream74.Buffer.Length);
			}
			if (stream75 != null && stream75.Buffer != null)
			{
				this.dx = this.fw.GetString(stream75.Buffer, 0, (int)stream75.Buffer.Length);
			}
			if (stream76 != null && stream76.Buffer != null)
			{
				this.dy = this.fw.GetString(stream76.Buffer, 0, (int)stream76.Buffer.Length);
			}
			if (stream77 != null && stream77.Buffer != null)
			{
				this.dz = this.fw.GetString(stream77.Buffer, 0, (int)stream77.Buffer.Length);
			}
			if (stream78 != null && stream78.Buffer != null)
			{
				this.d0 = this.fw.GetString(stream78.Buffer, 0, (int)stream78.Buffer.Length);
			}
			if (stream79 != null && stream79.Buffer != null)
			{
				this.d1 = this.fw.GetString(stream79.Buffer, 0, (int)stream79.Buffer.Length);
			}
			if (stream80 != null && stream80.Buffer != null)
			{
				this.d2 = this.fw.GetString(stream80.Buffer, 0, (int)stream80.Buffer.Length);
			}
			if (stream81 != null && stream81.Buffer != null)
			{
				this.d3 = this.fw.GetString(stream81.Buffer, 0, (int)stream81.Buffer.Length);
			}
			if (stream82 != null && stream82.Buffer != null)
			{
				this.d4 = this.fw.GetString(stream82.Buffer, 0, (int)stream82.Buffer.Length);
			}
			if (stream83 != null && stream83.Buffer != null)
			{
				this.d5 = this.fw.GetString(stream83.Buffer, 0, (int)stream83.Buffer.Length);
			}
			if (stream84 != null && stream84.Buffer != null)
			{
				this.d6 = this.fw.GetString(stream84.Buffer, 0, (int)stream84.Buffer.Length);
			}
			if (stream99 != null && stream99.Buffer != null)
			{
				this.el = this.fw.GetString(stream99.Buffer, 0, (int)stream99.Buffer.Length);
			}
			if (stream85 != null && stream85.Buffer != null)
			{
				this.d7 = this.fw.GetString(stream85.Buffer, 0, (int)stream85.Buffer.Length);
			}
			if (stream86 != null && stream86.Buffer != null)
			{
				this.d8 = this.fw.GetString(stream86.Buffer, 0, (int)stream86.Buffer.Length);
			}
			if (stream87 != null && stream87.Buffer != null)
			{
				this.d9 = this.fw.GetString(stream87.Buffer, 0, (int)stream87.Buffer.Length);
			}
			if (stream88 != null && stream88.Buffer != null)
			{
				this.ea = this.fw.GetString(stream88.Buffer, 0, (int)stream88.Buffer.Length);
			}
			if (stream89 != null && stream89.Buffer != null)
			{
				this.dd = this.fw.GetString(stream89.Buffer, 0, (int)stream89.Buffer.Length);
			}
			if (stream90 != null && stream90.Buffer != null)
			{
				this.eb = this.fw.GetString(stream90.Buffer, 0, (int)stream90.Buffer.Length);
			}
			if (stream91 != null && stream91.Buffer != null)
			{
				this.ec = this.fw.GetString(stream91.Buffer, 0, (int)stream91.Buffer.Length);
			}
			if (stream92 != null && stream92.Buffer != null)
			{
				this.ed = this.fw.GetString(stream92.Buffer, 0, (int)stream92.Buffer.Length);
			}
			if (stream93 != null && stream93.Buffer != null)
			{
				this.ee = this.fw.GetString(stream93.Buffer, 0, (int)stream93.Buffer.Length);
			}
			if (stream94 != null && stream94.Buffer != null)
			{
				this.ef = this.fw.GetString(stream94.Buffer, 0, (int)stream94.Buffer.Length);
			}
			if (stream95 != null && stream95.Buffer != null)
			{
				this.eg = this.fw.GetString(stream95.Buffer, 0, (int)stream95.Buffer.Length);
			}
			if (stream96 != null && stream96.Buffer != null)
			{
				this.eh = this.fw.GetString(stream96.Buffer, 0, (int)stream96.Buffer.Length);
			}
			if (stream97 != null && stream97.Buffer != null)
			{
				this.ei = this.fw.GetString(stream97.Buffer, 0, (int)stream97.Buffer.Length);
			}
			if (stream98 != null && stream98.Buffer != null)
			{
				this.ej = this.fw.GetString(stream98.Buffer, 0, (int)stream98.Buffer.Length);
			}
			if (stream101 != null && stream101.Buffer != null)
			{
				this.em = this.fw.GetString(stream101.Buffer, 0, (int)stream101.Buffer.Length);
			}
			if (stream102 != null && stream102.Buffer != null)
			{
				this.en = this.fw.GetString(stream102.Buffer, 0, (int)stream102.Buffer.Length);
			}
			if (stream103 != null && stream103.Buffer != null)
			{
				this.eo = this.fw.GetString(stream103.Buffer, 0, (int)stream103.Buffer.Length);
			}
			if (stream104 != null && stream104.Buffer != null)
			{
				this.ep = this.fw.GetString(stream104.Buffer, 0, (int)stream104.Buffer.Length);
			}
			if (stream105 != null && stream105.Buffer != null)
			{
				this.eq = this.fw.GetString(stream105.Buffer, 0, (int)stream105.Buffer.Length);
			}
			if (stream106 != null && stream106.Buffer != null)
			{
				this.er = this.fw.GetString(stream106.Buffer, 0, (int)stream106.Buffer.Length);
			}
			if (stream107 != null && stream107.Buffer != null)
			{
				this.es = this.fw.GetString(stream107.Buffer, 0, (int)stream107.Buffer.Length);
			}
			if (stream108 != null && stream108.Buffer != null)
			{
				this.et = this.fw.GetString(stream108.Buffer, 0, (int)stream108.Buffer.Length);
			}
			if (stream109 != null && stream109.Buffer != null)
			{
				this.eu = this.fw.GetString(stream109.Buffer, 0, (int)stream109.Buffer.Length);
			}
			if (stream110 != null && stream110.Buffer != null)
			{
				this.ev = this.fw.GetString(stream110.Buffer, 0, (int)stream110.Buffer.Length);
			}
			if (stream111 != null && stream111.Buffer != null)
			{
				this.ew = this.fw.GetString(stream111.Buffer, 0, (int)stream111.Buffer.Length);
			}
			if (stream112 != null && stream112.Buffer != null)
			{
				this.ex = this.fw.GetString(stream112.Buffer, 0, (int)stream112.Buffer.Length);
			}
			if (stream113 != null && stream113.Buffer != null)
			{
				this.ey = this.fw.GetString(stream113.Buffer, 0, (int)stream113.Buffer.Length);
			}
			for (int r = 0; (long)r < (ulong)num1; r++)
			{
				IDictionary<string, q> strs = new Dictionary<string, q>();
				string str129 = string.Format("__recip_version1.0_#{0:X8}", r);
				Storage storage = (Storage)A_0[str129];
				if (storage != null)
				{
					Independentsoft.IO.StructuredStorage.Stream stream114 = (Independentsoft.IO.StructuredStorage.Stream)storage.DirectoryEntries["__properties_version1.0"];
					if (stream114 != null && stream114.Buffer != null)
					{
						for (int s = 8; s < (int)stream114.Buffer.Length; s = s + 16)
						{
							byte[] numArray3 = new byte[16];
							Array.Copy(stream114.Buffer, s, numArray3, 0, 16);
							q _q187 = new q(numArray3);
							if (_q187.e() > 0)
							{
								string str130 = string.Concat("__substg1.0_", string.Format("{0:X8}", _q187.a()));
								Independentsoft.IO.StructuredStorage.Stream stream115 = (Independentsoft.IO.StructuredStorage.Stream)storage.DirectoryEntries[str130];
								if (stream115 != null && stream115.Buffer != null && (int)stream115.Buffer.Length > 0)
								{
									_q187.b(new byte[(int)stream115.Buffer.Length]);
									Array.Copy(stream115.Buffer, 0, _q187.c(), 0, (int)_q187.c().Length);
								}
							}
							string str131 = string.Format("{0:X8}", _q187.a());
							strs.Add(str131, _q187);
						}
					}
					Recipient recipient = new Recipient();
					if (strs.ContainsKey("39000003"))
					{
						_q16 = strs["39000003"];
					}
					else
					{
						_q16 = null;
					}
					q _q188 = _q16;
					if (_q188 != null && _q188.c() != null)
					{
						recipient.DisplayType = h.p(BitConverter.ToUInt32(_q188.c(), 0));
					}
					if (strs.ContainsKey("0FFE0003"))
					{
						item17 = strs["0FFE0003"];
					}
					else
					{
						item17 = null;
					}
					q _q189 = item17;
					if (_q189 != null && _q189.c() != null)
					{
						recipient.ObjectType = h.v(BitConverter.ToUInt32(_q189.c(), 0));
					}
					if (strs.ContainsKey("0C150003"))
					{
						_q17 = strs["0C150003"];
					}
					else
					{
						_q17 = null;
					}
					q _q190 = _q17;
					if (_q190 != null && _q190.c() != null)
					{
						recipient.RecipientType = h.n(BitConverter.ToUInt32(_q190.c(), 0));
					}
					if (strs.ContainsKey("0E0F000B"))
					{
						item18 = strs["0E0F000B"];
					}
					else
					{
						item18 = null;
					}
					q _q191 = item18;
					if (_q191 != null && _q191.c() != null && BitConverter.ToUInt16(_q191.c(), 0) > 0)
					{
						recipient.Responsibility = true;
					}
					if (strs.ContainsKey("3A40000B"))
					{
						_q18 = strs["3A40000B"];
					}
					else
					{
						_q18 = null;
					}
					q _q192 = _q18;
					if (_q192 != null && _q192.c() != null && BitConverter.ToUInt16(_q192.c(), 0) > 0)
					{
						recipient.SendRichInfo = true;
					}
					if (strs.ContainsKey("3A710003"))
					{
						item19 = strs["3A710003"];
					}
					else
					{
						item19 = null;
					}
					q _q193 = item19;
					if (_q193 != null && _q193.c() != null)
					{
						recipient.SendInternetEncoding = BitConverter.ToInt32(_q193.c(), 0);
					}
					Independentsoft.IO.StructuredStorage.Stream stream116 = (Independentsoft.IO.StructuredStorage.Stream)storage.DirectoryEntries[string.Concat("__substg1.0_3001", this.fs)];
					Independentsoft.IO.StructuredStorage.Stream stream117 = (Independentsoft.IO.StructuredStorage.Stream)storage.DirectoryEntries[string.Concat("__substg1.0_3002", this.fs)];
					Independentsoft.IO.StructuredStorage.Stream stream118 = (Independentsoft.IO.StructuredStorage.Stream)storage.DirectoryEntries[string.Concat("__substg1.0_3003", this.fs)];
					Independentsoft.IO.StructuredStorage.Stream stream119 = (Independentsoft.IO.StructuredStorage.Stream)storage.DirectoryEntries[string.Concat("__substg1.0_39FE", this.fs)];
					Independentsoft.IO.StructuredStorage.Stream stream120 = (Independentsoft.IO.StructuredStorage.Stream)storage.DirectoryEntries[string.Concat("__substg1.0_39FF", this.fs)];
					Independentsoft.IO.StructuredStorage.Stream stream121 = (Independentsoft.IO.StructuredStorage.Stream)storage.DirectoryEntries[string.Concat("__substg1.0_3A20", this.fs)];
					Independentsoft.IO.StructuredStorage.Stream stream122 = (Independentsoft.IO.StructuredStorage.Stream)storage.DirectoryEntries[string.Concat("__substg1.0_403D", this.fs)];
					Independentsoft.IO.StructuredStorage.Stream stream123 = (Independentsoft.IO.StructuredStorage.Stream)storage.DirectoryEntries[string.Concat("__substg1.0_403E", this.fs)];
					Independentsoft.IO.StructuredStorage.Stream stream124 = (Independentsoft.IO.StructuredStorage.Stream)storage.DirectoryEntries["__substg1.0_0FFF0102"];
					Independentsoft.IO.StructuredStorage.Stream item125 = (Independentsoft.IO.StructuredStorage.Stream)storage.DirectoryEntries["__substg1.0_300B0102"];
					Independentsoft.IO.StructuredStorage.Stream stream125 = (Independentsoft.IO.StructuredStorage.Stream)storage.DirectoryEntries["__substg1.0_0FF60102"];
					if (stream116 != null && stream116.Buffer != null)
					{
						recipient.DisplayName = this.fw.GetString(stream116.Buffer, 0, (int)stream116.Buffer.Length);
					}
					if (stream117 != null && stream117.Buffer != null)
					{
						recipient.AddressType = this.fw.GetString(stream117.Buffer, 0, (int)stream117.Buffer.Length);
					}
					if (stream118 != null && stream118.Buffer != null)
					{
						recipient.EmailAddress = this.fw.GetString(stream118.Buffer, 0, (int)stream118.Buffer.Length);
					}
					if (stream119 != null && stream119.Buffer != null)
					{
						recipient.SmtpAddress = this.fw.GetString(stream119.Buffer, 0, (int)stream119.Buffer.Length);
					}
					if (stream120 != null && stream120.Buffer != null)
					{
						recipient.DisplayName7Bit = this.fw.GetString(stream120.Buffer, 0, (int)stream120.Buffer.Length);
					}
					if (stream121 != null && stream121.Buffer != null)
					{
						recipient.TransmitableDisplayName = this.fw.GetString(stream121.Buffer, 0, (int)stream121.Buffer.Length);
					}
					if (stream122 != null && stream122.Buffer != null)
					{
						recipient.OriginatingAddressType = this.fw.GetString(stream122.Buffer, 0, (int)stream122.Buffer.Length);
					}
					if (stream123 != null && stream123.Buffer != null)
					{
						recipient.OriginatingEmailAddress = this.fw.GetString(stream123.Buffer, 0, (int)stream123.Buffer.Length);
					}
					if (stream124 != null && stream124.Buffer != null)
					{
						recipient.EntryId = stream124.Buffer;
					}
					if (item125 != null && item125.Buffer != null)
					{
						recipient.SearchKey = item125.Buffer;
					}
					if (stream125 != null && stream125.Buffer != null)
					{
						recipient.InstanceKey = stream125.Buffer;
					}
					this.fo.Add(recipient);
				}
			}
			int num92 = 0;
			for (int t = 0; t < A_0.Count; t++)
			{
				if (A_0[t] is Storage)
				{
					num92++;
				}
			}
			for (int u = 0; (long)u < (ulong)num2; u++)
			{
				IDictionary<string, q> strs1 = new Dictionary<string, q>();
				string str132 = string.Format("__attach_version1.0_#{0:X8}", u);
				Storage storage1 = (Storage)A_0[str132];
				if (storage1 != null)
				{
					Independentsoft.IO.StructuredStorage.Stream item126 = (Independentsoft.IO.StructuredStorage.Stream)storage1.DirectoryEntries["__properties_version1.0"];
					Independentsoft.Msg.Attachment attachment = new Independentsoft.Msg.Attachment();
					if (item126 != null && item126.Buffer != null)
					{
						for (int v = 8; v < (int)item126.Buffer.Length; v = v + 16)
						{
							byte[] numArray4 = new byte[16];
							Array.Copy(item126.Buffer, v, numArray4, 0, 16);
							q _q194 = new q(numArray4);
							if (_q194.e() > 0)
							{
								string str133 = string.Concat("__substg1.0_", string.Format("{0:X8}", _q194.a()));
								if (storage1.DirectoryEntries[str133] is Independentsoft.IO.StructuredStorage.Stream)
								{
									Independentsoft.IO.StructuredStorage.Stream stream126 = (Independentsoft.IO.StructuredStorage.Stream)storage1.DirectoryEntries[str133];
									if (stream126 != null && stream126.Buffer != null && (int)stream126.Buffer.Length > 0)
									{
										_q194.b(new byte[(int)stream126.Buffer.Length]);
										Array.Copy(stream126.Buffer, 0, _q194.c(), 0, (int)_q194.c().Length);
									}
								}
								else if (storage1.DirectoryEntries[str133] is Storage)
								{
									Storage storage2 = (Storage)storage1.DirectoryEntries[str133];
									if (storage2 != null && storage2.DirectoryEntries["__properties_version1.0"] != null)
									{
										attachment.EmbeddedMessage = new Independentsoft.Msg.Message(storage2.DirectoryEntries, true);
									}
								}
							}
							string str134 = string.Format("{0:X8}", _q194.a());
							if (!strs1.ContainsKey(str134))
							{
								strs1.Add(str134, _q194);
							}
						}
					}
					if (strs1.ContainsKey("37140003"))
					{
						_q19 = strs1["37140003"];
					}
					else
					{
						_q19 = null;
					}
					q _q195 = _q19;
					if (_q195 != null && _q195.c() != null)
					{
						attachment.Flags = h.b(BitConverter.ToUInt32(_q195.c(), 0));
					}
					if (strs1.ContainsKey("37050003"))
					{
						item20 = strs1["37050003"];
					}
					else
					{
						item20 = null;
					}
					q _q196 = item20;
					if (_q196 != null && _q196.c() != null)
					{
						attachment.Method = h.c(BitConverter.ToUInt32(_q196.c(), 0));
					}
					if (strs1.ContainsKey("37100003"))
					{
						_q20 = strs1["37100003"];
					}
					else
					{
						_q20 = null;
					}
					q _q197 = _q20;
					if (_q197 != null && _q197.c() != null)
					{
						attachment.MimeSequence = (long)BitConverter.ToUInt32(_q197.c(), 0);
					}
					if (strs1.ContainsKey("370B0003"))
					{
						item21 = strs1["370B0003"];
					}
					else
					{
						item21 = null;
					}
					q _q198 = item21;
					if (_q198 != null && _q198.c() != null)
					{
						attachment.RenderingPosition = (long)BitConverter.ToUInt32(_q198.c(), 0);
					}
					if (strs1.ContainsKey("0E200003"))
					{
						_q21 = strs1["0E200003"];
					}
					else
					{
						_q21 = null;
					}
					q _q199 = _q21;
					if (_q199 != null && _q199.c() != null)
					{
						attachment.Size = (long)BitConverter.ToUInt32(_q199.c(), 0);
					}
					if (strs1.ContainsKey("0FFE0003"))
					{
						item22 = strs1["0FFE0003"];
					}
					else
					{
						item22 = null;
					}
					q _q200 = item22;
					if (_q200 != null && _q200.c() != null)
					{
						attachment.ObjectType = h.v(BitConverter.ToUInt32(_q200.c(), 0));
					}
					if (strs1.ContainsKey("7FFE000B"))
					{
						_q22 = strs1["7FFE000B"];
					}
					else
					{
						_q22 = null;
					}
					q _q201 = _q22;
					if (_q201 != null && _q201.c() != null && BitConverter.ToUInt16(_q201.c(), 0) > 0)
					{
						attachment.IsHidden = true;
					}
					if (strs1.ContainsKey("7FFF000B"))
					{
						item23 = strs1["7FFF000B"];
					}
					else
					{
						item23 = null;
					}
					q _q202 = item23;
					if (_q202 != null && _q202.c() != null && BitConverter.ToUInt16(_q202.c(), 0) > 0)
					{
						attachment.IsContactPhoto = true;
					}
					if (strs1.ContainsKey("30070040"))
					{
						_q23 = strs1["30070040"];
					}
					else
					{
						_q23 = null;
					}
					q _q203 = _q23;
					if (_q203 != null && _q203.c() != null)
					{
						uint num93 = BitConverter.ToUInt32(_q203.c(), 0);
						ulong num94 = (ulong)BitConverter.ToUInt32(_q203.c(), 4);
						if (num94 > (long)0)
						{
							long num95 = (long)((ulong)num93 + (num94 << 32));
							DateTime dateTime22 = new DateTime(1601, 1, 1);
							try
							{
								dateTime = dateTime22.AddTicks(num95);
								attachment.CreationTime = dateTime.ToLocalTime();
							}
							catch (Exception exception21)
							{
							}
						}
					}
					if (strs1.ContainsKey("30080040"))
					{
						item24 = strs1["30080040"];
					}
					else
					{
						item24 = null;
					}
					q _q204 = item24;
					if (_q204 != null && _q204.c() != null)
					{
						uint num96 = BitConverter.ToUInt32(_q204.c(), 0);
						ulong num97 = (ulong)BitConverter.ToUInt32(_q204.c(), 4);
						if (num97 > (long)0)
						{
							long num98 = (long)((ulong)num96 + (num97 << 32));
							DateTime dateTime23 = new DateTime(1601, 1, 1);
							try
							{
								dateTime = dateTime23.AddTicks(num98);
								attachment.LastModificationTime = dateTime.ToLocalTime();
							}
							catch (Exception exception22)
							{
							}
						}
					}
					Independentsoft.IO.StructuredStorage.Stream item127 = (Independentsoft.IO.StructuredStorage.Stream)storage1.DirectoryEntries["__substg1.0_370F0102"];
					Independentsoft.IO.StructuredStorage.Stream stream127 = (Independentsoft.IO.StructuredStorage.Stream)storage1.DirectoryEntries[string.Concat("__substg1.0_3711", this.fs)];
					Independentsoft.IO.StructuredStorage.Stream item128 = (Independentsoft.IO.StructuredStorage.Stream)storage1.DirectoryEntries[string.Concat("__substg1.0_3712", this.fs)];
					Independentsoft.IO.StructuredStorage.Stream stream128 = (Independentsoft.IO.StructuredStorage.Stream)storage1.DirectoryEntries[string.Concat("__substg1.0_3713", this.fs)];
					Independentsoft.IO.StructuredStorage.Stream item129 = (Independentsoft.IO.StructuredStorage.Stream)storage1.DirectoryEntries[string.Concat("__substg1.0_3716", this.fs)];
					Independentsoft.IO.StructuredStorage.Stream stream129 = (Independentsoft.IO.StructuredStorage.Stream)storage1.DirectoryEntries["__substg1.0_37010102"];
					Independentsoft.IO.StructuredStorage.Stream item130 = (Independentsoft.IO.StructuredStorage.Stream)storage1.DirectoryEntries["__substg1.0_37020102"];
					Independentsoft.IO.StructuredStorage.Stream stream130 = (Independentsoft.IO.StructuredStorage.Stream)storage1.DirectoryEntries[string.Concat("__substg1.0_3703", this.fs)];
					Independentsoft.IO.StructuredStorage.Stream item131 = (Independentsoft.IO.StructuredStorage.Stream)storage1.DirectoryEntries[string.Concat("__substg1.0_3704", this.fs)];
					Independentsoft.IO.StructuredStorage.Stream stream131 = (Independentsoft.IO.StructuredStorage.Stream)storage1.DirectoryEntries[string.Concat("__substg1.0_3707", this.fs)];
					Independentsoft.IO.StructuredStorage.Stream item132 = (Independentsoft.IO.StructuredStorage.Stream)storage1.DirectoryEntries[string.Concat("__substg1.0_370D", this.fs)];
					Independentsoft.IO.StructuredStorage.Stream stream132 = (Independentsoft.IO.StructuredStorage.Stream)storage1.DirectoryEntries[string.Concat("__substg1.0_370E", this.fs)];
					Independentsoft.IO.StructuredStorage.Stream item133 = (Independentsoft.IO.StructuredStorage.Stream)storage1.DirectoryEntries[string.Concat("__substg1.0_3708", this.fs)];
					Independentsoft.IO.StructuredStorage.Stream stream133 = (Independentsoft.IO.StructuredStorage.Stream)storage1.DirectoryEntries["__substg1.0_37090102"];
					Independentsoft.IO.StructuredStorage.Stream item134 = (Independentsoft.IO.StructuredStorage.Stream)storage1.DirectoryEntries["__substg1.0_370A0102"];
					Independentsoft.IO.StructuredStorage.Stream stream134 = (Independentsoft.IO.StructuredStorage.Stream)storage1.DirectoryEntries[string.Concat("__substg1.0_370C", this.fs)];
					Independentsoft.IO.StructuredStorage.Stream item135 = (Independentsoft.IO.StructuredStorage.Stream)storage1.DirectoryEntries[string.Concat("__substg1.0_3001", this.fs)];
					if (storage1.DirectoryEntries["__substg1.0_3701000D"] != null && storage1.DirectoryEntries["__substg1.0_3701000D"] is Storage)
					{
						attachment.DataObjectStorage = (Storage)storage1.DirectoryEntries["__substg1.0_3701000D"];
						attachment.PropertiesStream = item126;
					}
					if (item127 != null && item127.Buffer != null)
					{
						attachment.AdditionalInfo = item127.Buffer;
					}
					if (stream127 != null && stream127.Buffer != null)
					{
						attachment.ContentBase = this.fw.GetString(stream127.Buffer, 0, (int)stream127.Buffer.Length);
					}
					if (item128 != null && item128.Buffer != null)
					{
						attachment.ContentId = this.fw.GetString(item128.Buffer, 0, (int)item128.Buffer.Length);
					}
					if (stream128 != null && stream128.Buffer != null)
					{
						attachment.ContentLocation = this.fw.GetString(stream128.Buffer, 0, (int)stream128.Buffer.Length);
					}
					if (item129 != null && item129.Buffer != null)
					{
						attachment.ContentDisposition = this.fw.GetString(item129.Buffer, 0, (int)item129.Buffer.Length);
					}
					if (stream129 != null && stream129.Buffer != null)
					{
						attachment.Data = stream129.Buffer;
					}
					if (item130 != null && item130.Buffer != null)
					{
						attachment.Encoding = item130.Buffer;
					}
					if (stream130 != null && stream130.Buffer != null)
					{
						attachment.Extension = this.fw.GetString(stream130.Buffer, 0, (int)stream130.Buffer.Length);
					}
					if (item131 != null && item131.Buffer != null)
					{
						attachment.FileName = this.fw.GetString(item131.Buffer, 0, (int)item131.Buffer.Length);
					}
					if (stream131 != null && stream131.Buffer != null)
					{
						attachment.LongFileName = this.fw.GetString(stream131.Buffer, 0, (int)stream131.Buffer.Length);
					}
					if (item132 != null && item132.Buffer != null)
					{
						attachment.LongPathName = this.fw.GetString(item132.Buffer, 0, (int)item132.Buffer.Length);
					}
					if (stream132 != null && stream132.Buffer != null)
					{
						attachment.MimeTag = this.fw.GetString(stream132.Buffer, 0, (int)stream132.Buffer.Length);
					}
					if (item133 != null && item133.Buffer != null)
					{
						attachment.PathName = this.fw.GetString(item133.Buffer, 0, (int)item133.Buffer.Length);
					}
					if (stream133 != null && stream133.Buffer != null)
					{
						attachment.Rendering = stream133.Buffer;
					}
					if (item134 != null && item134.Buffer != null)
					{
						attachment.Tag = item134.Buffer;
					}
					if (stream134 != null && stream134.Buffer != null)
					{
						attachment.TransportName = this.fw.GetString(stream134.Buffer, 0, (int)stream134.Buffer.Length);
					}
					if (item135 != null && item135.Buffer != null)
					{
						attachment.DisplayName = this.fw.GetString(item135.Buffer, 0, (int)item135.Buffer.Length);
					}
					if (attachment.Data != null || attachment.DataObject != null || attachment.DataObjectStorage != null || attachment.EmbeddedMessage != null)
					{
						this.fp.Add(attachment);
					}
				}
				else
				{
					num2++;
					if ((ulong)num2 > (long)num92)
					{
						return;
					}
				}
			}
		}

		private DirectoryEntryList a(ref IList<c> A_0)
		{
			DateTime universalTime;
			DirectoryEntryList directoryEntryList = new DirectoryEntryList();
			MemoryStream memoryStream = new MemoryStream();
			byte[] bytes = BitConverter.GetBytes((uint)0);
			byte[] numArray = BitConverter.GetBytes(this.fo.Count);
			byte[] bytes1 = BitConverter.GetBytes(this.fp.Count);
			memoryStream.Write(bytes, 0, 4);
			memoryStream.Write(bytes, 0, 4);
			memoryStream.Write(numArray, 0, 4);
			memoryStream.Write(bytes1, 0, 4);
			memoryStream.Write(numArray, 0, 4);
			memoryStream.Write(bytes1, 0, 4);
			if (!this.fx)
			{
				memoryStream.Write(bytes, 0, 4);
				memoryStream.Write(bytes, 0, 4);
			}
			if (this.fw == System.Text.Encoding.Unicode || this.fw is UnicodeEncoding)
			{
				this.fs = "001F";
				this.ft = 31;
				this.fu = "101F";
				this.fv = 4127;
				if (!this.bn.Contains(StoreSupportMask.Unicode))
				{
					this.bn.Add(StoreSupportMask.Unicode);
				}
			}
			else
			{
				this.bn.Remove(StoreSupportMask.Unicode);
			}
			if (this.bn != null)
			{
				q _q = new q();
				_q.a(873267203);
				_q.a(PropertyType.Integer32);
				_q.b(BitConverter.GetBytes(h.a(this.bn)));
				_q.b(true);
				_q.a(true);
				memoryStream.Write(_q.b(), 0, 16);
			}
			if (this.b != null)
			{
				byte[] numArray1 = this.fw.GetBytes(this.b);
				Independentsoft.IO.StructuredStorage.Stream stream = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_001A", this.fs), numArray1);
				directoryEntryList.Add(stream);
				q _q1 = new q();
				_q1.a(1703936 | this.ft);
				_q1.a(PropertyType.String8);
				_q1.b((uint)((int)numArray1.Length + (int)this.fw.GetBytes("\0").Length));
				_q1.b(true);
				_q1.a(true);
				memoryStream.Write(_q1.b(), 0, 16);
			}
			if (this.c != null)
			{
				byte[] bytes2 = this.fw.GetBytes(this.c);
				Independentsoft.IO.StructuredStorage.Stream stream1 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_0037", this.fs), bytes2);
				directoryEntryList.Add(stream1);
				q _q2 = new q();
				_q2.a(3604480 | this.ft);
				_q2.a(PropertyType.String8);
				_q2.b((uint)((int)bytes2.Length + (int)this.fw.GetBytes("\0").Length));
				_q2.b(true);
				_q2.a(true);
				memoryStream.Write(_q2.b(), 0, 16);
			}
			if (this.d != null)
			{
				byte[] numArray2 = this.fw.GetBytes(this.d);
				Independentsoft.IO.StructuredStorage.Stream stream2 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_003D", this.fs), numArray2);
				directoryEntryList.Add(stream2);
				q _q3 = new q();
				_q3.a(3997696 | this.ft);
				_q3.a(PropertyType.String8);
				_q3.b((uint)((int)numArray2.Length + (int)this.fw.GetBytes("\0").Length));
				_q3.b(true);
				_q3.a(true);
				memoryStream.Write(_q3.b(), 0, 16);
			}
			if (this.e != null)
			{
				byte[] bytes3 = this.fw.GetBytes(this.e);
				Independentsoft.IO.StructuredStorage.Stream stream3 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_0070", this.fs), bytes3);
				directoryEntryList.Add(stream3);
				q _q4 = new q();
				_q4.a(7340032 | this.ft);
				_q4.a(PropertyType.String8);
				_q4.b((uint)((int)bytes3.Length + (int)this.fw.GetBytes("\0").Length));
				_q4.b(true);
				_q4.a(true);
				memoryStream.Write(_q4.b(), 0, 16);
			}
			if (this.f != null)
			{
				byte[] numArray3 = this.fw.GetBytes(this.f);
				Independentsoft.IO.StructuredStorage.Stream stream4 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_0E02", this.fs), numArray3);
				directoryEntryList.Add(stream4);
				q _q5 = new q();
				_q5.a(235012096 | this.ft);
				_q5.a(PropertyType.String8);
				_q5.b((uint)((int)numArray3.Length + (int)this.fw.GetBytes("\0").Length));
				_q5.b(true);
				_q5.a(true);
				memoryStream.Write(_q5.b(), 0, 16);
			}
			if (this.g != null)
			{
				byte[] bytes4 = this.fw.GetBytes(this.g);
				Independentsoft.IO.StructuredStorage.Stream stream5 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_0E03", this.fs), bytes4);
				directoryEntryList.Add(stream5);
				q _q6 = new q();
				_q6.a(235077632 | this.ft);
				_q6.a(PropertyType.String8);
				_q6.b((uint)((int)bytes4.Length + (int)this.fw.GetBytes("\0").Length));
				_q6.b(true);
				_q6.a(true);
				memoryStream.Write(_q6.b(), 0, 16);
			}
			if (this.h != null)
			{
				byte[] numArray4 = this.fw.GetBytes(this.h);
				Independentsoft.IO.StructuredStorage.Stream stream6 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_0E04", this.fs), numArray4);
				directoryEntryList.Add(stream6);
				q _q7 = new q();
				_q7.a(235143168 | this.ft);
				_q7.a(PropertyType.String8);
				_q7.b((uint)((int)numArray4.Length + (int)this.fw.GetBytes("\0").Length));
				_q7.b(true);
				_q7.a(true);
				memoryStream.Write(_q7.b(), 0, 16);
			}
			if (this.i != null)
			{
				byte[] bytes5 = this.fw.GetBytes(this.i);
				Independentsoft.IO.StructuredStorage.Stream stream7 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_0074", this.fs), bytes5);
				directoryEntryList.Add(stream7);
				q _q8 = new q();
				_q8.a(7602176 | this.ft);
				_q8.a(PropertyType.String8);
				_q8.b((uint)((int)bytes5.Length + (int)this.fw.GetBytes("\0").Length));
				_q8.b(true);
				_q8.a(true);
				memoryStream.Write(_q8.b(), 0, 16);
			}
			if (this.j != null)
			{
				byte[] numArray5 = this.fw.GetBytes(this.j);
				Independentsoft.IO.StructuredStorage.Stream stream8 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_0050", this.fs), numArray5);
				directoryEntryList.Add(stream8);
				q _q9 = new q();
				_q9.a(5242880 | this.ft);
				_q9.a(PropertyType.String8);
				_q9.b((uint)((int)numArray5.Length + (int)this.fw.GetBytes("\0").Length));
				_q9.b(true);
				_q9.a(true);
				memoryStream.Write(_q9.b(), 0, 16);
				byte[] numArray6 = m.c(this.j);
				directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_004F0102", numArray6));
				q _q10 = new q();
				_q10.a(5177602);
				_q10.a(PropertyType.Binary);
				_q10.b((uint)numArray6.Length);
				_q10.b(true);
				_q10.a(true);
				memoryStream.Write(_q10.b(), 0, 16);
			}
			if (this.k != null)
			{
				byte[] bytes6 = this.fw.GetBytes(this.k);
				Independentsoft.IO.StructuredStorage.Stream stream9 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_0E1D", this.fs), bytes6);
				directoryEntryList.Add(stream9);
				q _q11 = new q();
				_q11.a(236781568 | this.ft);
				_q11.a(PropertyType.String8);
				_q11.b((uint)((int)bytes6.Length + (int)this.fw.GetBytes("\0").Length));
				_q11.b(true);
				_q11.a(true);
				memoryStream.Write(_q11.b(), 0, 16);
			}
			if (this.l != null)
			{
				byte[] bytes7 = this.fw.GetBytes(this.l);
				Independentsoft.IO.StructuredStorage.Stream stream10 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_1000", this.fs), bytes7);
				directoryEntryList.Add(stream10);
				q _q12 = new q();
				_q12.a(268435456 | this.ft);
				_q12.a(PropertyType.String8);
				_q12.b((uint)((int)bytes7.Length + (int)this.fw.GetBytes("\0").Length));
				_q12.b(true);
				_q12.a(true);
				memoryStream.Write(_q12.b(), 0, 16);
			}
			if (this.m != null)
			{
				directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_10090102", this.m));
				q _q13 = new q();
				_q13.a(269025538);
				_q13.a(PropertyType.Binary);
				_q13.b((uint)this.m.Length);
				_q13.b(true);
				_q13.a(true);
				memoryStream.Write(_q13.b(), 0, 16);
			}
			if (this.n != null)
			{
				directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_300B0102", this.n));
				q _q14 = new q();
				_q14.a(806027522);
				_q14.a(PropertyType.Binary);
				_q14.b((uint)this.n.Length);
				_q14.b(true);
				_q14.a(true);
				memoryStream.Write(_q14.b(), 0, 16);
			}
			if (this.o != null)
			{
				directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_65E20102", this.o));
				q _q15 = new q();
				_q15.a(1709310210);
				_q15.a(PropertyType.Binary);
				_q15.b((uint)this.o.Length);
				_q15.b(true);
				_q15.a(true);
				memoryStream.Write(_q15.b(), 0, 16);
			}
			if (this.p != null)
			{
				directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_0FFF0102", this.p));
				q _q16 = new q();
				_q16.a(268370178);
				_q16.a(PropertyType.Binary);
				_q16.b((uint)this.p.Length);
				_q16.b(true);
				_q16.a(true);
				memoryStream.Write(_q16.b(), 0, 16);
			}
			if (this.q != null)
			{
				directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_00460102", this.q));
				q _q17 = new q();
				_q17.a(4587778);
				_q17.a(PropertyType.Binary);
				_q17.b((uint)this.q.Length);
				_q17.b(true);
				_q17.a(true);
				memoryStream.Write(_q17.b(), 0, 16);
			}
			if (this.r != null)
			{
				directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_00530102", this.r));
				q _q18 = new q();
				_q18.a(5439746);
				_q18.a(PropertyType.Binary);
				_q18.b((uint)this.r.Length);
				_q18.b(true);
				_q18.a(true);
				memoryStream.Write(_q18.b(), 0, 16);
			}
			if (this.s.CompareTo(DateTime.MinValue) > 0)
			{
				DateTime dateTime = new DateTime(1601, 1, 1);
				universalTime = this.s.ToUniversalTime();
				TimeSpan timeSpan = universalTime.Subtract(dateTime);
				byte[] numArray7 = BitConverter.GetBytes(timeSpan.Ticks);
				q _q19 = new q();
				_q19.a(805765184);
				_q19.a(PropertyType.Time);
				_q19.b(numArray7);
				_q19.b(true);
				_q19.a(false);
				memoryStream.Write(_q19.b(), 0, 16);
			}
			if (this.t.CompareTo(DateTime.MinValue) > 0)
			{
				DateTime dateTime1 = new DateTime(1601, 1, 1);
				universalTime = this.t.ToUniversalTime();
				TimeSpan timeSpan1 = universalTime.Subtract(dateTime1);
				byte[] bytes8 = BitConverter.GetBytes(timeSpan1.Ticks);
				q _q20 = new q();
				_q20.a(805830720);
				_q20.a(PropertyType.Time);
				_q20.b(bytes8);
				_q20.b(true);
				_q20.a(false);
				memoryStream.Write(_q20.b(), 0, 16);
			}
			if (this.u.CompareTo(DateTime.MinValue) > 0)
			{
				DateTime dateTime2 = new DateTime(1601, 1, 1);
				universalTime = this.u.ToUniversalTime();
				TimeSpan timeSpan2 = universalTime.Subtract(dateTime2);
				byte[] numArray8 = BitConverter.GetBytes(timeSpan2.Ticks);
				q _q21 = new q();
				_q21.a(235274304);
				_q21.a(PropertyType.Time);
				_q21.b(numArray8);
				_q21.b(true);
				_q21.a(true);
				memoryStream.Write(_q21.b(), 0, 16);
			}
			if (this.v.CompareTo(DateTime.MinValue) > 0)
			{
				DateTime dateTime3 = new DateTime(1601, 1, 1);
				universalTime = this.v.ToUniversalTime();
				TimeSpan timeSpan3 = universalTime.Subtract(dateTime3);
				byte[] bytes9 = BitConverter.GetBytes(timeSpan3.Ticks);
				q _q22 = new q();
				_q22.a(3735616);
				_q22.a(PropertyType.Time);
				_q22.b(bytes9);
				_q22.b(true);
				_q22.a(true);
				memoryStream.Write(_q22.b(), 0, 16);
			}
			if (this.w.CompareTo(DateTime.MinValue) > 0)
			{
				DateTime dateTime4 = new DateTime(1601, 1, 1);
				universalTime = this.w.ToUniversalTime();
				TimeSpan timeSpan4 = universalTime.Subtract(dateTime4);
				byte[] numArray9 = BitConverter.GetBytes(timeSpan4.Ticks);
				q _q23 = new q();
				_q23.a(983104);
				_q23.a(PropertyType.Time);
				_q23.b(numArray9);
				_q23.b(true);
				_q23.a(true);
				memoryStream.Write(_q23.b(), 0, 16);
			}
			if (this.x.CompareTo(DateTime.MinValue) > 0)
			{
				DateTime dateTime5 = new DateTime(1601, 1, 1);
				universalTime = this.x.ToUniversalTime();
				TimeSpan timeSpan5 = universalTime.Subtract(dateTime5);
				byte[] bytes10 = BitConverter.GetBytes(timeSpan5.Ticks);
				q _q24 = new q();
				_q24.a(4718656);
				_q24.a(PropertyType.Time);
				_q24.b(bytes10);
				_q24.b(true);
				_q24.a(true);
				memoryStream.Write(_q24.b(), 0, 16);
			}
			if (this.y.CompareTo(DateTime.MinValue) > 0)
			{
				DateTime dateTime6 = new DateTime(1601, 1, 1);
				universalTime = this.y.ToUniversalTime();
				TimeSpan timeSpan6 = universalTime.Subtract(dateTime6);
				byte[] numArray10 = BitConverter.GetBytes(timeSpan6.Ticks);
				q _q25 = new q();
				_q25.a(3276864);
				_q25.a(PropertyType.Time);
				_q25.b(numArray10);
				_q25.b(true);
				_q25.a(true);
				memoryStream.Write(_q25.b(), 0, 16);
			}
			if (this.bk.CompareTo(DateTime.MinValue) > 0)
			{
				DateTime dateTime7 = new DateTime(1601, 1, 1);
				universalTime = this.bk.ToUniversalTime();
				TimeSpan timeSpan7 = universalTime.Subtract(dateTime7);
				byte[] bytes11 = BitConverter.GetBytes(timeSpan7.Ticks);
				q _q26 = new q();
				_q26.a(276955200);
				_q26.a(PropertyType.Time);
				_q26.b(bytes11);
				_q26.b(true);
				_q26.a(true);
				memoryStream.Write(_q26.b(), 0, 16);
			}
			if (this.z != null)
			{
				byte[] numArray11 = this.fw.GetBytes(this.z);
				Independentsoft.IO.StructuredStorage.Stream stream11 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_1001", this.fs), numArray11);
				directoryEntryList.Add(stream11);
				q _q27 = new q();
				_q27.a(268500992 | this.ft);
				_q27.a(PropertyType.String8);
				_q27.b((uint)((int)numArray11.Length + (int)this.fw.GetBytes("\0").Length));
				_q27.b(true);
				_q27.a(true);
				memoryStream.Write(_q27.b(), 0, 16);
			}
			if (this.aa != null)
			{
				byte[] bytes12 = this.fw.GetBytes(this.aa);
				Independentsoft.IO.StructuredStorage.Stream stream12 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3FF8", this.fs), bytes12);
				directoryEntryList.Add(stream12);
				q _q28 = new q();
				_q28.a(1073217536 | this.ft);
				_q28.a(PropertyType.String8);
				_q28.b((uint)((int)bytes12.Length + (int)this.fw.GetBytes("\0").Length));
				_q28.b(true);
				_q28.a(true);
				memoryStream.Write(_q28.b(), 0, 16);
			}
			if (this.ab != null)
			{
				byte[] numArray12 = this.fw.GetBytes(this.ab);
				Independentsoft.IO.StructuredStorage.Stream stream13 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3FFA", this.fs), numArray12);
				directoryEntryList.Add(stream13);
				q _q29 = new q();
				_q29.a(1073348608 | this.ft);
				_q29.a(PropertyType.String8);
				_q29.b((uint)((int)numArray12.Length + (int)this.fw.GetBytes("\0").Length));
				_q29.b(true);
				_q29.a(true);
				memoryStream.Write(_q29.b(), 0, 16);
			}
			if (this.ac != null)
			{
				byte[] bytes13 = this.fw.GetBytes(this.ac);
				Independentsoft.IO.StructuredStorage.Stream stream14 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_1035", this.fs), bytes13);
				directoryEntryList.Add(stream14);
				q _q30 = new q();
				_q30.a(271908864 | this.ft);
				_q30.a(PropertyType.String8);
				_q30.b((uint)((int)bytes13.Length + (int)this.fw.GetBytes("\0").Length));
				_q30.b(true);
				_q30.a(true);
				memoryStream.Write(_q30.b(), 0, 16);
			}
			if (this.ad != null)
			{
				byte[] numArray13 = this.fw.GetBytes(this.ad);
				Independentsoft.IO.StructuredStorage.Stream stream15 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_1042", this.fs), numArray13);
				directoryEntryList.Add(stream15);
				q _q31 = new q();
				_q31.a(272760832 | this.ft);
				_q31.a(PropertyType.String8);
				_q31.b((uint)((int)numArray13.Length + (int)this.fw.GetBytes("\0").Length));
				_q31.b(true);
				_q31.a(true);
				memoryStream.Write(_q31.b(), 0, 16);
			}
			if (this.ae != null)
			{
				byte[] bytes14 = this.fw.GetBytes(this.ae);
				Independentsoft.IO.StructuredStorage.Stream stream16 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_1039", this.fs), bytes14);
				directoryEntryList.Add(stream16);
				q _q32 = new q();
				_q32.a(272171008 | this.ft);
				_q32.a(PropertyType.String8);
				_q32.b((uint)((int)bytes14.Length + (int)this.fw.GetBytes("\0").Length));
				_q32.b(true);
				_q32.a(true);
				memoryStream.Write(_q32.b(), 0, 16);
			}
			if (this.af > 0)
			{
				q _q33 = new q();
				_q33.a(1073545219);
				_q33.a(PropertyType.Integer32);
				_q33.b(BitConverter.GetBytes(this.af));
				_q33.b(true);
				_q33.a(true);
				memoryStream.Write(_q33.b(), 0, 16);
			}
			if (this.ag > 0)
			{
				q _q34 = new q();
				_q34.a(276824067);
				_q34.a(PropertyType.Integer32);
				_q34.b(BitConverter.GetBytes(this.ag));
				_q34.b(true);
				_q34.a(true);
				memoryStream.Write(_q34.b(), 0, 16);
			}
			if (this.ah > 0)
			{
				q _q35 = new q();
				_q35.a(235405315);
				_q35.a(PropertyType.Integer32);
				_q35.b(BitConverter.GetBytes(this.ah));
				_q35.b(true);
				_q35.a(true);
				memoryStream.Write(_q35.b(), 0, 16);
			}
			if (this.bm != null && this.bm.Count > 0)
			{
				q _q36 = new q();
				_q36.a(235339779);
				_q36.a(PropertyType.Integer32);
				_q36.b(BitConverter.GetBytes(h.a(this.bm)));
				_q36.b(true);
				_q36.a(true);
				memoryStream.Write(_q36.b(), 0, 16);
			}
			if (this.ai > 0)
			{
				q _q37 = new q();
				_q37.a(1071513603);
				_q37.a(PropertyType.Integer32);
				_q37.b(BitConverter.GetBytes(this.ai));
				_q37.b(true);
				_q37.a(true);
				memoryStream.Write(_q37.b(), 0, 16);
			}
			if (this.aj != null)
			{
				directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_00710102", this.aj));
				q _q38 = new q();
				_q38.a(7405826);
				_q38.a(PropertyType.Binary);
				_q38.b((uint)this.aj.Length);
				_q38.b(true);
				_q38.a(true);
				memoryStream.Write(_q38.b(), 0, 16);
			}
			if (this.ak)
			{
				q _q39 = new q();
				_q39.a(284426251);
				_q39.a(PropertyType.Boolean);
				_q39.b(BitConverter.GetBytes(1));
				_q39.b(true);
				_q39.a(true);
				memoryStream.Write(_q39.b(), 0, 16);
			}
			if (this.al)
			{
				q _q40 = new q();
				_q40.a(284557323);
				_q40.a(PropertyType.Boolean);
				_q40.b(BitConverter.GetBytes(1));
				_q40.b(true);
				_q40.a(true);
				memoryStream.Write(_q40.b(), 0, 16);
			}
			if (this.am)
			{
				q _q41 = new q();
				_q41.a(284491787);
				_q41.a(PropertyType.Boolean);
				_q41.b(BitConverter.GetBytes(1));
				_q41.b(true);
				_q41.a(true);
				memoryStream.Write(_q41.b(), 0, 16);
			}
			if (this.an)
			{
				q _q42 = new q();
				_q42.a(284295179);
				_q42.a(PropertyType.Boolean);
				_q42.b(BitConverter.GetBytes(1));
				_q42.b(true);
				_q42.a(true);
				memoryStream.Write(_q42.b(), 0, 16);
			}
			if (this.fp.Count > 0)
			{
				q _q43 = new q();
				_q43.a(236650507);
				_q43.a(PropertyType.Boolean);
				_q43.b(BitConverter.GetBytes(1));
				_q43.b(true);
				_q43.a(true);
				memoryStream.Write(_q43.b(), 0, 16);
			}
			if (this.ap)
			{
				q _q44 = new q();
				_q44.a(236912651);
				_q44.a(PropertyType.Boolean);
				_q44.b(BitConverter.GetBytes(1));
				_q44.b(true);
				_q44.a(true);
				memoryStream.Write(_q44.b(), 0, 16);
			}
			if (this.aq)
			{
				q _q45 = new q();
				_q45.a(2686987);
				_q45.a(PropertyType.Boolean);
				_q45.b(BitConverter.GetBytes(1));
				_q45.b(true);
				_q45.a(true);
				memoryStream.Write(_q45.b(), 0, 16);
			}
			if (this.ar)
			{
				q _q46 = new q();
				_q46.a(2293771);
				_q46.a(PropertyType.Boolean);
				_q46.b(BitConverter.GetBytes(1));
				_q46.b(true);
				_q46.a(true);
				memoryStream.Write(_q46.b(), 0, 16);
			}
			if (this.@as != null)
			{
				directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_10130102", this.@as));
				q _q47 = new q();
				_q47.a(269680898);
				_q47.a(PropertyType.Binary);
				_q47.b((uint)this.@as.Length);
				_q47.b(true);
				_q47.a(true);
				memoryStream.Write(_q47.b(), 0, 16);
			}
			if (this.at != Independentsoft.Msg.Sensitivity.None)
			{
				q _q48 = new q();
				_q48.a(3538947);
				_q48.a(PropertyType.Integer32);
				_q48.b(BitConverter.GetBytes(h.a(this.at)));
				_q48.b(true);
				_q48.a(true);
				memoryStream.Write(_q48.b(), 0, 16);
			}
			if (this.bl != Independentsoft.Msg.LastVerbExecuted.None)
			{
				q _q49 = new q();
				_q49.a(276889603);
				_q49.a(PropertyType.Integer32);
				_q49.b(BitConverter.GetBytes(h.a(this.bl)));
				_q49.b(true);
				_q49.a(true);
				memoryStream.Write(_q49.b(), 0, 16);
			}
			if (this.au != Independentsoft.Msg.Importance.None)
			{
				q _q50 = new q();
				_q50.a(1507331);
				_q50.a(PropertyType.Integer32);
				_q50.b(BitConverter.GetBytes(h.a(this.au)));
				_q50.b(true);
				_q50.a(true);
				memoryStream.Write(_q50.b(), 0, 16);
			}
			if (this.av != Independentsoft.Msg.Priority.None)
			{
				q _q51 = new q();
				_q51.a(2490371);
				_q51.a(PropertyType.Integer32);
				_q51.b(BitConverter.GetBytes(h.a(this.av)));
				_q51.b(true);
				_q51.a(true);
				memoryStream.Write(_q51.b(), 0, 16);
			}
			if (this.aw != Independentsoft.Msg.FlagIcon.None)
			{
				q _q52 = new q();
				_q52.a(278200323);
				_q52.a(PropertyType.Integer32);
				_q52.b(BitConverter.GetBytes(h.a(this.aw)));
				_q52.b(true);
				_q52.a(true);
				memoryStream.Write(_q52.b(), 0, 16);
			}
			if (this.ax != Independentsoft.Msg.FlagStatus.None)
			{
				q _q53 = new q();
				_q53.a(277872643);
				_q53.a(PropertyType.Integer32);
				_q53.b(BitConverter.GetBytes(h.a(this.ax)));
				_q53.b(true);
				_q53.a(true);
				memoryStream.Write(_q53.b(), 0, 16);
			}
			if (this.ay != Independentsoft.Msg.ObjectType.None)
			{
				q _q54 = new q();
				_q54.a(268304387);
				_q54.a(PropertyType.Integer32);
				_q54.b(BitConverter.GetBytes(h.a(this.ay)));
				_q54.b(true);
				_q54.a(true);
				memoryStream.Write(_q54.b(), 0, 16);
			}
			if (this.az != null)
			{
				byte[] numArray14 = this.fw.GetBytes(this.az);
				Independentsoft.IO.StructuredStorage.Stream stream17 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_0077", this.fs), numArray14);
				directoryEntryList.Add(stream17);
				q _q55 = new q();
				_q55.a(7798784 | this.ft);
				_q55.a(PropertyType.String8);
				_q55.b((uint)((int)numArray14.Length + (int)this.fw.GetBytes("\0").Length));
				_q55.b(true);
				_q55.a(true);
				memoryStream.Write(_q55.b(), 0, 16);
			}
			if (this.a0 != null)
			{
				byte[] bytes15 = this.fw.GetBytes(this.a0);
				Independentsoft.IO.StructuredStorage.Stream stream18 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_0078", this.fs), bytes15);
				directoryEntryList.Add(stream18);
				q _q56 = new q();
				_q56.a(7864320 | this.ft);
				_q56.a(PropertyType.String8);
				_q56.b((uint)((int)bytes15.Length + (int)this.fw.GetBytes("\0").Length));
				_q56.b(true);
				_q56.a(true);
				memoryStream.Write(_q56.b(), 0, 16);
			}
			if (this.a1 != null)
			{
				directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_00430102", this.a1));
				q _q57 = new q();
				_q57.a(4391170);
				_q57.a(PropertyType.Binary);
				_q57.b((uint)this.a1.Length);
				_q57.b(true);
				_q57.a(true);
				memoryStream.Write(_q57.b(), 0, 16);
			}
			if (this.a2 != null)
			{
				byte[] numArray15 = this.fw.GetBytes(this.a2);
				Independentsoft.IO.StructuredStorage.Stream stream19 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_0044", this.fs), numArray15);
				directoryEntryList.Add(stream19);
				q _q58 = new q();
				_q58.a(4456448 | this.ft);
				_q58.a(PropertyType.String8);
				_q58.b((uint)((int)numArray15.Length + (int)this.fw.GetBytes("\0").Length));
				_q58.b(true);
				_q58.a(true);
				memoryStream.Write(_q58.b(), 0, 16);
			}
			if (this.a3 != null)
			{
				directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_00520102", this.a3));
				q _q59 = new q();
				_q59.a(5374210);
				_q59.a(PropertyType.Binary);
				_q59.b((uint)this.a3.Length);
				_q59.b(true);
				_q59.a(true);
				memoryStream.Write(_q59.b(), 0, 16);
			}
			if (this.a4 != null)
			{
				byte[] bytes16 = this.fw.GetBytes(this.a4);
				Independentsoft.IO.StructuredStorage.Stream stream20 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_0075", this.fs), bytes16);
				directoryEntryList.Add(stream20);
				q _q60 = new q();
				_q60.a(7667712 | this.ft);
				_q60.a(PropertyType.String8);
				_q60.b((uint)((int)bytes16.Length + (int)this.fw.GetBytes("\0").Length));
				_q60.b(true);
				_q60.a(true);
				memoryStream.Write(_q60.b(), 0, 16);
			}
			if (this.a5 != null)
			{
				byte[] numArray16 = this.fw.GetBytes(this.a5);
				Independentsoft.IO.StructuredStorage.Stream stream21 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_0076", this.fs), numArray16);
				directoryEntryList.Add(stream21);
				q _q61 = new q();
				_q61.a(7733248 | this.ft);
				_q61.a(PropertyType.String8);
				_q61.b((uint)((int)numArray16.Length + (int)this.fw.GetBytes("\0").Length));
				_q61.b(true);
				_q61.a(true);
				memoryStream.Write(_q61.b(), 0, 16);
			}
			if (this.a6 != null)
			{
				directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_003F0102", this.a6));
				q _q62 = new q();
				_q62.a(4129026);
				_q62.a(PropertyType.Binary);
				_q62.b((uint)this.a6.Length);
				_q62.b(true);
				_q62.a(true);
				memoryStream.Write(_q62.b(), 0, 16);
			}
			if (this.a7 != null)
			{
				byte[] bytes17 = this.fw.GetBytes(this.a7);
				Independentsoft.IO.StructuredStorage.Stream stream22 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_0040", this.fs), bytes17);
				directoryEntryList.Add(stream22);
				q _q63 = new q();
				_q63.a(4194304 | this.ft);
				_q63.a(PropertyType.String8);
				_q63.b((uint)((int)bytes17.Length + (int)this.fw.GetBytes("\0").Length));
				_q63.b(true);
				_q63.a(true);
				memoryStream.Write(_q63.b(), 0, 16);
			}
			if (this.a8 != null)
			{
				directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_00510102", this.a8));
				q _q64 = new q();
				_q64.a(5308674);
				_q64.a(PropertyType.Binary);
				_q64.b((uint)this.a8.Length);
				_q64.b(true);
				_q64.a(true);
				memoryStream.Write(_q64.b(), 0, 16);
			}
			if (this.a9 != null)
			{
				byte[] numArray17 = this.fw.GetBytes(this.a9);
				Independentsoft.IO.StructuredStorage.Stream stream23 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_0C1E", this.fs), numArray17);
				directoryEntryList.Add(stream23);
				q _q65 = new q();
				_q65.a(203292672 | this.ft);
				_q65.a(PropertyType.String8);
				_q65.b((uint)((int)numArray17.Length + (int)this.fw.GetBytes("\0").Length));
				_q65.b(true);
				_q65.a(true);
				memoryStream.Write(_q65.b(), 0, 16);
			}
			if (this.ba != null)
			{
				byte[] bytes18 = this.fw.GetBytes(this.ba);
				Independentsoft.IO.StructuredStorage.Stream stream24 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_0C1F", this.fs), bytes18);
				directoryEntryList.Add(stream24);
				q _q66 = new q();
				_q66.a(203358208 | this.ft);
				_q66.a(PropertyType.String8);
				_q66.b((uint)((int)bytes18.Length + (int)this.fw.GetBytes("\0").Length));
				_q66.b(true);
				_q66.a(true);
				memoryStream.Write(_q66.b(), 0, 16);
			}
			if (this.bb != null)
			{
				directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_0C190102", this.bb));
				q _q67 = new q();
				_q67.a(202965250);
				_q67.a(PropertyType.Binary);
				_q67.b((uint)this.bb.Length);
				_q67.b(true);
				_q67.a(true);
				memoryStream.Write(_q67.b(), 0, 16);
			}
			if (this.bc != null)
			{
				byte[] numArray18 = this.fw.GetBytes(this.bc);
				Independentsoft.IO.StructuredStorage.Stream stream25 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_0C1A", this.fs), numArray18);
				directoryEntryList.Add(stream25);
				q _q68 = new q();
				_q68.a(203030528 | this.ft);
				_q68.a(PropertyType.String8);
				_q68.b((uint)((int)numArray18.Length + (int)this.fw.GetBytes("\0").Length));
				_q68.b(true);
				_q68.a(true);
				memoryStream.Write(_q68.b(), 0, 16);
			}
			if (this.bd != null)
			{
				directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_0C1D0102", this.bd));
				q _q69 = new q();
				_q69.a(203227394);
				_q69.a(PropertyType.Binary);
				_q69.b((uint)this.bd.Length);
				_q69.b(true);
				_q69.a(true);
				memoryStream.Write(_q69.b(), 0, 16);
			}
			if (this.be != null)
			{
				byte[] bytes19 = this.fw.GetBytes(this.be);
				Independentsoft.IO.StructuredStorage.Stream stream26 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_0064", this.fs), bytes19);
				directoryEntryList.Add(stream26);
				q _q70 = new q();
				_q70.a(6553600 | this.ft);
				_q70.a(PropertyType.String8);
				_q70.b((uint)((int)bytes19.Length + (int)this.fw.GetBytes("\0").Length));
				_q70.b(true);
				_q70.a(true);
				memoryStream.Write(_q70.b(), 0, 16);
			}
			if (this.bf != null)
			{
				byte[] numArray19 = this.fw.GetBytes(this.bf);
				Independentsoft.IO.StructuredStorage.Stream stream27 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_0065", this.fs), numArray19);
				directoryEntryList.Add(stream27);
				q _q71 = new q();
				_q71.a(6619136 | this.ft);
				_q71.a(PropertyType.String8);
				_q71.b((uint)((int)numArray19.Length + (int)this.fw.GetBytes("\0").Length));
				_q71.b(true);
				_q71.a(true);
				memoryStream.Write(_q71.b(), 0, 16);
			}
			if (this.bg != null)
			{
				directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_00410102", this.bg));
				q _q72 = new q();
				_q72.a(4260098);
				_q72.a(PropertyType.Binary);
				_q72.b((uint)this.bg.Length);
				_q72.b(true);
				_q72.a(true);
				memoryStream.Write(_q72.b(), 0, 16);
			}
			if (this.bh != null)
			{
				byte[] bytes20 = this.fw.GetBytes(this.bh);
				Independentsoft.IO.StructuredStorage.Stream stream28 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_0042", this.fs), bytes20);
				directoryEntryList.Add(stream28);
				q _q73 = new q();
				_q73.a(4325376 | this.ft);
				_q73.a(PropertyType.String8);
				_q73.b((uint)((int)bytes20.Length + (int)this.fw.GetBytes("\0").Length));
				_q73.b(true);
				_q73.a(true);
				memoryStream.Write(_q73.b(), 0, 16);
			}
			if (this.bi != null)
			{
				directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_003B0102", this.bi));
				q _q74 = new q();
				_q74.a(3866882);
				_q74.a(PropertyType.Binary);
				_q74.b((uint)this.bi.Length);
				_q74.b(true);
				_q74.a(true);
				memoryStream.Write(_q74.b(), 0, 16);
			}
			if (this.bj != null)
			{
				byte[] numArray20 = this.fw.GetBytes(this.bj);
				Independentsoft.IO.StructuredStorage.Stream stream29 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_007D", this.fs), numArray20);
				directoryEntryList.Add(stream29);
				q _q75 = new q();
				_q75.a(8192000 | this.ft);
				_q75.a(PropertyType.String8);
				_q75.b((uint)((int)numArray20.Length + (int)this.fw.GetBytes("\0").Length));
				_q75.b(true);
				_q75.a(true);
				memoryStream.Write(_q75.b(), 0, 16);
			}
			if (this.bo != null)
			{
				c _c = new c();
				_c.a(34132);
				_c.a(StandardPropertySet.Common);
				_c.a(g.b);
				int count = m.a(A_0, _c);
				if (count == -1)
				{
					A_0.Add(_c);
					count = A_0.Count - 1;
				}
				uint num = 32768 + count << 16 | this.ft;
				string str = string.Format("{0:X8}", num);
				byte[] bytes21 = this.fw.GetBytes(this.bo);
				Independentsoft.IO.StructuredStorage.Stream stream30 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str), bytes21);
				directoryEntryList.Add(stream30);
				q _q76 = new q();
				_q76.a(num);
				_q76.a(PropertyType.String8);
				_q76.b((uint)((int)bytes21.Length + (int)this.fw.GetBytes("\0").Length));
				_q76.b(true);
				_q76.a(true);
				memoryStream.Write(_q76.b(), 0, 16);
			}
			if (this.bp > 0)
			{
				c _c1 = new c();
				_c1.a(34130);
				_c1.a(StandardPropertySet.Common);
				_c1.a(g.a);
				int count1 = m.a(A_0, _c1);
				if (count1 == -1)
				{
					A_0.Add(_c1);
					count1 = A_0.Count - 1;
				}
				uint num1 = (uint)(32768 + count1 << 16 | 3);
				q _q77 = new q();
				_q77.a(num1);
				_q77.a(PropertyType.Integer32);
				_q77.b(BitConverter.GetBytes(this.bp));
				_q77.b(true);
				_q77.a(true);
				memoryStream.Write(_q77.b(), 0, 16);
			}
			if (this.bq.CompareTo(DateTime.MinValue) > 0)
			{
				c _c2 = new c();
				_c2.a(34070);
				_c2.a(StandardPropertySet.Common);
				_c2.a(g.a);
				int count2 = m.a(A_0, _c2);
				if (count2 == -1)
				{
					A_0.Add(_c2);
					count2 = A_0.Count - 1;
				}
				uint num2 = (uint)(32768 + count2 << 16 | 64);
				DateTime dateTime8 = new DateTime(1601, 1, 1);
				universalTime = this.bq.ToUniversalTime();
				TimeSpan timeSpan8 = universalTime.Subtract(dateTime8);
				byte[] numArray21 = BitConverter.GetBytes(timeSpan8.Ticks);
				q _q78 = new q();
				_q78.a(num2);
				_q78.a(PropertyType.Time);
				_q78.b(numArray21);
				_q78.b(true);
				_q78.a(true);
				memoryStream.Write(_q78.b(), 0, 16);
			}
			if (this.br.CompareTo(DateTime.MinValue) > 0)
			{
				c _c3 = new c();
				_c3.a(34071);
				_c3.a(StandardPropertySet.Common);
				_c3.a(g.a);
				int count3 = m.a(A_0, _c3);
				if (count3 == -1)
				{
					A_0.Add(_c3);
					count3 = A_0.Count - 1;
				}
				uint num3 = (uint)(32768 + count3 << 16 | 64);
				DateTime dateTime9 = new DateTime(1601, 1, 1);
				universalTime = this.br.ToUniversalTime();
				TimeSpan timeSpan9 = universalTime.Subtract(dateTime9);
				byte[] bytes22 = BitConverter.GetBytes(timeSpan9.Ticks);
				q _q79 = new q();
				_q79.a(num3);
				_q79.a(PropertyType.Time);
				_q79.b(bytes22);
				_q79.b(true);
				_q79.a(true);
				memoryStream.Write(_q79.b(), 0, 16);
			}
			if (this.bs.CompareTo(DateTime.MinValue) > 0)
			{
				c _c4 = new c();
				_c4.a(34144);
				_c4.a(StandardPropertySet.Common);
				_c4.a(g.a);
				int count4 = m.a(A_0, _c4);
				if (count4 == -1)
				{
					A_0.Add(_c4);
					count4 = A_0.Count - 1;
				}
				uint num4 = (uint)(32768 + count4 << 16 | 64);
				DateTime dateTime10 = new DateTime(1601, 1, 1);
				universalTime = this.bs.ToUniversalTime();
				TimeSpan timeSpan10 = universalTime.Subtract(dateTime10);
				byte[] numArray22 = BitConverter.GetBytes(timeSpan10.Ticks);
				q _q80 = new q();
				_q80.a(num4);
				_q80.a(PropertyType.Time);
				_q80.b(numArray22);
				_q80.b(true);
				_q80.a(true);
				memoryStream.Write(_q80.b(), 0, 16);
			}
			if (this.bw.Count > 0)
			{
				c _c5 = new c();
				_c5.a(34105);
				_c5.a(StandardPropertySet.Common);
				_c5.a(g.b);
				int count5 = m.a(A_0, _c5);
				if (count5 == -1)
				{
					A_0.Add(_c5);
					count5 = A_0.Count - 1;
				}
				uint num5 = 32768 + count5 << 16 | this.fv;
				string str1 = string.Format("{0:X8}", num5);
				MemoryStream memoryStream1 = new MemoryStream();
				for (int i = 0; i < this.bw.Count; i++)
				{
					byte[] bytes23 = this.fw.GetBytes(string.Concat(this.bw[i], "\0"));
					uint length = (uint)bytes23.Length;
					memoryStream1.Write(BitConverter.GetBytes(length), 0, 4);
					string str2 = string.Concat("__substg1.0_", str1, "-", string.Format("{0:X8}", i));
					directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream(str2, bytes23));
				}
				byte[] array = memoryStream1.ToArray();
				Independentsoft.IO.StructuredStorage.Stream stream31 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str1), array);
				directoryEntryList.Add(stream31);
				q _q81 = new q();
				_q81.a(num5);
				_q81.a(PropertyType.MultipleString8);
				_q81.b((uint)array.Length);
				_q81.b(true);
				_q81.a(true);
				memoryStream.Write(_q81.b(), 0, 16);
			}
			if (this.bx.Count > 0)
			{
				c _c6 = new c();
				_c6.a(34106);
				_c6.a(StandardPropertySet.Common);
				_c6.a(g.b);
				int count6 = m.a(A_0, _c6);
				if (count6 == -1)
				{
					A_0.Add(_c6);
					count6 = A_0.Count - 1;
				}
				uint num6 = 32768 + count6 << 16 | this.fv;
				string str3 = string.Format("{0:X8}", num6);
				MemoryStream memoryStream2 = new MemoryStream();
				for (int j = 0; j < this.bx.Count; j++)
				{
					byte[] numArray23 = this.fw.GetBytes(string.Concat(this.bx[j], "\0"));
					uint length1 = (uint)numArray23.Length;
					memoryStream2.Write(BitConverter.GetBytes(length1), 0, 4);
					string str4 = string.Concat("__substg1.0_", str3, "-", string.Format("{0:X8}", j));
					directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream(str4, numArray23));
				}
				byte[] array1 = memoryStream2.ToArray();
				Independentsoft.IO.StructuredStorage.Stream stream32 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str3), array1);
				directoryEntryList.Add(stream32);
				q _q82 = new q();
				_q82.a(num6);
				_q82.a(PropertyType.MultipleString8);
				_q82.b((uint)array1.Length);
				_q82.b(true);
				_q82.a(true);
				memoryStream.Write(_q82.b(), 0, 16);
			}
			if (this.by.Count > 0)
			{
				c _c7 = new c();
				_c7.a("Keywords");
				_c7.a(StandardPropertySet.PublicStrings);
				_c7.a(g.b);
				int count7 = m.a(A_0, _c7);
				if (count7 == -1)
				{
					A_0.Add(_c7);
					count7 = A_0.Count - 1;
				}
				uint num7 = 32768 + count7 << 16 | this.fv;
				string str5 = string.Format("{0:X8}", num7);
				MemoryStream memoryStream3 = new MemoryStream();
				for (int k = 0; k < this.by.Count; k++)
				{
					byte[] bytes24 = this.fw.GetBytes(string.Concat(this.by[k], "\0"));
					uint length2 = (uint)bytes24.Length;
					memoryStream3.Write(BitConverter.GetBytes(length2), 0, 4);
					string str6 = string.Concat("__substg1.0_", str5, "-", string.Format("{0:X8}", k));
					directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream(str6, bytes24));
				}
				byte[] array2 = memoryStream3.ToArray();
				Independentsoft.IO.StructuredStorage.Stream stream33 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str5), array2);
				directoryEntryList.Add(stream33);
				q _q83 = new q();
				_q83.a(num7);
				_q83.a(PropertyType.MultipleString8);
				_q83.b((uint)array2.Length);
				_q83.b(true);
				_q83.a(true);
				memoryStream.Write(_q83.b(), 0, 16);
			}
			if (this.bz != null)
			{
				c _c8 = new c();
				_c8.a(34101);
				_c8.a(StandardPropertySet.Common);
				_c8.a(g.b);
				int count8 = m.a(A_0, _c8);
				if (count8 == -1)
				{
					A_0.Add(_c8);
					count8 = A_0.Count - 1;
				}
				uint num8 = 32768 + count8 << 16 | this.ft;
				string str7 = string.Format("{0:X8}", num8);
				byte[] numArray24 = this.fw.GetBytes(this.bz);
				Independentsoft.IO.StructuredStorage.Stream stream34 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str7), numArray24);
				directoryEntryList.Add(stream34);
				q _q84 = new q();
				_q84.a(num8);
				_q84.a(PropertyType.String8);
				_q84.b((uint)((int)numArray24.Length + (int)this.fw.GetBytes("\0").Length));
				_q84.b(true);
				_q84.a(true);
				memoryStream.Write(_q84.b(), 0, 16);
			}
			if (this.b0 != null)
			{
				c _c9 = new c();
				_c9.a(34100);
				_c9.a(StandardPropertySet.Common);
				_c9.a(g.b);
				int count9 = m.a(A_0, _c9);
				if (count9 == -1)
				{
					A_0.Add(_c9);
					count9 = A_0.Count - 1;
				}
				uint num9 = 32768 + count9 << 16 | this.ft;
				string str8 = string.Format("{0:X8}", num9);
				byte[] bytes25 = this.fw.GetBytes(this.b0);
				Independentsoft.IO.StructuredStorage.Stream stream35 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str8), bytes25);
				directoryEntryList.Add(stream35);
				q _q85 = new q();
				_q85.a(num9);
				_q85.a(PropertyType.String8);
				_q85.b((uint)((int)bytes25.Length + (int)this.fw.GetBytes("\0").Length));
				_q85.b(true);
				_q85.a(true);
				memoryStream.Write(_q85.b(), 0, 16);
			}
			if (this.b6 != null)
			{
				c _c10 = new c();
				_c10.a(34176);
				_c10.a(StandardPropertySet.Common);
				_c10.a(g.b);
				int count10 = m.a(A_0, _c10);
				if (count10 == -1)
				{
					A_0.Add(_c10);
					count10 = A_0.Count - 1;
				}
				uint num10 = 32768 + count10 << 16 | this.ft;
				string str9 = string.Format("{0:X8}", num10);
				byte[] numArray25 = this.fw.GetBytes(this.b6);
				Independentsoft.IO.StructuredStorage.Stream stream36 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str9), numArray25);
				directoryEntryList.Add(stream36);
				q _q86 = new q();
				_q86.a(num10);
				_q86.a(PropertyType.String8);
				_q86.b((uint)((int)numArray25.Length + (int)this.fw.GetBytes("\0").Length));
				_q86.b(true);
				_q86.a(true);
				memoryStream.Write(_q86.b(), 0, 16);
			}
			if (this.b1 != null)
			{
				c _c11 = new c();
				_c11.a(34079);
				_c11.a(StandardPropertySet.Common);
				_c11.a(g.b);
				int count11 = m.a(A_0, _c11);
				if (count11 == -1)
				{
					A_0.Add(_c11);
					count11 = A_0.Count - 1;
				}
				uint num11 = 32768 + count11 << 16 | this.ft;
				string str10 = string.Format("{0:X8}", num11);
				byte[] bytes26 = this.fw.GetBytes(this.b1);
				Independentsoft.IO.StructuredStorage.Stream stream37 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str10), bytes26);
				directoryEntryList.Add(stream37);
				q _q87 = new q();
				_q87.a(num11);
				_q87.a(PropertyType.String8);
				_q87.b((uint)((int)bytes26.Length + (int)this.fw.GetBytes("\0").Length));
				_q87.b(true);
				_q87.a(true);
				memoryStream.Write(_q87.b(), 0, 16);
			}
			if (this.b2)
			{
				c _c12 = new c();
				_c12.a(34054);
				_c12.a(StandardPropertySet.Common);
				_c12.a(g.a);
				int count12 = m.a(A_0, _c12);
				if (count12 == -1)
				{
					A_0.Add(_c12);
					count12 = A_0.Count - 1;
				}
				uint num12 = (uint)(32768 + count12 << 16 | 11);
				q _q88 = new q();
				_q88.a(num12);
				_q88.a(PropertyType.Boolean);
				_q88.b(BitConverter.GetBytes(1));
				_q88.b(true);
				_q88.a(true);
				memoryStream.Write(_q88.b(), 0, 16);
			}
			if (this.b4)
			{
				c _c13 = new c();
				_c13.a(34076);
				_c13.a(StandardPropertySet.Common);
				_c13.a(g.a);
				int count13 = m.a(A_0, _c13);
				if (count13 == -1)
				{
					A_0.Add(_c13);
					count13 = A_0.Count - 1;
				}
				uint num13 = (uint)(32768 + count13 << 16 | 11);
				q _q89 = new q();
				_q89.a(num13);
				_q89.a(PropertyType.Boolean);
				_q89.b(BitConverter.GetBytes(1));
				_q89.b(true);
				_q89.a(true);
				memoryStream.Write(_q89.b(), 0, 16);
			}
			if (this.b5)
			{
				c _c14 = new c();
				_c14.a(34078);
				_c14.a(StandardPropertySet.Common);
				_c14.a(g.a);
				int count14 = m.a(A_0, _c14);
				if (count14 == -1)
				{
					A_0.Add(_c14);
					count14 = A_0.Count - 1;
				}
				uint num14 = (uint)(32768 + count14 << 16 | 11);
				q _q90 = new q();
				_q90.a(num14);
				_q90.a(PropertyType.Boolean);
				_q90.b(BitConverter.GetBytes(1));
				_q90.b(true);
				_q90.a(true);
				memoryStream.Write(_q90.b(), 0, 16);
			}
			if (this.b7.CompareTo(DateTime.MinValue) > 0)
			{
				c _c15 = new c();
				_c15.a(33293);
				_c15.a(StandardPropertySet.Appointment);
				_c15.a(g.a);
				int count15 = m.a(A_0, _c15);
				if (count15 == -1)
				{
					A_0.Add(_c15);
					count15 = A_0.Count - 1;
				}
				uint num15 = (uint)(32768 + count15 << 16 | 64);
				DateTime dateTime11 = new DateTime(1601, 1, 1);
				universalTime = this.b7.ToUniversalTime();
				TimeSpan timeSpan11 = universalTime.Subtract(dateTime11);
				byte[] numArray26 = BitConverter.GetBytes(timeSpan11.Ticks);
				q _q91 = new q();
				_q91.a(num15);
				_q91.a(PropertyType.Time);
				_q91.b(numArray26);
				_q91.b(true);
				_q91.a(true);
				memoryStream.Write(_q91.b(), 0, 16);
			}
			if (this.b8.CompareTo(DateTime.MinValue) > 0)
			{
				c _c16 = new c();
				_c16.a(33294);
				_c16.a(StandardPropertySet.Appointment);
				_c16.a(g.a);
				int count16 = m.a(A_0, _c16);
				if (count16 == -1)
				{
					A_0.Add(_c16);
					count16 = A_0.Count - 1;
				}
				uint num16 = (uint)(32768 + count16 << 16 | 64);
				DateTime dateTime12 = new DateTime(1601, 1, 1);
				universalTime = this.b8.ToUniversalTime();
				TimeSpan timeSpan12 = universalTime.Subtract(dateTime12);
				byte[] bytes27 = BitConverter.GetBytes(timeSpan12.Ticks);
				q _q92 = new q();
				_q92.a(num16);
				_q92.a(PropertyType.Time);
				_q92.b(bytes27);
				_q92.b(true);
				_q92.a(true);
				memoryStream.Write(_q92.b(), 0, 16);
			}
			if (this.ca != null)
			{
				c _c17 = new c();
				_c17.a(33288);
				_c17.a(StandardPropertySet.Appointment);
				_c17.a(g.b);
				int count17 = m.a(A_0, _c17);
				if (count17 == -1)
				{
					A_0.Add(_c17);
					count17 = A_0.Count - 1;
				}
				uint num17 = 32768 + count17 << 16 | this.ft;
				string str11 = string.Format("{0:X8}", num17);
				byte[] numArray27 = this.fw.GetBytes(this.ca);
				Independentsoft.IO.StructuredStorage.Stream stream38 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str11), numArray27);
				directoryEntryList.Add(stream38);
				q _q93 = new q();
				_q93.a(num17);
				_q93.a(PropertyType.String8);
				_q93.b((uint)((int)numArray27.Length + (int)this.fw.GetBytes("\0").Length));
				_q93.b(true);
				_q93.a(true);
				memoryStream.Write(_q93.b(), 0, 16);
			}
			if (this.cf != null)
			{
				c _c18 = new c();
				_c18.a(36);
				_c18.a(new byte[] { 144, 218, 216, 110, 11, 69, 27, 16, 152, 218, 0, 170, 0, 63, 19, 5 });
				_c18.a(g.b);
				int count18 = m.a(A_0, _c18);
				if (count18 == -1)
				{
					A_0.Add(_c18);
					count18 = A_0.Count - 1;
				}
				uint num18 = 32768 + count18 << 16 | this.ft;
				string str12 = string.Format("{0:X8}", num18);
				byte[] bytes28 = this.fw.GetBytes(this.cf);
				Independentsoft.IO.StructuredStorage.Stream stream39 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str12), bytes28);
				directoryEntryList.Add(stream39);
				q _q94 = new q();
				_q94.a(num18);
				_q94.a(PropertyType.String8);
				_q94.b((uint)((int)bytes28.Length + (int)this.fw.GetBytes("\0").Length));
				_q94.b(true);
				_q94.a(true);
				memoryStream.Write(_q94.b(), 0, 16);
			}
			if (this.cg != null)
			{
				c _c19 = new c();
				_c19.a(33332);
				_c19.a(StandardPropertySet.Appointment);
				_c19.a(g.b);
				int count19 = m.a(A_0, _c19);
				if (count19 == -1)
				{
					A_0.Add(_c19);
					count19 = A_0.Count - 1;
				}
				uint num19 = 32768 + count19 << 16 | this.ft;
				string str13 = string.Format("{0:X8}", num19);
				byte[] numArray28 = this.fw.GetBytes(this.cg);
				Independentsoft.IO.StructuredStorage.Stream stream40 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str13), numArray28);
				directoryEntryList.Add(stream40);
				q _q95 = new q();
				_q95.a(num19);
				_q95.a(PropertyType.String8);
				_q95.b((uint)((int)numArray28.Length + (int)this.fw.GetBytes("\0").Length));
				_q95.b(true);
				_q95.a(true);
				memoryStream.Write(_q95.b(), 0, 16);
			}
			if (this.ch != null)
			{
				c _c20 = new c();
				_c20.a(33330);
				_c20.a(StandardPropertySet.Appointment);
				_c20.a(g.b);
				int count20 = m.a(A_0, _c20);
				if (count20 == -1)
				{
					A_0.Add(_c20);
					count20 = A_0.Count - 1;
				}
				uint num20 = 32768 + count20 << 16 | this.ft;
				string str14 = string.Format("{0:X8}", num20);
				byte[] bytes29 = this.fw.GetBytes(this.ch);
				Independentsoft.IO.StructuredStorage.Stream stream41 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str14), bytes29);
				directoryEntryList.Add(stream41);
				q _q96 = new q();
				_q96.a(num20);
				_q96.a(PropertyType.String8);
				_q96.b((uint)((int)bytes29.Length + (int)this.fw.GetBytes("\0").Length));
				_q96.b(true);
				_q96.a(true);
				memoryStream.Write(_q96.b(), 0, 16);
			}
			if (this.cb != Independentsoft.Msg.BusyStatus.None)
			{
				c _c21 = new c();
				_c21.a(33285);
				_c21.a(StandardPropertySet.Appointment);
				_c21.a(g.a);
				int count21 = m.a(A_0, _c21);
				if (count21 == -1)
				{
					A_0.Add(_c21);
					count21 = A_0.Count - 1;
				}
				uint num21 = (uint)(32768 + count21 << 16 | 3);
				q _q97 = new q();
				_q97.a(num21);
				_q97.a(PropertyType.Integer32);
				_q97.b(BitConverter.GetBytes(h.a(this.cb)));
				_q97.b(true);
				_q97.a(true);
				memoryStream.Write(_q97.b(), 0, 16);
			}
			if (this.cc != Independentsoft.Msg.MeetingStatus.None)
			{
				c _c22 = new c();
				_c22.a(33303);
				_c22.a(StandardPropertySet.Appointment);
				_c22.a(g.a);
				int count22 = m.a(A_0, _c22);
				if (count22 == -1)
				{
					A_0.Add(_c22);
					count22 = A_0.Count - 1;
				}
				uint num22 = (uint)(32768 + count22 << 16 | 3);
				q _q98 = new q();
				_q98.a(num22);
				_q98.a(PropertyType.Integer32);
				_q98.b(BitConverter.GetBytes(h.a(this.cc)));
				_q98.b(true);
				_q98.a(true);
				memoryStream.Write(_q98.b(), 0, 16);
			}
			if (this.cd != Independentsoft.Msg.ResponseStatus.None)
			{
				c _c23 = new c();
				_c23.a(33304);
				_c23.a(StandardPropertySet.Appointment);
				_c23.a(g.a);
				int count23 = m.a(A_0, _c23);
				if (count23 == -1)
				{
					A_0.Add(_c23);
					count23 = A_0.Count - 1;
				}
				uint num23 = (uint)(32768 + count23 << 16 | 3);
				q _q99 = new q();
				_q99.a(num23);
				_q99.a(PropertyType.Integer32);
				_q99.b(BitConverter.GetBytes(h.a(this.cd)));
				_q99.b(true);
				_q99.a(true);
				memoryStream.Write(_q99.b(), 0, 16);
			}
			if (this.ce != Independentsoft.Msg.RecurrenceType.None)
			{
				c _c24 = new c();
				_c24.a(33329);
				_c24.a(StandardPropertySet.Appointment);
				_c24.a(g.a);
				int count24 = m.a(A_0, _c24);
				if (count24 == -1)
				{
					A_0.Add(_c24);
					count24 = A_0.Count - 1;
				}
				uint num24 = (uint)(32768 + count24 << 16 | 3);
				q _q100 = new q();
				_q100.a(num24);
				_q100.a(PropertyType.Integer32);
				_q100.b(BitConverter.GetBytes(h.a(this.ce)));
				_q100.b(true);
				_q100.a(true);
				memoryStream.Write(_q100.b(), 0, 16);
			}
			if (this.cj != null)
			{
				c _c25 = new c();
				_c25.a(3);
				_c25.a(new byte[] { 144, 218, 216, 110, 11, 69, 27, 16, 152, 218, 0, 170, 0, 63, 19, 5 });
				_c25.a(g.a);
				int count25 = m.a(A_0, _c25);
				if (count25 == -1)
				{
					A_0.Add(_c25);
					count25 = A_0.Count - 1;
				}
				uint num25 = (uint)(32768 + count25 << 16 | 258);
				string str15 = string.Format("{0:X8}", num25);
				Independentsoft.IO.StructuredStorage.Stream stream42 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str15), this.cj);
				directoryEntryList.Add(stream42);
				q _q101 = new q();
				_q101.a(num25);
				_q101.a(PropertyType.Integer32);
				_q101.b((uint)this.cj.Length);
				_q101.b(true);
				_q101.a(true);
				memoryStream.Write(_q101.b(), 0, 16);
			}
			if (this.ck > -1)
			{
				c _c26 = new c();
				_c26.a(33300);
				_c26.a(StandardPropertySet.Appointment);
				_c26.a(g.a);
				int count26 = m.a(A_0, _c26);
				if (count26 == -1)
				{
					A_0.Add(_c26);
					count26 = A_0.Count - 1;
				}
				uint num26 = (uint)(32768 + count26 << 16 | 3);
				q _q102 = new q();
				_q102.a(num26);
				_q102.a(PropertyType.Integer32);
				_q102.b(BitConverter.GetBytes(this.ck));
				_q102.b(true);
				_q102.a(true);
				memoryStream.Write(_q102.b(), 0, 16);
			}
			if (this.cl > 0)
			{
				c _c27 = new c();
				_c27.a(33299);
				_c27.a(StandardPropertySet.Appointment);
				_c27.a(g.a);
				int count27 = m.a(A_0, _c27);
				if (count27 == -1)
				{
					A_0.Add(_c27);
					count27 = A_0.Count - 1;
				}
				uint num27 = (uint)(32768 + count27 << 16 | 3);
				q _q103 = new q();
				_q103.a(num27);
				_q103.a(PropertyType.Integer32);
				_q103.b(BitConverter.GetBytes(this.cl));
				_q103.b(true);
				_q103.a(true);
				memoryStream.Write(_q103.b(), 0, 16);
			}
			if (this.co != null)
			{
				c _c28 = new c();
				_c28.a(33055);
				_c28.a(StandardPropertySet.Task);
				_c28.a(g.b);
				int count28 = m.a(A_0, _c28);
				if (count28 == -1)
				{
					A_0.Add(_c28);
					count28 = A_0.Count - 1;
				}
				uint num28 = 32768 + count28 << 16 | this.ft;
				string str16 = string.Format("{0:X8}", num28);
				byte[] numArray29 = this.fw.GetBytes(this.co);
				Independentsoft.IO.StructuredStorage.Stream stream43 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str16), numArray29);
				directoryEntryList.Add(stream43);
				q _q104 = new q();
				_q104.a(num28);
				_q104.a(PropertyType.String8);
				_q104.b((uint)((int)numArray29.Length + (int)this.fw.GetBytes("\0").Length));
				_q104.b(true);
				_q104.a(true);
				memoryStream.Write(_q104.b(), 0, 16);
			}
			if (this.cp != null)
			{
				c _c29 = new c();
				_c29.a(33057);
				_c29.a(StandardPropertySet.Task);
				_c29.a(g.b);
				int count29 = m.a(A_0, _c29);
				if (count29 == -1)
				{
					A_0.Add(_c29);
					count29 = A_0.Count - 1;
				}
				uint num29 = 32768 + count29 << 16 | this.ft;
				string str17 = string.Format("{0:X8}", num29);
				byte[] bytes30 = this.fw.GetBytes(this.cp);
				Independentsoft.IO.StructuredStorage.Stream stream44 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str17), bytes30);
				directoryEntryList.Add(stream44);
				q _q105 = new q();
				_q105.a(num29);
				_q105.a(PropertyType.String8);
				_q105.b((uint)((int)bytes30.Length + (int)this.fw.GetBytes("\0").Length));
				_q105.b(true);
				_q105.a(true);
				memoryStream.Write(_q105.b(), 0, 16);
			}
			if (this.cq > 0)
			{
				c _c30 = new c();
				_c30.a(33026);
				_c30.a(StandardPropertySet.Task);
				_c30.a(g.a);
				int count30 = m.a(A_0, _c30);
				if (count30 == -1)
				{
					A_0.Add(_c30);
					count30 = A_0.Count - 1;
				}
				uint num30 = (uint)(32768 + count30 << 16 | 5);
				q _q106 = new q();
				_q106.a(num30);
				_q106.a(PropertyType.Floating64);
				_q106.b(BitConverter.GetBytes(this.cq / 100));
				_q106.b(true);
				_q106.a(true);
				memoryStream.Write(_q106.b(), 0, 16);
			}
			if (this.cr > 0)
			{
				c _c31 = new c();
				_c31.a(33040);
				_c31.a(StandardPropertySet.Task);
				_c31.a(g.a);
				int count31 = m.a(A_0, _c31);
				if (count31 == -1)
				{
					A_0.Add(_c31);
					count31 = A_0.Count - 1;
				}
				uint num31 = (uint)(32768 + count31 << 16 | 3);
				q _q107 = new q();
				_q107.a(num31);
				_q107.a(PropertyType.Integer32);
				_q107.b(BitConverter.GetBytes(this.cr));
				_q107.b(true);
				_q107.a(true);
				memoryStream.Write(_q107.b(), 0, 16);
			}
			if (this.cs > 0)
			{
				c _c32 = new c();
				_c32.a(33041);
				_c32.a(StandardPropertySet.Task);
				_c32.a(g.a);
				int count32 = m.a(A_0, _c32);
				if (count32 == -1)
				{
					A_0.Add(_c32);
					count32 = A_0.Count - 1;
				}
				uint num32 = (uint)(32768 + count32 << 16 | 3);
				q _q108 = new q();
				_q108.a(num32);
				_q108.a(PropertyType.Integer32);
				_q108.b(BitConverter.GetBytes(this.cs));
				_q108.b(true);
				_q108.a(true);
				memoryStream.Write(_q108.b(), 0, 16);
			}
			if (this.ct)
			{
				c _c33 = new c();
				_c33.a(33027);
				_c33.a(StandardPropertySet.Task);
				_c33.a(g.a);
				int count33 = m.a(A_0, _c33);
				if (count33 == -1)
				{
					A_0.Add(_c33);
					count33 = A_0.Count - 1;
				}
				uint num33 = (uint)(32768 + count33 << 16 | 11);
				q _q109 = new q();
				_q109.a(num33);
				_q109.a(PropertyType.Boolean);
				_q109.b(BitConverter.GetBytes(1));
				_q109.b(true);
				_q109.a(true);
				memoryStream.Write(_q109.b(), 0, 16);
			}
			if (this.cu)
			{
				c _c34 = new c();
				_c34.a(33052);
				_c34.a(StandardPropertySet.Task);
				_c34.a(g.a);
				int count34 = m.a(A_0, _c34);
				if (count34 == -1)
				{
					A_0.Add(_c34);
					count34 = A_0.Count - 1;
				}
				uint num34 = (uint)(32768 + count34 << 16 | 11);
				q _q110 = new q();
				_q110.a(num34);
				_q110.a(PropertyType.Boolean);
				_q110.b(BitConverter.GetBytes(1));
				_q110.b(true);
				_q110.a(true);
				memoryStream.Write(_q110.b(), 0, 16);
			}
			if (this.bt)
			{
				c _c35 = new c();
				_c35.a(33315);
				_c35.a(StandardPropertySet.Appointment);
				_c35.a(g.a);
				int count35 = m.a(A_0, _c35);
				if (count35 == -1)
				{
					A_0.Add(_c35);
					count35 = A_0.Count - 1;
				}
				uint num35 = (uint)(32768 + count35 << 16 | 11);
				q _q111 = new q();
				_q111.a(num35);
				_q111.a(PropertyType.Boolean);
				_q111.b(BitConverter.GetBytes(1));
				_q111.b(true);
				_q111.a(true);
				memoryStream.Write(_q111.b(), 0, 16);
			}
			if (this.b9)
			{
				c _c36 = new c();
				_c36.a(33301);
				_c36.a(StandardPropertySet.Appointment);
				_c36.a(g.a);
				int count36 = m.a(A_0, _c36);
				if (count36 == -1)
				{
					A_0.Add(_c36);
					count36 = A_0.Count - 1;
				}
				uint num36 = (uint)(32768 + count36 << 16 | 11);
				q _q112 = new q();
				_q112.a(num36);
				_q112.a(PropertyType.Boolean);
				_q112.b(BitConverter.GetBytes(1));
				_q112.b(true);
				_q112.a(true);
				memoryStream.Write(_q112.b(), 0, 16);
			}
			if (this.b3)
			{
				c _c37 = new c();
				_c37.a(34051);
				_c37.a(StandardPropertySet.Common);
				_c37.a(g.a);
				int count37 = m.a(A_0, _c37);
				if (count37 == -1)
				{
					A_0.Add(_c37);
					count37 = A_0.Count - 1;
				}
				uint num37 = (uint)(32768 + count37 << 16 | 11);
				q _q113 = new q();
				_q113.a(num37);
				_q113.a(PropertyType.Boolean);
				_q113.b(BitConverter.GetBytes(1));
				_q113.b(true);
				_q113.a(true);
				memoryStream.Write(_q113.b(), 0, 16);
			}
			if (this.bu.CompareTo(DateTime.MinValue) > 0)
			{
				c _c38 = new c();
				_c38.a(34050);
				_c38.a(StandardPropertySet.Common);
				_c38.a(g.a);
				int count38 = m.a(A_0, _c38);
				if (count38 == -1)
				{
					A_0.Add(_c38);
					count38 = A_0.Count - 1;
				}
				uint num38 = (uint)(32768 + count38 << 16 | 64);
				DateTime dateTime13 = new DateTime(1601, 1, 1);
				universalTime = this.bu.ToUniversalTime();
				TimeSpan timeSpan13 = universalTime.Subtract(dateTime13);
				byte[] numArray30 = BitConverter.GetBytes(timeSpan13.Ticks);
				q _q114 = new q();
				_q114.a(num38);
				_q114.a(PropertyType.Time);
				_q114.b(numArray30);
				_q114.b(true);
				_q114.a(true);
				memoryStream.Write(_q114.b(), 0, 16);
			}
			if (this.bv > 0)
			{
				c _c39 = new c();
				_c39.a(34049);
				_c39.a(StandardPropertySet.Common);
				_c39.a(g.a);
				int count39 = m.a(A_0, _c39);
				if (count39 == -1)
				{
					A_0.Add(_c39);
					count39 = A_0.Count - 1;
				}
				uint num39 = (uint)(32768 + count39 << 16 | 3);
				q _q115 = new q();
				_q115.a(num39);
				_q115.a(PropertyType.Integer32);
				_q115.b(BitConverter.GetBytes(this.bv));
				_q115.b(true);
				_q115.a(true);
				memoryStream.Write(_q115.b(), 0, 16);
			}
			if (this.cm.CompareTo(DateTime.MinValue) > 0)
			{
				c _c40 = new c();
				_c40.a(33028);
				_c40.a(StandardPropertySet.Task);
				_c40.a(g.a);
				int count40 = m.a(A_0, _c40);
				if (count40 == -1)
				{
					A_0.Add(_c40);
					count40 = A_0.Count - 1;
				}
				uint num40 = (uint)(32768 + count40 << 16 | 64);
				DateTime dateTime14 = new DateTime(1601, 1, 1);
				universalTime = this.cm.ToUniversalTime();
				TimeSpan timeSpan14 = universalTime.Subtract(dateTime14);
				byte[] bytes31 = BitConverter.GetBytes(timeSpan14.Ticks);
				q _q116 = new q();
				_q116.a(num40);
				_q116.a(PropertyType.Time);
				_q116.b(bytes31);
				_q116.b(true);
				_q116.a(true);
				memoryStream.Write(_q116.b(), 0, 16);
			}
			if (this.cn.CompareTo(DateTime.MinValue) > 0)
			{
				c _c41 = new c();
				_c41.a(33029);
				_c41.a(StandardPropertySet.Task);
				_c41.a(g.a);
				int count41 = m.a(A_0, _c41);
				if (count41 == -1)
				{
					A_0.Add(_c41);
					count41 = A_0.Count - 1;
				}
				uint num41 = (uint)(32768 + count41 << 16 | 64);
				DateTime dateTime15 = new DateTime(1601, 1, 1);
				universalTime = this.cn.ToUniversalTime();
				TimeSpan timeSpan15 = universalTime.Subtract(dateTime15);
				byte[] numArray31 = BitConverter.GetBytes(timeSpan15.Ticks);
				q _q117 = new q();
				_q117.a(num41);
				_q117.a(PropertyType.Time);
				_q117.b(numArray31);
				_q117.b(true);
				_q117.a(true);
				memoryStream.Write(_q117.b(), 0, 16);
			}
			if (this.cv.CompareTo(DateTime.MinValue) > 0)
			{
				c _c42 = new c();
				_c42.a(33039);
				_c42.a(StandardPropertySet.Task);
				_c42.a(g.a);
				int count42 = m.a(A_0, _c42);
				if (count42 == -1)
				{
					A_0.Add(_c42);
					count42 = A_0.Count - 1;
				}
				uint num42 = (uint)(32768 + count42 << 16 | 64);
				DateTime dateTime16 = new DateTime(1601, 1, 1);
				universalTime = this.cv.ToUniversalTime();
				TimeSpan timeSpan16 = universalTime.Subtract(dateTime16);
				byte[] bytes32 = BitConverter.GetBytes(timeSpan16.Ticks);
				q _q118 = new q();
				_q118.a(num42);
				_q118.a(PropertyType.Time);
				_q118.b(bytes32);
				_q118.b(true);
				_q118.a(true);
				memoryStream.Write(_q118.b(), 0, 16);
			}
			if (this.cw != Independentsoft.Msg.TaskStatus.None)
			{
				c _c43 = new c();
				_c43.a(33025);
				_c43.a(StandardPropertySet.Task);
				_c43.a(g.a);
				int count43 = m.a(A_0, _c43);
				if (count43 == -1)
				{
					A_0.Add(_c43);
					count43 = A_0.Count - 1;
				}
				uint num43 = (uint)(32768 + count43 << 16 | 3);
				q _q119 = new q();
				_q119.a(num43);
				_q119.a(PropertyType.Integer32);
				_q119.b(BitConverter.GetBytes(h.a(this.cw)));
				_q119.b(true);
				_q119.a(true);
				memoryStream.Write(_q119.b(), 0, 16);
			}
			if (this.cx != Independentsoft.Msg.TaskOwnership.None)
			{
				c _c44 = new c();
				_c44.a(33065);
				_c44.a(StandardPropertySet.Task);
				_c44.a(g.a);
				int count44 = m.a(A_0, _c44);
				if (count44 == -1)
				{
					A_0.Add(_c44);
					count44 = A_0.Count - 1;
				}
				uint num44 = (uint)(32768 + count44 << 16 | 3);
				q _q120 = new q();
				_q120.a(num44);
				_q120.a(PropertyType.Integer32);
				_q120.b(BitConverter.GetBytes(h.a(this.cx)));
				_q120.b(true);
				_q120.a(true);
				memoryStream.Write(_q120.b(), 0, 16);
			}
			if (this.cy != Independentsoft.Msg.TaskDelegationState.None)
			{
				c _c45 = new c();
				_c45.a(33066);
				_c45.a(StandardPropertySet.Task);
				_c45.a(g.a);
				int count45 = m.a(A_0, _c45);
				if (count45 == -1)
				{
					A_0.Add(_c45);
					count45 = A_0.Count - 1;
				}
				uint num45 = (uint)(32768 + count45 << 16 | 3);
				q _q121 = new q();
				_q121.a(num45);
				_q121.a(PropertyType.Integer32);
				_q121.b(BitConverter.GetBytes(h.a(this.cy)));
				_q121.b(true);
				_q121.a(true);
				memoryStream.Write(_q121.b(), 0, 16);
			}
			if (this.c2 > 0)
			{
				c _c46 = new c();
				_c46.a(35589);
				_c46.a(StandardPropertySet.Note);
				_c46.a(g.a);
				int count46 = m.a(A_0, _c46);
				if (count46 == -1)
				{
					A_0.Add(_c46);
					count46 = A_0.Count - 1;
				}
				uint num46 = (uint)(32768 + count46 << 16 | 3);
				q _q122 = new q();
				_q122.a(num46);
				_q122.a(PropertyType.Integer32);
				_q122.b(BitConverter.GetBytes(this.c2));
				_q122.b(true);
				_q122.a(true);
				memoryStream.Write(_q122.b(), 0, 16);
			}
			if (this.c1 > 0)
			{
				c _c47 = new c();
				_c47.a(35588);
				_c47.a(StandardPropertySet.Note);
				_c47.a(g.a);
				int count47 = m.a(A_0, _c47);
				if (count47 == -1)
				{
					A_0.Add(_c47);
					count47 = A_0.Count - 1;
				}
				uint num47 = (uint)(32768 + count47 << 16 | 3);
				q _q123 = new q();
				_q123.a(num47);
				_q123.a(PropertyType.Integer32);
				_q123.b(BitConverter.GetBytes(this.c1));
				_q123.b(true);
				_q123.a(true);
				memoryStream.Write(_q123.b(), 0, 16);
			}
			if (this.c0 > 0)
			{
				c _c48 = new c();
				_c48.a(35587);
				_c48.a(StandardPropertySet.Note);
				_c48.a(g.a);
				int count48 = m.a(A_0, _c48);
				if (count48 == -1)
				{
					A_0.Add(_c48);
					count48 = A_0.Count - 1;
				}
				uint num48 = (uint)(32768 + count48 << 16 | 3);
				q _q124 = new q();
				_q124.a(num48);
				_q124.a(PropertyType.Integer32);
				_q124.b(BitConverter.GetBytes(this.c0));
				_q124.b(true);
				_q124.a(true);
				memoryStream.Write(_q124.b(), 0, 16);
			}
			if (this.cz > 0)
			{
				c _c49 = new c();
				_c49.a(35586);
				_c49.a(StandardPropertySet.Note);
				_c49.a(g.a);
				int count49 = m.a(A_0, _c49);
				if (count49 == -1)
				{
					A_0.Add(_c49);
					count49 = A_0.Count - 1;
				}
				uint num49 = (uint)(32768 + count49 << 16 | 3);
				q _q125 = new q();
				_q125.a(num49);
				_q125.a(PropertyType.Integer32);
				_q125.b(BitConverter.GetBytes(this.cz));
				_q125.b(true);
				_q125.a(true);
				memoryStream.Write(_q125.b(), 0, 16);
			}
			if (this.c3 != Independentsoft.Msg.NoteColor.None)
			{
				c _c50 = new c();
				_c50.a(35584);
				_c50.a(StandardPropertySet.Note);
				_c50.a(g.a);
				int count50 = m.a(A_0, _c50);
				if (count50 == -1)
				{
					A_0.Add(_c50);
					count50 = A_0.Count - 1;
				}
				uint num50 = (uint)(32768 + count50 << 16 | 3);
				q _q126 = new q();
				_q126.a(num50);
				_q126.a(PropertyType.Integer32);
				_q126.b(BitConverter.GetBytes(h.a(this.c3)));
				_q126.b(true);
				_q126.a(true);
				memoryStream.Write(_q126.b(), 0, 16);
			}
			if (this.c4.CompareTo(DateTime.MinValue) > 0)
			{
				c _c51 = new c();
				_c51.a(34566);
				_c51.a(StandardPropertySet.Journal);
				_c51.a(g.a);
				int count51 = m.a(A_0, _c51);
				if (count51 == -1)
				{
					A_0.Add(_c51);
					count51 = A_0.Count - 1;
				}
				uint num51 = (uint)(32768 + count51 << 16 | 64);
				DateTime dateTime17 = new DateTime(1601, 1, 1);
				universalTime = this.c4.ToUniversalTime();
				TimeSpan timeSpan17 = universalTime.Subtract(dateTime17);
				byte[] numArray32 = BitConverter.GetBytes(timeSpan17.Ticks);
				q _q127 = new q();
				_q127.a(num51);
				_q127.a(PropertyType.Time);
				_q127.b(numArray32);
				_q127.b(true);
				_q127.a(true);
				memoryStream.Write(_q127.b(), 0, 16);
			}
			if (this.c5.CompareTo(DateTime.MinValue) > 0)
			{
				c _c52 = new c();
				_c52.a(34568);
				_c52.a(StandardPropertySet.Journal);
				_c52.a(g.a);
				int count52 = m.a(A_0, _c52);
				if (count52 == -1)
				{
					A_0.Add(_c52);
					count52 = A_0.Count - 1;
				}
				uint num52 = (uint)(32768 + count52 << 16 | 64);
				DateTime dateTime18 = new DateTime(1601, 1, 1);
				universalTime = this.c5.ToUniversalTime();
				TimeSpan timeSpan18 = universalTime.Subtract(dateTime18);
				byte[] bytes33 = BitConverter.GetBytes(timeSpan18.Ticks);
				q _q128 = new q();
				_q128.a(num52);
				_q128.a(PropertyType.Time);
				_q128.b(bytes33);
				_q128.b(true);
				_q128.a(true);
				memoryStream.Write(_q128.b(), 0, 16);
			}
			if (this.c6 != null)
			{
				c _c53 = new c();
				_c53.a(34560);
				_c53.a(StandardPropertySet.Journal);
				_c53.a(g.b);
				int count53 = m.a(A_0, _c53);
				if (count53 == -1)
				{
					A_0.Add(_c53);
					count53 = A_0.Count - 1;
				}
				uint num53 = 32768 + count53 << 16 | this.ft;
				string str18 = string.Format("{0:X8}", num53);
				byte[] numArray33 = this.fw.GetBytes(this.c6);
				Independentsoft.IO.StructuredStorage.Stream stream45 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str18), numArray33);
				directoryEntryList.Add(stream45);
				q _q129 = new q();
				_q129.a(num53);
				_q129.a(PropertyType.String8);
				_q129.b((uint)((int)numArray33.Length + (int)this.fw.GetBytes("\0").Length));
				_q129.b(true);
				_q129.a(true);
				memoryStream.Write(_q129.b(), 0, 16);
			}
			if (this.c7 != null)
			{
				c _c54 = new c();
				_c54.a(34578);
				_c54.a(StandardPropertySet.Journal);
				_c54.a(g.b);
				int count54 = m.a(A_0, _c54);
				if (count54 == -1)
				{
					A_0.Add(_c54);
					count54 = A_0.Count - 1;
				}
				uint num54 = 32768 + count54 << 16 | this.ft;
				string str19 = string.Format("{0:X8}", num54);
				byte[] bytes34 = this.fw.GetBytes(this.c7);
				Independentsoft.IO.StructuredStorage.Stream stream46 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str19), bytes34);
				directoryEntryList.Add(stream46);
				q _q130 = new q();
				_q130.a(num54);
				_q130.a(PropertyType.String8);
				_q130.b((uint)((int)bytes34.Length + (int)this.fw.GetBytes("\0").Length));
				_q130.b(true);
				_q130.a(true);
				memoryStream.Write(_q130.b(), 0, 16);
			}
			if (this.c8 > 0)
			{
				c _c55 = new c();
				_c55.a(34567);
				_c55.a(StandardPropertySet.Journal);
				_c55.a(g.a);
				int count55 = m.a(A_0, _c55);
				if (count55 == -1)
				{
					A_0.Add(_c55);
					count55 = A_0.Count - 1;
				}
				uint num55 = (uint)(32768 + count55 << 16 | 3);
				q _q131 = new q();
				_q131.a(num55);
				_q131.a(PropertyType.Integer32);
				_q131.b(BitConverter.GetBytes(this.c8));
				_q131.b(true);
				_q131.a(true);
				memoryStream.Write(_q131.b(), 0, 16);
			}
			if (this.c9.CompareTo(DateTime.MinValue) > 0)
			{
				DateTime dateTime19 = new DateTime(1601, 1, 1);
				universalTime = this.c9.ToUniversalTime();
				TimeSpan timeSpan19 = universalTime.Subtract(dateTime19);
				byte[] numArray34 = BitConverter.GetBytes(timeSpan19.Ticks);
				q _q132 = new q();
				_q132.a(977403968);
				_q132.a(PropertyType.Time);
				_q132.b(numArray34);
				_q132.b(true);
				_q132.a(false);
				memoryStream.Write(_q132.b(), 0, 16);
			}
			if (this.da.Count > 0)
			{
				MemoryStream memoryStream4 = new MemoryStream();
				for (int l = 0; l < this.da.Count; l++)
				{
					byte[] bytes35 = this.fw.GetBytes(string.Concat(this.da[l], "\0"));
					uint length3 = (uint)bytes35.Length;
					memoryStream4.Write(BitConverter.GetBytes(length3), 0, 4);
					string str20 = string.Concat("__substg1.0_3A58", this.fu, "-", string.Format("{0:X8}", l));
					directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream(str20, bytes35));
				}
				byte[] array3 = memoryStream4.ToArray();
				Independentsoft.IO.StructuredStorage.Stream stream47 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A58", this.fu), array3);
				directoryEntryList.Add(stream47);
				q _q133 = new q();
				_q133.a(978845696 | this.fv);
				_q133.a(PropertyType.MultipleString8);
				_q133.b((uint)array3.Length);
				_q133.b(true);
				_q133.a(true);
				memoryStream.Write(_q133.b(), 0, 16);
			}
			if (this.db != null)
			{
				byte[] numArray35 = this.fw.GetBytes(this.db);
				Independentsoft.IO.StructuredStorage.Stream stream48 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A30", this.fs), numArray35);
				directoryEntryList.Add(stream48);
				q _q134 = new q();
				_q134.a(976224256 | this.ft);
				_q134.a(PropertyType.String8);
				_q134.b((uint)((int)numArray35.Length + (int)this.fw.GetBytes("\0").Length));
				_q134.b(true);
				_q134.a(true);
				memoryStream.Write(_q134.b(), 0, 16);
			}
			if (this.dc != null)
			{
				byte[] bytes36 = this.fw.GetBytes(this.dc);
				Independentsoft.IO.StructuredStorage.Stream stream49 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A2E", this.fs), bytes36);
				directoryEntryList.Add(stream49);
				q _q135 = new q();
				_q135.a(976093184 | this.ft);
				_q135.a(PropertyType.String8);
				_q135.b((uint)((int)bytes36.Length + (int)this.fw.GetBytes("\0").Length));
				_q135.b(true);
				_q135.a(true);
				memoryStream.Write(_q135.b(), 0, 16);
			}
			if (this.de != null)
			{
				byte[] numArray36 = this.fw.GetBytes(this.de);
				Independentsoft.IO.StructuredStorage.Stream stream50 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A1B", this.fs), numArray36);
				directoryEntryList.Add(stream50);
				q _q136 = new q();
				_q136.a(974848000 | this.ft);
				_q136.a(PropertyType.String8);
				_q136.b((uint)((int)numArray36.Length + (int)this.fw.GetBytes("\0").Length));
				_q136.b(true);
				_q136.a(true);
				memoryStream.Write(_q136.b(), 0, 16);
			}
			if (this.df != null)
			{
				byte[] bytes37 = this.fw.GetBytes(this.df);
				Independentsoft.IO.StructuredStorage.Stream stream51 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A24", this.fs), bytes37);
				directoryEntryList.Add(stream51);
				q _q137 = new q();
				_q137.a(975437824 | this.ft);
				_q137.a(PropertyType.String8);
				_q137.b((uint)((int)bytes37.Length + (int)this.fw.GetBytes("\0").Length));
				_q137.b(true);
				_q137.a(true);
				memoryStream.Write(_q137.b(), 0, 16);
			}
			if (this.dg != null)
			{
				byte[] numArray37 = this.fw.GetBytes(this.dg);
				Independentsoft.IO.StructuredStorage.Stream stream52 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A51", this.fs), numArray37);
				directoryEntryList.Add(stream52);
				q _q138 = new q();
				_q138.a(978386944 | this.ft);
				_q138.a(PropertyType.String8);
				_q138.b((uint)((int)numArray37.Length + (int)this.fw.GetBytes("\0").Length));
				_q138.b(true);
				_q138.a(true);
				memoryStream.Write(_q138.b(), 0, 16);
			}
			if (this.dh != null)
			{
				byte[] bytes38 = this.fw.GetBytes(this.dh);
				Independentsoft.IO.StructuredStorage.Stream stream53 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A02", this.fs), bytes38);
				directoryEntryList.Add(stream53);
				q _q139 = new q();
				_q139.a(973209600 | this.ft);
				_q139.a(PropertyType.String8);
				_q139.b((uint)((int)bytes38.Length + (int)this.fw.GetBytes("\0").Length));
				_q139.b(true);
				_q139.a(true);
				memoryStream.Write(_q139.b(), 0, 16);
			}
			if (this.di != null)
			{
				byte[] numArray38 = this.fw.GetBytes(this.di);
				Independentsoft.IO.StructuredStorage.Stream stream54 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A1E", this.fs), numArray38);
				directoryEntryList.Add(stream54);
				q _q140 = new q();
				_q140.a(975044608 | this.ft);
				_q140.a(PropertyType.String8);
				_q140.b((uint)((int)numArray38.Length + (int)this.fw.GetBytes("\0").Length));
				_q140.b(true);
				_q140.a(true);
				memoryStream.Write(_q140.b(), 0, 16);
			}
			if (this.dj != null)
			{
				byte[] bytes39 = this.fw.GetBytes(this.dj);
				Independentsoft.IO.StructuredStorage.Stream stream55 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A1C", this.fs), bytes39);
				directoryEntryList.Add(stream55);
				q _q141 = new q();
				_q141.a(974913536 | this.ft);
				_q141.a(PropertyType.String8);
				_q141.b((uint)((int)bytes39.Length + (int)this.fw.GetBytes("\0").Length));
				_q141.b(true);
				_q141.a(true);
				memoryStream.Write(_q141.b(), 0, 16);
			}
			if (this.dk != null)
			{
				byte[] numArray39 = this.fw.GetBytes(this.dk);
				Independentsoft.IO.StructuredStorage.Stream stream56 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A57", this.fs), numArray39);
				directoryEntryList.Add(stream56);
				q _q142 = new q();
				_q142.a(978780160 | this.ft);
				_q142.a(PropertyType.String8);
				_q142.b((uint)((int)numArray39.Length + (int)this.fw.GetBytes("\0").Length));
				_q142.b(true);
				_q142.a(true);
				memoryStream.Write(_q142.b(), 0, 16);
			}
			if (this.dl != null)
			{
				byte[] bytes40 = this.fw.GetBytes(this.dl);
				Independentsoft.IO.StructuredStorage.Stream stream57 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A16", this.fs), bytes40);
				directoryEntryList.Add(stream57);
				q _q143 = new q();
				_q143.a(974520320 | this.ft);
				_q143.a(PropertyType.String8);
				_q143.b((uint)((int)bytes40.Length + (int)this.fw.GetBytes("\0").Length));
				_q143.b(true);
				_q143.a(true);
				memoryStream.Write(_q143.b(), 0, 16);
			}
			if (this.dm != null)
			{
				byte[] numArray40 = this.fw.GetBytes(this.dm);
				Independentsoft.IO.StructuredStorage.Stream stream58 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A49", this.fs), numArray40);
				directoryEntryList.Add(stream58);
				q _q144 = new q();
				_q144.a(977862656 | this.ft);
				_q144.a(PropertyType.String8);
				_q144.b((uint)((int)numArray40.Length + (int)this.fw.GetBytes("\0").Length));
				_q144.b(true);
				_q144.a(true);
				memoryStream.Write(_q144.b(), 0, 16);
			}
			if (this.ek != null)
			{
				c _c56 = new c();
				_c56.a(32841);
				_c56.a(StandardPropertySet.Address);
				_c56.a(g.b);
				int count56 = m.a(A_0, _c56);
				if (count56 == -1)
				{
					A_0.Add(_c56);
					count56 = A_0.Count - 1;
				}
				uint num56 = 32768 + count56 << 16 | this.ft;
				string str21 = string.Format("{0:X8}", num56);
				byte[] bytes41 = this.fw.GetBytes(this.ek);
				Independentsoft.IO.StructuredStorage.Stream stream59 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str21), bytes41);
				directoryEntryList.Add(stream59);
				q _q145 = new q();
				_q145.a(num56);
				_q145.a(PropertyType.String8);
				_q145.b((uint)((int)bytes41.Length + (int)this.fw.GetBytes("\0").Length));
				_q145.b(true);
				_q145.a(true);
				memoryStream.Write(_q145.b(), 0, 16);
				Independentsoft.IO.StructuredStorage.Stream stream60 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A26", this.fs), bytes41);
				directoryEntryList.Add(stream60);
				q _q146 = new q();
				_q146.a(975568896 | this.ft);
				_q146.a(PropertyType.String8);
				_q146.b((uint)((int)bytes41.Length + (int)this.fw.GetBytes("\0").Length));
				_q146.b(true);
				_q146.a(true);
				memoryStream.Write(_q146.b(), 0, 16);
			}
			if (this.dn != null)
			{
				byte[] numArray41 = this.fw.GetBytes(this.dn);
				Independentsoft.IO.StructuredStorage.Stream stream61 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A4A", this.fs), numArray41);
				directoryEntryList.Add(stream61);
				q _q147 = new q();
				_q147.a(977928192 | this.ft);
				_q147.a(PropertyType.String8);
				_q147.b((uint)((int)numArray41.Length + (int)this.fw.GetBytes("\0").Length));
				_q147.b(true);
				_q147.a(true);
				memoryStream.Write(_q147.b(), 0, 16);
			}
			if (this.@do != null)
			{
				byte[] bytes42 = this.fw.GetBytes(this.@do);
				Independentsoft.IO.StructuredStorage.Stream stream62 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A18", this.fs), bytes42);
				directoryEntryList.Add(stream62);
				q _q148 = new q();
				_q148.a(974651392 | this.ft);
				_q148.a(PropertyType.String8);
				_q148.b((uint)((int)bytes42.Length + (int)this.fw.GetBytes("\0").Length));
				_q148.b(true);
				_q148.a(true);
				memoryStream.Write(_q148.b(), 0, 16);
			}
			if (this.dp != null)
			{
				byte[] numArray42 = this.fw.GetBytes(this.dp);
				Independentsoft.IO.StructuredStorage.Stream stream63 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3001", this.fs), numArray42);
				directoryEntryList.Add(stream63);
				q _q149 = new q();
				_q149.a(805371904 | this.ft);
				_q149.a(PropertyType.String8);
				_q149.b((uint)((int)numArray42.Length + (int)this.fw.GetBytes("\0").Length));
				_q149.b(true);
				_q149.a(true);
				memoryStream.Write(_q149.b(), 0, 16);
			}
			if (this.dq != null)
			{
				byte[] bytes43 = this.fw.GetBytes(this.dq);
				Independentsoft.IO.StructuredStorage.Stream stream64 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A45", this.fs), bytes43);
				directoryEntryList.Add(stream64);
				q _q150 = new q();
				_q150.a(977600512 | this.ft);
				_q150.a(PropertyType.String8);
				_q150.b((uint)((int)bytes43.Length + (int)this.fw.GetBytes("\0").Length));
				_q150.b(true);
				_q150.a(true);
				memoryStream.Write(_q150.b(), 0, 16);
			}
			if (this.dr != null)
			{
				byte[] numArray43 = this.fw.GetBytes(this.dr);
				Independentsoft.IO.StructuredStorage.Stream stream65 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A4C", this.fs), numArray43);
				directoryEntryList.Add(stream65);
				q _q151 = new q();
				_q151.a(978059264 | this.ft);
				_q151.a(PropertyType.String8);
				_q151.b((uint)((int)numArray43.Length + (int)this.fw.GetBytes("\0").Length));
				_q151.b(true);
				_q151.a(true);
				memoryStream.Write(_q151.b(), 0, 16);
			}
			if (this.ds != null)
			{
				byte[] bytes44 = this.fw.GetBytes(this.ds);
				Independentsoft.IO.StructuredStorage.Stream stream66 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A05", this.fs), bytes44);
				directoryEntryList.Add(stream66);
				q _q152 = new q();
				_q152.a(973406208 | this.ft);
				_q152.a(PropertyType.String8);
				_q152.b((uint)((int)bytes44.Length + (int)this.fw.GetBytes("\0").Length));
				_q152.b(true);
				_q152.a(true);
				memoryStream.Write(_q152.b(), 0, 16);
			}
			if (this.dt != null)
			{
				byte[] numArray44 = this.fw.GetBytes(this.dt);
				Independentsoft.IO.StructuredStorage.Stream stream67 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A06", this.fs), numArray44);
				directoryEntryList.Add(stream67);
				q _q153 = new q();
				_q153.a(973471744 | this.ft);
				_q153.a(PropertyType.String8);
				_q153.b((uint)((int)numArray44.Length + (int)this.fw.GetBytes("\0").Length));
				_q153.b(true);
				_q153.a(true);
				memoryStream.Write(_q153.b(), 0, 16);
			}
			if (this.du != null)
			{
				byte[] bytes45 = this.fw.GetBytes(this.du);
				Independentsoft.IO.StructuredStorage.Stream stream68 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A07", this.fs), bytes45);
				directoryEntryList.Add(stream68);
				q _q154 = new q();
				_q154.a(973537280 | this.ft);
				_q154.a(PropertyType.String8);
				_q154.b((uint)((int)bytes45.Length + (int)this.fw.GetBytes("\0").Length));
				_q154.b(true);
				_q154.a(true);
				memoryStream.Write(_q154.b(), 0, 16);
			}
			if (this.dv != null)
			{
				byte[] numArray45 = this.fw.GetBytes(this.dv);
				Independentsoft.IO.StructuredStorage.Stream stream69 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A43", this.fs), numArray45);
				directoryEntryList.Add(stream69);
				q _q155 = new q();
				_q155.a(977469440 | this.ft);
				_q155.a(PropertyType.String8);
				_q155.b((uint)((int)numArray45.Length + (int)this.fw.GetBytes("\0").Length));
				_q155.b(true);
				_q155.a(true);
				memoryStream.Write(_q155.b(), 0, 16);
			}
			if (this.dw != null)
			{
				byte[] bytes46 = this.fw.GetBytes(this.dw);
				Independentsoft.IO.StructuredStorage.Stream stream70 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A2F", this.fs), bytes46);
				directoryEntryList.Add(stream70);
				q _q156 = new q();
				_q156.a(976158720 | this.ft);
				_q156.a(PropertyType.String8);
				_q156.b((uint)((int)bytes46.Length + (int)this.fw.GetBytes("\0").Length));
				_q156.b(true);
				_q156.a(true);
				memoryStream.Write(_q156.b(), 0, 16);
			}
			if (this.dx != null)
			{
				byte[] numArray46 = this.fw.GetBytes(this.dx);
				Independentsoft.IO.StructuredStorage.Stream stream71 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A59", this.fs), numArray46);
				directoryEntryList.Add(stream71);
				q _q157 = new q();
				_q157.a(978911232 | this.ft);
				_q157.a(PropertyType.String8);
				_q157.b((uint)((int)numArray46.Length + (int)this.fw.GetBytes("\0").Length));
				_q157.b(true);
				_q157.a(true);
				memoryStream.Write(_q157.b(), 0, 16);
			}
			if (this.dy != null)
			{
				byte[] bytes47 = this.fw.GetBytes(this.dy);
				Independentsoft.IO.StructuredStorage.Stream stream72 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A5A", this.fs), bytes47);
				directoryEntryList.Add(stream72);
				q _q158 = new q();
				_q158.a(978976768 | this.ft);
				_q158.a(PropertyType.String8);
				_q158.b((uint)((int)bytes47.Length + (int)this.fw.GetBytes("\0").Length));
				_q158.b(true);
				_q158.a(true);
				memoryStream.Write(_q158.b(), 0, 16);
			}
			if (this.dz != null)
			{
				byte[] numArray47 = this.fw.GetBytes(this.dz);
				Independentsoft.IO.StructuredStorage.Stream stream73 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A5B", this.fs), numArray47);
				directoryEntryList.Add(stream73);
				q _q159 = new q();
				_q159.a(979042304 | this.ft);
				_q159.a(PropertyType.String8);
				_q159.b((uint)((int)numArray47.Length + (int)this.fw.GetBytes("\0").Length));
				_q159.b(true);
				_q159.a(true);
				memoryStream.Write(_q159.b(), 0, 16);
			}
			if (this.d0 != null)
			{
				byte[] bytes48 = this.fw.GetBytes(this.d0);
				Independentsoft.IO.StructuredStorage.Stream stream74 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A5E", this.fs), bytes48);
				directoryEntryList.Add(stream74);
				q _q160 = new q();
				_q160.a(979238912 | this.ft);
				_q160.a(PropertyType.String8);
				_q160.b((uint)((int)bytes48.Length + (int)this.fw.GetBytes("\0").Length));
				_q160.b(true);
				_q160.a(true);
				memoryStream.Write(_q160.b(), 0, 16);
			}
			if (this.d1 != null)
			{
				byte[] numArray48 = this.fw.GetBytes(this.d1);
				Independentsoft.IO.StructuredStorage.Stream stream75 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A5C", this.fs), numArray48);
				directoryEntryList.Add(stream75);
				q _q161 = new q();
				_q161.a(979107840 | this.ft);
				_q161.a(PropertyType.String8);
				_q161.b((uint)((int)numArray48.Length + (int)this.fw.GetBytes("\0").Length));
				_q161.b(true);
				_q161.a(true);
				memoryStream.Write(_q161.b(), 0, 16);
			}
			if (this.d2 != null)
			{
				byte[] bytes49 = this.fw.GetBytes(this.d2);
				Independentsoft.IO.StructuredStorage.Stream stream76 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A5D", this.fs), bytes49);
				directoryEntryList.Add(stream76);
				q _q162 = new q();
				_q162.a(979173376 | this.ft);
				_q162.a(PropertyType.String8);
				_q162.b((uint)((int)bytes49.Length + (int)this.fw.GetBytes("\0").Length));
				_q162.b(true);
				_q162.a(true);
				memoryStream.Write(_q162.b(), 0, 16);
			}
			if (this.d3 != null)
			{
				byte[] numArray49 = this.fw.GetBytes(this.d3);
				Independentsoft.IO.StructuredStorage.Stream stream77 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A25", this.fs), numArray49);
				directoryEntryList.Add(stream77);
				q _q163 = new q();
				_q163.a(975503360 | this.ft);
				_q163.a(PropertyType.String8);
				_q163.b((uint)((int)numArray49.Length + (int)this.fw.GetBytes("\0").Length));
				_q163.b(true);
				_q163.a(true);
				memoryStream.Write(_q163.b(), 0, 16);
			}
			if (this.d4 != null)
			{
				byte[] bytes50 = this.fw.GetBytes(this.d4);
				Independentsoft.IO.StructuredStorage.Stream stream78 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A09", this.fs), bytes50);
				directoryEntryList.Add(stream78);
				q _q164 = new q();
				_q164.a(973668352 | this.ft);
				_q164.a(PropertyType.String8);
				_q164.b((uint)((int)bytes50.Length + (int)this.fw.GetBytes("\0").Length));
				_q164.b(true);
				_q164.a(true);
				memoryStream.Write(_q164.b(), 0, 16);
			}
			if (this.d5 != null)
			{
				byte[] numArray50 = this.fw.GetBytes(this.d5);
				Independentsoft.IO.StructuredStorage.Stream stream79 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A0A", this.fs), numArray50);
				directoryEntryList.Add(stream79);
				q _q165 = new q();
				_q165.a(973733888 | this.ft);
				_q165.a(PropertyType.String8);
				_q165.b((uint)((int)numArray50.Length + (int)this.fw.GetBytes("\0").Length));
				_q165.b(true);
				_q165.a(true);
				memoryStream.Write(_q165.b(), 0, 16);
			}
			if (this.d6 != null)
			{
				byte[] bytes51 = this.fw.GetBytes(this.d6);
				Independentsoft.IO.StructuredStorage.Stream stream80 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A2D", this.fs), bytes51);
				directoryEntryList.Add(stream80);
				q _q166 = new q();
				_q166.a(976027648 | this.ft);
				_q166.a(PropertyType.String8);
				_q166.b((uint)((int)bytes51.Length + (int)this.fw.GetBytes("\0").Length));
				_q166.b(true);
				_q166.a(true);
				memoryStream.Write(_q166.b(), 0, 16);
			}
			if (this.el != null)
			{
				c _c57 = new c();
				_c57.a(32838);
				_c57.a(StandardPropertySet.Address);
				_c57.a(g.b);
				int count57 = m.a(A_0, _c57);
				if (count57 == -1)
				{
					A_0.Add(_c57);
					count57 = A_0.Count - 1;
				}
				uint num57 = 32768 + count57 << 16 | this.ft;
				string str22 = string.Format("{0:X8}", num57);
				byte[] numArray51 = this.fw.GetBytes(this.el);
				Independentsoft.IO.StructuredStorage.Stream stream81 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str22), numArray51);
				directoryEntryList.Add(stream81);
				q _q167 = new q();
				_q167.a(num57);
				_q167.a(PropertyType.String8);
				_q167.b((uint)((int)numArray51.Length + (int)this.fw.GetBytes("\0").Length));
				_q167.b(true);
				_q167.a(true);
				memoryStream.Write(_q167.b(), 0, 16);
				Independentsoft.IO.StructuredStorage.Stream stream82 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A27", this.fs), numArray51);
				directoryEntryList.Add(stream82);
				q _q168 = new q();
				_q168.a(975634432 | this.ft);
				_q168.a(PropertyType.String8);
				_q168.b((uint)((int)numArray51.Length + (int)this.fw.GetBytes("\0").Length));
				_q168.b(true);
				_q168.a(true);
				memoryStream.Write(_q168.b(), 0, 16);
			}
			if (this.d7 != null)
			{
				byte[] bytes52 = this.fw.GetBytes(this.d7);
				Independentsoft.IO.StructuredStorage.Stream stream83 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A4E", this.fs), bytes52);
				directoryEntryList.Add(stream83);
				q _q169 = new q();
				_q169.a(978190336 | this.ft);
				_q169.a(PropertyType.String8);
				_q169.b((uint)((int)bytes52.Length + (int)this.fw.GetBytes("\0").Length));
				_q169.b(true);
				_q169.a(true);
				memoryStream.Write(_q169.b(), 0, 16);
			}
			if (this.d8 != null)
			{
				byte[] numArray52 = this.fw.GetBytes(this.d8);
				Independentsoft.IO.StructuredStorage.Stream stream84 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A44", this.fs), numArray52);
				directoryEntryList.Add(stream84);
				q _q170 = new q();
				_q170.a(977534976 | this.ft);
				_q170.a(PropertyType.String8);
				_q170.b((uint)((int)numArray52.Length + (int)this.fw.GetBytes("\0").Length));
				_q170.b(true);
				_q170.a(true);
				memoryStream.Write(_q170.b(), 0, 16);
			}
			if (this.d9 != null)
			{
				byte[] bytes53 = this.fw.GetBytes(this.d9);
				Independentsoft.IO.StructuredStorage.Stream stream85 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A4F", this.fs), bytes53);
				directoryEntryList.Add(stream85);
				q _q171 = new q();
				_q171.a(978255872 | this.ft);
				_q171.a(PropertyType.String8);
				_q171.b((uint)((int)bytes53.Length + (int)this.fw.GetBytes("\0").Length));
				_q171.b(true);
				_q171.a(true);
				memoryStream.Write(_q171.b(), 0, 16);
			}
			if (this.ea != null)
			{
				byte[] numArray53 = this.fw.GetBytes(this.ea);
				Independentsoft.IO.StructuredStorage.Stream stream86 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A19", this.fs), numArray53);
				directoryEntryList.Add(stream86);
				q _q172 = new q();
				_q172.a(974716928 | this.ft);
				_q172.a(PropertyType.String8);
				_q172.b((uint)((int)numArray53.Length + (int)this.fw.GetBytes("\0").Length));
				_q172.b(true);
				_q172.a(true);
				memoryStream.Write(_q172.b(), 0, 16);
			}
			if (this.dd != null)
			{
				byte[] bytes54 = this.fw.GetBytes(this.dd);
				Independentsoft.IO.StructuredStorage.Stream stream87 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A08", this.fs), bytes54);
				directoryEntryList.Add(stream87);
				q _q173 = new q();
				_q173.a(973602816 | this.ft);
				_q173.a(PropertyType.String8);
				_q173.b((uint)((int)bytes54.Length + (int)this.fw.GetBytes("\0").Length));
				_q173.b(true);
				_q173.a(true);
				memoryStream.Write(_q173.b(), 0, 16);
			}
			if (this.eb != null)
			{
				byte[] numArray54 = this.fw.GetBytes(this.eb);
				Independentsoft.IO.StructuredStorage.Stream stream88 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A5F", this.fs), numArray54);
				directoryEntryList.Add(stream88);
				q _q174 = new q();
				_q174.a(979304448 | this.ft);
				_q174.a(PropertyType.String8);
				_q174.b((uint)((int)numArray54.Length + (int)this.fw.GetBytes("\0").Length));
				_q174.b(true);
				_q174.a(true);
				memoryStream.Write(_q174.b(), 0, 16);
			}
			if (this.ec != null)
			{
				byte[] bytes55 = this.fw.GetBytes(this.ec);
				Independentsoft.IO.StructuredStorage.Stream stream89 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A60", this.fs), bytes55);
				directoryEntryList.Add(stream89);
				q _q175 = new q();
				_q175.a(979369984 | this.ft);
				_q175.a(PropertyType.String8);
				_q175.b((uint)((int)bytes55.Length + (int)this.fw.GetBytes("\0").Length));
				_q175.b(true);
				_q175.a(true);
				memoryStream.Write(_q175.b(), 0, 16);
			}
			if (this.ed != null)
			{
				byte[] numArray55 = this.fw.GetBytes(this.ed);
				Independentsoft.IO.StructuredStorage.Stream stream90 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A61", this.fs), numArray55);
				directoryEntryList.Add(stream90);
				q _q176 = new q();
				_q176.a(979435520 | this.ft);
				_q176.a(PropertyType.String8);
				_q176.b((uint)((int)numArray55.Length + (int)this.fw.GetBytes("\0").Length));
				_q176.b(true);
				_q176.a(true);
				memoryStream.Write(_q176.b(), 0, 16);
			}
			if (this.ee != null)
			{
				byte[] bytes56 = this.fw.GetBytes(this.ee);
				Independentsoft.IO.StructuredStorage.Stream stream91 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A62", this.fs), bytes56);
				directoryEntryList.Add(stream91);
				q _q177 = new q();
				_q177.a(979501056 | this.ft);
				_q177.a(PropertyType.String8);
				_q177.b((uint)((int)bytes56.Length + (int)this.fw.GetBytes("\0").Length));
				_q177.b(true);
				_q177.a(true);
				memoryStream.Write(_q177.b(), 0, 16);
			}
			if (this.ef != null)
			{
				byte[] numArray56 = this.fw.GetBytes(this.ef);
				Independentsoft.IO.StructuredStorage.Stream stream92 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A63", this.fs), numArray56);
				directoryEntryList.Add(stream92);
				q _q178 = new q();
				_q178.a(979566592 | this.ft);
				_q178.a(PropertyType.String8);
				_q178.b((uint)((int)numArray56.Length + (int)this.fw.GetBytes("\0").Length));
				_q178.b(true);
				_q178.a(true);
				memoryStream.Write(_q178.b(), 0, 16);
			}
			if (this.eg != null)
			{
				byte[] bytes57 = this.fw.GetBytes(this.eg);
				Independentsoft.IO.StructuredStorage.Stream stream93 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A1F", this.fs), bytes57);
				directoryEntryList.Add(stream93);
				q _q179 = new q();
				_q179.a(975110144 | this.ft);
				_q179.a(PropertyType.String8);
				_q179.b((uint)((int)bytes57.Length + (int)this.fw.GetBytes("\0").Length));
				_q179.b(true);
				_q179.a(true);
				memoryStream.Write(_q179.b(), 0, 16);
			}
			if (this.eh != null)
			{
				byte[] numArray57 = this.fw.GetBytes(this.eh);
				Independentsoft.IO.StructuredStorage.Stream stream94 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A21", this.fs), numArray57);
				directoryEntryList.Add(stream94);
				q _q180 = new q();
				_q180.a(975241216 | this.ft);
				_q180.a(PropertyType.String8);
				_q180.b((uint)((int)numArray57.Length + (int)this.fw.GetBytes("\0").Length));
				_q180.b(true);
				_q180.a(true);
				memoryStream.Write(_q180.b(), 0, 16);
			}
			if (this.ei != null)
			{
				byte[] bytes58 = this.fw.GetBytes(this.ei);
				Independentsoft.IO.StructuredStorage.Stream stream95 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A50", this.fs), bytes58);
				directoryEntryList.Add(stream95);
				q _q181 = new q();
				_q181.a(978321408 | this.ft);
				_q181.a(PropertyType.String8);
				_q181.b((uint)((int)bytes58.Length + (int)this.fw.GetBytes("\0").Length));
				_q181.b(true);
				_q181.a(true);
				memoryStream.Write(_q181.b(), 0, 16);
			}
			if (this.ej != null)
			{
				byte[] numArray58 = this.fw.GetBytes(this.ej);
				Independentsoft.IO.StructuredStorage.Stream stream96 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A15", this.fs), numArray58);
				directoryEntryList.Add(stream96);
				q _q182 = new q();
				_q182.a(974454784 | this.ft);
				_q182.a(PropertyType.String8);
				_q182.b((uint)((int)numArray58.Length + (int)this.fw.GetBytes("\0").Length));
				_q182.b(true);
				_q182.a(true);
				memoryStream.Write(_q182.b(), 0, 16);
			}
			if (this.em != null)
			{
				c _c58 = new c();
				_c58.a(32840);
				_c58.a(StandardPropertySet.Address);
				_c58.a(g.b);
				int count58 = m.a(A_0, _c58);
				if (count58 == -1)
				{
					A_0.Add(_c58);
					count58 = A_0.Count - 1;
				}
				uint num58 = 32768 + count58 << 16 | this.ft;
				string str23 = string.Format("{0:X8}", num58);
				byte[] bytes59 = this.fw.GetBytes(this.em);
				Independentsoft.IO.StructuredStorage.Stream stream97 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str23), bytes59);
				directoryEntryList.Add(stream97);
				q _q183 = new q();
				_q183.a(num58);
				_q183.a(PropertyType.String8);
				_q183.b((uint)((int)bytes59.Length + (int)this.fw.GetBytes("\0").Length));
				_q183.b(true);
				_q183.a(true);
				memoryStream.Write(_q183.b(), 0, 16);
				Independentsoft.IO.StructuredStorage.Stream stream98 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A2A", this.fs), bytes59);
				directoryEntryList.Add(stream98);
				q _q184 = new q();
				_q184.a(975831040 | this.ft);
				_q184.a(PropertyType.String8);
				_q184.b((uint)((int)bytes59.Length + (int)this.fw.GetBytes("\0").Length));
				_q184.b(true);
				_q184.a(true);
				memoryStream.Write(_q184.b(), 0, 16);
			}
			if (this.en != null)
			{
				byte[] numArray59 = this.fw.GetBytes(this.en);
				Independentsoft.IO.StructuredStorage.Stream stream99 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A2B", this.fs), numArray59);
				directoryEntryList.Add(stream99);
				q _q185 = new q();
				_q185.a(975896576 | this.ft);
				_q185.a(PropertyType.String8);
				_q185.b((uint)((int)numArray59.Length + (int)this.fw.GetBytes("\0").Length));
				_q185.b(true);
				_q185.a(true);
				memoryStream.Write(_q185.b(), 0, 16);
			}
			if (this.eo != null)
			{
				c _c59 = new c();
				_c59.a(32839);
				_c59.a(StandardPropertySet.Address);
				_c59.a(g.b);
				int count59 = m.a(A_0, _c59);
				if (count59 == -1)
				{
					A_0.Add(_c59);
					count59 = A_0.Count - 1;
				}
				uint num59 = 32768 + count59 << 16 | this.ft;
				string str24 = string.Format("{0:X8}", num59);
				byte[] bytes60 = this.fw.GetBytes(this.eo);
				Independentsoft.IO.StructuredStorage.Stream stream100 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str24), bytes60);
				directoryEntryList.Add(stream100);
				q _q186 = new q();
				_q186.a(num59);
				_q186.a(PropertyType.String8);
				_q186.b((uint)((int)bytes60.Length + (int)this.fw.GetBytes("\0").Length));
				_q186.b(true);
				_q186.a(true);
				memoryStream.Write(_q186.b(), 0, 16);
				Independentsoft.IO.StructuredStorage.Stream stream101 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A28", this.fs), bytes60);
				directoryEntryList.Add(stream101);
				q _q187 = new q();
				_q187.a(975699968 | this.ft);
				_q187.a(PropertyType.String8);
				_q187.b((uint)((int)bytes60.Length + (int)this.fw.GetBytes("\0").Length));
				_q187.b(true);
				_q187.a(true);
				memoryStream.Write(_q187.b(), 0, 16);
			}
			if (this.ep != null)
			{
				c _c60 = new c();
				_c60.a(32837);
				_c60.a(StandardPropertySet.Address);
				_c60.a(g.b);
				int count60 = m.a(A_0, _c60);
				if (count60 == -1)
				{
					A_0.Add(_c60);
					count60 = A_0.Count - 1;
				}
				uint num60 = 32768 + count60 << 16 | this.ft;
				string str25 = string.Format("{0:X8}", num60);
				byte[] numArray60 = this.fw.GetBytes(this.ep);
				Independentsoft.IO.StructuredStorage.Stream stream102 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str25), numArray60);
				directoryEntryList.Add(stream102);
				q _q188 = new q();
				_q188.a(num60);
				_q188.a(PropertyType.String8);
				_q188.b((uint)((int)numArray60.Length + (int)this.fw.GetBytes("\0").Length));
				_q188.b(true);
				_q188.a(true);
				memoryStream.Write(_q188.b(), 0, 16);
				Independentsoft.IO.StructuredStorage.Stream stream103 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A29", this.fs), numArray60);
				directoryEntryList.Add(stream103);
				q _q189 = new q();
				_q189.a(975765504 | this.ft);
				_q189.a(PropertyType.String8);
				_q189.b((uint)((int)numArray60.Length + (int)this.fw.GetBytes("\0").Length));
				_q189.b(true);
				_q189.a(true);
				memoryStream.Write(_q189.b(), 0, 16);
			}
			if (this.eq != null)
			{
				byte[] bytes61 = this.fw.GetBytes(this.eq);
				Independentsoft.IO.StructuredStorage.Stream stream104 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A23", this.fs), bytes61);
				directoryEntryList.Add(stream104);
				q _q190 = new q();
				_q190.a(975372288 | this.ft);
				_q190.a(PropertyType.String8);
				_q190.b((uint)((int)bytes61.Length + (int)this.fw.GetBytes("\0").Length));
				_q190.b(true);
				_q190.a(true);
				memoryStream.Write(_q190.b(), 0, 16);
			}
			if (this.er != null)
			{
				byte[] numArray61 = this.fw.GetBytes(this.er);
				Independentsoft.IO.StructuredStorage.Stream stream105 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A1A", this.fs), numArray61);
				directoryEntryList.Add(stream105);
				q _q191 = new q();
				_q191.a(974782464 | this.ft);
				_q191.a(PropertyType.String8);
				_q191.b((uint)((int)numArray61.Length + (int)this.fw.GetBytes("\0").Length));
				_q191.b(true);
				_q191.a(true);
				memoryStream.Write(_q191.b(), 0, 16);
			}
			if (this.es != null)
			{
				byte[] bytes62 = this.fw.GetBytes(this.es);
				Independentsoft.IO.StructuredStorage.Stream stream106 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A46", this.fs), bytes62);
				directoryEntryList.Add(stream106);
				q _q192 = new q();
				_q192.a(977666048 | this.ft);
				_q192.a(PropertyType.String8);
				_q192.b((uint)((int)bytes62.Length + (int)this.fw.GetBytes("\0").Length));
				_q192.b(true);
				_q192.a(true);
				memoryStream.Write(_q192.b(), 0, 16);
			}
			if (this.et != null)
			{
				byte[] numArray62 = this.fw.GetBytes(this.et);
				Independentsoft.IO.StructuredStorage.Stream stream107 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A1D", this.fs), numArray62);
				directoryEntryList.Add(stream107);
				q _q193 = new q();
				_q193.a(974979072 | this.ft);
				_q193.a(PropertyType.String8);
				_q193.b((uint)((int)numArray62.Length + (int)this.fw.GetBytes("\0").Length));
				_q193.b(true);
				_q193.a(true);
				memoryStream.Write(_q193.b(), 0, 16);
			}
			if (this.eu != null)
			{
				byte[] bytes63 = this.fw.GetBytes(this.eu);
				Independentsoft.IO.StructuredStorage.Stream stream108 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A48", this.fs), bytes63);
				directoryEntryList.Add(stream108);
				q _q194 = new q();
				_q194.a(977797120 | this.ft);
				_q194.a(PropertyType.String8);
				_q194.b((uint)((int)bytes63.Length + (int)this.fw.GetBytes("\0").Length));
				_q194.b(true);
				_q194.a(true);
				memoryStream.Write(_q194.b(), 0, 16);
			}
			if (this.ev != null)
			{
				byte[] numArray63 = this.fw.GetBytes(this.ev);
				Independentsoft.IO.StructuredStorage.Stream stream109 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A11", this.fs), numArray63);
				directoryEntryList.Add(stream109);
				q _q195 = new q();
				_q195.a(974192640 | this.ft);
				_q195.a(PropertyType.String8);
				_q195.b((uint)((int)numArray63.Length + (int)this.fw.GetBytes("\0").Length));
				_q195.b(true);
				_q195.a(true);
				memoryStream.Write(_q195.b(), 0, 16);
			}
			if (this.ew != null)
			{
				byte[] bytes64 = this.fw.GetBytes(this.ew);
				Independentsoft.IO.StructuredStorage.Stream stream110 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A2C", this.fs), bytes64);
				directoryEntryList.Add(stream110);
				q _q196 = new q();
				_q196.a(975962112 | this.ft);
				_q196.a(PropertyType.String8);
				_q196.b((uint)((int)bytes64.Length + (int)this.fw.GetBytes("\0").Length));
				_q196.b(true);
				_q196.a(true);
				memoryStream.Write(_q196.b(), 0, 16);
			}
			if (this.ex != null)
			{
				byte[] numArray64 = this.fw.GetBytes(this.ex);
				Independentsoft.IO.StructuredStorage.Stream stream111 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A17", this.fs), numArray64);
				directoryEntryList.Add(stream111);
				q _q197 = new q();
				_q197.a(974585856 | this.ft);
				_q197.a(PropertyType.String8);
				_q197.b((uint)((int)numArray64.Length + (int)this.fw.GetBytes("\0").Length));
				_q197.b(true);
				_q197.a(true);
				memoryStream.Write(_q197.b(), 0, 16);
			}
			if (this.ey != null)
			{
				byte[] bytes65 = this.fw.GetBytes(this.ey);
				Independentsoft.IO.StructuredStorage.Stream stream112 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A4B", this.fs), bytes65);
				directoryEntryList.Add(stream112);
				q _q198 = new q();
				_q198.a(977993728 | this.ft);
				_q198.a(PropertyType.String8);
				_q198.b((uint)((int)bytes65.Length + (int)this.fw.GetBytes("\0").Length));
				_q198.b(true);
				_q198.a(true);
				memoryStream.Write(_q198.b(), 0, 16);
			}
			if (this.ez.CompareTo(DateTime.MinValue) > 0)
			{
				DateTime dateTime20 = new DateTime(1601, 1, 1);
				universalTime = this.ez.ToUniversalTime();
				TimeSpan timeSpan20 = universalTime.Subtract(dateTime20);
				byte[] numArray65 = BitConverter.GetBytes(timeSpan20.Ticks);
				q _q199 = new q();
				_q199.a(977338432);
				_q199.a(PropertyType.Time);
				_q199.b(numArray65);
				_q199.b(true);
				_q199.a(false);
				memoryStream.Write(_q199.b(), 0, 16);
			}
			if (this.e0 != Independentsoft.Msg.Gender.None)
			{
				q _q200 = new q();
				_q200.a(978124802);
				_q200.a(PropertyType.Integer16);
				_q200.b(BitConverter.GetBytes(h.a(this.e0)));
				_q200.b(true);
				_q200.a(true);
				memoryStream.Write(_q200.b(), 0, 16);
			}
			if (this.e1 != Independentsoft.Msg.SelectedMailingAddress.None)
			{
				c _c61 = new c();
				_c61.a(32802);
				_c61.a(StandardPropertySet.Address);
				_c61.a(g.a);
				int count61 = m.a(A_0, _c61);
				if (count61 == -1)
				{
					A_0.Add(_c61);
					count61 = A_0.Count - 1;
				}
				uint num61 = (uint)(32768 + count61 << 16 | 3);
				q _q201 = new q();
				_q201.a(num61);
				_q201.a(PropertyType.Integer32);
				_q201.b(BitConverter.GetBytes(h.a(this.e1)));
				_q201.b(true);
				_q201.a(true);
				memoryStream.Write(_q201.b(), 0, 16);
			}
			if (this.e2)
			{
				c _c62 = new c();
				_c62.a(32789);
				_c62.a(StandardPropertySet.Address);
				_c62.a(g.a);
				int count62 = m.a(A_0, _c62);
				if (count62 == -1)
				{
					A_0.Add(_c62);
					count62 = A_0.Count - 1;
				}
				uint num62 = (uint)(32768 + count62 << 16 | 11);
				q _q202 = new q();
				_q202.a(num62);
				_q202.a(PropertyType.Boolean);
				_q202.b(BitConverter.GetBytes(1));
				_q202.b(true);
				_q202.a(true);
				memoryStream.Write(_q202.b(), 0, 16);
			}
			if (this.e3 != null)
			{
				c _c63 = new c();
				_c63.a(32773);
				_c63.a(StandardPropertySet.Address);
				_c63.a(g.b);
				int count63 = m.a(A_0, _c63);
				if (count63 == -1)
				{
					A_0.Add(_c63);
					count63 = A_0.Count - 1;
				}
				uint num63 = 32768 + count63 << 16 | this.ft;
				string str26 = string.Format("{0:X8}", num63);
				byte[] bytes66 = this.fw.GetBytes(this.e3);
				Independentsoft.IO.StructuredStorage.Stream stream113 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str26), bytes66);
				directoryEntryList.Add(stream113);
				q _q203 = new q();
				_q203.a(num63);
				_q203.a(PropertyType.String8);
				_q203.b((uint)((int)bytes66.Length + (int)this.fw.GetBytes("\0").Length));
				_q203.b(true);
				_q203.a(true);
				memoryStream.Write(_q203.b(), 0, 16);
			}
			if (this.e4 != null)
			{
				c _c64 = new c();
				_c64.a(32866);
				_c64.a(StandardPropertySet.Address);
				_c64.a(g.b);
				int count64 = m.a(A_0, _c64);
				if (count64 == -1)
				{
					A_0.Add(_c64);
					count64 = A_0.Count - 1;
				}
				uint num64 = 32768 + count64 << 16 | this.ft;
				string str27 = string.Format("{0:X8}", num64);
				byte[] numArray66 = this.fw.GetBytes(this.e4);
				Independentsoft.IO.StructuredStorage.Stream stream114 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str27), numArray66);
				directoryEntryList.Add(stream114);
				q _q204 = new q();
				_q204.a(num64);
				_q204.a(PropertyType.String8);
				_q204.b((uint)((int)numArray66.Length + (int)this.fw.GetBytes("\0").Length));
				_q204.b(true);
				_q204.a(true);
				memoryStream.Write(_q204.b(), 0, 16);
			}
			if (this.e5 != null)
			{
				c _c65 = new c();
				_c65.a(32984);
				_c65.a(StandardPropertySet.Address);
				_c65.a(g.b);
				int count65 = m.a(A_0, _c65);
				if (count65 == -1)
				{
					A_0.Add(_c65);
					count65 = A_0.Count - 1;
				}
				uint num65 = 32768 + count65 << 16 | this.ft;
				string str28 = string.Format("{0:X8}", num65);
				byte[] bytes67 = this.fw.GetBytes(this.e5);
				Independentsoft.IO.StructuredStorage.Stream stream115 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str28), bytes67);
				directoryEntryList.Add(stream115);
				q _q205 = new q();
				_q205.a(num65);
				_q205.a(PropertyType.String8);
				_q205.b((uint)((int)bytes67.Length + (int)this.fw.GetBytes("\0").Length));
				_q205.b(true);
				_q205.a(true);
				memoryStream.Write(_q205.b(), 0, 16);
			}
			if (this.e6 != null)
			{
				c _c66 = new c();
				_c66.a(32795);
				_c66.a(StandardPropertySet.Address);
				_c66.a(g.b);
				int count66 = m.a(A_0, _c66);
				if (count66 == -1)
				{
					A_0.Add(_c66);
					count66 = A_0.Count - 1;
				}
				uint num66 = 32768 + count66 << 16 | this.ft;
				string str29 = string.Format("{0:X8}", num66);
				byte[] numArray67 = this.fw.GetBytes(this.e6);
				Independentsoft.IO.StructuredStorage.Stream stream116 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str29), numArray67);
				directoryEntryList.Add(stream116);
				q _q206 = new q();
				_q206.a(num66);
				_q206.a(PropertyType.String8);
				_q206.b((uint)((int)numArray67.Length + (int)this.fw.GetBytes("\0").Length));
				_q206.b(true);
				_q206.a(true);
				memoryStream.Write(_q206.b(), 0, 16);
			}
			if (this.e7 != null)
			{
				c _c67 = new c();
				_c67.a(32794);
				_c67.a(StandardPropertySet.Address);
				_c67.a(g.b);
				int count67 = m.a(A_0, _c67);
				if (count67 == -1)
				{
					A_0.Add(_c67);
					count67 = A_0.Count - 1;
				}
				uint num67 = 32768 + count67 << 16 | this.ft;
				string str30 = string.Format("{0:X8}", num67);
				byte[] bytes68 = this.fw.GetBytes(this.e7);
				Independentsoft.IO.StructuredStorage.Stream stream117 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str30), bytes68);
				directoryEntryList.Add(stream117);
				q _q207 = new q();
				_q207.a(num67);
				_q207.a(PropertyType.String8);
				_q207.b((uint)((int)bytes68.Length + (int)this.fw.GetBytes("\0").Length));
				_q207.b(true);
				_q207.a(true);
				memoryStream.Write(_q207.b(), 0, 16);
			}
			if (this.e8 != null)
			{
				c _c68 = new c();
				_c68.a(32796);
				_c68.a(StandardPropertySet.Address);
				_c68.a(g.b);
				int count68 = m.a(A_0, _c68);
				if (count68 == -1)
				{
					A_0.Add(_c68);
					count68 = A_0.Count - 1;
				}
				uint num68 = 32768 + count68 << 16 | this.ft;
				string str31 = string.Format("{0:X8}", num68);
				byte[] numArray68 = this.fw.GetBytes(this.e8);
				Independentsoft.IO.StructuredStorage.Stream stream118 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str31), numArray68);
				directoryEntryList.Add(stream118);
				q _q208 = new q();
				_q208.a(num68);
				_q208.a(PropertyType.String8);
				_q208.b((uint)((int)numArray68.Length + (int)this.fw.GetBytes("\0").Length));
				_q208.b(true);
				_q208.a(true);
				memoryStream.Write(_q208.b(), 0, 16);
			}
			if (this.e9 != null)
			{
				c _c69 = new c();
				_c69.a(32899);
				_c69.a(StandardPropertySet.Address);
				_c69.a(g.b);
				int count69 = m.a(A_0, _c69);
				if (count69 == -1)
				{
					A_0.Add(_c69);
					count69 = A_0.Count - 1;
				}
				uint num69 = 32768 + count69 << 16 | this.ft;
				string str32 = string.Format("{0:X8}", num69);
				byte[] bytes69 = this.fw.GetBytes(this.e9);
				Independentsoft.IO.StructuredStorage.Stream stream119 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str32), bytes69);
				directoryEntryList.Add(stream119);
				q _q209 = new q();
				_q209.a(num69);
				_q209.a(PropertyType.String8);
				_q209.b((uint)((int)bytes69.Length + (int)this.fw.GetBytes("\0").Length));
				_q209.b(true);
				_q209.a(true);
				memoryStream.Write(_q209.b(), 0, 16);
			}
			if (this.fa != null)
			{
				c _c70 = new c();
				_c70.a(32915);
				_c70.a(StandardPropertySet.Address);
				_c70.a(g.b);
				int count70 = m.a(A_0, _c70);
				if (count70 == -1)
				{
					A_0.Add(_c70);
					count70 = A_0.Count - 1;
				}
				uint num70 = 32768 + count70 << 16 | this.ft;
				string str33 = string.Format("{0:X8}", num70);
				byte[] numArray69 = this.fw.GetBytes(this.fa);
				Independentsoft.IO.StructuredStorage.Stream stream120 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str33), numArray69);
				directoryEntryList.Add(stream120);
				q _q210 = new q();
				_q210.a(num70);
				_q210.a(PropertyType.String8);
				_q210.b((uint)((int)numArray69.Length + (int)this.fw.GetBytes("\0").Length));
				_q210.b(true);
				_q210.a(true);
				memoryStream.Write(_q210.b(), 0, 16);
			}
			if (this.fb != null)
			{
				c _c71 = new c();
				_c71.a(32931);
				_c71.a(StandardPropertySet.Address);
				_c71.a(g.b);
				int count71 = m.a(A_0, _c71);
				if (count71 == -1)
				{
					A_0.Add(_c71);
					count71 = A_0.Count - 1;
				}
				uint num71 = 32768 + count71 << 16 | this.ft;
				string str34 = string.Format("{0:X8}", num71);
				byte[] bytes70 = this.fw.GetBytes(this.fb);
				Independentsoft.IO.StructuredStorage.Stream stream121 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str34), bytes70);
				directoryEntryList.Add(stream121);
				q _q211 = new q();
				_q211.a(num71);
				_q211.a(PropertyType.String8);
				_q211.b((uint)((int)bytes70.Length + (int)this.fw.GetBytes("\0").Length));
				_q211.b(true);
				_q211.a(true);
				memoryStream.Write(_q211.b(), 0, 16);
			}
			if (this.fc != null)
			{
				c _c72 = new c();
				_c72.a(32900);
				_c72.a(StandardPropertySet.Address);
				_c72.a(g.b);
				int count72 = m.a(A_0, _c72);
				if (count72 == -1)
				{
					A_0.Add(_c72);
					count72 = A_0.Count - 1;
				}
				uint num72 = 32768 + count72 << 16 | this.ft;
				string str35 = string.Format("{0:X8}", num72);
				byte[] numArray70 = this.fw.GetBytes(this.fc);
				Independentsoft.IO.StructuredStorage.Stream stream122 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str35), numArray70);
				directoryEntryList.Add(stream122);
				q _q212 = new q();
				_q212.a(num72);
				_q212.a(PropertyType.String8);
				_q212.b((uint)((int)numArray70.Length + (int)this.fw.GetBytes("\0").Length));
				_q212.b(true);
				_q212.a(true);
				memoryStream.Write(_q212.b(), 0, 16);
			}
			if (this.fd != null)
			{
				c _c73 = new c();
				_c73.a(32916);
				_c73.a(StandardPropertySet.Address);
				_c73.a(g.b);
				int count73 = m.a(A_0, _c73);
				if (count73 == -1)
				{
					A_0.Add(_c73);
					count73 = A_0.Count - 1;
				}
				uint num73 = 32768 + count73 << 16 | this.ft;
				string str36 = string.Format("{0:X8}", num73);
				byte[] bytes71 = this.fw.GetBytes(this.fd);
				Independentsoft.IO.StructuredStorage.Stream stream123 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str36), bytes71);
				directoryEntryList.Add(stream123);
				q _q213 = new q();
				_q213.a(num73);
				_q213.a(PropertyType.String8);
				_q213.b((uint)((int)bytes71.Length + (int)this.fw.GetBytes("\0").Length));
				_q213.b(true);
				_q213.a(true);
				memoryStream.Write(_q213.b(), 0, 16);
			}
			if (this.fe != null)
			{
				c _c74 = new c();
				_c74.a(32932);
				_c74.a(StandardPropertySet.Address);
				_c74.a(g.b);
				int count74 = m.a(A_0, _c74);
				if (count74 == -1)
				{
					A_0.Add(_c74);
					count74 = A_0.Count - 1;
				}
				uint num74 = 32768 + count74 << 16 | this.ft;
				string str37 = string.Format("{0:X8}", num74);
				byte[] numArray71 = this.fw.GetBytes(this.fe);
				Independentsoft.IO.StructuredStorage.Stream stream124 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str37), numArray71);
				directoryEntryList.Add(stream124);
				q _q214 = new q();
				_q214.a(num74);
				_q214.a(PropertyType.String8);
				_q214.b((uint)((int)numArray71.Length + (int)this.fw.GetBytes("\0").Length));
				_q214.b(true);
				_q214.a(true);
				memoryStream.Write(_q214.b(), 0, 16);
			}
			if (this.ff != null)
			{
				c _c75 = new c();
				_c75.a(32896);
				_c75.a(StandardPropertySet.Address);
				_c75.a(g.b);
				int count75 = m.a(A_0, _c75);
				if (count75 == -1)
				{
					A_0.Add(_c75);
					count75 = A_0.Count - 1;
				}
				uint num75 = 32768 + count75 << 16 | this.ft;
				string str38 = string.Format("{0:X8}", num75);
				byte[] bytes72 = this.fw.GetBytes(this.ff);
				Independentsoft.IO.StructuredStorage.Stream stream125 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str38), bytes72);
				directoryEntryList.Add(stream125);
				q _q215 = new q();
				_q215.a(num75);
				_q215.a(PropertyType.String8);
				_q215.b((uint)((int)bytes72.Length + (int)this.fw.GetBytes("\0").Length));
				_q215.b(true);
				_q215.a(true);
				memoryStream.Write(_q215.b(), 0, 16);
			}
			if (this.fg != null)
			{
				c _c76 = new c();
				_c76.a(32912);
				_c76.a(StandardPropertySet.Address);
				_c76.a(g.b);
				int count76 = m.a(A_0, _c76);
				if (count76 == -1)
				{
					A_0.Add(_c76);
					count76 = A_0.Count - 1;
				}
				uint num76 = 32768 + count76 << 16 | this.ft;
				string str39 = string.Format("{0:X8}", num76);
				byte[] numArray72 = this.fw.GetBytes(this.fg);
				Independentsoft.IO.StructuredStorage.Stream stream126 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str39), numArray72);
				directoryEntryList.Add(stream126);
				q _q216 = new q();
				_q216.a(num76);
				_q216.a(PropertyType.String8);
				_q216.b((uint)((int)numArray72.Length + (int)this.fw.GetBytes("\0").Length));
				_q216.b(true);
				_q216.a(true);
				memoryStream.Write(_q216.b(), 0, 16);
			}
			if (this.fh != null)
			{
				c _c77 = new c();
				_c77.a(32928);
				_c77.a(StandardPropertySet.Address);
				_c77.a(g.b);
				int count77 = m.a(A_0, _c77);
				if (count77 == -1)
				{
					A_0.Add(_c77);
					count77 = A_0.Count - 1;
				}
				uint num77 = 32768 + count77 << 16 | this.ft;
				string str40 = string.Format("{0:X8}", num77);
				byte[] bytes73 = this.fw.GetBytes(this.fh);
				Independentsoft.IO.StructuredStorage.Stream stream127 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str40), bytes73);
				directoryEntryList.Add(stream127);
				q _q217 = new q();
				_q217.a(num77);
				_q217.a(PropertyType.String8);
				_q217.b((uint)((int)bytes73.Length + (int)this.fw.GetBytes("\0").Length));
				_q217.b(true);
				_q217.a(true);
				memoryStream.Write(_q217.b(), 0, 16);
			}
			if (this.fi != null)
			{
				c _c78 = new c();
				_c78.a(32898);
				_c78.a(StandardPropertySet.Address);
				_c78.a(g.b);
				int count78 = m.a(A_0, _c78);
				if (count78 == -1)
				{
					A_0.Add(_c78);
					count78 = A_0.Count - 1;
				}
				uint num78 = 32768 + count78 << 16 | this.ft;
				string str41 = string.Format("{0:X8}", num78);
				byte[] numArray73 = this.fw.GetBytes(this.fi);
				Independentsoft.IO.StructuredStorage.Stream stream128 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str41), numArray73);
				directoryEntryList.Add(stream128);
				q _q218 = new q();
				_q218.a(num78);
				_q218.a(PropertyType.String8);
				_q218.b((uint)((int)numArray73.Length + (int)this.fw.GetBytes("\0").Length));
				_q218.b(true);
				_q218.a(true);
				memoryStream.Write(_q218.b(), 0, 16);
			}
			if (this.fj != null)
			{
				c _c79 = new c();
				_c79.a(32914);
				_c79.a(StandardPropertySet.Address);
				_c79.a(g.b);
				int count79 = m.a(A_0, _c79);
				if (count79 == -1)
				{
					A_0.Add(_c79);
					count79 = A_0.Count - 1;
				}
				uint num79 = 32768 + count79 << 16 | this.ft;
				string str42 = string.Format("{0:X8}", num79);
				byte[] bytes74 = this.fw.GetBytes(this.fj);
				Independentsoft.IO.StructuredStorage.Stream stream129 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str42), bytes74);
				directoryEntryList.Add(stream129);
				q _q219 = new q();
				_q219.a(num79);
				_q219.a(PropertyType.String8);
				_q219.b((uint)((int)bytes74.Length + (int)this.fw.GetBytes("\0").Length));
				_q219.b(true);
				_q219.a(true);
				memoryStream.Write(_q219.b(), 0, 16);
			}
			if (this.fk != null)
			{
				c _c80 = new c();
				_c80.a(32930);
				_c80.a(StandardPropertySet.Address);
				_c80.a(g.b);
				int count80 = m.a(A_0, _c80);
				if (count80 == -1)
				{
					A_0.Add(_c80);
					count80 = A_0.Count - 1;
				}
				uint num80 = 32768 + count80 << 16 | this.ft;
				string str43 = string.Format("{0:X8}", num80);
				byte[] numArray74 = this.fw.GetBytes(this.fk);
				Independentsoft.IO.StructuredStorage.Stream stream130 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str43), numArray74);
				directoryEntryList.Add(stream130);
				q _q220 = new q();
				_q220.a(num80);
				_q220.a(PropertyType.String8);
				_q220.b((uint)((int)numArray74.Length + (int)this.fw.GetBytes("\0").Length));
				_q220.b(true);
				_q220.a(true);
				memoryStream.Write(_q220.b(), 0, 16);
			}
			if (this.fl != null)
			{
				c _c81 = new c();
				_c81.a(32901);
				_c81.a(StandardPropertySet.Address);
				_c81.a(g.a);
				int count81 = m.a(A_0, _c81);
				if (count81 == -1)
				{
					A_0.Add(_c81);
					count81 = A_0.Count - 1;
				}
				uint num81 = (uint)(32768 + count81 << 16 | 258);
				string str44 = string.Format("{0:X8}", num81);
				Independentsoft.IO.StructuredStorage.Stream stream131 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str44), this.fl);
				directoryEntryList.Add(stream131);
				q _q221 = new q();
				_q221.a(num81);
				_q221.a(PropertyType.Integer32);
				_q221.b((uint)this.fl.Length);
				_q221.b(true);
				_q221.a(true);
				memoryStream.Write(_q221.b(), 0, 16);
			}
			if (this.fm != null)
			{
				c _c82 = new c();
				_c82.a(32917);
				_c82.a(StandardPropertySet.Address);
				_c82.a(g.a);
				int count82 = m.a(A_0, _c82);
				if (count82 == -1)
				{
					A_0.Add(_c82);
					count82 = A_0.Count - 1;
				}
				uint num82 = (uint)(32768 + count82 << 16 | 258);
				string str45 = string.Format("{0:X8}", num82);
				Independentsoft.IO.StructuredStorage.Stream stream132 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str45), this.fm);
				directoryEntryList.Add(stream132);
				q _q222 = new q();
				_q222.a(num82);
				_q222.a(PropertyType.Integer32);
				_q222.b((uint)this.fm.Length);
				_q222.b(true);
				_q222.a(true);
				memoryStream.Write(_q222.b(), 0, 16);
			}
			if (this.fn != null)
			{
				c _c83 = new c();
				_c83.a(32933);
				_c83.a(StandardPropertySet.Address);
				_c83.a(g.a);
				int count83 = m.a(A_0, _c83);
				if (count83 == -1)
				{
					A_0.Add(_c83);
					count83 = A_0.Count - 1;
				}
				uint num83 = (uint)(32768 + count83 << 16 | 258);
				string str46 = string.Format("{0:X8}", num83);
				Independentsoft.IO.StructuredStorage.Stream stream133 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str46), this.fn);
				directoryEntryList.Add(stream133);
				q _q223 = new q();
				_q223.a(num83);
				_q223.a(PropertyType.Integer32);
				_q223.b((uint)this.fn.Length);
				_q223.b(true);
				_q223.a(true);
				memoryStream.Write(_q223.b(), 0, 16);
			}
			for (int m = 0; m < this.fq.Count; m++)
			{
				if (this.fq[m].Value != null)
				{
					c _c84 = new c();
					if (!(this.fq[m].Tag is ExtendedPropertyId))
					{
						ExtendedPropertyName tag = (ExtendedPropertyName)this.fq[m].Tag;
						_c84.a(tag.Name);
						_c84.a(tag.Guid);
						_c84.a(g.b);
					}
					else
					{
						ExtendedPropertyId extendedPropertyId = (ExtendedPropertyId)this.fq[m].Tag;
						_c84.a((uint)extendedPropertyId.Id);
						_c84.a(extendedPropertyId.Guid);
						_c84.a(g.a);
					}
					if (m.a(A_0, _c84) == -1)
					{
						A_0.Add(_c84);
						int count84 = A_0.Count - 1;
						uint num84 = 32768 + count84 << 16 | m.a(this.fq[m].Tag.Type);
						if (this.fq[m].Tag.Type == PropertyType.Boolean || this.fq[m].Tag.Type == PropertyType.Integer16 || this.fq[m].Tag.Type == PropertyType.Integer32 || this.fq[m].Tag.Type == PropertyType.Integer64 || this.fq[m].Tag.Type == PropertyType.Floating32 || this.fq[m].Tag.Type == PropertyType.Floating64 || this.fq[m].Tag.Type == PropertyType.FloatingTime || this.fq[m].Tag.Type == PropertyType.Time)
						{
							q _q224 = new q();
							_q224.a(num84);
							_q224.a(this.fq[m].Tag.Type);
							_q224.b(this.fq[m].Value);
							_q224.b(true);
							_q224.a(true);
							memoryStream.Write(_q224.b(), 0, 16);
						}
						else if (this.fq[m].Tag.Type != PropertyType.MultipleCurrency && this.fq[m].Tag.Type != PropertyType.MultipleFloating32 && this.fq[m].Tag.Type != PropertyType.MultipleFloating64 && this.fq[m].Tag.Type != PropertyType.MultipleFloatingTime && this.fq[m].Tag.Type != PropertyType.MultipleGuid && this.fq[m].Tag.Type != PropertyType.MultipleInteger16 && this.fq[m].Tag.Type != PropertyType.MultipleInteger32 && this.fq[m].Tag.Type != PropertyType.MultipleInteger64 && this.fq[m].Tag.Type != PropertyType.MultipleString && this.fq[m].Tag.Type != PropertyType.MultipleString8 && this.fq[m].Tag.Type != PropertyType.MultipleTime)
						{
							if (this.fq[m].Tag.Type != PropertyType.MultipleBinary)
							{
								byte[] value = this.fq[m].Value;
								if (value != null && this.fq[m].Tag.Type == PropertyType.String && this.fw != System.Text.Encoding.Unicode && !(this.fw is UnicodeEncoding))
								{
									string str47 = System.Text.Encoding.Unicode.GetString(value, 0, (int)value.Length);
									value = this.fw.GetBytes(str47);
									num84 = 32768 + count84 << 16 | this.ft;
								}
								else if (value != null && this.fq[m].Tag.Type == PropertyType.String8 && (this.fw == System.Text.Encoding.Unicode || this.fw is UnicodeEncoding))
								{
									string str48 = System.Text.Encoding.UTF8.GetString(value, 0, (int)value.Length);
									value = this.fw.GetBytes(str48);
									num84 = 32768 + count84 << 16 | this.ft;
								}
								string str49 = string.Format("{0:X8}", num84);
								Independentsoft.IO.StructuredStorage.Stream stream134 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str49), value);
								directoryEntryList.Add(stream134);
								q _q225 = new q();
								_q225.a(num84);
								if (this.fq[m].Tag.Type == PropertyType.Binary || this.fq[m].Tag.Type == PropertyType.Object)
								{
									_q225.a(PropertyType.Integer32);
								}
								else
								{
									_q225.a(PropertyType.String8);
								}
								_q225.b(m.a(value, this.fq[m].Tag.Type, this.fw));
								_q225.b(true);
								_q225.a(true);
								memoryStream.Write(_q225.b(), 0, 16);
							}
							else
							{
								string str50 = string.Format("{0:X8}", num84);
								MemoryStream memoryStream5 = new MemoryStream();
								int num85 = BitConverter.ToInt32(this.fq[m].Value, 0);
								int[] length4 = new int[num85 + 1];
								for (int n = 0; n < num85; n++)
								{
									length4[n] = BitConverter.ToInt32(this.fq[m].Value, 4 + n * 4);
								}
								length4[num85] = (int)this.fq[m].Value.Length;
								for (int o = 0; o < (int)length4.Length - 1; o++)
								{
									long num86 = (long)(length4[o + 1] - length4[o]);
									memoryStream5.Write(BitConverter.GetBytes(num86), 0, 8);
									byte[] numArray75 = new byte[(int)num86];
									Array.Copy(this.fq[m].Value, length4[o], numArray75, 0, (int)num86);
									string str51 = string.Concat("__substg1.0_", str50, "-", string.Format("{0:X8}", o));
									directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream(str51, numArray75));
								}
								byte[] array4 = memoryStream5.ToArray();
								Independentsoft.IO.StructuredStorage.Stream stream135 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_", str50), array4);
								directoryEntryList.Add(stream135);
								q _q226 = new q();
								_q226.a(num84);
								_q226.a(PropertyType.MultipleBinary);
								_q226.b((uint)array4.Length);
								_q226.b(true);
								_q226.a(true);
								memoryStream.Write(_q226.b(), 0, 16);
							}
						}
					}
				}
			}
			directoryEntryList.Add(new Independentsoft.IO.StructuredStorage.Stream("__properties_version1.0", memoryStream.ToArray()));
			for (int p = 0; p < this.fo.Count; p++)
			{
				Storage storage = new Storage(string.Format("__recip_version1.0_#{0:X8}", p));
				Recipient item = this.fo[p];
				MemoryStream memoryStream6 = new MemoryStream();
				memoryStream6.Write(new byte[8], 0, 8);
				q _q227 = new q();
				_q227.a(805306371);
				_q227.a(PropertyType.Integer32);
				_q227.b(BitConverter.GetBytes(p));
				_q227.b(true);
				_q227.a(true);
				memoryStream6.Write(_q227.b(), 0, 16);
				if (item.DisplayType != DisplayType.None)
				{
					q _q228 = new q();
					_q228.a(956301315);
					_q228.a(PropertyType.Integer32);
					_q228.b(BitConverter.GetBytes(h.a(item.DisplayType)));
					_q228.b(true);
					_q228.a(true);
					memoryStream6.Write(_q228.b(), 0, 16);
				}
				if (item.ObjectType != Independentsoft.Msg.ObjectType.None)
				{
					q _q229 = new q();
					_q229.a(268304387);
					_q229.a(PropertyType.Integer32);
					_q229.b(BitConverter.GetBytes(h.a(item.ObjectType)));
					_q229.b(true);
					_q229.a(true);
					memoryStream6.Write(_q229.b(), 0, 16);
				}
				if (item.RecipientType != RecipientType.None)
				{
					q _q230 = new q();
					_q230.a(202702851);
					_q230.a(PropertyType.Integer32);
					_q230.b(BitConverter.GetBytes(h.a(item.RecipientType)));
					_q230.b(true);
					_q230.a(true);
					memoryStream6.Write(_q230.b(), 0, 16);
				}
				if (item.DisplayName != null)
				{
					byte[] bytes75 = this.fw.GetBytes(item.DisplayName);
					Independentsoft.IO.StructuredStorage.Stream stream136 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3001", this.fs), bytes75);
					storage.DirectoryEntries.Add(stream136);
					q _q231 = new q();
					_q231.a(805371904 | this.ft);
					_q231.a(PropertyType.String8);
					_q231.b((uint)((int)bytes75.Length + (int)this.fw.GetBytes("\0").Length));
					_q231.b(true);
					_q231.a(true);
					memoryStream6.Write(_q231.b(), 0, 16);
					Independentsoft.IO.StructuredStorage.Stream stream137 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_5FF6", this.fs), bytes75);
					storage.DirectoryEntries.Add(stream137);
					q _q232 = new q();
					_q232.a(1609957376 | this.ft);
					_q232.a(PropertyType.String8);
					_q232.b((uint)((int)bytes75.Length + (int)this.fw.GetBytes("\0").Length));
					_q232.b(true);
					_q232.a(true);
					memoryStream6.Write(_q232.b(), 0, 16);
				}
				if (item.EmailAddress != null)
				{
					byte[] bytes76 = this.fw.GetBytes(item.EmailAddress);
					Independentsoft.IO.StructuredStorage.Stream stream138 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3003", this.fs), bytes76);
					storage.DirectoryEntries.Add(stream138);
					q _q233 = new q();
					_q233.a(805502976 | this.ft);
					_q233.a(PropertyType.String8);
					_q233.b((uint)((int)bytes76.Length + (int)this.fw.GetBytes("\0").Length));
					_q233.b(true);
					_q233.a(true);
					memoryStream6.Write(_q233.b(), 0, 16);
				}
				if (item.AddressType != null)
				{
					byte[] numArray76 = this.fw.GetBytes(item.AddressType);
					Independentsoft.IO.StructuredStorage.Stream stream139 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3002", this.fs), numArray76);
					storage.DirectoryEntries.Add(stream139);
					q _q234 = new q();
					_q234.a(805437440 | this.ft);
					_q234.a(PropertyType.String8);
					_q234.b((uint)((int)numArray76.Length + (int)this.fw.GetBytes("\0").Length));
					_q234.b(true);
					_q234.a(true);
					memoryStream6.Write(_q234.b(), 0, 16);
				}
				if (item.EntryId != null)
				{
					Independentsoft.IO.StructuredStorage.Stream stream140 = new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_0FFF0102", item.EntryId);
					storage.DirectoryEntries.Add(stream140);
					q _q235 = new q();
					_q235.a(268370178);
					_q235.a(PropertyType.Binary);
					_q235.b((uint)item.EntryId.Length);
					_q235.b(true);
					_q235.a(true);
					memoryStream6.Write(_q235.b(), 0, 16);
					Independentsoft.IO.StructuredStorage.Stream stream141 = new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_5FF70102", item.EntryId);
					storage.DirectoryEntries.Add(stream141);
					q _q236 = new q();
					_q236.a(1610023170);
					_q236.a(PropertyType.Binary);
					_q236.b((uint)item.EntryId.Length);
					_q236.b(true);
					_q236.a(true);
					memoryStream6.Write(_q236.b(), 0, 16);
				}
				if (item.SearchKey != null)
				{
					Independentsoft.IO.StructuredStorage.Stream stream142 = new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_300B0102", item.SearchKey);
					storage.DirectoryEntries.Add(stream142);
					q _q237 = new q();
					_q237.a(806027522);
					_q237.a(PropertyType.Binary);
					_q237.b((uint)item.SearchKey.Length);
					_q237.b(true);
					_q237.a(true);
					memoryStream6.Write(_q237.b(), 0, 16);
				}
				if (item.InstanceKey != null)
				{
					Independentsoft.IO.StructuredStorage.Stream stream143 = new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_0FF60102", item.InstanceKey);
					storage.DirectoryEntries.Add(stream143);
					q _q238 = new q();
					_q238.a(267780354);
					_q238.a(PropertyType.Binary);
					_q238.b((uint)item.InstanceKey.Length);
					_q238.b(true);
					_q238.a(true);
					memoryStream6.Write(_q238.b(), 0, 16);
				}
				if (item.Responsibility)
				{
					q _q239 = new q();
					_q239.a(235864075);
					_q239.a(PropertyType.Boolean);
					_q239.b(BitConverter.GetBytes(1));
					_q239.b(true);
					_q239.a(true);
					memoryStream6.Write(_q239.b(), 0, 16);
				}
				if (item.SendRichInfo)
				{
					q _q240 = new q();
					_q240.a(977272843);
					_q240.a(PropertyType.Boolean);
					_q240.b(BitConverter.GetBytes(1));
					_q240.b(true);
					_q240.a(true);
					memoryStream6.Write(_q240.b(), 0, 16);
				}
				if (item.SendInternetEncoding > 0)
				{
					q _q241 = new q();
					_q241.a(980484099);
					_q241.a(PropertyType.Integer32);
					_q241.b(BitConverter.GetBytes(item.SendInternetEncoding));
					_q241.b(true);
					_q241.a(true);
					memoryStream6.Write(_q241.b(), 0, 16);
				}
				if (item.SmtpAddress != null)
				{
					byte[] bytes77 = this.fw.GetBytes(item.SmtpAddress);
					Independentsoft.IO.StructuredStorage.Stream stream144 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_39FE", this.fs), bytes77);
					storage.DirectoryEntries.Add(stream144);
					q _q242 = new q();
					_q242.a(972947456 | this.ft);
					_q242.a(PropertyType.String8);
					_q242.b((uint)((int)bytes77.Length + (int)this.fw.GetBytes("\0").Length));
					_q242.b(true);
					_q242.a(true);
					memoryStream6.Write(_q242.b(), 0, 16);
				}
				if (item.DisplayName7Bit != null)
				{
					byte[] numArray77 = this.fw.GetBytes(item.DisplayName7Bit);
					Independentsoft.IO.StructuredStorage.Stream stream145 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_39FF", this.fs), numArray77);
					storage.DirectoryEntries.Add(stream145);
					q _q243 = new q();
					_q243.a(973012992 | this.ft);
					_q243.a(PropertyType.String8);
					_q243.b((uint)((int)numArray77.Length + (int)this.fw.GetBytes("\0").Length));
					_q243.b(true);
					_q243.a(true);
					memoryStream6.Write(_q243.b(), 0, 16);
				}
				if (item.TransmitableDisplayName != null)
				{
					byte[] bytes78 = this.fw.GetBytes(item.TransmitableDisplayName);
					Independentsoft.IO.StructuredStorage.Stream stream146 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3A20", this.fs), bytes78);
					storage.DirectoryEntries.Add(stream146);
					q _q244 = new q();
					_q244.a(975175680 | this.ft);
					_q244.a(PropertyType.String8);
					_q244.b((uint)((int)bytes78.Length + (int)this.fw.GetBytes("\0").Length));
					_q244.b(true);
					_q244.a(true);
					memoryStream6.Write(_q244.b(), 0, 16);
				}
				if (item.OriginatingAddressType != null)
				{
					byte[] numArray78 = this.fw.GetBytes(item.OriginatingAddressType);
					Independentsoft.IO.StructuredStorage.Stream stream147 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_403D", this.fs), numArray78);
					storage.DirectoryEntries.Add(stream147);
					q _q245 = new q();
					_q245.a(1077739520 | this.ft);
					_q245.a(PropertyType.String8);
					_q245.b((uint)((int)numArray78.Length + (int)this.fw.GetBytes("\0").Length));
					_q245.b(true);
					_q245.a(true);
					memoryStream6.Write(_q245.b(), 0, 16);
				}
				if (item.OriginatingEmailAddress != null)
				{
					byte[] bytes79 = this.fw.GetBytes(item.OriginatingEmailAddress);
					Independentsoft.IO.StructuredStorage.Stream stream148 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_403E", this.fs), bytes79);
					storage.DirectoryEntries.Add(stream148);
					q _q246 = new q();
					_q246.a(1077805056 | this.ft);
					_q246.a(PropertyType.String8);
					_q246.b((uint)((int)bytes79.Length + (int)this.fw.GetBytes("\0").Length));
					_q246.b(true);
					_q246.a(true);
					memoryStream6.Write(_q246.b(), 0, 16);
				}
				Independentsoft.IO.StructuredStorage.Stream stream149 = new Independentsoft.IO.StructuredStorage.Stream("__properties_version1.0", memoryStream6.ToArray());
				storage.DirectoryEntries.Add(stream149);
				directoryEntryList.Add(storage);
			}
			for (int q = 0; q < this.fp.Count; q++)
			{
				Storage storage1 = new Storage(string.Format("__attach_version1.0_#{0:X8}", q));
				Independentsoft.Msg.Attachment attachment = this.fp[q];
				MemoryStream memoryStream7 = new MemoryStream();
				memoryStream7.Write(new byte[8], 0, 8);
				q _q247 = new q();
				_q247.a(237043715);
				_q247.a(PropertyType.Integer32);
				_q247.b(BitConverter.GetBytes(q));
				_q247.b(true);
				_q247.a(false);
				memoryStream7.Write(_q247.b(), 0, 16);
				q _q248 = new q();
				_q248.a(2147090435);
				_q248.a(PropertyType.Integer32);
				_q248.b(BitConverter.GetBytes(q));
				_q248.b(true);
				_q248.a(true);
				memoryStream7.Write(_q248.b(), 0, 16);
				attachment.RecordKey = BitConverter.GetBytes(q);
				Independentsoft.IO.StructuredStorage.Stream stream150 = new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_0FF90102", attachment.RecordKey);
				storage1.DirectoryEntries.Add(stream150);
				q _q249 = new q();
				_q249.a(267976962);
				_q249.a(PropertyType.Binary);
				_q249.b((uint)attachment.RecordKey.Length);
				_q249.b(true);
				_q249.a(true);
				memoryStream7.Write(_q249.b(), 0, 16);
				if (attachment.AdditionalInfo != null)
				{
					Independentsoft.IO.StructuredStorage.Stream stream151 = new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_370F0102", attachment.AdditionalInfo);
					storage1.DirectoryEntries.Add(stream151);
					q _q250 = new q();
					_q250.a(923730178);
					_q250.a(PropertyType.Binary);
					_q250.b((uint)attachment.AdditionalInfo.Length);
					_q250.b(true);
					_q250.a(true);
					memoryStream7.Write(_q250.b(), 0, 16);
				}
				if (attachment.ContentBase != null)
				{
					byte[] numArray79 = this.fw.GetBytes(attachment.ContentBase);
					Independentsoft.IO.StructuredStorage.Stream stream152 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3711", this.fs), numArray79);
					storage1.DirectoryEntries.Add(stream152);
					q _q251 = new q();
					_q251.a(923860992 | this.ft);
					_q251.a(PropertyType.String8);
					_q251.b((uint)((int)numArray79.Length + (int)this.fw.GetBytes("\0").Length));
					_q251.b(true);
					_q251.a(true);
					memoryStream7.Write(_q251.b(), 0, 16);
				}
				if (attachment.ContentId != null)
				{
					byte[] bytes80 = this.fw.GetBytes(attachment.ContentId);
					Independentsoft.IO.StructuredStorage.Stream stream153 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3712", this.fs), bytes80);
					storage1.DirectoryEntries.Add(stream153);
					q _q252 = new q();
					_q252.a(923926528 | this.ft);
					_q252.a(PropertyType.String8);
					_q252.b((uint)((int)bytes80.Length + (int)this.fw.GetBytes("\0").Length));
					_q252.b(true);
					_q252.a(true);
					memoryStream7.Write(_q252.b(), 0, 16);
				}
				if (attachment.ContentLocation != null)
				{
					byte[] numArray80 = this.fw.GetBytes(attachment.ContentLocation);
					Independentsoft.IO.StructuredStorage.Stream stream154 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3713", this.fs), numArray80);
					storage1.DirectoryEntries.Add(stream154);
					q _q253 = new q();
					_q253.a(923992064 | this.ft);
					_q253.a(PropertyType.String8);
					_q253.b((uint)((int)numArray80.Length + (int)this.fw.GetBytes("\0").Length));
					_q253.b(true);
					_q253.a(true);
					memoryStream7.Write(_q253.b(), 0, 16);
				}
				if (attachment.ContentDisposition != null)
				{
					byte[] bytes81 = this.fw.GetBytes(attachment.ContentDisposition);
					Independentsoft.IO.StructuredStorage.Stream stream155 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3716", this.fs), bytes81);
					storage1.DirectoryEntries.Add(stream155);
					q _q254 = new q();
					_q254.a(924188672 | this.ft);
					_q254.a(PropertyType.String8);
					_q254.b((uint)((int)bytes81.Length + (int)this.fw.GetBytes("\0").Length));
					_q254.b(true);
					_q254.a(true);
					memoryStream7.Write(_q254.b(), 0, 16);
				}
				if (attachment.Data != null)
				{
					if (attachment.Method != AttachmentMethod.Ole)
					{
						Independentsoft.IO.StructuredStorage.Stream stream156 = new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_37010102", attachment.Data);
						storage1.DirectoryEntries.Add(stream156);
						q _q255 = new q();
						_q255.a(922812674);
						_q255.a(PropertyType.Binary);
						_q255.b((uint)attachment.Data.Length);
						_q255.b(true);
						_q255.a(true);
						memoryStream7.Write(_q255.b(), 0, 16);
					}
					else
					{
						Storage classId = new Storage("__substg1.0_3701000D");
						storage1.DirectoryEntries.Add(classId);
						CompoundFile compoundFile = new CompoundFile(new MemoryStream(attachment.Data));
						classId.g = compoundFile.Root.ClassId;
						for (int r = 0; r < compoundFile.Root.DirectoryEntries.Count; r++)
						{
							classId.DirectoryEntries.Add(compoundFile.Root.DirectoryEntries[r]);
						}
						q _q256 = new q();
						_q256.a(922812429);
						_q256.a(PropertyType.Object);
						_q256.b(-1);
						_q256.b(true);
						_q256.a(true);
						byte[] numArray81 = _q256.b();
						numArray81[12] = 4;
						memoryStream7.Write(numArray81, 0, 16);
					}
				}
				if (attachment.Encoding != null)
				{
					Independentsoft.IO.StructuredStorage.Stream stream157 = new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_37020102", attachment.Encoding);
					storage1.DirectoryEntries.Add(stream157);
					q _q257 = new q();
					_q257.a(922878210);
					_q257.a(PropertyType.Binary);
					_q257.b((uint)attachment.Encoding.Length);
					_q257.b(true);
					_q257.a(true);
					memoryStream7.Write(_q257.b(), 0, 16);
				}
				if (attachment.Extension != null)
				{
					byte[] bytes82 = this.fw.GetBytes(attachment.Extension);
					Independentsoft.IO.StructuredStorage.Stream stream158 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3703", this.fs), bytes82);
					storage1.DirectoryEntries.Add(stream158);
					q _q258 = new q();
					_q258.a(922943488 | this.ft);
					_q258.a(PropertyType.String8);
					_q258.b((uint)((int)bytes82.Length + (int)this.fw.GetBytes("\0").Length));
					_q258.b(true);
					_q258.a(true);
					memoryStream7.Write(_q258.b(), 0, 16);
				}
				if (attachment.FileName != null)
				{
					byte[] numArray82 = this.fw.GetBytes(attachment.FileName);
					Independentsoft.IO.StructuredStorage.Stream stream159 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3704", this.fs), numArray82);
					storage1.DirectoryEntries.Add(stream159);
					q _q259 = new q();
					_q259.a(923009024 | this.ft);
					_q259.a(PropertyType.String8);
					_q259.b((uint)((int)numArray82.Length + (int)this.fw.GetBytes("\0").Length));
					_q259.b(true);
					_q259.a(true);
					memoryStream7.Write(_q259.b(), 0, 16);
				}
				if (attachment.Flags != AttachmentFlags.None)
				{
					q _q260 = new q();
					_q260.a(924057603);
					_q260.a(PropertyType.Integer32);
					_q260.b(BitConverter.GetBytes(h.a(attachment.Flags)));
					_q260.b(true);
					_q260.a(true);
					memoryStream7.Write(_q260.b(), 0, 16);
				}
				if (attachment.LongFileName != null)
				{
					byte[] bytes83 = this.fw.GetBytes(attachment.LongFileName);
					Independentsoft.IO.StructuredStorage.Stream stream160 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3707", this.fs), bytes83);
					storage1.DirectoryEntries.Add(stream160);
					q _q261 = new q();
					_q261.a(923205632 | this.ft);
					_q261.a(PropertyType.String8);
					_q261.b((uint)((int)bytes83.Length + (int)this.fw.GetBytes("\0").Length));
					_q261.b(true);
					_q261.a(true);
					memoryStream7.Write(_q261.b(), 0, 16);
				}
				if (attachment.LongPathName != null)
				{
					byte[] numArray83 = this.fw.GetBytes(attachment.LongPathName);
					Independentsoft.IO.StructuredStorage.Stream stream161 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_370D", this.fs), numArray83);
					storage1.DirectoryEntries.Add(stream161);
					q _q262 = new q();
					_q262.a(923598848 | this.ft);
					_q262.a(PropertyType.String8);
					_q262.b((uint)((int)numArray83.Length + (int)this.fw.GetBytes("\0").Length));
					_q262.b(true);
					_q262.a(true);
					memoryStream7.Write(_q262.b(), 0, 16);
				}
				if (attachment.Method != AttachmentMethod.None)
				{
					q _q263 = new q();
					_q263.a(923074563);
					_q263.a(PropertyType.Integer32);
					_q263.b(BitConverter.GetBytes(h.a(attachment.Method)));
					_q263.b(true);
					_q263.a(true);
					memoryStream7.Write(_q263.b(), 0, 16);
				}
				if (attachment.MimeSequence > (long)0)
				{
					q _q264 = new q();
					_q264.a(923795459);
					_q264.a(PropertyType.Integer32);
					_q264.b(BitConverter.GetBytes(attachment.MimeSequence));
					_q264.b(true);
					_q264.a(true);
					memoryStream7.Write(_q264.b(), 0, 16);
				}
				if (attachment.MimeTag != null)
				{
					byte[] bytes84 = this.fw.GetBytes(attachment.MimeTag);
					Independentsoft.IO.StructuredStorage.Stream stream162 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_370E", this.fs), bytes84);
					storage1.DirectoryEntries.Add(stream162);
					q _q265 = new q();
					_q265.a(923664384 | this.ft);
					_q265.a(PropertyType.String8);
					_q265.b((uint)((int)bytes84.Length + (int)this.fw.GetBytes("\0").Length));
					_q265.b(true);
					_q265.a(true);
					memoryStream7.Write(_q265.b(), 0, 16);
				}
				if (attachment.PathName != null)
				{
					byte[] numArray84 = this.fw.GetBytes(attachment.PathName);
					Independentsoft.IO.StructuredStorage.Stream stream163 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3708", this.fs), numArray84);
					storage1.DirectoryEntries.Add(stream163);
					q _q266 = new q();
					_q266.a(923271168 | this.ft);
					_q266.a(PropertyType.String8);
					_q266.b((uint)((int)numArray84.Length + (int)this.fw.GetBytes("\0").Length));
					_q266.b(true);
					_q266.a(true);
					memoryStream7.Write(_q266.b(), 0, 16);
				}
				if (attachment.Rendering != null)
				{
					Independentsoft.IO.StructuredStorage.Stream stream164 = new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_37090102", attachment.Rendering);
					storage1.DirectoryEntries.Add(stream164);
					q _q267 = new q();
					_q267.a(923336962);
					_q267.a(PropertyType.Binary);
					_q267.b((uint)attachment.Rendering.Length);
					_q267.b(true);
					_q267.a(true);
					memoryStream7.Write(_q267.b(), 0, 16);
				}
				if (attachment.RenderingPosition > (long)0)
				{
					q _q268 = new q();
					_q268.a(923467779);
					_q268.a(PropertyType.Integer32);
					_q268.b(BitConverter.GetBytes(attachment.RenderingPosition));
					_q268.b(true);
					_q268.a(true);
					memoryStream7.Write(_q268.b(), 0, 16);
				}
				if (attachment.Size > (long)0)
				{
					q _q269 = new q();
					_q269.a(236978179);
					_q269.a(PropertyType.Integer32);
					_q269.b(BitConverter.GetBytes(attachment.Size));
					_q269.b(true);
					_q269.a(true);
					memoryStream7.Write(_q269.b(), 0, 16);
				}
				if (attachment.Tag != null)
				{
					Independentsoft.IO.StructuredStorage.Stream stream165 = new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_370A0102", attachment.Tag);
					storage1.DirectoryEntries.Add(stream165);
					q _q270 = new q();
					_q270.a(923402498);
					_q270.a(PropertyType.Binary);
					_q270.b((uint)attachment.Tag.Length);
					_q270.b(true);
					_q270.a(true);
					memoryStream7.Write(_q270.b(), 0, 16);
				}
				if (attachment.TransportName != null)
				{
					byte[] bytes85 = this.fw.GetBytes(attachment.TransportName);
					Independentsoft.IO.StructuredStorage.Stream stream166 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_370C", this.fs), bytes85);
					storage1.DirectoryEntries.Add(stream166);
					q _q271 = new q();
					_q271.a(923533312 | this.ft);
					_q271.a(PropertyType.String8);
					_q271.b((uint)((int)bytes85.Length + (int)this.fw.GetBytes("\0").Length));
					_q271.b(true);
					_q271.a(true);
					memoryStream7.Write(_q271.b(), 0, 16);
				}
				if (attachment.DisplayName != null)
				{
					byte[] numArray85 = this.fw.GetBytes(attachment.DisplayName);
					Independentsoft.IO.StructuredStorage.Stream stream167 = new Independentsoft.IO.StructuredStorage.Stream(string.Concat("__substg1.0_3001", this.fs), numArray85);
					storage1.DirectoryEntries.Add(stream167);
					q _q272 = new q();
					_q272.a(805371904 | this.ft);
					_q272.a(PropertyType.String8);
					_q272.b((uint)((int)numArray85.Length + (int)this.fw.GetBytes("\0").Length));
					_q272.b(true);
					_q272.a(true);
					memoryStream7.Write(_q272.b(), 0, 16);
				}
				if (attachment.EmbeddedMessage != null && attachment.Method != AttachmentMethod.Ole)
				{
					DirectoryEntryList directoryEntryList1 = attachment.EmbeddedMessage.a(ref A_0);
					Storage storage2 = new Storage("__substg1.0_3701000D");
					for (int s = 0; s < directoryEntryList1.Count; s++)
					{
						storage2.DirectoryEntries.Add(directoryEntryList1[s]);
					}
					storage1.DirectoryEntries.Add(storage2);
					q _q273 = new q();
					_q273.a(922812429);
					_q273.a(PropertyType.Object);
					_q273.b(-1);
					_q273.b(true);
					_q273.a(true);
					byte[] numArray86 = _q273.b();
					numArray86[12] = 1;
					memoryStream7.Write(numArray86, 0, 16);
				}
				if (attachment.ObjectType != Independentsoft.Msg.ObjectType.None)
				{
					q _q274 = new q();
					_q274.a(268304387);
					_q274.a(PropertyType.Integer32);
					_q274.b(BitConverter.GetBytes(h.a(attachment.ObjectType)));
					_q274.b(true);
					_q274.a(true);
					memoryStream7.Write(_q274.b(), 0, 16);
				}
				if (attachment.IsHidden)
				{
					q _q275 = new q();
					_q275.a(2147352587);
					_q275.a(PropertyType.Boolean);
					_q275.b(BitConverter.GetBytes(1));
					_q275.b(true);
					_q275.a(true);
					memoryStream7.Write(_q275.b(), 0, 16);
				}
				if (attachment.IsContactPhoto)
				{
					q _q276 = new q();
					_q276.a(2147418123);
					_q276.a(PropertyType.Boolean);
					_q276.b(BitConverter.GetBytes(1));
					_q276.b(true);
					_q276.a(true);
					memoryStream7.Write(_q276.b(), 0, 16);
				}
				if (attachment.CreationTime.CompareTo(DateTime.MinValue) > 0)
				{
					DateTime dateTime21 = new DateTime(1601, 1, 1);
					universalTime = attachment.CreationTime.ToUniversalTime();
					TimeSpan timeSpan21 = universalTime.Subtract(dateTime21);
					byte[] bytes86 = BitConverter.GetBytes(timeSpan21.Ticks);
					q _q277 = new q();
					_q277.a(805765184);
					_q277.a(PropertyType.Time);
					_q277.b(bytes86);
					_q277.b(true);
					_q277.a(false);
					memoryStream7.Write(_q277.b(), 0, 16);
				}
				if (attachment.LastModificationTime.CompareTo(DateTime.MinValue) > 0)
				{
					DateTime dateTime22 = new DateTime(1601, 1, 1);
					universalTime = attachment.LastModificationTime.ToUniversalTime();
					TimeSpan timeSpan22 = universalTime.Subtract(dateTime22);
					byte[] bytes87 = BitConverter.GetBytes(timeSpan22.Ticks);
					q _q278 = new q();
					_q278.a(805830720);
					_q278.a(PropertyType.Time);
					_q278.b(bytes87);
					_q278.b(true);
					_q278.a(false);
					memoryStream7.Write(_q278.b(), 0, 16);
				}
				if (attachment.DataObjectStorage == null || attachment.Method != AttachmentMethod.Ole)
				{
					Independentsoft.IO.StructuredStorage.Stream stream168 = new Independentsoft.IO.StructuredStorage.Stream("__properties_version1.0", memoryStream7.ToArray());
					storage1.DirectoryEntries.Add(stream168);
				}
				else
				{
					storage1.DirectoryEntries.Add(attachment.DataObjectStorage);
					storage1.DirectoryEntries.Add(attachment.PropertiesStream);
				}
				directoryEntryList.Add(storage1);
			}
			return directoryEntryList;
		}

		private static int a(byte[] A_0, IList<byte[]> A_1)
		{
			if (A_0 != null)
			{
				for (int i = 0; i < A_1.Count; i++)
				{
					byte[] item = A_1[i];
					bool flag = true;
					int num = 0;
					while (num < 16)
					{
						if (A_0[num] == item[num])
						{
							num++;
						}
						else
						{
							flag = false;
							break;
						}
					}
					if (flag)
					{
						return i;
					}
				}
			}
			return -1;
		}

		private Independentsoft.Email.Mime.Message a()
		{
			Independentsoft.Email.Mime.Message message = new Independentsoft.Email.Mime.Message();
			if (this.TransportMessageHeaders != null)
			{
				string transportMessageHeaders = this.TransportMessageHeaders;
				if (!transportMessageHeaders.EndsWith("\r\n\r\n"))
				{
					transportMessageHeaders = string.Concat(transportMessageHeaders, "\r\n\r\n");
				}
				System.Text.Encoding encoding = m.a(this.InternetCodePage);
				message = new Independentsoft.Email.Mime.Message(encoding.GetBytes(transportMessageHeaders));
				message.BodyParts.Clear();
				message.To.Clear();
				message.Cc.Clear();
				message.Bcc.Clear();
			}
			for (int i = 0; i < this.Recipients.Count; i++)
			{
				Mailbox mailbox = new Mailbox();
				if (this.Recipients[i].DisplayName != null && this.Recipients[i].DisplayName.Length > 0)
				{
					mailbox.Name = this.Recipients[i].DisplayName;
				}
				else if (this.Recipients[i].SmtpAddress == null)
				{
					mailbox.Name = this.Recipients[i].EmailAddress;
				}
				else
				{
					mailbox.Name = this.Recipients[i].SmtpAddress;
				}
				if (this.Recipients[i].SmtpAddress == null)
				{
					mailbox.EmailAddress = this.Recipients[i].EmailAddress;
				}
				else
				{
					mailbox.EmailAddress = this.Recipients[i].SmtpAddress;
				}
				if (this.Recipients[i].RecipientType == RecipientType.To)
				{
					message.To.Add(mailbox);
				}
				else if (this.Recipients[i].RecipientType == RecipientType.Cc)
				{
					message.Cc.Add(mailbox);
				}
				else if (this.Recipients[i].RecipientType == RecipientType.Bcc)
				{
					message.Bcc.Add(mailbox);
				}
			}
			if (message.From == null)
			{
				Mailbox senderEmailAddress = new Mailbox();
				if (this.SenderName == null || this.SenderName.Length <= 0)
				{
					senderEmailAddress.Name = this.SenderEmailAddress;
				}
				else
				{
					senderEmailAddress.Name = this.SenderName;
				}
				if (this.InternetAccountName == null || !this.InternetAccountName.Contains("@"))
				{
					senderEmailAddress.EmailAddress = this.SenderEmailAddress;
				}
				else
				{
					senderEmailAddress.EmailAddress = this.InternetAccountName;
				}
				message.From = senderEmailAddress;
			}
			message.Subject = this.Subject;
			message.Date = this.ClientSubmitTime;
			message.ContentType = new ContentType("multipart", "mixed");
			BodyPart bodyPart = new BodyPart()
			{
				ContentType = new ContentType("multipart", "alternative")
			};
			BodyPart bodyPart1 = new BodyPart()
			{
				ContentType = new ContentType("multipart", "related")
			};
			if (this.Body != null && this.Body.Length > 0)
			{
				BodyPart bodyPart2 = new BodyPart()
				{
					ContentType = new ContentType("text", "plain", "utf-8"),
					ContentTransferEncoding = ContentTransferEncoding.QuotedPrintable,
					Body = this.Body
				};
				bodyPart.BodyParts.Add(bodyPart2);
			}
			string bodyHtmlText = this.BodyHtmlText;
			if (bodyHtmlText != null && bodyHtmlText.Length > 0)
			{
				System.Text.Encoding uTF7 = System.Text.Encoding.UTF7;
				string str = "utf-8";
				int num = bodyHtmlText.IndexOf("charset=");
				if (num > 0)
				{
					int num1 = bodyHtmlText.IndexOf("\"", num);
					if (num1 != -1)
					{
						str = bodyHtmlText.Substring(num + 8, num1 - num - 8);
						try
						{
							uTF7 = System.Text.Encoding.GetEncoding(str);
						}
						catch
						{
						}
					}
				}
				BodyPart contentType = new BodyPart();
				byte[] bodyHtml = this.BodyHtml;
				if (this.Encoding != System.Text.Encoding.Unicode || bodyHtml == null)
				{
					contentType.Body = bodyHtmlText;
				}
				else
				{
					if (p.a(bodyHtml, (int)bodyHtml.Length))
					{
						uTF7 = System.Text.Encoding.UTF8;
						str = "utf-8";
					}
					contentType.Body = uTF7.GetString(bodyHtml, 0, (int)bodyHtml.Length);
				}
				contentType.ContentType = new ContentType("text", "html", str);
				contentType.ContentTransferEncoding = ContentTransferEncoding.QuotedPrintable;
				bodyPart.BodyParts.Add(contentType);
			}
			if (bodyPart.BodyParts.Count > 0)
			{
				bodyPart1.BodyParts.Add(bodyPart);
			}
			IList<Independentsoft.Email.Mime.Attachment> attachments = new List<Independentsoft.Email.Mime.Attachment>();
			for (int j = 0; j < this.Attachments.Count; j++)
			{
				if (this.Attachments[j].EmbeddedMessage == null)
				{
					Independentsoft.Email.Mime.Attachment attachment = new Independentsoft.Email.Mime.Attachment(this.Attachments[j].GetBytes());
					if (this.Attachments[j].MimeTag != null)
					{
						attachment.ContentType = new ContentType(this.Attachments[j].MimeTag);
					}
					attachment.ContentID = this.Attachments[j].ContentId;
					attachment.ContentLocation = this.Attachments[j].ContentLocation;
					if (this.Attachments[j].LongFileName != null)
					{
						attachment.Name = this.Attachments[j].LongFileName;
					}
					else if (this.Attachments[j].DisplayName != null)
					{
						attachment.Name = this.Attachments[j].DisplayName;
					}
					else if (this.Attachments[j].FileName != null)
					{
						attachment.Name = this.Attachments[j].FileName;
					}
					if (attachment.ContentID != null || attachment.ContentLocation != null || attachment.ContentDisposition != null && attachment.ContentDisposition.Type == ContentDispositionType.Inline)
					{
						bodyPart1.BodyParts.Add(attachment);
					}
					else
					{
						attachments.Add(attachment);
					}
				}
				else
				{
					ContentType contentType1 = message.ContentType;
					contentType1.Type = "multipart";
					contentType1.SubType = "mixed";
					message.ContentType = contentType1;
					Independentsoft.Email.Mime.Message mimeMessage = this.Attachments[j].EmbeddedMessage.ConvertToMimeMessage();
					BodyPart bodyPart3 = new BodyPart()
					{
						Body = mimeMessage.ToString()
					};
					ContentType contentType2 = new ContentType("message", "rfc822");
					contentType2.Parameters.Add(new Parameter("name", string.Concat("\"", mimeMessage.GetFileName(), "\"")));
					bodyPart3.ContentType = contentType2;
					ContentDisposition contentDisposition = new ContentDisposition(ContentDispositionType.Attachment);
					contentDisposition.Parameters.Add(new Parameter("filename", string.Concat("\"", mimeMessage.GetFileName(), "\"")));
					bodyPart3.ContentDisposition = contentDisposition;
					message.BodyParts.Add(bodyPart3);
				}
			}
			if (bodyPart1.BodyParts.Count > 0)
			{
				message.BodyParts.Add(bodyPart1);
			}
			for (int k = 0; k < attachments.Count; k++)
			{
				message.BodyParts.Add(attachments[k]);
			}
			return message;
		}

		private void a(Independentsoft.Email.Mime.Message A_0)
		{
			if (A_0 != null)
			{
				this.bj = "";
				this.b(A_0);
				for (int i = 0; i < A_0.Headers.Count; i++)
				{
					Independentsoft.Msg.Message message = this;
					message.bj = string.Concat(message.bj, A_0.Headers[i].ToString(), "\r\n");
				}
				for (int j = 0; j < A_0.To.Count; j++)
				{
					Mailbox item = A_0.To[j];
					Recipient recipient = new Recipient()
					{
						AddressType = "SMTP",
						RecipientType = RecipientType.To,
						EmailAddress = item.EmailAddress,
						EntryId = Independentsoft.Msg.Message.a(item.EmailAddress)
					};
					if (item.Name == null || item.Name.Length <= 0)
					{
						recipient.DisplayName = item.EmailAddress;
						Independentsoft.Msg.Message message1 = this;
						message1.DisplayTo = string.Concat(message1.DisplayTo, item.EmailAddress);
					}
					else
					{
						recipient.DisplayName = item.Name;
						Independentsoft.Msg.Message message2 = this;
						message2.DisplayTo = string.Concat(message2.DisplayTo, item.Name);
					}
					if (j < A_0.To.Count - 1)
					{
						Independentsoft.Msg.Message message3 = this;
						message3.DisplayTo = string.Concat(message3.DisplayTo, "; ");
					}
					this.Recipients.Add(recipient);
				}
				for (int k = 0; k < A_0.Cc.Count; k++)
				{
					Mailbox mailbox = A_0.Cc[k];
					Recipient emailAddress = new Recipient()
					{
						AddressType = "SMTP",
						RecipientType = RecipientType.Cc,
						EmailAddress = mailbox.EmailAddress,
						EntryId = Independentsoft.Msg.Message.a(mailbox.EmailAddress)
					};
					if (mailbox.Name == null || mailbox.Name.Length <= 0)
					{
						emailAddress.DisplayName = mailbox.EmailAddress;
						Independentsoft.Msg.Message message4 = this;
						message4.DisplayCc = string.Concat(message4.DisplayCc, mailbox.EmailAddress);
					}
					else
					{
						emailAddress.DisplayName = mailbox.Name;
						Independentsoft.Msg.Message message5 = this;
						message5.DisplayCc = string.Concat(message5.DisplayCc, mailbox.Name);
					}
					if (k < A_0.Cc.Count - 1)
					{
						Independentsoft.Msg.Message message6 = this;
						message6.DisplayCc = string.Concat(message6.DisplayCc, "; ");
					}
					this.Recipients.Add(emailAddress);
				}
				for (int l = 0; l < A_0.Bcc.Count; l++)
				{
					Mailbox item1 = A_0.Bcc[l];
					Recipient name = new Recipient()
					{
						AddressType = "SMTP",
						RecipientType = RecipientType.Bcc,
						EmailAddress = item1.EmailAddress,
						EntryId = Independentsoft.Msg.Message.a(item1.EmailAddress)
					};
					if (item1.Name == null || item1.Name.Length <= 0)
					{
						name.DisplayName = item1.EmailAddress;
						Independentsoft.Msg.Message message7 = this;
						message7.DisplayBcc = string.Concat(message7.DisplayBcc, item1.EmailAddress);
					}
					else
					{
						name.DisplayName = item1.Name;
						Independentsoft.Msg.Message message8 = this;
						message8.DisplayBcc = string.Concat(message8.DisplayBcc, item1.Name);
					}
					if (l < A_0.Bcc.Count - 1)
					{
						Independentsoft.Msg.Message message9 = this;
						message9.DisplayBcc = string.Concat(message9.DisplayBcc, "; ");
					}
					this.Recipients.Add(name);
				}
				this.CreationTime = A_0.Date;
				this.MessageDeliveryTime = A_0.Date;
				this.ClientSubmitTime = A_0.Date;
				this.InternetMessageId = A_0.MessageID;
				if (A_0.Headers["Priority"] != null && A_0.Headers["Priority"].Value != null && A_0.Headers["Priority"].Value.ToLower() == "urgent")
				{
					this.Priority = Independentsoft.Msg.Priority.High;
					this.Importance = Independentsoft.Msg.Importance.High;
				}
				else if (A_0.Headers["Priority"] != null && A_0.Headers["Priority"].Value != null && A_0.Headers["Priority"].Value.ToLower() == "non-urgent")
				{
					this.Priority = Independentsoft.Msg.Priority.Low;
					this.Importance = Independentsoft.Msg.Importance.Low;
				}
				else if (A_0.Headers["X-Priority"] != null && A_0.Headers["X-Priority"].Value != null && A_0.Headers["X-Priority"].Value == "1")
				{
					this.Priority = Independentsoft.Msg.Priority.High;
					this.Importance = Independentsoft.Msg.Importance.High;
				}
				else if (A_0.Headers["X-Priority"] != null && A_0.Headers["X-Priority"].Value != null && A_0.Headers["X-Priority"].Value == "-1")
				{
					this.Priority = Independentsoft.Msg.Priority.Low;
					this.Importance = Independentsoft.Msg.Importance.Low;
				}
				else if (A_0.Headers["Importance"] != null && A_0.Headers["Importance"].Value != null && A_0.Headers["Importance"].Value.ToLower() == "high")
				{
					this.Priority = Independentsoft.Msg.Priority.High;
					this.Importance = Independentsoft.Msg.Importance.High;
				}
				else if (A_0.Headers["Importance"] != null && A_0.Headers["Importance"].Value != null && A_0.Headers["Importance"].Value.ToLower() == "low")
				{
					this.Priority = Independentsoft.Msg.Priority.Low;
					this.Importance = Independentsoft.Msg.Importance.Low;
				}
				if (A_0.Sender != null)
				{
					if (A_0.Sender.Name == null || A_0.Sender.Name.Length <= 0)
					{
						this.SenderName = A_0.Sender.EmailAddress;
					}
					else
					{
						this.SenderName = A_0.Sender.Name;
					}
					this.SenderEmailAddress = A_0.Sender.EmailAddress;
					this.SenderAddressType = "SMTP";
					if (A_0.Sender.EmailAddress != null)
					{
						this.SenderEntryId = Independentsoft.Msg.Message.a(A_0.Sender.EmailAddress);
					}
				}
				else if (A_0.From != null)
				{
					if (A_0.From.Name == null || A_0.From.Name.Length <= 0)
					{
						this.SenderName = A_0.From.EmailAddress;
					}
					else
					{
						this.SenderName = A_0.From.Name;
					}
					this.SenderEmailAddress = A_0.From.EmailAddress;
					this.SenderAddressType = "SMTP";
					if (A_0.From.EmailAddress != null)
					{
						this.SenderEntryId = Independentsoft.Msg.Message.a(A_0.From.EmailAddress);
					}
				}
				if (A_0.From != null)
				{
					this.bf = A_0.From.EmailAddress;
					this.bh = A_0.From.Name;
					this.be = "SMTP";
				}
				this.Subject = A_0.Subject;
				BodyPartList bodyPartList = new BodyPartList();
				if (A_0.ContentType == null)
				{
					this.Body = A_0.Body;
				}
				else if (A_0.ContentType != null && A_0.ContentType.Type != null && A_0.ContentType.Type.ToLower() == "text" && A_0.ContentType.SubType != null && A_0.ContentType.SubType.ToLower() == "plain")
				{
					this.Body = A_0.Body;
				}
				else if (A_0.ContentType == null || A_0.ContentType.Type == null || !(A_0.ContentType.Type.ToLower() == "text") || A_0.ContentType.SubType == null || !(A_0.ContentType.SubType.ToLower() == "html"))
				{
					foreach (BodyPart bodyPart in Independentsoft.Msg.Message.a(A_0.BodyParts))
					{
						bodyPartList.Add(bodyPart);
					}
					foreach (BodyPart bodyPart1 in bodyPartList)
					{
						if (bodyPart1.ContentType == null || bodyPart1.ContentType.Type == null || !(bodyPart1.ContentType.Type.ToLower() == "text") || bodyPart1.ContentType.SubType == null || !(bodyPart1.ContentType.SubType.ToLower() == "plain") || bodyPart1.ContentDisposition != null && bodyPart1.ContentDisposition.Type == ContentDispositionType.Attachment)
						{
							if (bodyPart1.ContentType == null || bodyPart1.ContentType.Type == null || !(bodyPart1.ContentType.Type.ToLower() == "text") || bodyPart1.ContentType.SubType == null || !(bodyPart1.ContentType.SubType.ToLower() == "html") || bodyPart1.ContentDisposition != null && bodyPart1.ContentDisposition.Type == ContentDispositionType.Attachment)
							{
								continue;
							}
							if (bodyPart1.ContentType.CharSet == null)
							{
								this.InternetCodePage = (long)65001;
								this.BodyHtmlText = bodyPart1.Body;
							}
							else
							{
								System.Text.Encoding encoding = o.m(bodyPart1.ContentType.CharSet);
								this.InternetCodePage = (long)encoding.CodePage;
								if (bodyPart1.Body == null)
								{
									continue;
								}
								this.BodyHtml = o.m(bodyPart1.ContentType.CharSet).GetBytes(bodyPart1.Body);
							}
						}
						else if (bodyPart1.ContentType.CharSet == null)
						{
							this.InternetCodePage = (long)65001;
							this.Body = bodyPart1.Body;
						}
						else
						{
							System.Text.Encoding encoding1 = o.m(bodyPart1.ContentType.CharSet);
							this.InternetCodePage = (long)encoding1.CodePage;
							this.Body = bodyPart1.Body;
						}
					}
				}
				else if (A_0.ContentType.CharSet == null)
				{
					this.InternetCodePage = (long)65001;
					this.BodyHtmlText = A_0.Body;
				}
				else
				{
					System.Text.Encoding encoding2 = o.m(A_0.ContentType.CharSet);
					this.InternetCodePage = (long)encoding2.CodePage;
					if (A_0.Body != null)
					{
						this.BodyHtml = o.m(A_0.ContentType.CharSet).GetBytes(A_0.Body);
					}
				}
				Independentsoft.Email.Mime.Attachment[] attachments = A_0.GetAttachments(true);
				for (int m = 0; m < (int)attachments.Length; m++)
				{
					Independentsoft.Msg.Attachment attachment = new Independentsoft.Msg.Attachment(attachments[m].Name, attachments[m].GetBytes())
					{
						ContentId = attachments[m].ContentID,
						ContentLocation = attachments[m].ContentLocation
					};
					if (attachment.FileName == null && attachment.DisplayName == null && attachments[m].ContentDescription != null)
					{
						attachment.FileName = attachments[m].ContentDescription;
						attachment.DisplayName = attachments[m].ContentDescription;
					}
					this.Attachments.Add(attachment);
				}
				this.Encoding = System.Text.Encoding.Unicode;
			}
		}

		private static BodyPartList a(BodyPartList A_0)
		{
			BodyPartList bodyPartList = new BodyPartList();
			for (int i = 0; i < A_0.Count; i++)
			{
				foreach (BodyPart bodyPart in Independentsoft.Msg.Message.a(A_0[i].BodyParts))
				{
					bodyPartList.Add(bodyPart);
				}
				bodyPartList.Add(A_0[i]);
			}
			return bodyPartList;
		}

		private static byte[] a(string A_0)
		{
			byte[] numArray = new byte[] { 0, 0, 0, 0, 129, 43, 31, 164, 190, 163, 16, 25, 157, 110, 0, 221, 1, 15, 84, 2, 0, 0, 1, 128 };
			string str = string.Concat(A_0, "\0SMTP\0", A_0, "\0");
			byte[] bytes = System.Text.Encoding.Unicode.GetBytes(str);
			byte[] numArray1 = new byte[(int)numArray.Length + (int)bytes.Length];
			Array.Copy(numArray, 0, numArray1, 0, (int)numArray.Length);
			Array.Copy(bytes, 0, numArray1, (int)numArray.Length, (int)bytes.Length);
			return numArray1;
		}

		private byte[] b()
		{
			d.a();
			CompoundFile compoundFile = new CompoundFile()
			{
				MajorVersion = 4
			};
			compoundFile.Root.ClassId = new byte[] { 11, 13, 2, 0, 0, 0, 0, 0, 192, 0, 0, 0, 0, 0, 0, 70 };
			MemoryStream memoryStream = new MemoryStream();
			MemoryStream memoryStream1 = new MemoryStream();
			MemoryStream memoryStream2 = new MemoryStream();
			IList<byte[]> numArrays = new List<byte[]>()
			{
				new byte[16],
				StandardPropertySet.Mapi,
				StandardPropertySet.PublicStrings
			};
			IList<string> strs = new List<string>();
			IDictionary<string, MemoryStream> strs1 = new Dictionary<string, MemoryStream>();
			this.fr = new List<c>();
			DirectoryEntryList directoryEntryList = this.a(ref this.fr);
			int length = 0;
			for (int i = 0; i < this.fr.Count; i++)
			{
				int count = Independentsoft.Msg.Message.a(this.fr[i].b(), numArrays);
				if (count == -1 && this.fr[i].b() != null)
				{
					numArrays.Add(this.fr[i].b());
					count = numArrays.Count - 1;
				}
				uint num = 0;
				ushort num1 = 0;
				if (this.fr[i].d() == null)
				{
					num = this.fr[i].a();
				}
				else
				{
					strs.Add(this.fr[i].d());
					num1 = 1;
					num = (uint)length;
				}
				uint num2 = (uint)((ushort)i << 16);
				ushort num3 = (ushort)(count << 1);
				if (num1 == 1)
				{
					num3 = (ushort)(num3 + 1);
				}
				num2 = num2 + num3;
				byte[] numArray = new byte[8];
				byte[] bytes = BitConverter.GetBytes(num);
				byte[] bytes1 = BitConverter.GetBytes(num2);
				Array.Copy(bytes, 0, numArray, 0, 4);
				Array.Copy(bytes1, 0, numArray, 4, 4);
				memoryStream1.Write(numArray, 0, 8);
				if (num1 != 0)
				{
					j _j = new j();
					_j.a(this.fw.GetBytes(this.fr[i].d()));
					uint num4 = _j.a();
					uint num5 = (uint)((long)4096 + ((ulong)num4 ^ (long)(count << 1 | 1)) % (long)31);
					num5 = num5 << 16 | 258;
					string str = string.Format("{0:X8}", num5);
					str = string.Concat("__substg1.0_", str);
					if (!strs1.ContainsKey(str))
					{
						MemoryStream memoryStream3 = new MemoryStream();
						memoryStream3.Write(numArray, 0, (int)numArray.Length);
						strs1.Add(str, memoryStream3);
					}
					else
					{
						MemoryStream item = strs1[str];
						item.Write(numArray, 0, (int)numArray.Length);
					}
				}
				else
				{
					uint num6 = (uint)((long)4096 + ((ulong)this.fr[i].a() ^ (long)(count << 1)) % (long)31);
					num6 = num6 << 16 | 258;
					string str1 = string.Format("{0:X8}", num6);
					str1 = string.Concat("__substg1.0_", str1);
					if (!strs1.ContainsKey(str1))
					{
						MemoryStream memoryStream4 = new MemoryStream();
						memoryStream4.Write(numArray, 0, (int)numArray.Length);
						strs1.Add(str1, memoryStream4);
					}
					else
					{
						MemoryStream item1 = strs1[str1];
						item1.Write(numArray, 0, (int)numArray.Length);
					}
				}
				if (this.fr[i].d() != null)
				{
					byte[] numArray1 = System.Text.Encoding.Unicode.GetBytes(this.fr[i].d());
					int length1 = (int)numArray1.Length % 4;
					length = length + (int)numArray1.Length + length1 + 4;
				}
			}
			Storage storage = new Storage("__nameid_version1.0");
			Independentsoft.IO.StructuredStorage.Stream stream = new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_00030102", memoryStream1.ToArray());
			for (int j = 3; j < numArrays.Count; j++)
			{
				byte[] item2 = numArrays[j];
				memoryStream.Write(item2, 0, (int)item2.Length);
			}
			Independentsoft.IO.StructuredStorage.Stream stream1 = new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_00020102", memoryStream.ToArray());
			for (int k = 0; k < strs.Count; k++)
			{
				byte[] bytes2 = System.Text.Encoding.Unicode.GetBytes(strs[k]);
				byte[] numArray2 = BitConverter.GetBytes((int)bytes2.Length);
				memoryStream2.Write(numArray2, 0, 4);
				memoryStream2.Write(bytes2, 0, (int)bytes2.Length);
				int length2 = (int)bytes2.Length % 4;
				if (length2 > 0)
				{
					byte[] numArray3 = new byte[length2];
					memoryStream2.Write(numArray3, 0, (int)numArray3.Length);
				}
			}
			Independentsoft.IO.StructuredStorage.Stream stream2 = new Independentsoft.IO.StructuredStorage.Stream("__substg1.0_00040102", memoryStream2.ToArray());
			storage.DirectoryEntries.Add(stream1);
			storage.DirectoryEntries.Add(stream);
			storage.DirectoryEntries.Add(stream2);
			foreach (string key in strs1.Keys)
			{
				MemoryStream item3 = strs1[key];
				Independentsoft.IO.StructuredStorage.Stream stream3 = new Independentsoft.IO.StructuredStorage.Stream(key, item3.ToArray());
				storage.DirectoryEntries.Add(stream3);
			}
			for (int l = 0; l < directoryEntryList.Count; l++)
			{
				compoundFile.Root.DirectoryEntries.Add(directoryEntryList[l]);
			}
			compoundFile.Root.DirectoryEntries.Add(storage);
			return compoundFile.GetBytes();
		}

		private void b(Independentsoft.Email.Mime.Message A_0)
		{
			string str = "";
			string str1 = "";
			string str2 = "";
			string str3 = "";
			for (int i = 0; i < A_0.To.Count; i++)
			{
				if (A_0.To[i] != null)
				{
					str = string.Concat(str, A_0.To[i].ToString());
				}
				if (i < A_0.To.Count - 1)
				{
					str = string.Concat(str, ", ");
				}
			}
			for (int j = 0; j < A_0.Cc.Count; j++)
			{
				if (A_0.Cc[j] != null)
				{
					str1 = string.Concat(str1, A_0.Cc[j].ToString());
				}
				if (j < A_0.Cc.Count - 1)
				{
					str1 = string.Concat(str1, ", ");
				}
			}
			for (int k = 0; k < A_0.Bcc.Count; k++)
			{
				if (A_0.Bcc[k] != null)
				{
					str2 = string.Concat(str2, A_0.Bcc[k].ToString());
				}
				if (k < A_0.Bcc.Count - 1)
				{
					str2 = string.Concat(str2, ", ");
				}
			}
			for (int l = 0; l < A_0.ReplyTo.Count; l++)
			{
				if (A_0.ReplyTo[l] != null)
				{
					str3 = string.Concat(str3, A_0.ReplyTo[l].ToString());
				}
				if (l < A_0.ReplyTo.Count - 1)
				{
					str3 = string.Concat(str3, ", ");
				}
			}
			if (str.Length > 0)
			{
				Header header = new Header(StandardHeader.To, str);
				A_0.Headers.Remove(StandardHeader.To);
				A_0.Headers.Add(header);
			}
			if (str1.Length > 0)
			{
				Header header1 = new Header(StandardHeader.Cc, str1);
				A_0.Headers.Remove(StandardHeader.Cc);
				A_0.Headers.Add(header1);
			}
			if (str2.Length > 0)
			{
				Header header2 = new Header(StandardHeader.Bcc, str2);
				A_0.Headers.Remove(StandardHeader.Bcc);
				A_0.Headers.Add(header2);
			}
			if (str3.Length > 0)
			{
				Header header3 = new Header(StandardHeader.ReplyTo, str3);
				A_0.Headers.Remove(StandardHeader.ReplyTo);
				A_0.Headers.Add(header3);
			}
		}

		/// <summary>
		/// Converts to MIME message.
		/// </summary>
		/// <returns>Independentsoft.Email.Mime.Message.</returns>
		public Independentsoft.Email.Mime.Message ConvertToMimeMessage()
		{
			return this.a();
		}

		/// <summary>
		/// Gets bytes to read from this message.
		/// </summary>
		/// <returns>Attachment as a byte array.</returns>
		public byte[] GetBytes()
		{
			return this.b();
		}

		/// <summary>
		/// Gets stream to read from this message.
		/// </summary>
		/// <returns>A stream.</returns>
		public System.IO.Stream GetStream()
		{
			return new MemoryStream(this.b());
		}

		/// <summary>
		/// Loads message from the specified file.
		/// </summary>
		/// <param name="filePath">File path.</param>
		public void Open(string filePath)
		{
			FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
			using (fileStream)
			{
				this.Open(fileStream);
			}
		}

		/// <summary>
		/// Loads message from the specified stream.
		/// </summary>
		/// <param name="stream">An input stream.</param>
		public void Open(System.IO.Stream stream)
		{
			this.a(stream);
		}

		/// <summary>
		/// Saves this message to the specified file.
		/// </summary>
		/// <param name="filePath">File path.</param>
		public void Save(string filePath)
		{
			this.Save(filePath, false);
		}

		/// <summary>
		/// Saves this message to the specified file.
		/// </summary>
		/// <param name="filePath">File path.</param>
		/// <param name="overwrite">True to overwrite existing file, otherwise false.</param>
		public void Save(string filePath, bool overwrite)
		{
			FileMode fileMode = FileMode.CreateNew;
			if (overwrite)
			{
				fileMode = FileMode.Create;
			}
			using (FileStream fileStream = new FileStream(filePath, fileMode, FileAccess.Write))
			{
				this.Save(fileStream);
			}
		}

		/// <summary>
		/// Saves this message to the specified stream.
		/// </summary>
		/// <param name="stream">A stream.</param>
		/// <exception cref="T:System.ArgumentNullException">stream</exception>
		public void Save(System.IO.Stream stream)
		{
			if (stream == null)
			{
				throw new ArgumentNullException("stream");
			}
			byte[] numArray = this.b();
			stream.Write(numArray, 0, (int)numArray.Length);
		}
	}
}