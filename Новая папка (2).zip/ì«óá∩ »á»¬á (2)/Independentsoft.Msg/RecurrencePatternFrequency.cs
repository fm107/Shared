using System;

namespace Independentsoft.Msg
{
	public enum RecurrencePatternFrequency
	{
		Daily,
		Weekly,
		Monthly,
		Yearly
	}
}