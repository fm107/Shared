using System;
using System.Collections.Generic;
using System.Reflection;

namespace Independentsoft.Msg
{
	/// <summary>
	/// Class ExtendedPropertyList.
	/// </summary>
	public class ExtendedPropertyList : List<ExtendedProperty>
	{
		/// <summary>
		/// Gets the <see cref="T:Independentsoft.Msg.ExtendedProperty" /> with the specified tag.
		/// </summary>
		/// <param name="tag">The tag.</param>
		/// <returns>ExtendedProperty.</returns>
		public ExtendedProperty this[ExtendedPropertyTag tag]
		{
			get
			{
				if (tag != null)
				{
					if (!(tag is ExtendedPropertyId))
					{
						ExtendedPropertyName extendedPropertyName = (ExtendedPropertyName)tag;
						for (int i = 0; i < base.Count; i++)
						{
							ExtendedProperty item = base[i];
							if (item.Tag is ExtendedPropertyName)
							{
								ExtendedPropertyName extendedPropertyName1 = (ExtendedPropertyName)item.Tag;
								if (extendedPropertyName1.Name == extendedPropertyName.Name)
								{
									bool flag = true;
									if (extendedPropertyName1.Guid != null && extendedPropertyName.Guid != null && (int)extendedPropertyName1.Guid.Length == (int)extendedPropertyName.Guid.Length)
									{
										int num = 0;
										while (num < (int)extendedPropertyName1.Guid.Length)
										{
											if (extendedPropertyName1.Guid[num] == extendedPropertyName.Guid[num])
											{
												num++;
											}
											else
											{
												flag = false;
												break;
											}
										}
									}
									if (flag)
									{
										return item;
									}
								}
							}
						}
					}
					else
					{
						ExtendedPropertyId extendedPropertyId = (ExtendedPropertyId)tag;
						for (int j = 0; j < base.Count; j++)
						{
							ExtendedProperty extendedProperty = base[j];
							if (extendedProperty.Tag is ExtendedPropertyId)
							{
								ExtendedPropertyId extendedPropertyId1 = (ExtendedPropertyId)extendedProperty.Tag;
								if (extendedPropertyId1.Id == extendedPropertyId.Id)
								{
									bool flag1 = true;
									if (extendedPropertyId1.Guid != null && extendedPropertyId.Guid != null && (int)extendedPropertyId1.Guid.Length == (int)extendedPropertyId.Guid.Length)
									{
										int num1 = 0;
										while (num1 < (int)extendedPropertyId1.Guid.Length)
										{
											if (extendedPropertyId1.Guid[num1] == extendedPropertyId.Guid[num1])
											{
												num1++;
											}
											else
											{
												flag1 = false;
												break;
											}
										}
									}
									if (flag1)
									{
										return extendedProperty;
									}
								}
							}
						}
					}
				}
				return null;
			}
		}

		public ExtendedPropertyList()
		{
		}
	}
}