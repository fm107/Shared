using System;

namespace Independentsoft.Msg
{
	/// <summary>
	/// Represents a user or resource, generally a mail message addressee.
	/// </summary>
	public class Recipient
	{
		private string a;

		private string b;

		private string c;

		private Independentsoft.Msg.ObjectType d = Independentsoft.Msg.ObjectType.None;

		private Independentsoft.Msg.RecipientType e = Independentsoft.Msg.RecipientType.None;

		private Independentsoft.Msg.DisplayType f = Independentsoft.Msg.DisplayType.None;

		private byte[] g;

		private byte[] h;

		private byte[] i;

		private bool j;

		private string k;

		private string l;

		private string m;

		private bool n;

		private int o;

		private string p;

		private string q;

		/// <summary>
		/// Contains the recipient's e-mail address type, such as Simple Mail Transfer Protocol (SMTP).
		/// </summary>
		public string AddressType
		{
			get
			{
				return this.c;
			}
			set
			{
				this.c = value;
			}
		}

		/// <summary>
		/// Contains the display name of the recipient.
		/// </summary>
		public string DisplayName
		{
			get
			{
				return this.a;
			}
			set
			{
				this.a = value;
			}
		}

		/// <summary>
		/// Contains a 7-bit ASCII representation of the recipient's display name.
		/// </summary>
		public string DisplayName7Bit
		{
			get
			{
				return this.l;
			}
			set
			{
				this.l = value;
			}
		}

		/// <summary>
		/// Contains a value used to associate an icon with a particular row of a table.
		/// </summary>
		public Independentsoft.Msg.DisplayType DisplayType
		{
			get
			{
				return this.f;
			}
			set
			{
				this.f = value;
			}
		}

		/// <summary>
		/// Contains the recipient's e-mail address.
		/// </summary>
		public string EmailAddress
		{
			get
			{
				return this.b;
			}
			set
			{
				this.b = value;
			}
		}

		/// <summary>
		/// Contains the EntryID of the recipient.
		/// </summary>
		public byte[] EntryId
		{
			get
			{
				return this.g;
			}
			set
			{
				this.g = value;
			}
		}

		/// <summary>
		/// Contains a value that uniquely identifies a row in a table.
		/// </summary>
		public byte[] InstanceKey
		{
			get
			{
				return this.h;
			}
			set
			{
				this.h = value;
			}
		}

		/// <summary>
		/// Contains the type of the recipient.
		/// </summary>
		public Independentsoft.Msg.ObjectType ObjectType
		{
			get
			{
				return this.d;
			}
			set
			{
				this.d = value;
			}
		}

		/// <summary>
		/// </summary>
		public string OriginatingAddressType
		{
			get
			{
				return this.p;
			}
			set
			{
				this.p = value;
			}
		}

		/// <summary>
		/// </summary>
		public string OriginatingEmailAddress
		{
			get
			{
				return this.q;
			}
			set
			{
				this.q = value;
			}
		}

		/// <summary>
		/// Contains the recipient type for a message recipient.
		/// </summary>
		public Independentsoft.Msg.RecipientType RecipientType
		{
			get
			{
				return this.e;
			}
			set
			{
				this.e = value;
			}
		}

		/// <summary>
		/// Contains true if some transport provider has already accepted responsibility for delivering the message to this recipient, and false if the MAPI spooler considers that this transport provider should accept responsibility.
		/// </summary>
		public bool Responsibility
		{
			get
			{
				return this.j;
			}
			set
			{
				this.j = value;
			}
		}

		/// <summary>
		/// Contains a binary-comparable key that identifies correlated objects for a search.
		/// </summary>
		public byte[] SearchKey
		{
			get
			{
				return this.i;
			}
			set
			{
				this.i = value;
			}
		}

		/// <summary>
		/// Contains a bitmask of encoding preferences.
		/// </summary>
		public int SendInternetEncoding
		{
			get
			{
				return this.o;
			}
			set
			{
				this.o = value;
			}
		}

		/// <summary>
		/// Contains true if the recipient can receive all message content, including Rich Text Format (RTF) and Object Linking and Embedding (OLE) objects.
		/// </summary>
		public bool SendRichInfo
		{
			get
			{
				return this.n;
			}
			set
			{
				this.n = value;
			}
		}

		/// <summary>
		/// Contains SMTP email address.
		/// </summary>
		public string SmtpAddress
		{
			get
			{
				return this.k;
			}
			set
			{
				this.k = value;
			}
		}

		/// <summary>
		/// Contains a recipient's display name in a secure form that cannot be changed.
		/// </summary>
		public string TransmitableDisplayName
		{
			get
			{
				return this.m;
			}
			set
			{
				this.m = value;
			}
		}

		/// <summary>
		/// Initializes a new instance of the Recipient class. 
		/// </summary>
		public Recipient()
		{
		}
	}
}