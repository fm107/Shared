using System;
using System.Text;

internal class a
{
	private string a;

	private Encoding b = Encoding.UTF8;

	internal a(string A_0, Encoding A_1)
	{
		this.a = A_0;
		this.b = A_1;
	}

	internal string a()
	{
		return this.a;
	}
}