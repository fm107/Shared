using System;
using System.IO;
using System.Text;

namespace Independentsoft.IO.StructuredStorage
{
	/// <summary>
	/// Represents a directory entry. 
	/// </summary>
	public abstract class DirectoryEntry : IComparable
	{
		internal string a;

		internal i b;

		internal f c = f.b;

		internal uint d;

		internal uint e;

		internal uint f;

		internal byte[] g = new byte[16];

		internal uint h;

		internal DateTime i;

		internal DateTime j;

		internal uint k;

		internal uint l;

		internal byte[] m;

		internal DirectoryEntryList n = new DirectoryEntryList();

		internal DirectoryEntry o;

		/// <summary>
		/// Gets or sets class ID.
		/// </summary>
		public byte[] ClassId
		{
			get
			{
				return this.g;
			}
			set
			{
				this.g = value;
			}
		}

		/// <summary>
		/// Gets creation time.
		/// </summary>
		public DateTime CreatedTime
		{
			get
			{
				return this.i;
			}
		}

		/// <summary>
		/// Gets last modified time.
		/// </summary>
		public DateTime LastModifiedTime
		{
			get
			{
				return this.j;
			}
		}

		/// <summary>
		/// Gets or sets name.
		/// </summary>
		public string Name
		{
			get
			{
				return this.a;
			}
			set
			{
				if (value == null)
				{
					throw new ArgumentNullException("Name", "Name is null.");
				}
				if (value.Length > 31)
				{
					throw new ArgumentException("Name", "Name must be less than 32 characters.");
				}
				this.a = value;
			}
		}

		/// <summary>
		/// Gets size.
		/// </summary>
		public long Size
		{
			get
			{
				return (long)this.l;
			}
		}

		protected DirectoryEntry()
		{
		}

		internal static DirectoryEntry a(BinaryReader A_0)
		{
			byte[] numArray = A_0.ReadBytes(64);
			ushort num = A_0.ReadUInt16();
			string str = null;
			if (num > 1)
			{
				str = Encoding.Unicode.GetString(numArray, 0, num - 2);
			}
			i _i = l.a(A_0.ReadByte());
			f _f = l.b(A_0.ReadByte());
			uint num1 = A_0.ReadUInt32();
			uint num2 = A_0.ReadUInt32();
			uint num3 = A_0.ReadUInt32();
			byte[] numArray1 = A_0.ReadBytes(16);
			uint num4 = A_0.ReadUInt32();
			uint num5 = A_0.ReadUInt32();
			long num6 = (long)A_0.ReadUInt32();
			DateTime localTime = new DateTime();
			if (num6 > (long)0)
			{
				long num7 = (long)((ulong)num5 + (num6 << 32));
				DateTime dateTime = new DateTime(1601, 1, 1);
				try
				{
					localTime = dateTime.AddTicks(num7).ToLocalTime();
				}
				catch (Exception exception)
				{
				}
			}
			uint num8 = A_0.ReadUInt32();
			long num9 = (long)A_0.ReadUInt32();
			DateTime localTime1 = new DateTime();
			if (num9 > (long)0)
			{
				long num10 = (long)((ulong)num8 + (num9 << 32));
				DateTime dateTime1 = new DateTime(1601, 1, 1);
				try
				{
					localTime1 = dateTime1.AddTicks(num10).ToLocalTime();
				}
				catch (Exception exception1)
				{
				}
			}
			uint num11 = A_0.ReadUInt32();
			uint num12 = A_0.ReadUInt32();
			if (_i == i.f)
			{
				RootDirectoryEntry rootDirectoryEntry = new RootDirectoryEntry()
				{
					b = i.f,
					a = str,
					c = _f,
					d = num1,
					e = num2,
					f = num3,
					g = numArray1,
					h = num4,
					i = localTime,
					j = localTime1,
					k = num11,
					l = num12
				};
				return rootDirectoryEntry;
			}
			if (_i == i.c)
			{
				Independentsoft.IO.StructuredStorage.Stream stream = new Independentsoft.IO.StructuredStorage.Stream()
				{
					b = i.c,
					a = str,
					c = _f,
					d = num1,
					e = num2,
					f = num3,
					g = numArray1,
					h = num4,
					i = localTime,
					j = localTime1,
					k = num11,
					l = num12
				};
				return stream;
			}
			if (_i == i.b)
			{
				Storage storage = new Storage()
				{
					b = i.b,
					a = str,
					c = _f,
					d = num1,
					e = num2,
					f = num3,
					g = numArray1,
					h = num4,
					i = localTime,
					j = localTime1,
					k = num11,
					l = num12
				};
				return storage;
			}
			Storage storage1 = new Storage()
			{
				b = i.a,
				a = str,
				c = _f,
				d = num1,
				e = num2,
				f = num3,
				g = numArray1,
				h = num4,
				i = localTime,
				j = localTime1,
				k = num11,
				l = num12
			};
			return storage1;
		}

		internal byte[] a()
		{
			byte[] numArray = new byte[128];
			MemoryStream memoryStream = new MemoryStream(numArray);
			using (memoryStream)
			{
				BinaryWriter binaryWriter = new BinaryWriter(memoryStream, Encoding.Unicode);
				byte[] numArray1 = new byte[64];
				byte[] bytes = Encoding.Unicode.GetBytes(this.a);
				for (int i = 0; i < (int)bytes.Length; i++)
				{
					numArray1[i] = bytes[i];
				}
				binaryWriter.Write(numArray1);
				binaryWriter.Write((ushort)((this.a.Length + 1) * 2));
				binaryWriter.Write(l.a(this.b));
				binaryWriter.Write(l.a(this.c));
				binaryWriter.Write(this.d);
				binaryWriter.Write(this.e);
				binaryWriter.Write(this.f);
				binaryWriter.Write(this.g);
				binaryWriter.Write(this.h);
				if (this.i.CompareTo(DateTime.MinValue) <= 0)
				{
					binaryWriter.Write((uint)0);
					binaryWriter.Write((uint)0);
				}
				else
				{
					DateTime dateTime = new DateTime(1601, 1, 1);
					TimeSpan timeSpan = this.i.ToUniversalTime().Subtract(dateTime);
					byte[] bytes1 = BitConverter.GetBytes(timeSpan.Ticks);
					uint num = BitConverter.ToUInt32(bytes1, 0);
					uint num1 = BitConverter.ToUInt32(bytes1, 4);
					binaryWriter.Write(num);
					binaryWriter.Write(num1);
				}
				if (this.j.CompareTo(DateTime.MinValue) <= 0)
				{
					binaryWriter.Write((uint)0);
					binaryWriter.Write((uint)0);
				}
				else
				{
					DateTime dateTime1 = new DateTime(1601, 1, 1);
					TimeSpan timeSpan1 = this.j.ToUniversalTime().Subtract(dateTime1);
					byte[] bytes2 = BitConverter.GetBytes(timeSpan1.Ticks);
					uint num2 = BitConverter.ToUInt32(bytes2, 0);
					uint num3 = BitConverter.ToUInt32(bytes2, 4);
					binaryWriter.Write(num2);
					binaryWriter.Write(num3);
				}
				binaryWriter.Write(this.k);
				binaryWriter.Write(this.l);
			}
			return numArray;
		}

		/// <summary>
		/// Compares this instance with the specified <see cref="T:Independentsoft.IO.StructuredStorage.DirectoryEntry" /> object and indicates whether this instance precedes, follows, or appears in the same position in the sort order as the specified DirectoryEntry.
		/// </summary>
		/// <param name="obj">A DirectoryEntry</param>
		/// <returns>A 32-bit signed integer that indicates whether this instance precedes, follows, or appears in the same position in the sort order as the value parameter.</returns>
		public int CompareTo(object obj)
		{
			if (!(obj is DirectoryEntry))
			{
				throw new ArgumentException("object is not a DirectoryEntry");
			}
			DirectoryEntry directoryEntry = (DirectoryEntry)obj;
			if (directoryEntry.Name.Length < this.a.Length)
			{
				return 1;
			}
			if (directoryEntry.Name.Length != this.a.Length)
			{
				return -1;
			}
			for (int i = 0; i < this.a.Length; i++)
			{
				int name = directoryEntry.Name[i];
				int num = this.a[i];
				if (name < num)
				{
					return 1;
				}
				if (name > num)
				{
					return -1;
				}
			}
			return 1;
		}
	}
}