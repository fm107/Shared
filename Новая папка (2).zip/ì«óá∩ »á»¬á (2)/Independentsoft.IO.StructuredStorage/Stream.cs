using System;
using System.IO;

namespace Independentsoft.IO.StructuredStorage
{
	/// <summary>
	/// Represents a virtual stream to store data.
	/// </summary>
	/// <remarks>
	/// Stream is analogous to a file system file. The parent object of a stream object must be a <see cref="T:Independentsoft.IO.StructuredStorage.Storage" /> object or the <see cref="T:Independentsoft.IO.StructuredStorage.RootDirectoryEntry" />.
	/// </remarks>
	public class Stream : DirectoryEntry
	{
		/// <summary>
		/// Gets or sets streams data.
		/// </summary>
		public byte[] Buffer
		{
			get
			{
				return this.m;
			}
			set
			{
				this.m = value;
			}
		}

		/// <summary>
		/// Initializes a new instance of the Stream class.  
		/// </summary>
		public Stream()
		{
			this.b = i.c;
		}

		/// <summary>
		/// Initializes a new instance of the Stream class and load data from the specified file.
		/// </summary>
		/// <param name="filePath">File path.</param>
		public Stream(string filePath) : this()
		{
			this.Load(filePath);
		}

		/// <summary>
		/// Initializes a new instance of the Stream class and load data from the specified <see cref="T:System.IO.Stream" />.
		/// </summary>
		/// <param name="name">Stream name.</param>
		/// <param name="stream">A stream.</param>
		public Stream(string name, System.IO.Stream stream) : this()
		{
			this.Load(name, stream);
		}

		/// <summary>
		/// Initializes a new instance of the Stream class and load data from the specified buffer.
		/// </summary>
		/// <param name="name">Stream name.</param>
		/// <param name="buffer">Data buffer.</param>
		public Stream(string name, byte[] buffer) : this()
		{
			this.a = name;
			this.m = buffer;
		}

		/// <summary>
		/// Gets <see cref="T:System.IO.Stream" /> to read data from this stream. 
		/// </summary>
		/// <returns></returns>
		public System.IO.Stream GetStream()
		{
			if (this.m == null)
			{
				return null;
			}
			return new MemoryStream(this.m);
		}

		/// <summary>
		/// Loads data to this stream from the specified file.
		/// </summary>
		/// <param name="filePath">File path.</param>
		public void Load(string filePath)
		{
			FileInfo fileInfo = new FileInfo(filePath);
			FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
			using (fileStream)
			{
				this.Load(fileInfo.Name, fileStream);
			}
		}

		/// <summary>
		/// Loads data to this stream from the specified <see cref="T:System.IO.Stream" />.
		/// </summary>
		/// <param name="name">Stream name.</param>
		/// <param name="stream">A stream.</param>
		public void Load(string name, System.IO.Stream stream)
		{
			if (stream == null)
			{
				throw new ArgumentNullException("stream");
			}
			this.a = name;
			this.m = new byte[checked((IntPtr)stream.Length)];
			stream.Read(this.m, 0, (int)this.m.Length);
		}

		/// <summary>
		/// Loads data to this stream from the specified buffer.
		/// </summary>
		/// <param name="name">Stream name.</param>
		/// <param name="buffer">Data buffer.</param>
		public void Load(string name, byte[] buffer)
		{
			this.a = name;
			this.m = buffer;
		}

		/// <summary>
		/// Saves data from this stream to to the specified file.
		/// </summary>
		/// <param name="filePath">File path.</param>
		public void Save(string filePath)
		{
			if (this.m != null && (int)this.m.Length > 0)
			{
				FileStream fileStream = new FileStream(filePath, FileMode.Create);
				using (fileStream)
				{
					fileStream.Write(this.m, 0, (int)this.m.Length);
				}
			}
		}

		/// <summary>
		/// Saves data from this stream to the specified <see cref="T:System.IO.Stream" />.
		/// </summary>
		/// <param name="stream">A stream.</param>
		public void Save(System.IO.Stream stream)
		{
			if (stream == null)
			{
				throw new ArgumentNullException("stream");
			}
			if (this.m != null && (int)this.m.Length > 0)
			{
				stream.Write(this.m, 0, (int)this.m.Length);
			}
		}
	}
}