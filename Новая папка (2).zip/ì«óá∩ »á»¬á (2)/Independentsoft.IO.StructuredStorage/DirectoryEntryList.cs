using System;
using System.Collections.Generic;
using System.Reflection;

namespace Independentsoft.IO.StructuredStorage
{
	/// <summary>
	/// Description of DirectoryEntryList.
	/// </summary>
	public class DirectoryEntryList : List<DirectoryEntry>
	{
		/// <summary>
		/// Gets the <see cref="T:Independentsoft.IO.StructuredStorage.DirectoryEntry" /> with the specified name.
		/// </summary>
		/// <param name="name">The name.</param>
		/// <returns>DirectoryEntry.</returns>
		public DirectoryEntry this[string name]
		{
			get
			{
				for (int i = 0; i < base.Count; i++)
				{
					DirectoryEntry item = base[i];
					if (item.Name == name)
					{
						return item;
					}
				}
				return null;
			}
		}

		public DirectoryEntryList()
		{
		}
	}
}