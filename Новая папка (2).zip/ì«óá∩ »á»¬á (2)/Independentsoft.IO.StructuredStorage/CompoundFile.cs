using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Independentsoft.IO.StructuredStorage
{
	/// <summary>
	/// Represents a file used to store data as virtual streams. 
	/// </summary>
	public class CompoundFile
	{
		private n a = new n();

		private RootDirectoryEntry b = new RootDirectoryEntry();

		/// <summary>
		/// Gets or sets compound file class ID.
		/// </summary>
		public byte[] ClassId
		{
			get
			{
				return this.a.i();
			}
			set
			{
				if (value != null)
				{
					this.a.a(value);
				}
			}
		}

		/// <summary>
		/// Gets FAT sector count.
		/// </summary>
		public int FatSectorCount
		{
			get
			{
				return (int)this.a.f();
			}
		}

		/// <summary>
		/// Gets or sets major version. Allowed values are 3 (512 bytes sector size) or 4 (4096 bytes sector size).
		/// </summary>
		public int MajorVersion
		{
			get
			{
				return this.a.e();
			}
			set
			{
				if (value != 3 && value != 4)
				{
					throw new ArgumentException("MajorVersion must be 3 or 4.");
				}
				this.a.a((ushort)value);
			}
		}

		/// <summary>
		/// Gets count of mini FAT sectors.
		/// </summary>
		public long MiniFatSectorCount
		{
			get
			{
				return (long)this.a.j();
			}
		}

		/// <summary>
		/// Gets size of mini sectors.
		/// </summary>
		public int MiniSectorSize
		{
			get
			{
				return this.a.g();
			}
		}

		/// <summary>
		/// Gets maximum size of mini streams.
		/// </summary>
		public long MiniStreamMaxSize
		{
			get
			{
				return (long)this.a.c();
			}
		}

		/// <summary>
		/// Gets the root node.
		/// </summary>
		public RootDirectoryEntry Root
		{
			get
			{
				return this.b;
			}
		}

		/// <summary>
		/// Gets FAT sector size.
		/// </summary>
		public int SectorSize
		{
			get
			{
				return this.a.d();
			}
		}

		/// <summary>
		/// Initializes a new instance of the CompoundFile class.  
		/// </summary>
		public CompoundFile()
		{
			e.a();
		}

		/// <summary>
		/// Initializes a new instance of the CompoundFile class based on the supplied file. 
		/// </summary>
		/// <param name="filePath">File path.</param>
		public CompoundFile(string filePath) : this()
		{
			this.Open(filePath);
		}

		/// <summary>
		/// Initializes a new instance of the CompoundFile class based on the supplied stream. 
		/// </summary>
		/// <param name="stream">A stream.</param>
		public CompoundFile(System.IO.Stream stream) : this()
		{
			this.Open(stream);
		}

		private void a(System.IO.Stream A_0)
		{
			unsafe
			{
				if (A_0.Length < (long)512)
				{
					throw new InvalidFileFormatException("Invalid file format.");
				}
				BinaryReader binaryReader = new BinaryReader(A_0, Encoding.Unicode);
				binaryReader.BaseStream.Position = (long)0;
				this.a = new n(binaryReader);
				uint[] numArray = this.b(binaryReader, this.a(binaryReader));
				uint[] numArray1 = null;
				if (this.a.b() != -2)
				{
					numArray1 = this.a(binaryReader, numArray);
				}
				IList<uint> nums = new List<uint>();
				uint num = this.a.l();
				nums.Add(num);
				while (true)
				{
					num = numArray[num];
					if (num == -2)
					{
						break;
					}
					nums.Add(num);
				}
				MemoryStream memoryStream = new MemoryStream();
				using (memoryStream)
				{
					BinaryReader binaryReader1 = new BinaryReader(memoryStream, Encoding.Unicode);
					for (int i = 0; i < nums.Count; i++)
					{
						uint item = nums[i];
						binaryReader.BaseStream.Position = (long)(item * this.a.d() + this.a.d());
						byte[] numArray2 = binaryReader.ReadBytes((int)this.a.d());
						memoryStream.Write(numArray2, 0, (int)numArray2.Length);
					}
					binaryReader1.BaseStream.Position = (long)0;
					this.b = (RootDirectoryEntry)DirectoryEntry.a(binaryReader1);
					IDictionary<uint, DirectoryEntry> nums1 = new Dictionary<uint, DirectoryEntry>()
					{
						{ 0, this.b }
					};
					if (this.b.f != -1)
					{
						binaryReader1.BaseStream.Position = (long)(this.b.f * 128);
						DirectoryEntry directoryEntry = DirectoryEntry.a(binaryReader1);
						nums1.Add(this.b.f, directoryEntry);
						this.b.n.Add(directoryEntry);
						directoryEntry.o = this.b;
						Stack<DirectoryEntry> directoryEntries = new Stack<DirectoryEntry>();
						Stack<DirectoryEntry> directoryEntries1 = new Stack<DirectoryEntry>();
						Stack<DirectoryEntry> directoryEntries2 = new Stack<DirectoryEntry>();
						directoryEntries.Push(directoryEntry);
						directoryEntries1.Push(directoryEntry);
						directoryEntries2.Push(directoryEntry);
						while (directoryEntries.Count > 0 || directoryEntries1.Count > 0 || directoryEntries2.Count > 0)
						{
							if (directoryEntries.Count > 0)
							{
								DirectoryEntry directoryEntry1 = directoryEntries.Pop();
								if (directoryEntry1.d != -1 && !nums1.ContainsKey(directoryEntry1.d))
								{
									binaryReader1.BaseStream.Position = (long)(directoryEntry1.d * 128);
									directoryEntry = DirectoryEntry.a(binaryReader1);
									nums1.Add(directoryEntry1.d, directoryEntry);
									directoryEntry1.o.n.Add(directoryEntry);
									directoryEntry.o = directoryEntry1.o;
									directoryEntries.Push(directoryEntry);
									directoryEntries1.Push(directoryEntry);
									directoryEntries2.Push(directoryEntry);
									continue;
								}
							}
							if (directoryEntries1.Count > 0)
							{
								DirectoryEntry directoryEntry2 = directoryEntries1.Pop();
								if (directoryEntry2.e != -1 && !nums1.ContainsKey(directoryEntry2.e))
								{
									binaryReader1.BaseStream.Position = (long)(directoryEntry2.e * 128);
									directoryEntry = DirectoryEntry.a(binaryReader1);
									nums1.Add(directoryEntry2.e, directoryEntry);
									directoryEntry2.o.n.Add(directoryEntry);
									directoryEntry.o = directoryEntry2.o;
									directoryEntries.Push(directoryEntry);
									directoryEntries1.Push(directoryEntry);
									directoryEntries2.Push(directoryEntry);
									continue;
								}
							}
							if (directoryEntries2.Count <= 0)
							{
								continue;
							}
							DirectoryEntry directoryEntry3 = directoryEntries2.Pop();
							if (directoryEntry3.f == -1 || nums1.ContainsKey(directoryEntry3.f))
							{
								continue;
							}
							binaryReader1.BaseStream.Position = (long)(directoryEntry3.f * 128);
							directoryEntry = DirectoryEntry.a(binaryReader1);
							nums1.Add(directoryEntry3.f, directoryEntry);
							directoryEntry3.n.Add(directoryEntry);
							directoryEntry.o = directoryEntry3;
							directoryEntries.Push(directoryEntry);
							directoryEntries1.Push(directoryEntry);
							directoryEntries2.Push(directoryEntry);
						}
					}
					IList<DirectoryEntry> directoryEntries3 = new List<DirectoryEntry>();
					foreach (DirectoryEntry value in nums1.Values)
					{
						if (value != this.b)
						{
							directoryEntries3.Add(value);
						}
						else
						{
							directoryEntries3.Insert(0, value);
						}
					}
					MemoryStream memoryStream1 = new MemoryStream();
					using (memoryStream1)
					{
						BinaryReader binaryReader2 = new BinaryReader(memoryStream1);
						for (int j = 0; j < directoryEntries3.Count; j++)
						{
							DirectoryEntry item1 = directoryEntries3[j];
							if (item1.b != i.b)
							{
								if (item1.b != i.f && item1.Size > (long)0 && item1.Size < (ulong)this.a.c())
								{
									IList<uint> nums2 = new List<uint>();
									uint num1 = item1.k;
									nums2.Add(num1);
									while (true)
									{
										num1 = numArray1[num1];
										if (num1 == -4 || num1 == -3 || num1 == -2 || num1 == -1 || num1 == numArray1[num1])
										{
											break;
										}
										nums2.Add(num1);
									}
									MemoryStream memoryStream2 = new MemoryStream();
									using (memoryStream2)
									{
										for (int k = 0; k < nums2.Count; k++)
										{
											uint item2 = nums2[k];
											binaryReader2.BaseStream.Position = (long)(item2 * 64);
											byte[] numArray3 = binaryReader2.ReadBytes(64);
											memoryStream2.Write(numArray3, 0, (int)numArray3.Length);
										}
										item1.m = new byte[item1.l];
										if (memoryStream2.Length < (long)((int)item1.m.Length))
										{
											item1.m = new byte[checked((IntPtr)memoryStream2.Length)];
										}
										Array.Copy(memoryStream2.ToArray(), 0, item1.m, 0, (int)item1.m.Length);
									}
								}
								else if (item1.Size > (long)0)
								{
									IList<uint> nums3 = new List<uint>();
									uint num2 = item1.k;
									nums3.Add(num2);
									while (true)
									{
										num2 = numArray[num2];
										if (num2 == -4 || num2 == -3 || num2 == -2 || num2 == -1 || num2 == numArray[num2])
										{
											break;
										}
										nums3.Add(num2);
									}
									MemoryStream memoryStream3 = new MemoryStream();
									using (memoryStream3)
									{
										for (int l = 0; l < nums3.Count; l++)
										{
											uint item3 = nums3[l];
											binaryReader.BaseStream.Position = (long)(item3 * this.a.d() + this.a.d());
											byte[] numArray4 = binaryReader.ReadBytes((int)this.a.d());
											memoryStream3.Write(numArray4, 0, (int)numArray4.Length);
										}
										item1.m = new byte[checked((IntPtr)item1.Size)];
										if (memoryStream3.Length < (long)((int)item1.m.Length))
										{
											item1.m = new byte[checked((IntPtr)memoryStream3.Length)];
										}
										Array.Copy(memoryStream3.ToArray(), 0, item1.m, 0, (int)item1.m.Length);
									}
									if (item1 == this.b && this.b.m != null)
									{
										memoryStream1.Write(this.b.m, 0, (int)this.b.m.Length);
									}
								}
							}
						}
					}
				}
			}
		}

		private byte[] a()
		{
			byte[] numArray = null;
			IList<DirectoryEntry> directoryEntries = new List<DirectoryEntry>();
			IList<uint> nums = new List<uint>();
			IList<uint> nums1 = new List<uint>();
			uint count = -2;
			uint num = -2;
			uint num1 = 0;
			MemoryStream memoryStream = new MemoryStream();
			using (memoryStream)
			{
				BinaryWriter binaryWriter = new BinaryWriter(memoryStream, Encoding.Unicode);
				this.b.c = f.a;
				this.b.b = i.f;
				this.b.m = null;
				this.b.d = -1;
				this.b.e = -1;
				this.b.i = DateTime.MinValue;
				this.b.j = DateTime.MinValue;
				this.b.l = 0;
				this.b.k = 0;
				directoryEntries.Add(this.b);
				this.a(this.b, ref directoryEntries);
				MemoryStream memoryStream1 = new MemoryStream();
				MemoryStream memoryStream2 = new MemoryStream();
				using (memoryStream1)
				{
					using (memoryStream2)
					{
						BinaryWriter binaryWriter1 = new BinaryWriter(memoryStream1, Encoding.Unicode);
						BinaryWriter binaryWriter2 = new BinaryWriter(memoryStream2, Encoding.Unicode);
						for (int i = directoryEntries.Count - 1; i >= 0; i--)
						{
							DirectoryEntry item = directoryEntries[i];
							if (item.m == null)
							{
								item.l = 0;
							}
							else
							{
								item.l = (uint)item.m.Length;
							}
							if (i == 0 && memoryStream2.Position > (long)0)
							{
								item.m = new byte[checked((IntPtr)memoryStream2.Position)];
								Array.Copy(memoryStream2.ToArray(), 0, item.m, 0, (int)memoryStream2.Position);
								item.l = (uint)item.m.Length;
							}
							if (i > 0 && item.l > 0 && item.l < this.a.c())
							{
								item.k = (uint)nums1.Count;
								for (int j = 0; j < (int)item.m.Length; j = j + this.a.g())
								{
									byte[] numArray1 = new byte[this.a.g()];
									int length = (int)numArray1.Length;
									if ((int)item.m.Length < j + this.a.g())
									{
										length = (int)item.m.Length - j;
									}
									Array.Copy(item.m, j, numArray1, 0, length);
									binaryWriter2.Write(numArray1);
									if (j + this.a.g() >= (int)item.m.Length)
									{
										nums1.Add(-2);
									}
									else
									{
										nums1.Add((uint)(nums1.Count + 1));
									}
								}
							}
							else if (i > 0 && item.l > 0 && item.l >= this.a.c())
							{
								item.k = (uint)nums.Count;
								for (int k = 0; k < (int)item.m.Length; k = k + this.a.d())
								{
									byte[] numArray2 = new byte[this.a.d()];
									int length1 = (int)numArray2.Length;
									if ((int)item.m.Length < k + this.a.d())
									{
										length1 = (int)item.m.Length - k;
									}
									Array.Copy(item.m, k, numArray2, 0, length1);
									binaryWriter1.Write(numArray2);
									if (k + this.a.d() >= (int)item.m.Length)
									{
										nums.Add(-2);
									}
									else
									{
										nums.Add((uint)(nums.Count + 1));
									}
								}
							}
						}
						int num2 = this.a.d() / this.a.g();
						int num3 = 0;
						bool flag = false;
						num = (uint)nums.Count;
						if (memoryStream2.Length > (long)0)
						{
							byte[] array = memoryStream2.ToArray();
							byte[] numArray3 = new byte[this.a.d()];
							for (int l = 0; l < (int)array.Length; l = l + this.a.g())
							{
								int length2 = this.a.g();
								if ((int)array.Length < l + this.a.g())
								{
									length2 = (int)(memoryStream2.Length - (long)l);
								}
								Array.Copy(array, l, numArray3, num3 * this.a.g(), length2);
								num3++;
								if (l + this.a.g() >= (int)array.Length)
								{
									flag = true;
								}
								if (flag || num3 == num2)
								{
									num3 = 0;
									binaryWriter1.Write(numArray3);
									if (flag)
									{
										nums.Add(-2);
									}
									else
									{
										nums.Add((uint)(nums.Count + 1));
									}
								}
							}
							int num4 = this.a.d() / 4;
							count = (uint)nums.Count;
							for (int m = 0; m < nums1.Count; m = m + num4)
							{
								byte[] numArray4 = new byte[this.a.d()];
								for (int n = 0; n < num4; n++)
								{
									if (m + n >= nums1.Count)
									{
										byte[] bytes = BitConverter.GetBytes((uint)-1);
										Array.Copy(bytes, 0, numArray4, n * 4, 4);
									}
									else
									{
										uint item1 = nums1[m + n];
										byte[] bytes1 = BitConverter.GetBytes(item1);
										Array.Copy(bytes1, 0, numArray4, n * 4, 4);
									}
								}
								binaryWriter1.Write(numArray4);
								num1++;
								if (m + num4 >= nums1.Count)
								{
									nums.Add(-2);
								}
								else
								{
									nums.Add((uint)(nums.Count + 1));
								}
							}
						}
						binaryWriter.Write(memoryStream1.ToArray());
					}
				}
				this.a.d((uint)nums.Count);
				uint num5 = 0;
				int num6 = this.a.d() / 128;
				for (int o = 0; o < directoryEntries.Count; o = o + num6)
				{
					if (directoryEntries[o] == this.b && num != -2)
					{
						this.b.k = num;
					}
					byte[] numArray5 = new byte[this.a.d()];
					for (int p = 0; p < num6; p++)
					{
						if (o + p < directoryEntries.Count)
						{
							DirectoryEntry directoryEntry = directoryEntries[o + p];
							Array.Copy(directoryEntry.a(), 0, numArray5, p * 128, 128);
						}
					}
					binaryWriter.Write(numArray5);
					num5++;
					if (o + num6 >= directoryEntries.Count)
					{
						nums.Add(-2);
					}
					else
					{
						nums.Add((uint)(nums.Count + 1));
					}
				}
				if (this.a.e() == 4)
				{
					this.a.g(num5);
				}
				int num7 = this.a.d() / 4;
				int count1 = nums.Count / num7;
				if (count1 * num7 < nums.Count)
				{
					count1++;
				}
				count1 = (nums.Count + count1) / num7;
				if (count1 * num7 < nums.Count + count1)
				{
					count1++;
				}
				int num8 = (count1 - 109) / (num7 - 1);
				if (num8 * num7 < count1 - 109)
				{
					num8++;
				}
				this.a.a((uint)count1);
				IList<uint> nums2 = new List<uint>();
				IList<uint> nums3 = new List<uint>();
				for (int q = 0; q < count1; q++)
				{
					nums.Add(-3);
					int count2 = nums.Count - 1;
					if (q >= 109)
					{
						nums3.Add((uint)count2);
					}
					else
					{
						nums2.Add((uint)count2);
					}
				}
				for (int r = 0; r < num8; r++)
				{
					nums.Add(-4);
				}
				for (int s = 0; s < nums.Count; s = s + num7)
				{
					byte[] numArray6 = new byte[this.a.d()];
					for (int t = 0; t < num7; t++)
					{
						if (s + t >= nums.Count)
						{
							byte[] bytes2 = BitConverter.GetBytes((uint)-1);
							Array.Copy(bytes2, 0, numArray6, t * 4, 4);
						}
						else
						{
							uint item2 = nums[s + t];
							byte[] bytes3 = BitConverter.GetBytes(item2);
							Array.Copy(bytes3, 0, numArray6, t * 4, 4);
						}
					}
					binaryWriter.Write(numArray6);
				}
				if (num8 <= 0)
				{
					this.a.b(-2);
				}
				else
				{
					this.a.b((uint)(binaryWriter.BaseStream.Position / (ulong)this.a.d()));
				}
				this.a.c((uint)num8);
				for (int u = 0; u < nums2.Count; u++)
				{
					this.a.k()[u] = nums2[u];
				}
				for (int v = nums2.Count; v < 109; v++)
				{
					this.a.k()[v] = -1;
				}
				int num9 = 1;
				for (int w = 0; w < nums3.Count; w = w + (num7 - 1))
				{
					byte[] numArray7 = new byte[this.a.d()];
					for (int x = 0; x < num7 - 1; x++)
					{
						if (w + x >= nums3.Count)
						{
							byte[] bytes4 = BitConverter.GetBytes((uint)-1);
							Array.Copy(bytes4, 0, numArray7, x * 4, 4);
						}
						else
						{
							uint item3 = nums3[w + x];
							byte[] bytes5 = BitConverter.GetBytes(item3);
							Array.Copy(bytes5, 0, numArray7, x * 4, 4);
						}
					}
					if (w + (num7 - 1) >= nums3.Count)
					{
						byte[] bytes6 = BitConverter.GetBytes((uint)-2);
						Array.Copy(bytes6, 0, numArray7, (num7 - 1) * 4, 4);
					}
					else
					{
						int num10 = num9;
						num9 = num10 + 1;
						byte[] bytes7 = BitConverter.GetBytes((long)((ulong)this.a.a() + (long)num10));
						Array.Copy(bytes7, 0, numArray7, (num7 - 1) * 4, 4);
					}
					binaryWriter.Write(numArray7);
				}
				this.a.f(count);
				this.a.e(num1);
				byte[] numArray8 = this.a.h();
				numArray = new byte[checked((IntPtr)(memoryStream.Length + (long)((int)numArray8.Length)))];
				Array.Copy(numArray8, 0, numArray, 0, (int)numArray8.Length);
				Array.Copy(memoryStream.ToArray(), 0, numArray, (int)numArray8.Length, (int)numArray.Length - (int)numArray8.Length);
			}
			return numArray;
		}

		private void a(DirectoryEntry A_0, ref IList<DirectoryEntry> A_1)
		{
			if (A_0.n.Count > 0)
			{
				A_0.n.Sort();
				int count = A_0.n.Count / 2;
				DirectoryEntry item = A_0.n[count];
				if (A_0.c != f.b)
				{
					item.c = f.b;
				}
				else
				{
					item.c = f.a;
				}
				item.i = DateTime.Now;
				item.j = item.i;
				if (item.m == null)
				{
					item.l = 0;
				}
				else
				{
					item.l = (uint)item.m.Length;
				}
				item.k = 0;
				item.d = -1;
				item.e = -1;
				item.f = -1;
				A_1.Add(item);
				A_0.f = (uint)(A_1.Count - 1);
				DirectoryEntry directoryEntry = item;
				for (int i = count - 1; i >= 0; i--)
				{
					DirectoryEntry now = A_0.n[i];
					if (A_0.c != f.b)
					{
						now.c = f.b;
					}
					else
					{
						now.c = f.a;
					}
					now.i = DateTime.Now;
					now.j = now.i;
					if (now.m == null)
					{
						now.l = 0;
					}
					else
					{
						now.l = (uint)now.m.Length;
					}
					now.d = -1;
					now.e = -1;
					now.f = -1;
					A_1.Add(now);
					directoryEntry.d = (uint)(A_1.Count - 1);
					directoryEntry = now;
					if (now is Storage)
					{
						this.a(now, ref A_1);
					}
				}
				directoryEntry = item;
				for (int j = count + 1; j < A_0.n.Count; j++)
				{
					DirectoryEntry length = A_0.n[j];
					if (A_0.c != f.b)
					{
						length.c = f.b;
					}
					else
					{
						length.c = f.a;
					}
					length.i = DateTime.Now;
					length.j = length.i;
					if (length.m == null)
					{
						length.l = 0;
					}
					else
					{
						length.l = (uint)length.m.Length;
					}
					length.d = -1;
					length.e = -1;
					length.f = -1;
					A_1.Add(length);
					directoryEntry.e = (uint)(A_1.Count - 1);
					directoryEntry = length;
					if (length is Storage)
					{
						this.a(length, ref A_1);
					}
				}
				if (item is Storage)
				{
					this.a(item, ref A_1);
				}
			}
		}

		private uint[] a(BinaryReader A_0, uint[] A_1)
		{
			unsafe
			{
				int num = this.a.d() / 4;
				uint[] numArray = new uint[checked((IntPtr)((ulong)this.a.j() * (long)num))];
				IList<uint> nums = new List<uint>();
				uint a1 = this.a.b();
				nums.Add(a1);
				while (true)
				{
					a1 = A_1[a1];
					if (a1 == -2)
					{
						break;
					}
					nums.Add(a1);
				}
				uint[] numArray1 = new uint[nums.Count];
				for (int i = 0; i < (int)numArray1.Length; i++)
				{
					uint item = nums[i];
					numArray1[i] = uint.Parse(item.ToString());
				}
				int num1 = 0;
				for (int j = 0; j < (int)numArray1.Length; j++)
				{
					A_0.BaseStream.Position = (long)(numArray1[j] * this.a.d() + this.a.d());
					for (int k = 0; k < num; k++)
					{
						int num2 = num1;
						num1 = num2 + 1;
						numArray[num2] = A_0.ReadUInt32();
					}
				}
				return numArray;
			}
		}

		private uint[] a(BinaryReader A_0)
		{
			unsafe
			{
				if (this.a.f() <= 109)
				{
					uint[] numArray = new uint[this.a.f()];
					for (int i = 0; (long)i < (ulong)this.a.f(); i++)
					{
						numArray[i] = this.a.k()[i];
					}
					return numArray;
				}
				int num = this.a.d() / 4;
				uint[] numArray1 = new uint[num];
				uint[] numArray2 = new uint[this.a.f()];
				for (int j = 0; j < 109; j++)
				{
					numArray2[j] = this.a.k()[j];
				}
				A_0.BaseStream.Position = (long)(this.a.a() * this.a.d() + this.a.d());
				uint num1 = 109;
				while (true)
				{
					for (int k = 0; k < num; k++)
					{
						numArray1[k] = A_0.ReadUInt32();
					}
					for (int l = 0; l < num - 1; l++)
					{
						if (numArray1[l] != -1 && (ulong)num1 < (long)((int)numArray2.Length))
						{
							uint num2 = num1;
							num1 = num2 + 1;
							numArray2[num2] = numArray1[l];
						}
					}
					if (numArray1[num - 1] == -2 || (ulong)num1 >= (long)((int)numArray2.Length))
					{
						break;
					}
					A_0.BaseStream.Position = (long)(numArray1[num - 1] * this.a.d() + this.a.d());
				}
				return numArray2;
			}
		}

		private uint[] b(BinaryReader A_0, uint[] A_1)
		{
			unsafe
			{
				int num = this.a.d() / 4;
				uint[] numArray = new uint[checked((IntPtr)((ulong)this.a.f() * (long)num))];
				uint num1 = 0;
				for (int i = 0; i < (int)A_1.Length; i++)
				{
					A_0.BaseStream.Position = (long)(A_1[i] * this.a.d() + this.a.d());
					for (int j = 0; j < num; j++)
					{
						uint num2 = num1;
						num1 = num2 + 1;
						numArray[num2] = A_0.ReadUInt32();
					}
				}
				return numArray;
			}
		}

		/// <summary>
		/// Gets buffer to read from this compound file.
		/// </summary>
		/// <returns></returns>
		public byte[] GetBytes()
		{
			return this.a();
		}

		/// <summary>
		/// Gets stream to read from this compound file.
		/// </summary>
		/// <returns></returns>
		public System.IO.Stream GetStream()
		{
			return new MemoryStream(this.a());
		}

		/// <summary>
		/// Opens compound file from the specified file.
		/// </summary>
		/// <param name="filePath">File path.</param>
		public void Open(string filePath)
		{
			FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
			using (fileStream)
			{
				this.Open(fileStream);
			}
		}

		/// <summary>
		/// Opens compound file from the specified stream.
		/// </summary>
		/// <param name="stream">A stream.</param>
		public void Open(System.IO.Stream stream)
		{
			this.a(stream);
		}

		/// <summary>
		/// Saves this compound file to the specified file.
		/// </summary>
		/// <param name="filePath">File path.</param>
		public void Save(string filePath)
		{
			this.Save(filePath, false);
		}

		/// <summary>
		/// Saves this compound file to the specified file.
		/// </summary>
		/// <param name="filePath">File path.</param>
		/// <param name="overwrite">True to overwrite existing file, otherwise false.</param>
		public void Save(string filePath, bool overwrite)
		{
			FileMode fileMode = FileMode.CreateNew;
			if (overwrite)
			{
				fileMode = FileMode.Create;
			}
			using (FileStream fileStream = new FileStream(filePath, fileMode, FileAccess.Write))
			{
				this.Save(fileStream);
			}
		}

		/// <summary>
		/// Saves this compound file to the specified stream.
		/// </summary>
		/// <param name="stream">A stream.</param>
		public void Save(System.IO.Stream stream)
		{
			if (stream == null)
			{
				throw new ArgumentNullException("stream");
			}
			byte[] numArray = this.a();
			stream.Write(numArray, 0, (int)numArray.Length);
		}
	}
}