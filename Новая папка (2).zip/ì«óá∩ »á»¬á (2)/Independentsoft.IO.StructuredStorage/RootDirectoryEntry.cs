using System;

namespace Independentsoft.IO.StructuredStorage
{
	/// <summary>
	/// Represents a root node.
	/// </summary>
	/// <remarks>
	/// RootDirectoryEntry object in a compound file that must be accessed before any other <see cref="T:Independentsoft.IO.StructuredStorage.Storage" /> objects and <see cref="T:Independentsoft.IO.StructuredStorage.Stream" /> objects are referenced. It is the uppermost parent object in the storage object and stream object hierarchy.
	/// </remarks>
	public class RootDirectoryEntry : DirectoryEntry
	{
		/// <summary>
		/// Gets collection of <see cref="T:Independentsoft.IO.StructuredStorage.DirectoryEntry" />.
		/// </summary>
		public DirectoryEntryList DirectoryEntries
		{
			get
			{
				return this.n;
			}
		}

		/// <summary>
		/// Gets root's name.
		/// </summary>
		public new string Name
		{
			get
			{
				return this.a;
			}
		}

		internal RootDirectoryEntry()
		{
			this.a = "Root Entry";
			this.b = i.f;
		}
	}
}