using System;

namespace Independentsoft.IO.StructuredStorage
{
	/// <summary>
	/// Contains collection of <see cref="T:Independentsoft.IO.StructuredStorage.DirectoryEntry" />.
	/// </summary>
	/// <remarks>
	/// Storage is analogous to a file system directory. The parent object of a storage object must be another storage object or the <see cref="T:Independentsoft.IO.StructuredStorage.RootDirectoryEntry" />.
	/// </remarks>
	public class Storage : DirectoryEntry
	{
		/// <summary>
		/// Gets collection of <see cref="T:Independentsoft.IO.StructuredStorage.DirectoryEntry" />.
		/// </summary>
		public DirectoryEntryList DirectoryEntries
		{
			get
			{
				return this.n;
			}
		}

		/// <summary>
		///  Initializes a new instance of the Storage class.  
		/// </summary>
		public Storage()
		{
			this.b = i.b;
		}

		/// <summary>
		///  Initializes a new instance of the Storage class.  
		/// </summary>
		/// <param name="name">Storage name.</param>
		public Storage(string name) : this()
		{
			this.a = name;
		}
	}
}