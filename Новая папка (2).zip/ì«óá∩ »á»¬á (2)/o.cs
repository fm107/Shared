using Independentsoft.Email.Mime;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

internal class o
{
	private static Random a;

	internal static byte[] b;

	internal readonly static char[] c;

	internal readonly static char[] d;

	internal readonly static char[] e;

	internal static string[] f;

	internal static string[] g;

	static o()
	{
		o.a = new Random();
		o.b = new byte[] { 13, 10, 13, 10 };
		o.c = new char[] { '\r', '\n' };
		o.d = new char[] { ' ', '\t' };
		o.e = new char[] { ' ' };
		string[] strArrays = new string[] { "Resent-Date", "Resent-From", "Resent-Sender", "Resent-To", "Resent-Cc", "Resent-Bcc", "Resent-Message-ID", "From", "Sender", "Reply-To", "To", "Cc", "Bcc", "Subject", "Date", "Message-ID", "In-Reply-To", "References", "Comments", "Keywords", "Return-Path", "Received", "MIME-Version", "Content-Type", "Content-Transfer-Encoding", "Content-ID", "Content-Description" };
		o.f = strArrays;
		string[] strArrays1 = new string[] { "resent-date", "resent-from", "resent-sender", "resent-to", "resent-cc", "resent-bcc", "resent-message-id", "from", "sender", "reply-to", "to", "cc", "bcc", "subject", "date", "message-id", "in-reply-to", "references", "comments", "keywords", "return-path", "received", "mime-version", "content-type", "content-transfer-encoding", "content-id", "content-description" };
		o.g = strArrays1;
	}

	internal static IList<byte[]> a(byte[] A_0, string A_1)
	{
		IList<byte[]> numArrays = new List<byte[]>();
		string str = string.Concat("--", A_1);
		string str1 = string.Concat(str, "--");
		byte[] bytes = Encoding.UTF8.GetBytes(str);
		byte[] numArray = Encoding.UTF8.GetBytes(str1);
		int num = o.a(A_0, bytes);
		if (num > -1)
		{
			int num1 = o.a(A_0, numArray, num + (int)bytes.Length);
			if (num1 > -1)
			{
				for (int i = o.a(A_0, bytes, num + (int)bytes.Length); i > num + (int)bytes.Length; i = o.a(A_0, bytes, i + (int)bytes.Length))
				{
					byte[] numArray1 = new byte[i - num - (int)bytes.Length];
					Array.Copy(A_0, num + (int)bytes.Length, numArray1, 0, (int)numArray1.Length);
					numArrays.Add(numArray1);
					if (i == num1)
					{
						break;
					}
					num = i;
				}
			}
		}
		return numArrays;
	}

	internal static bool a(string A_0, string A_1)
	{
		if (A_0.ToLower() != "received")
		{
			char[] charArray = A_1.ToCharArray();
			for (int i = 0; i < (int)charArray.Length; i++)
			{
				if (charArray[i] > 127)
				{
					return true;
				}
			}
		}
		return false;
	}

	internal static string a(string A_0, string A_1, HeaderEncoding A_2)
	{
		Encoding encoding = null;
		try
		{
			encoding = Encoding.GetEncoding(A_1);
		}
		catch
		{
			encoding = Encoding.UTF8;
			A_1 = "utf-8";
		}
		string str = "";
		if (A_2 == HeaderEncoding.QuotedPrintable)
		{
			string[] strArrays = o.b(A_0, 68);
			for (int i = 0; i < (int)strArrays.Length; i++)
			{
				if (!o.l(strArrays[i]))
				{
					str = (str.EndsWith(" ") || str.EndsWith("\t") ? string.Concat(str, strArrays[i]) : string.Concat(str, " ", strArrays[i]));
				}
				else
				{
					string str1 = o.d(strArrays[i], encoding);
					string[] a1 = new string[] { "=?", A_1, "?", k.a(A_2), "?", str1, "?=" };
					str1 = string.Concat(a1);
					str = (str.EndsWith(" ") || str.EndsWith("\t") ? string.Concat(str, str1) : string.Concat(str, " ", str1));
				}
			}
		}
		else if (A_2 == HeaderEncoding.Binary)
		{
			string[] strArrays1 = o.b(A_0, 68);
			for (int j = 0; j < (int)strArrays1.Length; j++)
			{
				if (!o.l(strArrays1[j]))
				{
					str = (str.EndsWith(" ") || str.EndsWith("\t") ? string.Concat(str, strArrays1[j]) : string.Concat(str, " ", strArrays1[j]));
				}
				else
				{
					byte[] bytes = encoding.GetBytes(strArrays1[j]);
					string base64String = Convert.ToBase64String(bytes, 0, (int)bytes.Length);
					string[] a11 = new string[] { "=?", A_1, "?", k.a(A_2), "?", base64String, "?=" };
					base64String = string.Concat(a11);
					str = (str.EndsWith(" ") || str.EndsWith("\t") ? string.Concat(str, base64String) : string.Concat(str, " ", base64String));
				}
			}
		}
		return str;
	}

	internal static string a(string A_0, ref HeaderEncoding A_1, ref string A_2)
	{
		bool flag;
		int num = A_0.IndexOf("=?");
		if (num == -1)
		{
			return A_0;
		}
		int length = A_0.IndexOf("?=", num);
		if (length == -1)
		{
			return A_0;
		}
		if (length < num)
		{
			return A_0;
		}
		A_0 = A_0.Replace("?= =?", "?==?");
		do
		{
			if (A_0.IndexOf("?==?") <= 0)
			{
				break;
			}
			flag = false;
			int num1 = A_0.IndexOf("?==?");
			int num2 = A_0.IndexOf("?", num1 + 4);
			if (num2 <= num1)
			{
				continue;
			}
			int num3 = A_0.IndexOf("?", num2 + 1);
			if (num3 <= num2)
			{
				continue;
			}
			A_0 = string.Concat(A_0.Substring(0, num1), A_0.Substring(num3 + 1));
			flag = true;
		}
		while (flag);
		string str = A_0.Substring(0, num);
		while (true)
		{
			int num4 = A_0.IndexOf("?", num + 2);
			int num5 = A_0.IndexOf("?", num4 + 1);
			if (num4 > -1 && num5 > -1)
			{
				length = A_0.IndexOf("?=", num5 + 1);
				if (length == -1)
				{
					length = A_0.Length - 2;
				}
				A_2 = A_0.Substring(num + 2, num4 - num - 2);
				string str1 = A_0.Substring(num4 + 1, 1);
				string str2 = null;
				str2 = (length <= -1 ? A_0.Substring(num5 + 1) : A_0.Substring(num5 + 1, length - num5 - 1));
				if (str1 == "Q" || str1 == "q")
				{
					A_1 = HeaderEncoding.QuotedPrintable;
					Encoding encoding = null;
					try
					{
						encoding = Encoding.GetEncoding(A_2);
					}
					catch
					{
						encoding = Encoding.UTF8;
						A_2 = "utf-8";
					}
					string str3 = o.a(str2, encoding);
					str3 = str3.Replace("_", " ");
					str = string.Concat(str, str3);
				}
				else if (str1 == "B" || str1 == "b")
				{
					A_1 = HeaderEncoding.Binary;
					Encoding uTF8 = null;
					try
					{
						uTF8 = Encoding.GetEncoding(A_2);
					}
					catch
					{
						uTF8 = Encoding.UTF8;
						A_2 = "utf-8";
					}
					string str4 = o.b(str2, uTF8);
					str4 = str4.Replace("_", " ");
					str = string.Concat(str, str4);
				}
			}
			num = A_0.IndexOf("=?", length + 2);
			if (num != -1)
			{
				int num6 = length;
				length = A_0.IndexOf("?=", num);
				if (length != -1)
				{
					str = string.Concat(str, A_0.Substring(num6 + 2, num - num6 - 2));
				}
				else
				{
					str = string.Concat(str, A_0.Substring(num6 + 2, num - num6 - 2));
					break;
				}
			}
			else
			{
				str = string.Concat(str, A_0.Substring(length + 2, A_0.Length - length - 2));
				break;
			}
		}
		return str;
	}

	internal static string a(string A_0, Encoding A_1)
	{
		string str;
		try
		{
			byte[] numArray = o.f(A_0);
			str = A_1.GetString(numArray, 0, (int)numArray.Length);
		}
		catch (OverflowException overflowException)
		{
			str = A_0;
		}
		catch (Exception exception1)
		{
			Exception exception = exception1;
			throw new MessageFormatException(exception.Message, exception);
		}
		return str;
	}

	internal static string a(string A_0, int A_1)
	{
		if (A_0.Length <= A_1)
		{
			return A_0;
		}
		IList<string> strs = new List<string>();
		string[] strArrays = o.c(A_0);
		string str = "";
		for (int i = 0; i < (int)strArrays.Length; i++)
		{
			if (str.Length + strArrays[i].Length >= A_1)
			{
				if (str.Length > 0)
				{
					strs.Add(str);
					str = "";
				}
				str = string.Concat(str, strArrays[i]);
			}
			else
			{
				str = string.Concat(str, strArrays[i]);
			}
		}
		if (str.Length > 0)
		{
			strs.Add(str);
		}
		string str1 = "";
		for (int j = 0; j < strs.Count; j++)
		{
			str1 = string.Concat(str1, strs[j]);
			if (j < strs.Count - 1)
			{
				str1 = string.Concat(str1, "\r\n ");
			}
		}
		return str1;
	}

	internal static int a(byte[] A_0, byte[] A_1)
	{
		return o.a(A_0, A_1, 0);
	}

	internal static int a(byte[] A_0, byte[] A_1, int A_2)
	{
		bool flag = false;
		for (int i = A_2; i <= (int)A_0.Length - (int)A_1.Length; i++)
		{
			int num = 0;
			while (num < (int)A_1.Length)
			{
				if (A_0[i + num] != A_1[num])
				{
					flag = false;
					break;
				}
				else
				{
					flag = true;
					num++;
				}
			}
			if (flag)
			{
				return i;
			}
		}
		return -1;
	}

	internal static byte[] a(byte[] A_0)
	{
		MemoryStream memoryStream = new MemoryStream((int)A_0.Length);
		for (int i = 0; i < (int)A_0.Length - 1; i++)
		{
			if (A_0[i] == 13 || A_0[i + 1] == 10)
			{
				i++;
			}
			else
			{
				memoryStream.WriteByte(A_0[i]);
			}
		}
		if ((int)A_0.Length > 1 && A_0[(int)A_0.Length - 2] != 13 && A_0[(int)A_0.Length - 1] != 10)
		{
			memoryStream.WriteByte(A_0[(int)A_0.Length - 1]);
		}
		return memoryStream.ToArray();
	}

	internal static int a()
	{
		return o.a.Next(2147483647);
	}

	internal static DateTime a(string A_0)
	{
		string str;
		int num;
		DateTime now = DateTime.Now;
		string str1 = Regex.Replace(A_0, "(\\([^(].*\\))", "");
		str1 = Regex.Replace(str1, "\\s+", " ");
		str1 = Regex.Replace(str1, "^\\s+", "");
		str1 = Regex.Replace(str1, "\\s+$", "");
		char[] chrArray = new char[] { ',' };
		string[] strArrays = str1.Split(chrArray, 2);
		if ((int)strArrays.Length != 2)
		{
			str = "";
		}
		else
		{
			str = strArrays[0];
			str1 = strArrays[1];
		}
		try
		{
			int num1 = str1.LastIndexOf(" ");
			if (num1 < 1)
			{
				throw new FormatException("Probably not a date");
			}
			string str2 = str1.Substring(0, num1 - 1);
			string str3 = str1.Substring(num1 + 1);
			now = Convert.ToDateTime(str2);
			if (str != string.Empty && (now.DayOfWeek == DayOfWeek.Friday && str != "Fri" || now.DayOfWeek == DayOfWeek.Monday && str != "Mon" || now.DayOfWeek == DayOfWeek.Saturday && str != "Sat" || now.DayOfWeek == DayOfWeek.Sunday && str != "Sun" || now.DayOfWeek == DayOfWeek.Thursday && str != "Thu" || now.DayOfWeek == DayOfWeek.Tuesday && str != "Tue" || now.DayOfWeek == DayOfWeek.Wednesday && str != "Wed"))
			{
				throw new FormatException("Invalid week of day");
			}
			if (!Regex.IsMatch(str3, "[+\\-][0-9][0-9][0-9][0-9]"))
			{
				string str4 = str3;
				string str5 = str4;
				if (str4 != null)
				{
					if (b.a == null)
					{
						b.a = new Dictionary<string, int>(36)
						{
							{ "A", 0 },
							{ "B", 1 },
							{ "C", 2 },
							{ "D", 3 },
							{ "E", 4 },
							{ "F", 5 },
							{ "G", 6 },
							{ "H", 7 },
							{ "I", 8 },
							{ "K", 9 },
							{ "L", 10 },
							{ "M", 11 },
							{ "N", 12 },
							{ "O", 13 },
							{ "P", 14 },
							{ "Q", 15 },
							{ "R", 16 },
							{ "S", 17 },
							{ "T", 18 },
							{ "U", 19 },
							{ "V", 20 },
							{ "W", 21 },
							{ "X", 22 },
							{ "Y", 23 },
							{ "Z", 24 },
							{ "UT", 25 },
							{ "GMT", 26 },
							{ "BST", 27 },
							{ "EST", 28 },
							{ "EDT", 29 },
							{ "CST", 30 },
							{ "CDT", 31 },
							{ "MST", 32 },
							{ "MDT", 33 },
							{ "PST", 34 },
							{ "PDT", 35 }
						};
					}
					if (b.a.TryGetValue(str5, out num))
					{
						switch (num)
						{
							case 0:
							{
								now = now.AddHours(1);
								break;
							}
							case 1:
							{
								now = now.AddHours(2);
								break;
							}
							case 2:
							{
								now = now.AddHours(3);
								break;
							}
							case 3:
							{
								now = now.AddHours(4);
								break;
							}
							case 4:
							{
								now = now.AddHours(5);
								break;
							}
							case 5:
							{
								now = now.AddHours(6);
								break;
							}
							case 6:
							{
								now = now.AddHours(7);
								break;
							}
							case 7:
							{
								now = now.AddHours(8);
								break;
							}
							case 8:
							{
								now = now.AddHours(9);
								break;
							}
							case 9:
							{
								now = now.AddHours(10);
								break;
							}
							case 10:
							{
								now = now.AddHours(11);
								break;
							}
							case 11:
							{
								now = now.AddHours(12);
								break;
							}
							case 12:
							{
								now = now.AddHours(-1);
								break;
							}
							case 13:
							{
								now = now.AddHours(-2);
								break;
							}
							case 14:
							{
								now = now.AddHours(-3);
								break;
							}
							case 15:
							{
								now = now.AddHours(-4);
								break;
							}
							case 16:
							{
								now = now.AddHours(-5);
								break;
							}
							case 17:
							{
								now = now.AddHours(-6);
								break;
							}
							case 18:
							{
								now = now.AddHours(-7);
								break;
							}
							case 19:
							{
								now = now.AddHours(-8);
								break;
							}
							case 20:
							{
								now = now.AddHours(-9);
								break;
							}
							case 21:
							{
								now = now.AddHours(-10);
								break;
							}
							case 22:
							{
								now = now.AddHours(-11);
								break;
							}
							case 23:
							{
								now = now.AddHours(-12);
								break;
							}
							case 27:
							{
								now = now.AddHours(1);
								break;
							}
							case 28:
							{
								now = now.AddHours(5);
								break;
							}
							case 29:
							{
								now = now.AddHours(4);
								break;
							}
							case 30:
							{
								now = now.AddHours(6);
								break;
							}
							case 31:
							{
								now = now.AddHours(5);
								break;
							}
							case 32:
							{
								now = now.AddHours(7);
								break;
							}
							case 33:
							{
								now = now.AddHours(6);
								break;
							}
							case 34:
							{
								now = now.AddHours(8);
								break;
							}
							case 35:
							{
								now = now.AddHours(7);
								break;
							}
						}
					}
				}
			}
			else
			{
				int num2 = 0;
				string str6 = str3.Substring(1, 2);
				string str7 = str3.Substring(3, 2);
				if (str3.Substring(0, 1) != "+")
				{
					if (str3.Substring(0, 1) != "-")
					{
						throw new FormatException("incorrect time zone");
					}
					num2 = -1;
				}
				else
				{
					num2 = 1;
				}
				now = now.AddHours((double)(num2 * Convert.ToInt32(str6)));
				now = now.AddMinutes((double)(num2 * Convert.ToInt32(str7)));
			}
		}
		catch (Exception exception)
		{
		}
		return now;
	}

	internal static string b(string A_0, Encoding A_1)
	{
		byte[] numArray = o.h(A_0);
		return A_1.GetString(numArray, 0, (int)numArray.Length);
	}

	private static string[] b(string A_0, int A_1)
	{
		IList<string> strs = new List<string>();
		string[] strArrays = o.c(A_0);
		string str = "";
		for (int i = 0; i < (int)strArrays.Length; i++)
		{
			if (o.k(strArrays[i]))
			{
				if (str.Length > 0)
				{
					strs.Add(str);
					str = "";
				}
				strs.Add(strArrays[i]);
			}
			else if (str.Length + strArrays[i].Length >= A_1)
			{
				if (str.Length > 0)
				{
					strs.Add(str);
					str = "";
				}
				str = string.Concat(str, strArrays[i]);
			}
			else
			{
				str = string.Concat(str, strArrays[i]);
			}
		}
		if (str.Length > 0)
		{
			strs.Add(str);
		}
		string[] item = new string[strs.Count];
		for (int j = 0; j < strs.Count; j++)
		{
			item[j] = strs[j];
		}
		return item;
	}

	internal static string b(string A_0)
	{
		return A_0.Replace("\r\n ", " ").Replace("\r\n\t", " ");
	}

	internal static byte[] b(byte[] A_0)
	{
		MemoryStream memoryStream = new MemoryStream();
		for (int i = 0; i < (int)A_0.Length; i++)
		{
			byte a0 = A_0[i];
			if (a0 == 10)
			{
				if (i == 0)
				{
					memoryStream.WriteByte(13);
					memoryStream.WriteByte(10);
				}
				else if (A_0[i - 1] == 13)
				{
					memoryStream.WriteByte(10);
				}
				else
				{
					memoryStream.WriteByte(13);
					memoryStream.WriteByte(10);
				}
			}
			else if (a0 != 13)
			{
				memoryStream.WriteByte(A_0[i]);
			}
			else if (i == (int)A_0.Length - 1)
			{
				memoryStream.WriteByte(13);
				memoryStream.WriteByte(10);
			}
			else if (A_0[i + 1] == 10)
			{
				memoryStream.WriteByte(13);
				memoryStream.WriteByte(A_0[i + 1]);
				i++;
			}
			else
			{
				memoryStream.WriteByte(13);
				memoryStream.WriteByte(10);
			}
		}
		if (memoryStream.Length == (long)2)
		{
			memoryStream.WriteByte(13);
			memoryStream.WriteByte(10);
		}
		return memoryStream.ToArray();
	}

	internal static string b()
	{
		object[] objArray = new object[] { o.a(), "-", o.a(), "-", o.a() };
		return string.Concat(objArray);
	}

	internal static string c(string A_0, Encoding A_1)
	{
		byte[] bytes = A_1.GetBytes(A_0);
		char[] chars = A_1.GetChars(bytes);
		StringBuilder stringBuilder = new StringBuilder((int)bytes.Length);
		for (int i = 0; i < (int)chars.Length; i++)
		{
			int num = chars[i];
			if (num >= 33 && num <= 60 || num >= 62 && num <= 126 || num == 9 || num == 32)
			{
				stringBuilder.Append(chars[i]);
			}
			else if (num <= 127)
			{
				string str = num.ToString("X");
				if (str.Length == 1)
				{
					str = string.Concat("0", str);
				}
				str = string.Concat("=", str);
				stringBuilder.Append(str);
			}
			else
			{
				string str1 = chars[i].ToString();
				byte[] numArray = A_1.GetBytes(str1);
				for (int j = 0; j < (int)numArray.Length; j++)
				{
					string str2 = numArray[j].ToString("X");
					if (str2.Length == 1)
					{
						str2 = string.Concat("0", str2);
					}
					str2 = string.Concat("=", str2);
					stringBuilder.Append(str2);
				}
			}
		}
		return stringBuilder.ToString();
	}

	private static string[] c(string A_0)
	{
		if (A_0.Length > 2097152)
		{
			return new string[] { A_0 };
		}
		IList<string> strs = new List<string>();
		char[] charArray = A_0.ToCharArray();
		string str = "";
		for (int i = 0; i < (int)charArray.Length; i++)
		{
			if (charArray[i] == ' ' || charArray[i] == '\t')
			{
				if (str.Length > 0)
				{
					strs.Add(str);
				}
				str = "";
				str = string.Concat(str, charArray[i]);
			}
			else if (i == 0)
			{
				str = string.Concat(str, charArray[i]);
			}
			else if (charArray[i - 1] == ' ' || charArray[i - 1] == '\t')
			{
				if (str.Length > 0)
				{
					strs.Add(str);
				}
				str = "";
				str = string.Concat(str, charArray[i]);
			}
			else
			{
				str = string.Concat(str, charArray[i]);
			}
		}
		if (str.Length > 0)
		{
			strs.Add(str);
		}
		string[] item = new string[strs.Count];
		for (int j = 0; j < strs.Count; j++)
		{
			item[j] = strs[j];
		}
		return item;
	}

	internal static string d(string A_0, Encoding A_1)
	{
		byte[] bytes = A_1.GetBytes(A_0);
		char[] chars = A_1.GetChars(bytes);
		StringBuilder stringBuilder = new StringBuilder((int)bytes.Length);
		for (int i = 0; i < (int)chars.Length; i++)
		{
			int num = chars[i];
			if (num >= 33 && num <= 60 || num >= 62 && num <= 126)
			{
				stringBuilder.Append(chars[i]);
			}
			else if (num <= 127)
			{
				string str = num.ToString("X");
				if (str.Length == 1)
				{
					str = string.Concat("0", str);
				}
				str = string.Concat("=", str);
				stringBuilder.Append(str);
			}
			else
			{
				string str1 = chars[i].ToString();
				byte[] numArray = A_1.GetBytes(str1);
				for (int j = 0; j < (int)numArray.Length; j++)
				{
					string str2 = numArray[j].ToString("X");
					if (str2.Length == 1)
					{
						str2 = string.Concat("0", str2);
					}
					str2 = string.Concat("=", str2);
					stringBuilder.Append(str2);
				}
			}
		}
		return stringBuilder.ToString();
	}

	private static string[] d(string A_0)
	{
		IList<string> strs = new List<string>();
		int num = A_0.IndexOf("\r\n");
		int num1 = 0;
		string str = "";
		while (num > -1)
		{
			str = A_0.Substring(num1, num + 2 - num1);
			num1 = num + 2;
			strs.Add(str);
			num = A_0.IndexOf("\r\n", num1);
		}
		strs.Add(A_0.Substring(num1));
		string[] item = new string[strs.Count];
		for (int i = 0; i < strs.Count; i++)
		{
			item[i] = strs[i];
		}
		return item;
	}

	internal static IList<Mailbox> e(string A_0)
	{
		IList<Mailbox> mailboxes = new List<Mailbox>();
		int num = A_0.IndexOf(";");
		int num1 = A_0.IndexOf(",");
		int num2 = num;
		if (num == -1 && num1 > -1 || num > -1 && num1 > -1 && num1 < num)
		{
			num2 = num1;
		}
		while (num2 > -1)
		{
			int num3 = A_0.IndexOf("\"");
			int num4 = A_0.IndexOf("\"", num3 + 1);
			if (num3 >= num2 || num2 >= num4)
			{
				string str = A_0.Substring(0, num2);
				A_0 = A_0.Substring(num2 + 1);
				mailboxes.Add(new Mailbox(str));
				num = A_0.IndexOf(";");
				num1 = A_0.IndexOf(",");
				num2 = num;
				if ((num != -1 || num1 <= -1) && (num <= -1 || num1 <= -1 || num1 >= num))
				{
					continue;
				}
				num2 = num1;
			}
			else
			{
				num = A_0.IndexOf(";", num4 + 1);
				num1 = A_0.IndexOf(",", num4 + 1);
				num2 = num;
				if ((num != -1 || num1 <= -1) && (num <= -1 || num1 <= -1 || num1 >= num))
				{
					continue;
				}
				num2 = num1;
			}
		}
		mailboxes.Add(new Mailbox(A_0));
		return mailboxes;
	}

	internal static byte[] f(string A_0)
	{
		byte[] numArray = null;
		A_0 = A_0.Replace("=09", "\t");
		A_0 = A_0.Replace("=20", " ");
		A_0 = A_0.Replace("=\r\n", "");
		byte[] bytes = Encoding.UTF8.GetBytes(A_0);
		byte[] numArray1 = new byte[(int)bytes.Length];
		int num = 0;
		int length = 0;
		int length1 = 0;
		byte[] numArray2 = null;
		for (int i = 0; i < (int)bytes.Length; i++)
		{
			if (bytes[i] != 13)
			{
				if (bytes[i] != 10)
				{
					if (i < (int)bytes.Length - 1)
					{
						goto Label0;
					}
					length = (int)bytes.Length;
				}
				else
				{
					length = i + 1;
				}
				if (length <= 1)
				{
					numArray2 = new byte[(int)bytes.Length - length1];
					Array.Copy(bytes, length1, numArray2, 0, (int)bytes.Length - length1);
					length1 = (int)bytes.Length;
				}
				else
				{
					numArray2 = new byte[length - length1];
					Array.Copy(bytes, length1, numArray2, 0, length - length1);
					length1 = length;
				}
				for (int j = 0; j < (int)numArray2.Length; j++)
				{
					byte num1 = numArray2[j];
					if (num1 <= 126)
					{
						if (num1 != 61)
						{
							int num2 = num;
							num = num2 + 1;
							numArray1[num2] = num1;
						}
						else if (j < (int)numArray2.Length - 2)
						{
							int num3 = numArray2[j + 1];
							int num4 = numArray2[j + 2];
							if (num3 > 47 && num3 < 58 || num3 > 64 && num3 < 71 && num4 > 47 && num4 < 58 || num4 > 64 && num4 < 71)
							{
								string str = string.Concat(Convert.ToString((char)num3), char.ToString((char)num4));
								try
								{
									byte num5 = byte.Parse(str, NumberStyles.HexNumber);
									int num6 = num;
									num = num6 + 1;
									numArray1[num6] = num5;
								}
								catch
								{
								}
								j = j + 2;
							}
						}
					}
				}
			}
		Label0:;
		}
		numArray = new byte[num];
		Array.Copy(numArray1, 0, numArray, 0, num);
		return numArray;
	}

	internal static byte[] g(string A_0)
	{
		if (A_0 == null || A_0.Length == 0)
		{
			return new byte[0];
		}
		A_0 = A_0.TrimEnd(new char[] { '.' });
		byte[] numArray = new byte[0];
		try
		{
			numArray = Convert.FromBase64String(A_0);
		}
		catch
		{
			if (!A_0.EndsWith("==") && A_0.EndsWith("="))
			{
				A_0 = string.Concat(A_0, "=");
			}
			else if (!A_0.EndsWith("==") && !A_0.EndsWith("="))
			{
				A_0 = string.Concat(A_0, "==");
			}
			A_0 = A_0.Replace(" ", string.Empty);
			try
			{
				numArray = Convert.FromBase64String(A_0);
			}
			catch
			{
			}
		}
		return numArray;
	}

	internal static byte[] h(string A_0)
	{
		if (A_0 == null || A_0.Length == 0)
		{
			return new byte[0];
		}
		A_0 = A_0.Replace("\r\n", string.Empty);
		A_0 = A_0.TrimEnd(new char[] { '.' });
		byte[] numArray = new byte[0];
		try
		{
			numArray = Convert.FromBase64String(A_0);
		}
		catch
		{
			if (!A_0.EndsWith("==") && A_0.EndsWith("="))
			{
				A_0 = string.Concat(A_0, "=");
			}
			else if (!A_0.EndsWith("==") && !A_0.EndsWith("="))
			{
				A_0 = string.Concat(A_0, "==");
			}
			A_0 = A_0.Replace(" ", string.Empty);
		}
		try
		{
			numArray = Convert.FromBase64String(A_0);
		}
		catch
		{
		}
		return numArray;
	}

	internal static string i(string A_0)
	{
		int length = A_0.Length;
		int num = A_0.Length / 76;
		int num1 = length + num * 2;
		StringBuilder stringBuilder = new StringBuilder(num1);
		int num2 = 76;
		int num3 = 0;
		while (num2 < num1 + 1)
		{
			string str = A_0.Substring(num3, 76);
			stringBuilder.Append(string.Concat(str, "\r\n"));
			num2 = num2 + 78;
			num3 = num3 + 76;
		}
		stringBuilder.Append(A_0.Substring(num3));
		return stringBuilder.ToString();
	}

	internal static string j(string A_0)
	{
		StringBuilder stringBuilder = new StringBuilder(A_0.Length);
		string[] strArrays = o.d(A_0);
		for (int i = 0; i < (int)strArrays.Length; i++)
		{
			if (strArrays[i].Length >= 76)
			{
				string[] strArrays1 = o.c(strArrays[i]);
				string str = "";
				for (int j = 0; j < (int)strArrays1.Length; j++)
				{
					if (str.Length + strArrays1[j].Length >= 76)
					{
						if (str.Length > 0)
						{
							str = string.Concat(str, "=\r\n");
							stringBuilder.Append(str);
							str = "";
						}
						str = string.Concat(str, strArrays1[j]);
					}
					else
					{
						str = string.Concat(str, strArrays1[j]);
					}
				}
				if (str.Length > 0)
				{
					str = string.Concat(str, "=\r\n");
					stringBuilder.Append(str);
				}
			}
			else
			{
				stringBuilder.Append(strArrays[i]);
			}
		}
		return stringBuilder.ToString();
	}

	private static bool k(string A_0)
	{
		if (A_0.IndexOf(" ") > -1)
		{
			return false;
		}
		if (A_0.IndexOf("\t") > -1)
		{
			return false;
		}
		int num = A_0.IndexOf("<");
		if (num == -1)
		{
			return false;
		}
		int num1 = A_0.IndexOf(">", num);
		if (num1 == -1)
		{
			return false;
		}
		int num2 = A_0.IndexOf("@");
		if (num2 != -1 && num2 >= num && num2 <= num1)
		{
			return true;
		}
		return false;
	}

	internal static bool l(string A_0)
	{
		char[] charArray = A_0.ToCharArray();
		for (int i = 0; i < (int)charArray.Length; i++)
		{
			if (charArray[i] > 127)
			{
				return true;
			}
		}
		return false;
	}

	internal static Encoding m(string A_0)
	{
		Encoding uTF8 = Encoding.UTF8;
		if (!string.IsNullOrEmpty(A_0))
		{
			try
			{
				uTF8 = Encoding.GetEncoding(A_0);
			}
			catch
			{
				if (A_0.ToLower().IndexOf("1250") > -1)
				{
					A_0 = "Windows-1250";
				}
				else if (A_0.ToLower().IndexOf("1252") > -1)
				{
					A_0 = "Windows-1252";
				}
				else if (A_0.ToLower().IndexOf("iso8859") > -1)
				{
					A_0 = A_0.Replace("8859", "-8859");
				}
				else if (A_0.ToLower().StartsWith("8859"))
				{
					A_0 = A_0.Replace("8859", "iso-8859");
				}
				try
				{
					uTF8 = Encoding.GetEncoding(A_0);
				}
				catch
				{
				}
			}
		}
		return uTF8;
	}

	internal static string n(string A_0)
	{
		string lower = A_0.ToLower();
		for (int i = 0; i < (int)o.g.Length; i++)
		{
			if (lower == o.g[i])
			{
				return o.f[i];
			}
		}
		return A_0;
	}

	internal static bool o(string A_0)
	{
		string lower = A_0.ToLower();
		for (int i = 0; i < (int)o.g.Length; i++)
		{
			if (lower == o.g[i])
			{
				return true;
			}
		}
		return false;
	}
}