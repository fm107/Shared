﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;

[assembly: AllowPartiallyTrustedCallers]
[assembly: AssemblyCompany("Independentsoft")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright (c) Independentsoft, 2016")]
[assembly: AssemblyDescription("MSG .NET")]
[assembly: AssemblyProduct("MSG .NET")]
[assembly: AssemblyTitle("MSG .NET")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("2.0.320.15784")]
[assembly: CLSCompliant(true)]
[assembly: CompilationRelaxations(8)]
[assembly: ComVisible(true)]
[assembly: Dotfuscator("38978:1:0:4.8.1000.21906", 0)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows=true)]
