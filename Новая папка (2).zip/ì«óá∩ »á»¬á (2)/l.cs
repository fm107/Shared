using System;

internal class l
{
	internal static byte a(f A_0)
	{
		if (A_0 == f.a)
		{
			return (byte)0;
		}
		return (byte)1;
	}

	internal static byte a(i A_0)
	{
		if (A_0 == i.f)
		{
			return (byte)5;
		}
		if (A_0 == i.e)
		{
			return (byte)4;
		}
		if (A_0 == i.d)
		{
			return (byte)3;
		}
		if (A_0 == i.c)
		{
			return (byte)2;
		}
		if (A_0 == i.b)
		{
			return (byte)1;
		}
		return (byte)0;
	}

	internal static i a(byte A_0)
	{
		if (A_0 == 5)
		{
			return i.f;
		}
		if (A_0 == 4)
		{
			return i.e;
		}
		if (A_0 == 3)
		{
			return i.d;
		}
		if (A_0 == 2)
		{
			return i.c;
		}
		if (A_0 == 1)
		{
			return i.b;
		}
		return i.a;
	}

	internal static f b(byte A_0)
	{
		if (A_0 == 0)
		{
			return f.a;
		}
		return f.b;
	}
}