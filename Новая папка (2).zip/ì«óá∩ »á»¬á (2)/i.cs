using System;

internal enum i
{
	a,
	b,
	c,
	d,
	e,
	f
}