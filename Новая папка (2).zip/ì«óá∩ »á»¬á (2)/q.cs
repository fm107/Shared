using Independentsoft.Msg;
using System;
using System.IO;

internal class q
{
	private uint a;

	private PropertyType b;

	private uint c;

	private byte[] d;

	private bool e;

	private bool f = true;

	private bool g = true;

	public q()
	{
	}

	public q(byte[] A_0)
	{
		this.a(A_0);
	}

	private void a(byte[] A_0)
	{
		this.a = BitConverter.ToUInt32(A_0, 0);
		this.b = h.a(this.a);
		uint num = BitConverter.ToUInt32(A_0, 4);
		if (num == 1)
		{
			this.e = true;
		}
		else if (num == 2)
		{
			this.f = true;
		}
		else if (num == 3)
		{
			this.e = true;
			this.f = true;
		}
		else if (num == 4)
		{
			this.g = true;
		}
		else if (num == 5)
		{
			this.e = true;
			this.g = true;
		}
		else if (num == 6)
		{
			this.f = true;
			this.g = true;
		}
		else if (num == 7)
		{
			this.e = true;
			this.f = true;
			this.g = true;
		}
		if (this.b == PropertyType.Integer16)
		{
			this.d = new byte[2];
			Array.Copy(A_0, 8, this.d, 0, (int)this.d.Length);
			return;
		}
		if (this.b == PropertyType.Integer32)
		{
			this.d = new byte[4];
			Array.Copy(A_0, 8, this.d, 0, (int)this.d.Length);
			return;
		}
		if (this.b == PropertyType.Integer64)
		{
			this.d = new byte[8];
			Array.Copy(A_0, 8, this.d, 0, (int)this.d.Length);
			return;
		}
		if (this.b == PropertyType.Floating32)
		{
			this.d = new byte[4];
			Array.Copy(A_0, 8, this.d, 0, (int)this.d.Length);
			return;
		}
		if (this.b == PropertyType.Floating64)
		{
			this.d = new byte[8];
			Array.Copy(A_0, 8, this.d, 0, (int)this.d.Length);
			return;
		}
		if (this.b == PropertyType.Currency)
		{
			this.d = new byte[8];
			Array.Copy(A_0, 8, this.d, 0, (int)this.d.Length);
			return;
		}
		if (this.b == PropertyType.FloatingTime)
		{
			this.d = new byte[8];
			Array.Copy(A_0, 8, this.d, 0, (int)this.d.Length);
			return;
		}
		if (this.b == PropertyType.ErrorCode)
		{
			this.d = new byte[4];
			Array.Copy(A_0, 8, this.d, 0, (int)this.d.Length);
			return;
		}
		if (this.b == PropertyType.Boolean)
		{
			this.d = new byte[2];
			Array.Copy(A_0, 8, this.d, 0, (int)this.d.Length);
			return;
		}
		if (this.b != PropertyType.Time)
		{
			this.c = BitConverter.ToUInt32(A_0, 8);
			return;
		}
		this.d = new byte[8];
		Array.Copy(A_0, 8, this.d, 0, (int)this.d.Length);
	}

	internal uint a()
	{
		return this.a;
	}

	internal void a(uint A_0)
	{
		this.a = A_0;
	}

	internal void a(PropertyType A_0)
	{
		this.b = A_0;
	}

	internal void a(bool A_0)
	{
		this.g = A_0;
	}

	public byte[] b()
	{
		byte[] numArray = new byte[16];
		MemoryStream memoryStream = new MemoryStream(numArray);
		memoryStream.Write(BitConverter.GetBytes(this.a), 0, 4);
		uint num = 0;
		if (this.e)
		{
			num++;
		}
		if (this.f)
		{
			num = num + 2;
		}
		if (this.g)
		{
			num = num + 4;
		}
		memoryStream.Write(BitConverter.GetBytes(num), 0, 4);
		if (this.c > 0)
		{
			memoryStream.Write(BitConverter.GetBytes(this.c), 0, 4);
		}
		else if (this.d != null && (int)this.d.Length > 0)
		{
			memoryStream.Write(this.d, 0, (int)this.d.Length);
		}
		return numArray;
	}

	internal void b(bool A_0)
	{
		this.f = A_0;
	}

	internal void b(uint A_0)
	{
		this.c = A_0;
	}

	internal void b(byte[] A_0)
	{
		this.d = A_0;
	}

	internal byte[] c()
	{
		return this.d;
	}

	internal PropertyType d()
	{
		return this.b;
	}

	internal uint e()
	{
		return this.c;
	}
}