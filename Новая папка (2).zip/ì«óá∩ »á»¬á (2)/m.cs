using Independentsoft.Msg;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

internal class m
{
	internal static DateTime a(int A_0)
	{
		DateTime dateTime;
		if (A_0 <= 0)
		{
			return DateTime.MinValue;
		}
		DateTime dateTime1 = new DateTime(1601, 1, 1);
		try
		{
			dateTime = dateTime1.AddMinutes((double)A_0);
		}
		catch (Exception exception)
		{
			return DateTime.MinValue;
		}
		return dateTime;
	}

	internal static string a(uint A_0, byte[] A_1)
	{
		if (A_1 == null || (int)A_1.Length != 16)
		{
			return A_0.ToString();
		}
		ulong num = BitConverter.ToUInt64(A_1, 0);
		ulong num1 = BitConverter.ToUInt64(A_1, 8);
		string[] str = new string[] { A_0.ToString(), "-", num.ToString(), "-", num1.ToString() };
		return string.Concat(str);
	}

	internal static string a(string A_0, byte[] A_1)
	{
		if (A_1 == null || (int)A_1.Length != 16)
		{
			return A_0;
		}
		ulong num = BitConverter.ToUInt64(A_1, 0);
		ulong num1 = BitConverter.ToUInt64(A_1, 8);
		string[] a0 = new string[] { A_0, "-", num.ToString(), "-", num1.ToString() };
		return string.Concat(a0);
	}

	internal static int a(IList<c> A_0, c A_1)
	{
		if (A_0.Count == 0)
		{
			return -1;
		}
		bool flag = false;
		for (int i = 0; i < A_0.Count; i++)
		{
			c item = A_0[i];
			if (A_1.d() != null && item.d() == A_1.d())
			{
				flag = true;
			}
			else if (item.a() == A_1.a() && A_1.c() == g.a)
			{
				flag = true;
			}
			if (flag)
			{
				bool flag1 = true;
				if (item.b() == null || A_1.b() == null || (int)item.b().Length != (int)A_1.b().Length)
				{
					flag1 = false;
				}
				else
				{
					for (int j = 0; j < (int)item.b().Length; j++)
					{
						if (item.b()[j] != A_1.b()[j])
						{
							flag1 = false;
						}
					}
				}
				if (flag1)
				{
					return i;
				}
			}
		}
		return -1;
	}

	internal static string[] a(byte[] A_0, Encoding A_1)
	{
		unsafe
		{
			if (A_0 == null || (int)A_0.Length < 4)
			{
				return new string[0];
			}
			uint num = BitConverter.ToUInt32(A_0, 0);
			if (num > 65535)
			{
				return new string[0];
			}
			string[] str = new string[num];
			for (int i = 0; (long)i < (ulong)num; i++)
			{
				int num1 = BitConverter.ToInt32(A_0, i * 4 + 4);
				int length = (int)A_0.Length;
				if ((long)i < (ulong)(num - 1))
				{
					length = BitConverter.ToInt32(A_0, i * 4 + 8);
				}
				if (length >= num1)
				{
					str[i] = A_1.GetString(A_0, num1, length - num1);
				}
			}
			return str;
		}
	}

	internal static uint a(byte[] A_0, PropertyType A_1, Encoding A_2)
	{
		if (A_0 == null && (A_1 == PropertyType.String || A_1 == PropertyType.String8))
		{
			return (uint)1;
		}
		if (A_0 == null || A_1 != PropertyType.String && A_1 != PropertyType.String8)
		{
			if (A_0 == null)
			{
				return (uint)0;
			}
			return (uint)A_0.Length;
		}
		return (uint)((int)A_0.Length + (int)A_2.GetBytes("\0").Length);
	}

	internal static uint a(PropertyType A_0)
	{
		if (A_0 == PropertyType.Integer16)
		{
			return (uint)2;
		}
		if (A_0 == PropertyType.Integer32)
		{
			return (uint)3;
		}
		if (A_0 == PropertyType.Floating32)
		{
			return (uint)4;
		}
		if (A_0 == PropertyType.Floating64)
		{
			return (uint)5;
		}
		if (A_0 == PropertyType.Currency)
		{
			return (uint)6;
		}
		if (A_0 == PropertyType.FloatingTime)
		{
			return (uint)7;
		}
		if (A_0 == PropertyType.Boolean)
		{
			return (uint)11;
		}
		if (A_0 == PropertyType.Object)
		{
			return (uint)13;
		}
		if (A_0 == PropertyType.Integer64)
		{
			return (uint)20;
		}
		if (A_0 == PropertyType.String8)
		{
			return (uint)30;
		}
		if (A_0 == PropertyType.String)
		{
			return (uint)31;
		}
		if (A_0 == PropertyType.Time)
		{
			return (uint)64;
		}
		if (A_0 == PropertyType.Guid)
		{
			return (uint)72;
		}
		if (A_0 == PropertyType.Binary)
		{
			return (uint)258;
		}
		if (A_0 == PropertyType.MultipleInteger16)
		{
			return (uint)4098;
		}
		if (A_0 == PropertyType.MultipleInteger32)
		{
			return (uint)4099;
		}
		if (A_0 == PropertyType.MultipleFloating32)
		{
			return (uint)4100;
		}
		if (A_0 == PropertyType.MultipleFloating64)
		{
			return (uint)4101;
		}
		if (A_0 == PropertyType.MultipleCurrency)
		{
			return (uint)4102;
		}
		if (A_0 == PropertyType.MultipleFloatingTime)
		{
			return (uint)4103;
		}
		if (A_0 == PropertyType.MultipleInteger64)
		{
			return (uint)4116;
		}
		if (A_0 == PropertyType.MultipleString8)
		{
			return (uint)4126;
		}
		if (A_0 == PropertyType.MultipleString)
		{
			return (uint)4127;
		}
		if (A_0 == PropertyType.MultipleTime)
		{
			return (uint)4160;
		}
		if (A_0 == PropertyType.MultipleGuid)
		{
			return (uint)4168;
		}
		if (A_0 == PropertyType.MultipleBinary)
		{
			return (uint)4354;
		}
		return (uint)30;
	}

	private static IDictionary<string, Encoding> a(string A_0)
	{
		IDictionary<string, Encoding> strs = new Dictionary<string, Encoding>();
		int num = A_0.IndexOf("{\\fonttbl");
		if (num > 0)
		{
			int num1 = A_0.IndexOf("}}", num);
			if (num1 > 0)
			{
				string str = A_0.Substring(num + 8, num1 - num);
				StringReader stringReader = new StringReader(str);
				string str1 = "";
				while (true)
				{
					string str2 = stringReader.ReadLine();
					str1 = str2;
					if (str2 == null)
					{
						break;
					}
					int num2 = str1.IndexOf("{");
					if (num2 > -1)
					{
						int num3 = str1.IndexOf("}", num2);
						if (num3 > -1)
						{
							str1 = str1.Substring(num2 + 1, num3 - num2 - 1);
							char[] chrArray = new char[] { ' ', '\\' };
							string[] strArrays = str1.Split(chrArray);
							if ((int)strArrays.Length > 1 && strArrays[1].StartsWith("f"))
							{
								string str3 = strArrays[1];
								Encoding encoding = null;
								for (int i = 2; i < (int)strArrays.Length; i++)
								{
									if (strArrays[i] == "fcharset128")
									{
										encoding = Encoding.GetEncoding(932);
									}
									else if (strArrays[i] == "fcharset129")
									{
										encoding = Encoding.GetEncoding("ks_c_5601-1987");
									}
									else if (strArrays[i] == "fcharset134")
									{
										encoding = Encoding.GetEncoding("gb2312");
									}
									else if (strArrays[i] == "fcharset136")
									{
										encoding = Encoding.GetEncoding("big5");
									}
									else if (strArrays[i] == "fcharset161")
									{
										encoding = Encoding.GetEncoding("windows-1253");
									}
									else if (strArrays[i] == "fcharset162")
									{
										encoding = Encoding.GetEncoding("windows-1254");
									}
									else if (strArrays[i] == "fcharset163")
									{
										encoding = Encoding.GetEncoding("windows-1258");
									}
									else if (strArrays[i] == "fcharset177")
									{
										encoding = Encoding.GetEncoding("windows-1255");
									}
									else if (strArrays[i] == "fcharset178")
									{
										encoding = Encoding.GetEncoding("windows-1256");
									}
									else if (strArrays[i] == "fcharset186")
									{
										encoding = Encoding.GetEncoding("windows-1257");
									}
									else if (strArrays[i] == "fcharset204")
									{
										encoding = Encoding.GetEncoding("windows-1251");
									}
									else if (strArrays[i] == "fcharset222")
									{
										encoding = Encoding.GetEncoding("windows-874");
									}
									else if (strArrays[i] == "fcharset238")
									{
										encoding = Encoding.GetEncoding("windows-1250");
									}
								}
								if (!strs.ContainsKey(str3))
								{
									strs.Add(str3, encoding);
								}
							}
						}
					}
				}
			}
		}
		return strs;
	}

	private static Encoding a(string A_0, IDictionary<string, Encoding> A_1, Encoding A_2, int A_3)
	{
		string str = A_0.Substring(0, A_3);
		Encoding a2 = A_2;
		int num = -1;
		foreach (string key in A_1.Keys)
		{
			int num1 = str.LastIndexOf(string.Concat("\\", key));
			if (num1 <= -1 || num1 <= num)
			{
				continue;
			}
			a2 = (A_1[key] != null ? A_1[key] : A_2);
			num = num1;
		}
		return a2;
	}

	internal static byte[] a(byte[] A_0)
	{
		byte[] a0;
		byte[] numArray;
		int num;
		byte[] bytes = Encoding.ASCII.GetBytes("{\\rtf1\\ansi\\mac\\deff0\\deftab720{\\fonttbl;}{\\f0\\fnil \\froman \\fswiss \\fmodern \\fscript \\fdecor MS Sans SerifSymbolArialTimes New RomanCourier{\\colortbl\\red0\\green0\\blue0\n\r\\par \\pard\\plain\\f0\\fs20\\b\\i\\u\\tab\\tx");
		int num1 = 0;
		int length = 0;
		if (A_0 == null || (int)A_0.Length < 16)
		{
			throw new ArgumentException("Invalid PR_RTF_COMPRESSION header");
		}
		int num2 = (int)m.a(A_0, num1);
		num1 = num1 + 4;
		int length1 = (int)m.a(A_0, num1);
		num1 = num1 + 4;
		int num3 = (int)m.a(A_0, num1);
		num1 = num1 + 4;
		m.a(A_0, num1);
		num1 = num1 + 4;
		if (num2 != (int)A_0.Length - 4)
		{
			throw new ArgumentException("Invalid PR_RTF_COMPRESSION size.");
		}
		if (num3 != 1095517517)
		{
			if (num3 != 1967544908)
			{
				throw new ArgumentException("Wrong magic number.");
			}
			a0 = new byte[(int)bytes.Length + length1];
			Array.Copy(bytes, 0, a0, 0, (int)bytes.Length);
			length = (int)bytes.Length;
			int num4 = 0;
			int num5 = 0;
			while (true)
			{
				if (length < (int)a0.Length)
				{
					int num6 = num4;
					num4 = num6 + 1;
					if (num6 % 8 == 0)
					{
						int num7 = num1;
						num1 = num7 + 1;
						num = m.b(A_0, num7);
					}
					else
					{
						num = num5 >> 1;
					}
					num5 = num;
					if ((num5 & 1) != 1)
					{
						try
						{
							int num8 = length;
							length = num8 + 1;
							int num9 = num1;
							num1 = num9 + 1;
							a0[num8] = A_0[num9];
						}
						catch (IndexOutOfRangeException indexOutOfRangeException)
						{
							numArray = new byte[0];
							break;
						}
					}
					else
					{
						int num10 = num1;
						num1 = num10 + 1;
						int num11 = m.b(A_0, num10);
						int num12 = num1;
						num1 = num12 + 1;
						int num13 = m.b(A_0, num12);
						num11 = num11 << 4 | num13 >> 4;
						num13 = (num13 & 15) + 2;
						num11 = length / 4096 * 4096 + num11;
						if (num11 >= length)
						{
							num11 = num11 - 4096;
						}
						int num14 = num11 + num13;
						while (num11 < num14)
						{
							try
							{
								int num15 = length;
								length = num15 + 1;
								int num16 = num11;
								num11 = num16 + 1;
								a0[num15] = a0[num16];
							}
							catch (IndexOutOfRangeException indexOutOfRangeException1)
							{
								numArray = new byte[0];
								return numArray;
							}
						}
					}
				}
				else
				{
					A_0 = a0;
					a0 = new byte[length1];
					Array.Copy(A_0, (int)bytes.Length, a0, 0, length1);
					return a0;
				}
			}
			return numArray;
		}
		else
		{
			if (length1 > (int)A_0.Length - num1)
			{
				length1 = (int)A_0.Length - num1;
			}
			a0 = new byte[length1];
			Array.Copy(A_0, num1, a0, length, length1);
		}
		return a0;
	}

	internal static Encoding a(long A_0)
	{
		Encoding @default = Encoding.Default;
		if (A_0 > (long)0)
		{
			try
			{
				@default = Encoding.GetEncoding((int)A_0);
			}
			catch
			{
				@default = Encoding.UTF8;
			}
		}
		return @default;
	}

	private static long a(byte[] A_0, int A_1)
	{
		return (long)((long)(A_0[A_1] & 255 | (A_0[A_1 + 1] & 255) << 8 | (A_0[A_1 + 2] & 255) << 16 | (A_0[A_1 + 3] & 255) << 24) & (ulong)-1);
	}

	private static Encoding b(string A_0)
	{
		Encoding encoding = Encoding.GetEncoding(1252);
		int num = A_0.IndexOf("ansicpg");
		int num1 = A_0.IndexOf("\\", num + 7);
		if (num > -1 && num1 > -1)
		{
			string str = A_0.Substring(num + 7, num1 - num - 7);
			try
			{
				encoding = Encoding.GetEncoding(int.Parse(str));
			}
			catch
			{
			}
		}
		return encoding;
	}

	internal static a b(byte[] A_0)
	{
		string str = Encoding.UTF8.GetString(A_0, 0, (int)A_0.Length);
		Encoding encoding = m.b(str);
		IDictionary<string, Encoding> strs = m.a(str);
		str = str.Replace("\n\r{", "{");
		str = str.Replace("{\\*\\htmltag64}", "");
		string str1 = null;
		int num = str.IndexOf("{\\*\\htmltag");
		if (num > -1)
		{
			str1 = str.Substring(num);
			for (int i = str1.IndexOf("\\'"); i > -1; i = str1.IndexOf("\\'"))
			{
				Encoding encoding1 = m.a(str1, strs, encoding, i);
				int num1 = str1.IndexOf("\\'", i + 2);
				string str2 = null;
				byte[] numArray = null;
				try
				{
					if (num1 != i + 4)
					{
						str2 = str1.Substring(i, 4);
						byte num2 = Convert.ToByte(str2.Substring(2), 16);
						numArray = new byte[] { num2 };
					}
					else
					{
						str2 = str1.Substring(i, 8);
						string str3 = str2.Substring(2, 2);
						string str4 = str2.Substring(6, 2);
						byte num3 = Convert.ToByte(str3, 16);
						byte num4 = Convert.ToByte(str4, 16);
						numArray = new byte[] { num3, num4 };
					}
					if (numArray != null && str2 != null)
					{
						string str5 = encoding1.GetString(numArray, 0, (int)numArray.Length);
						str1 = str1.Replace(str2, str5);
					}
				}
				catch (FormatException formatException)
				{
					str1 = str1.Replace(str2, str2.Substring(1));
				}
				catch (ArgumentException argumentException)
				{
					str1 = str1.Replace(str2, str2.Substring(1));
				}
			}
			int num5 = 0;
			while (num5 > -1)
			{
				num5 = str1.IndexOf("{\\*\\htmltag", 0);
				if (num5 <= -1)
				{
					continue;
				}
				int num6 = str1.IndexOf("}", num5);
				int num7 = str1.IndexOf(" ", num5);
				int num8 = str1.IndexOf("<", num5);
				if (num8 > -1 && num6 > -1 && num8 < num6 && num8 < num7)
				{
					string str6 = str1.Substring(num5, num6 - num5);
					string str7 = str1.Substring(num8, num6 - num8);
					str1 = str1.Replace(str6, str7);
				}
				else if (num7 <= -1 || num6 <= -1 || num7 >= num6)
				{
					string str8 = str1.Substring(num5, num6 - num5);
					str1 = str1.Replace(str8, "");
				}
				else
				{
					string str9 = str1.Substring(num5, num6 - num5);
					string str10 = str1.Substring(num7 + 1, num6 - num7 - 1);
					str1 = str1.Replace(str9, str10);
				}
			}
			IList<int> nums = new List<int>();
			int num9 = 0;
			int num10 = 0;
			while (num9 > -1 && num10 > -1)
			{
				num9 = str1.IndexOf("\\htmlrtf", num9);
				if (num9 <= -1)
				{
					num10 = -1;
				}
				else
				{
					num10 = str1.IndexOf("\\htmlrtf0", num9);
					int num11 = (num10 == str1.IndexOf("\\htmlrtf0 ", num9) ? 10 : 9);
					if (num10 <= -1)
					{
						continue;
					}
					nums.Add(num9);
					nums.Add(num10 + num11);
					num9 = num10 + num11;
				}
			}
			StringBuilder stringBuilder = new StringBuilder(str1.Length);
			int num12 = 0;
			for (int j = 0; j < nums.Count - 1; j = j + 2)
			{
				int item = nums[j];
				int item1 = nums[j + 1];
				stringBuilder.Append(str1.Substring(num12, item - num12));
				num12 = item1;
			}
			stringBuilder.Append(str1.Substring(num12, str1.Length - num12));
			str1 = stringBuilder.ToString();
			IList<int> nums1 = new List<int>();
			int num13 = 0;
			int num14 = 0;
			while (num13 > -1 && num14 > -1)
			{
				num13 = str1.IndexOf("{\\pntext", num13);
				if (num13 <= -1)
				{
					num14 = -1;
				}
				else
				{
					num14 = str1.IndexOf("}", num13);
					if (num14 <= -1)
					{
						continue;
					}
					nums1.Add(num13);
					nums1.Add(num14 + 1);
					num13 = num14 + 1;
				}
			}
			stringBuilder = new StringBuilder(str1.Length);
			num12 = 0;
			for (int k = 0; k < nums1.Count - 1; k = k + 2)
			{
				int item2 = nums1[k];
				int item3 = nums1[k + 1];
				stringBuilder.Append(str1.Substring(num12, item2 - num12));
				num12 = item3;
			}
			stringBuilder.Append(str1.Substring(num12, str1.Length - num12));
			str1 = stringBuilder.ToString();
			IList<int> nums2 = new List<int>();
			int num15 = str1.IndexOf("{\\*\\mhtmltag");
			int num16 = 0;
			int num17 = num15;
			while (num15 > -1)
			{
				int num18 = str1.IndexOf("{", num17 + 1);
				int num19 = str1.IndexOf("}", num17 + 1);
				if (num19 == -1)
				{
					break;
				}
				if (num16 == 0 && (num19 < num18 || num18 == -1))
				{
					nums2.Add(num15);
					nums2.Add(num19);
					num17 = num19;
					num15 = str1.IndexOf("{\\*\\mhtmltag", num17 + 1);
					num17 = num15;
				}
				else if (num16 <= 0 || num19 >= num18 && num18 != -1)
				{
					if (num18 >= num19)
					{
						continue;
					}
					num16++;
					num17 = num18;
				}
				else
				{
					num16--;
					num17 = num19;
				}
			}
			stringBuilder = new StringBuilder(str1.Length);
			num12 = 0;
			for (int l = 0; l < nums2.Count - 1; l = l + 2)
			{
				int item4 = nums2[l];
				int item5 = nums2[l + 1];
				stringBuilder.Append(str1.Substring(num12, item4 - num12));
				num12 = item5;
			}
			stringBuilder.Append(str1.Substring(num12, str1.Length - num12));
			str1 = stringBuilder.ToString();
			str1 = str1.Replace("\\{", "{");
			str1 = str1.Replace("\\}", "%x7D");
			str1 = str1.Replace("}", "");
			str1 = str1.Replace("%x7D", "}");
			str1 = str1.Replace("\\\\", "\\");
			str1 = str1.Replace("\\line", "");
			str1 = str1.Replace("\\pard", "");
			str1 = str1.Replace("\\par", "");
			str1 = str1.Replace("\\tab", "\t");
			str1 = str1.Replace("\\plain", "");
			str1 = str1.Replace("\\fs20", "");
			str1 = str1.Replace("\\f4", "");
			str1 = str1.Replace("\\f5", "");
			str1 = str1.Replace("\\f6", "");
			str1 = str1.Replace("\\objattph", "");
			str1 = str1.Replace("\\li360", "");
			str1 = str1.Replace("\\li720", "");
			str1 = str1.Replace("\\li1440", "");
			str1 = str1.Replace("\\li1080", "");
			str1 = str1.Replace("\\fi-360", "");
			str1 = str1.Replace("\\fi-720", "");
			str1 = str1.Replace("\\rtlch", "");
			str1 = str1.Replace("\\ltrch", "");
			str1 = str1.Replace("\\sb100", "");
			str1 = str1.Replace("\\intbl", "");
			str1 = str1.Replace("\\cbpat1", "");
			str1 = str1.Replace("\\cbpat2", "");
			str1 = str1.Replace("\\cbpat3", "");
			str1 = str1.Replace("\\cbpat4", "");
			str1 = str1.Replace("\\cbpat5", "");
			str1 = str1.Replace("\\cbpat6", "");
			str1 = str1.Replace("\\cbpat7", "");
			str1 = str1.Replace("\\cbpat8", "");
			str1 = str1.Replace("\\sb90", "");
			str1 = str1.Replace("\\sb150", "");
			str1 = str1.Replace("\\sb240", "");
			str1 = str1.Replace("\\qc", "");
			str1 = str1.Replace("\\qr", "");
			str1 = str1.Replace("\\fs18", "");
			str1 = str1.Replace("\\b0", "");
			str1 = str1.Replace("\\b", "");
			str1 = str1.Replace("\\protect", "");
			int num20 = 0;
			int num21 = 0;
			while (num20 > -1)
			{
				num20 = str1.IndexOf("\\u", num21);
				if (num20 <= -1)
				{
					continue;
				}
				string str11 = str1.Substring(num20, 8);
				string str12 = str11.Substring(2, 4);
				try
				{
					char chr = (char)int.Parse(str12);
					str1 = str1.Replace(str11, chr.ToString());
				}
				catch (FormatException formatException1)
				{
					str1 = str1.Replace(str11, str11.Substring(1));
				}
				num21 = num20 + 8;
			}
		}
		if (str1 == null)
		{
			return null;
		}
		return new a(str1, encoding);
	}

	private static int b(byte[] A_0, int A_1)
	{
		return A_0[A_1] & 255;
	}

	internal static byte[] c(string A_0)
	{
		string[] strArrays = A_0.Split(new char[] { ';' });
		MemoryStream memoryStream = new MemoryStream();
		for (int i = 0; i < (int)strArrays.Length; i++)
		{
			byte[] numArray = new byte[] { 0, 0, 0, 0, 129, 43, 31, 164, 190, 163, 16, 25, 157, 110, 0, 221, 1, 15, 84, 2, 0, 0, 1, 128 };
			byte[] bytes = Encoding.Unicode.GetBytes(string.Concat(strArrays[i], "\0SMTP\0", strArrays[i], "\0"));
			byte[] numArray1 = new byte[2];
			int length = (int)numArray.Length + (int)bytes.Length;
			memoryStream.Write(BitConverter.GetBytes(length), 0, 4);
			memoryStream.Write(numArray, 0, (int)numArray.Length);
			memoryStream.Write(bytes, 0, (int)bytes.Length);
			memoryStream.Write(numArray1, 0, (int)numArray1.Length);
		}
		byte[] numArray2 = new byte[checked((IntPtr)((long)8 + memoryStream.Position))];
		int num = (int)strArrays.Length;
		int length1 = (int)numArray2.Length - 8;
		Array.Copy(BitConverter.GetBytes(num), 0, numArray2, 0, 4);
		Array.Copy(BitConverter.GetBytes(length1), 0, numArray2, 4, 4);
		Array.Copy(memoryStream.GetBuffer(), (long)0, numArray2, (long)8, memoryStream.Position);
		return numArray2;
	}
}