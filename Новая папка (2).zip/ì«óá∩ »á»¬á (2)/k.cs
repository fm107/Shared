using Independentsoft.Email.Mime;
using System;

internal class k
{
	internal static string a(HeaderEncoding A_0)
	{
		if (A_0 == HeaderEncoding.QuotedPrintable)
		{
			return "Q";
		}
		return "B";
	}

	internal static string a(ContentTransferEncoding A_0)
	{
		if (A_0 == ContentTransferEncoding.Base64)
		{
			return "base64";
		}
		if (A_0 == ContentTransferEncoding.QuotedPrintable)
		{
			return "quoted-printable";
		}
		if (A_0 == ContentTransferEncoding.EightBit)
		{
			return "8bit";
		}
		if (A_0 == ContentTransferEncoding.Binary)
		{
			return "binary";
		}
		return "7bit";
	}

	internal static string a(ContentDispositionType A_0)
	{
		if (A_0 == ContentDispositionType.Inline)
		{
			return "inline";
		}
		return "attachment";
	}

	internal static ContentDispositionType a(string A_0)
	{
		if (A_0 == null)
		{
			return ContentDispositionType.Attachment;
		}
		A_0 = A_0.ToLower().Trim();
		if (A_0 == "inline")
		{
			return ContentDispositionType.Inline;
		}
		return ContentDispositionType.Attachment;
	}

	internal static string a(StandardHeader A_0)
	{
		if (A_0 == StandardHeader.ResentDate)
		{
			return "Resent-Date";
		}
		if (A_0 == StandardHeader.ResentFrom)
		{
			return "Resent-From";
		}
		if (A_0 == StandardHeader.ResentSender)
		{
			return "Resent-Sender";
		}
		if (A_0 == StandardHeader.ResentTo)
		{
			return "Resent-To";
		}
		if (A_0 == StandardHeader.ResentCc)
		{
			return "Resent-Cc";
		}
		if (A_0 == StandardHeader.ResentBcc)
		{
			return "Resent-Bcc";
		}
		if (A_0 == StandardHeader.ResentMessageID)
		{
			return "Resent-Message-ID";
		}
		if (A_0 == StandardHeader.From)
		{
			return "From";
		}
		if (A_0 == StandardHeader.Sender)
		{
			return "Sender";
		}
		if (A_0 == StandardHeader.ReplyTo)
		{
			return "Reply-To";
		}
		if (A_0 == StandardHeader.To)
		{
			return "To";
		}
		if (A_0 == StandardHeader.Cc)
		{
			return "Cc";
		}
		if (A_0 == StandardHeader.Bcc)
		{
			return "Bcc";
		}
		if (A_0 == StandardHeader.MessageID)
		{
			return "Message-ID";
		}
		if (A_0 == StandardHeader.InReplyTo)
		{
			return "In-Reply-To";
		}
		if (A_0 == StandardHeader.References)
		{
			return "References";
		}
		if (A_0 == StandardHeader.Subject)
		{
			return "Subject";
		}
		if (A_0 == StandardHeader.Comments)
		{
			return "Comments";
		}
		if (A_0 == StandardHeader.Keywords)
		{
			return "Keywords";
		}
		if (A_0 == StandardHeader.Date)
		{
			return "Date";
		}
		if (A_0 == StandardHeader.ReturnPath)
		{
			return "Return-Path";
		}
		if (A_0 == StandardHeader.Received)
		{
			return "Received";
		}
		if (A_0 == StandardHeader.MimeVersion)
		{
			return "MIME-Version";
		}
		if (A_0 == StandardHeader.ContentType)
		{
			return "Content-Type";
		}
		if (A_0 == StandardHeader.ContentID)
		{
			return "Content-ID";
		}
		if (A_0 == StandardHeader.ContentTransferEncoding)
		{
			return "Content-Transfer-Encoding";
		}
		if (A_0 == StandardHeader.ContentDescription)
		{
			return "Content-Description";
		}
		if (A_0 == StandardHeader.ContentDisposition)
		{
			return "Content-Disposition";
		}
		if (A_0 == StandardHeader.ContentLocation)
		{
			return "Content-Location";
		}
		return "ContentLength";
	}

	internal static ContentTransferEncoding b(string A_0)
	{
		if (A_0 == null)
		{
			return ContentTransferEncoding.SevenBit;
		}
		A_0 = A_0.ToLower();
		if (A_0 == "base64")
		{
			return ContentTransferEncoding.Base64;
		}
		if (A_0 == "quoted-printable")
		{
			return ContentTransferEncoding.QuotedPrintable;
		}
		if (A_0 == "8bit")
		{
			return ContentTransferEncoding.EightBit;
		}
		if (A_0 == "binary")
		{
			return ContentTransferEncoding.Binary;
		}
		return ContentTransferEncoding.SevenBit;
	}
}