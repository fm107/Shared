using System;

namespace Independentsoft.Email.Mime
{
	/// <summary>
	/// Represents a mailbox.
	/// </summary>
	public class Mailbox
	{
		private string a;

		private string b;

		/// <summary>
		/// Gets or sets email address.
		/// </summary>
		public string EmailAddress
		{
			get
			{
				return this.a;
			}
			set
			{
				this.a = value;
			}
		}

		/// <summary>
		/// Gets or sets display name.
		/// </summary>
		public string Name
		{
			get
			{
				return this.b;
			}
			set
			{
				this.b = value;
			}
		}

		/// <summary>
		/// Initializes a new instance of the Mailbox.
		/// </summary>
		public Mailbox()
		{
		}

		/// <summary>
		/// Initializes a new instance of the Mailbox.
		/// </summary>
		/// <param name="emailAddress">Email address of mailbox owner.</param>
		/// <param name="name">Name of mailbox owner.</param>
		public Mailbox(string emailAddress, string name)
		{
			this.a = emailAddress;
			this.b = name;
		}

		/// <summary>
		/// Initializes a new instance of the Mailbox.
		/// </summary>
		/// <param name="mailbox">Email address and name of mailbox owner.</param>
		public Mailbox(string mailbox)
		{
			this.a(mailbox);
		}

		internal void a(string A_0)
		{
			if (A_0 != null)
			{
				A_0 = A_0.Trim();
				A_0 = A_0.Replace("\t", " ");
				int num = A_0.LastIndexOf("<");
				int num1 = A_0.LastIndexOf(">");
				int num2 = A_0.LastIndexOf(" ");
				string a0 = null;
				string str = null;
				if (num > -1 && num1 > num)
				{
					str = A_0.Substring(0, num);
					a0 = A_0.Substring(num + 1, num1 - num - 1);
				}
				else if (num2 != -1)
				{
					str = A_0.Substring(0, num2);
					a0 = A_0.Substring(num2 + 1);
				}
				else
				{
					a0 = A_0;
				}
				if (str != null)
				{
					char[] chrArray = new char[] { ' ', '\"' };
					str = str.Trim(chrArray);
				}
				this.a = a0;
				this.b = str;
			}
		}

		/// <summary>
		/// Returns a String that represents the current Mailbox.
		/// </summary>
		/// <returns></returns>
		public override string ToString()
		{
			string str = null;
			string str1 = null;
			if (this.b != null && this.b.Length > 0)
			{
				str = string.Concat("\"", this.b.Trim(), "\" ");
			}
			if (this.a != null && this.a.Length > 0)
			{
				str1 = string.Concat("<", this.a.Trim(), ">");
			}
			if (str == null)
			{
				return str1;
			}
			return string.Concat(str, " ", str1);
		}
	}
}