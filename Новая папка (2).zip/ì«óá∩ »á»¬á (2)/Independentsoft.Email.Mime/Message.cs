using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace Independentsoft.Email.Mime
{
	/// <summary>
	/// Class Message.
	/// </summary>
	public class Message
	{
		private HeaderList a = new HeaderList();

		private BodyPartList b = new BodyPartList();

		private string c;

		private Message d;

		private Independentsoft.Email.Mime.HeaderEncoding e;

		private string f = "utf-8";

		private IList<Mailbox> g = new List<Mailbox>();

		private IList<Mailbox> h = new List<Mailbox>();

		private IList<Mailbox> i = new List<Mailbox>();

		private IList<Mailbox> j = new List<Mailbox>();

		/// <summary>
		/// Gets the BCC.
		/// </summary>
		/// <value>The BCC.</value>
		public IList<Mailbox> Bcc
		{
			get
			{
				return this.i;
			}
		}

		/// <summary>
		/// Gets or sets the body.
		/// </summary>
		/// <value>The body.</value>
		public string Body
		{
			get
			{
				return this.c;
			}
			set
			{
				this.c = value;
			}
		}

		/// <summary>
		/// Gets the body parts.
		/// </summary>
		/// <value>The body parts.</value>
		public BodyPartList BodyParts
		{
			get
			{
				return this.b;
			}
		}

		/// <summary>
		/// Gets the cc.
		/// </summary>
		/// <value>The cc.</value>
		public IList<Mailbox> Cc
		{
			get
			{
				return this.h;
			}
		}

		/// <summary>
		/// Gets or sets the comments.
		/// </summary>
		/// <value>The comments.</value>
		public string Comments
		{
			get
			{
				Header item = this.a[StandardHeader.Comments];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return item.Value;
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.Comments);
					return;
				}
				this.a.Remove(StandardHeader.Comments);
				Header header = new Header(StandardHeader.Comments, value);
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the content description.
		/// </summary>
		/// <value>The content description.</value>
		public string ContentDescription
		{
			get
			{
				Header item = this.a[StandardHeader.ContentDescription];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return item.Value;
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.ContentDescription);
					return;
				}
				this.a.Remove(StandardHeader.ContentDescription);
				Header header = new Header(StandardHeader.ContentDescription, value);
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the content disposition.
		/// </summary>
		/// <value>The content disposition.</value>
		public Independentsoft.Email.Mime.ContentDisposition ContentDisposition
		{
			get
			{
				Header item = this.a[StandardHeader.ContentDisposition];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return new Independentsoft.Email.Mime.ContentDisposition(item.Value);
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.ContentDisposition);
					return;
				}
				this.a.Remove(StandardHeader.ContentDisposition);
				Header header = new Header(StandardHeader.ContentDisposition, value.ToString());
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the content identifier.
		/// </summary>
		/// <value>The content identifier.</value>
		public string ContentID
		{
			get
			{
				Header item = this.a[StandardHeader.ContentID];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return item.Value;
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.ContentID);
					return;
				}
				this.a.Remove(StandardHeader.ContentID);
				Header header = new Header(StandardHeader.ContentID, value);
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the content location.
		/// </summary>
		/// <value>The content location.</value>
		public string ContentLocation
		{
			get
			{
				Header item = this.a[StandardHeader.ContentLocation];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return item.Value;
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.ContentLocation);
					return;
				}
				this.a.Remove(StandardHeader.ContentLocation);
				Header header = new Header(StandardHeader.ContentLocation, value);
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the content transfer encoding.
		/// </summary>
		/// <value>The content transfer encoding.</value>
		public Independentsoft.Email.Mime.ContentTransferEncoding ContentTransferEncoding
		{
			get
			{
				Header item = this.a[StandardHeader.ContentTransferEncoding];
				if (item == null || item.Value == null)
				{
					return Independentsoft.Email.Mime.ContentTransferEncoding.SevenBit;
				}
				return k.b(item.Value);
			}
			set
			{
				this.a.Remove(StandardHeader.ContentTransferEncoding);
				Header header = new Header(StandardHeader.ContentTransferEncoding, k.a(value));
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the type of the content.
		/// </summary>
		/// <value>The type of the content.</value>
		public Independentsoft.Email.Mime.ContentType ContentType
		{
			get
			{
				Header item = this.a[StandardHeader.ContentType];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return new Independentsoft.Email.Mime.ContentType(item.Value);
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.ContentType);
					return;
				}
				this.a.Remove(StandardHeader.ContentType);
				Header header = new Header(StandardHeader.ContentType, value.ToString());
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the date.
		/// </summary>
		/// <value>The date.</value>
		public DateTime Date
		{
			get
			{
				Header item = this.a[StandardHeader.Date];
				if (item == null || item.Value == null)
				{
					return DateTime.MinValue;
				}
				string value = item.Value;
				int num = value.IndexOf("(");
				if (num > -1)
				{
					value = value.Substring(0, num);
				}
				DateTime minValue = DateTime.MinValue;
				try
				{
					minValue = DateTime.Parse(value, CultureInfo.InvariantCulture);
				}
				catch
				{
					minValue = o.a(value);
				}
				return minValue;
			}
			set
			{
				if (value.CompareTo(DateTime.MinValue) <= 0)
				{
					this.a.Remove(StandardHeader.Date);
					return;
				}
				this.a.Remove(StandardHeader.Date);
				string str = value.ToString("ddd, dd MMM yyyy HH:mm:ss", CultureInfo.InvariantCulture);
				string str1 = value.ToString("zzzz", CultureInfo.InvariantCulture);
				str = string.Concat(str, " ", str1.Replace(":", ""));
				Header header = new Header(StandardHeader.Date, str);
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the embedded message.
		/// </summary>
		/// <value>The embedded message.</value>
		public Message EmbeddedMessage
		{
			get
			{
				return this.d;
			}
			set
			{
				this.d = value;
			}
		}

		/// <summary>
		/// Gets or sets from.
		/// </summary>
		/// <value>From.</value>
		public Mailbox From
		{
			get
			{
				Header item = this.a[StandardHeader.From];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return new Mailbox(item.Value);
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.From);
					return;
				}
				this.a.Remove(StandardHeader.From);
				Header header = new Header(StandardHeader.From, value.ToString());
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the header character set.
		/// </summary>
		/// <value>The header character set.</value>
		public string HeaderCharSet
		{
			get
			{
				return this.f;
			}
			set
			{
				this.f = value;
			}
		}

		/// <summary>
		/// Gets or sets the header encoding.
		/// </summary>
		/// <value>The header encoding.</value>
		public Independentsoft.Email.Mime.HeaderEncoding HeaderEncoding
		{
			get
			{
				return this.e;
			}
			set
			{
				this.e = value;
			}
		}

		/// <summary>
		/// Gets the headers.
		/// </summary>
		/// <value>The headers.</value>
		public HeaderList Headers
		{
			get
			{
				return this.a;
			}
		}

		/// <summary>
		/// Gets or sets the in reply to.
		/// </summary>
		/// <value>The in reply to.</value>
		public Mailbox InReplyTo
		{
			get
			{
				Header item = this.a[StandardHeader.InReplyTo];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return new Mailbox(item.Value);
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.InReplyTo);
					return;
				}
				this.a.Remove(StandardHeader.InReplyTo);
				Header header = new Header(StandardHeader.InReplyTo, value.ToString());
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the keywords.
		/// </summary>
		/// <value>The keywords.</value>
		public string Keywords
		{
			get
			{
				Header item = this.a[StandardHeader.Keywords];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return item.Value;
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.Keywords);
					return;
				}
				this.a.Remove(StandardHeader.Keywords);
				Header header = new Header(StandardHeader.Keywords, value);
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the message identifier.
		/// </summary>
		/// <value>The message identifier.</value>
		public string MessageID
		{
			get
			{
				Header item = this.a[StandardHeader.MessageID];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return item.Value;
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.MessageID);
					return;
				}
				this.a.Remove(StandardHeader.MessageID);
				Header header = new Header(StandardHeader.MessageID, value);
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the MIME version.
		/// </summary>
		/// <value>The MIME version.</value>
		public string MimeVersion
		{
			get
			{
				Header item = this.a[StandardHeader.MimeVersion];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return item.Value;
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.MimeVersion);
					return;
				}
				this.a.Remove(StandardHeader.MimeVersion);
				Header header = new Header(StandardHeader.MimeVersion, value);
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the references.
		/// </summary>
		/// <value>The references.</value>
		public string References
		{
			get
			{
				Header item = this.a[StandardHeader.References];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return item.Value;
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.References);
					return;
				}
				this.a.Remove(StandardHeader.References);
				Header header = new Header(StandardHeader.References, value);
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets the reply to.
		/// </summary>
		/// <value>The reply to.</value>
		public IList<Mailbox> ReplyTo
		{
			get
			{
				return this.j;
			}
		}

		/// <summary>
		/// Gets or sets the resent date.
		/// </summary>
		/// <value>The resent date.</value>
		public DateTime ResentDate
		{
			get
			{
				Header item = this.a[StandardHeader.ResentDate];
				if (item == null || item.Value == null)
				{
					return DateTime.MinValue;
				}
				string value = item.Value;
				int num = value.IndexOf("(");
				if (num > -1)
				{
					value = value.Substring(0, num);
				}
				DateTime minValue = DateTime.MinValue;
				try
				{
					minValue = DateTime.Parse(value, CultureInfo.InvariantCulture);
				}
				catch
				{
				}
				return minValue;
			}
			set
			{
				if (value.CompareTo(DateTime.MinValue) <= 0)
				{
					this.a.Remove(StandardHeader.ResentDate);
					return;
				}
				this.a.Remove(StandardHeader.ResentDate);
				string str = value.ToString("ddd, dd MMM yyyy HH:mm:ss");
				string str1 = value.ToString("zzzz");
				str = string.Concat(str, " ", str1.Replace(":", ""));
				Header header = new Header(StandardHeader.ResentDate, str);
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the resent from.
		/// </summary>
		/// <value>The resent from.</value>
		public Mailbox ResentFrom
		{
			get
			{
				Header item = this.a[StandardHeader.ResentFrom];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return new Mailbox(item.Value);
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.ResentFrom);
					return;
				}
				this.a.Remove(StandardHeader.ResentFrom);
				Header header = new Header(StandardHeader.ResentFrom, value.ToString());
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the resent message identifier.
		/// </summary>
		/// <value>The resent message identifier.</value>
		public string ResentMessageID
		{
			get
			{
				Header item = this.a[StandardHeader.ResentMessageID];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return item.Value;
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.ResentMessageID);
					return;
				}
				this.a.Remove(StandardHeader.ResentMessageID);
				Header header = new Header(StandardHeader.ResentMessageID, value);
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the resent sender.
		/// </summary>
		/// <value>The resent sender.</value>
		public Mailbox ResentSender
		{
			get
			{
				Header item = this.a[StandardHeader.ResentSender];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return new Mailbox(item.Value);
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.ResentSender);
					return;
				}
				this.a.Remove(StandardHeader.ResentSender);
				Header header = new Header(StandardHeader.ResentSender, value.ToString());
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the return path.
		/// </summary>
		/// <value>The return path.</value>
		public Mailbox ReturnPath
		{
			get
			{
				Header item = this.a[StandardHeader.ReturnPath];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return new Mailbox(item.Value);
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.ReturnPath);
					return;
				}
				this.a.Remove(StandardHeader.ReturnPath);
				Header header = new Header(StandardHeader.ReturnPath, value.ToString());
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the sender.
		/// </summary>
		/// <value>The sender.</value>
		public Mailbox Sender
		{
			get
			{
				Header item = this.a[StandardHeader.Sender];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return new Mailbox(item.Value);
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.Sender);
					return;
				}
				this.a.Remove(StandardHeader.Sender);
				Header header = new Header(StandardHeader.Sender, value.ToString());
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the subject.
		/// </summary>
		/// <value>The subject.</value>
		public string Subject
		{
			get
			{
				Header item = this.a[StandardHeader.Subject];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return item.Value;
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.Subject);
					return;
				}
				this.a.Remove(StandardHeader.Subject);
				Header header = new Header(StandardHeader.Subject, value);
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets to.
		/// </summary>
		/// <value>To.</value>
		public IList<Mailbox> To
		{
			get
			{
				return this.g;
			}
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.Message" /> class.
		/// </summary>
		public Message()
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.Message" /> class.
		/// </summary>
		/// <param name="filePath">The file path.</param>
		public Message(string filePath) : this()
		{
			this.Open(filePath);
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.Message" /> class.
		/// </summary>
		/// <param name="stream">The stream.</param>
		public Message(Stream stream) : this()
		{
			this.Open(stream);
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.Message" /> class.
		/// </summary>
		/// <param name="buffer">The buffer.</param>
		public Message(byte[] buffer) : this()
		{
			this.Open(buffer);
		}

		private void a(byte[] A_0)
		{
			string str = Encoding.Default.GetString(A_0, 0, (int)A_0.Length);
			string[] strArrays = o.b(str).Split(o.c);
			string str1 = null;
			string str2 = null;
			for (int i = 0; i < (int)strArrays.Length; i++)
			{
				string str3 = strArrays[i];
				if (str3.Length > 0)
				{
					if (str3.StartsWith(" ") || str3.StartsWith("\t"))
					{
						str3 = str3.TrimStart(o.d);
						str2 = string.Concat(str2, str3);
					}
					else
					{
						int num = str3.IndexOf(":");
						if (num > -1)
						{
							str1 = str3.Substring(0, num);
							str2 = str3.Substring(num + 1);
						}
						if (str1 != null && str2 != null)
						{
							str2 = str2.TrimStart(new char[0]);
							str2 = o.a(str2, ref this.e, ref this.f);
							if (o.o(str1))
							{
								str1 = o.n(str1);
							}
							Header header = new Header(str1, str2);
							this.a.Add(header);
							str1 = null;
							str2 = null;
						}
					}
				}
			}
			if (str1 != null && str2 != null)
			{
				str2 = str2.TrimStart(new char[0]);
				str2 = o.a(str2, ref this.e, ref this.f);
				if (o.o(str1))
				{
					str1 = o.n(str1);
				}
				Header header1 = new Header(str1, str2);
				this.a.Add(header1);
			}
			this.a = this.b(this.a);
		}

		private HeaderList a(HeaderList A_0)
		{
			string str = "";
			string str1 = "";
			string str2 = "";
			string str3 = "";
			for (int i = 0; i < this.g.Count; i++)
			{
				if (this.g[i] != null)
				{
					str = string.Concat(str, this.g[i].ToString());
				}
				if (i < this.g.Count - 1)
				{
					str = string.Concat(str, ", ");
				}
			}
			for (int j = 0; j < this.h.Count; j++)
			{
				if (this.h[j] != null)
				{
					str1 = string.Concat(str1, this.h[j].ToString());
				}
				if (j < this.h.Count - 1)
				{
					str1 = string.Concat(str1, ", ");
				}
			}
			for (int k = 0; k < this.i.Count; k++)
			{
				if (this.i[k] != null)
				{
					str2 = string.Concat(str2, this.i[k].ToString());
				}
				if (k < this.i.Count - 1)
				{
					str2 = string.Concat(str2, ", ");
				}
			}
			for (int l = 0; l < this.j.Count; l++)
			{
				if (this.j[l] != null)
				{
					str3 = string.Concat(str3, this.j[l].ToString());
				}
				if (l < this.j.Count - 1)
				{
					str3 = string.Concat(str3, ", ");
				}
			}
			if (str.Length > 0)
			{
				Header header = new Header(StandardHeader.To, str);
				A_0.Remove(StandardHeader.To);
				A_0.Add(header);
			}
			if (str1.Length > 0)
			{
				Header header1 = new Header(StandardHeader.Cc, str1);
				A_0.Remove(StandardHeader.Cc);
				A_0.Add(header1);
			}
			if (str2.Length > 0)
			{
				Header header2 = new Header(StandardHeader.Bcc, str2);
				A_0.Remove(StandardHeader.Bcc);
				A_0.Add(header2);
			}
			if (str3.Length > 0)
			{
				Header header3 = new Header(StandardHeader.ReplyTo, str3);
				A_0.Remove(StandardHeader.ReplyTo);
				A_0.Add(header3);
			}
			return A_0;
		}

		private Stream a()
		{
			MemoryStream memoryStream = new MemoryStream();
			string str = "";
			Independentsoft.Email.Mime.ContentType contentType = this.ContentType;
			string str1 = null;
			if (contentType != null && contentType.Type != null && contentType.Type.ToLower() == "multipart")
			{
				contentType.Parameters.Remove("boundary");
				str1 = string.Concat("----=_NextPart_", o.b());
				contentType.Parameters.Add(new Parameter("boundary", string.Concat("\"", str1, "\"")));
				this.ContentType = contentType;
				if (this.MimeVersion == null)
				{
					this.MimeVersion = "1.0";
				}
			}
			else if (contentType == null && this.b.Count > 0)
			{
				contentType = new Independentsoft.Email.Mime.ContentType("multipart", "mixed");
				str1 = string.Concat("----=_NextPart_", o.b());
				contentType.Parameters.Add(new Parameter("boundary", string.Concat("\"", str1, "\"")));
				this.ContentType = contentType;
				if (this.MimeVersion == null)
				{
					this.MimeVersion = "1.0";
				}
			}
			else if (contentType == null)
			{
				contentType = new Independentsoft.Email.Mime.ContentType("text", "plain");
				this.ContentType = contentType;
			}
			this.a = this.a(this.a);
			for (int i = 0; i < this.a.Count; i++)
			{
				Header item = this.a[i];
				if (item != null && item.Name != null && item.Value != null)
				{
					if (!o.a(item.Name, item.Value))
					{
						string str2 = string.Concat(item.Name, ": ", item.Value);
						str2 = o.a(str2, 76);
						str = string.Concat(str, str2, "\r\n");
					}
					else
					{
						string str3 = o.a(item.Value, this.f, this.e);
						string str4 = string.Concat(item.Name, ": ", str3);
						str4 = o.a(str4, 76);
						str = string.Concat(str, str4, "\r\n");
					}
				}
			}
			str = string.Concat(str, "\r\n");
			byte[] bytes = Encoding.Default.GetBytes(str);
			memoryStream.Write(bytes, 0, (int)bytes.Length);
			if (this.b.Count > 0)
			{
				string str5 = string.Concat("--", str1);
				string str6 = string.Concat("--", str1, "--");
				for (int j = 0; j < this.b.Count; j++)
				{
					string str7 = string.Concat("\r\n", str5, "\r\n");
					byte[] numArray = Encoding.Default.GetBytes(str7);
					memoryStream.Write(numArray, 0, (int)numArray.Length);
					byte[] bytes1 = this.b[j].GetBytes();
					memoryStream.Write(bytes1, 0, (int)bytes1.Length);
				}
				string str8 = string.Concat("\r\n", str6, "\r\n");
				byte[] numArray1 = Encoding.Default.GetBytes(str8);
				memoryStream.Write(numArray1, 0, (int)numArray1.Length);
			}
			else if (contentType != null && contentType.Type != null && contentType.Type.ToLower() == "message" && contentType.SubType != null && contentType.SubType.ToLower() == "rfc822" && this.d != null)
			{
				byte[] bytes2 = this.d.GetBytes();
				memoryStream.Write(bytes2, 0, (int)bytes2.Length);
			}
			else if (contentType != null && contentType.Type != null && contentType.Type.ToLower() == "text" && this.c != null)
			{
				Encoding @default = Encoding.Default;
				Independentsoft.Email.Mime.ContentTransferEncoding contentTransferEncoding = Independentsoft.Email.Mime.ContentTransferEncoding.SevenBit;
				if (contentType != null)
				{
					Parameter parameter = contentType.Parameters["charset"];
					if (parameter != null && parameter.Value != null)
					{
						@default = o.m(parameter.Value);
					}
				}
				Header header = this.a[StandardHeader.ContentTransferEncoding];
				if (header != null && header.Value != null)
				{
					contentTransferEncoding = k.b(header.Value);
				}
				if (contentTransferEncoding == Independentsoft.Email.Mime.ContentTransferEncoding.QuotedPrintable)
				{
					string str9 = o.c(this.c, @default);
					str9 = o.j(str9);
					byte[] numArray2 = Encoding.Default.GetBytes(str9);
					memoryStream.Write(numArray2, 0, (int)numArray2.Length);
				}
				else if (contentTransferEncoding != Independentsoft.Email.Mime.ContentTransferEncoding.Base64)
				{
					byte[] bytes3 = @default.GetBytes(this.c);
					memoryStream.Write(bytes3, 0, (int)bytes3.Length);
				}
				else
				{
					byte[] numArray3 = @default.GetBytes(this.c);
					string base64String = Convert.ToBase64String(numArray3, 0, (int)numArray3.Length);
					base64String = o.i(base64String);
					byte[] bytes4 = Encoding.Default.GetBytes(base64String);
					memoryStream.Write(bytes4, 0, (int)bytes4.Length);
				}
			}
			else if (this.c != null)
			{
				Independentsoft.Email.Mime.ContentTransferEncoding contentTransferEncoding1 = Independentsoft.Email.Mime.ContentTransferEncoding.SevenBit;
				Header item1 = this.a[StandardHeader.ContentTransferEncoding];
				if (item1 != null && item1.Value != null)
				{
					contentTransferEncoding1 = k.b(item1.Value);
				}
				if (contentTransferEncoding1 == Independentsoft.Email.Mime.ContentTransferEncoding.QuotedPrintable)
				{
					string str10 = o.j(this.c);
					byte[] numArray4 = Encoding.Default.GetBytes(str10);
					memoryStream.Write(numArray4, 0, (int)numArray4.Length);
				}
				else if (contentTransferEncoding1 != Independentsoft.Email.Mime.ContentTransferEncoding.Base64)
				{
					byte[] bytes5 = Encoding.Default.GetBytes(this.c);
					memoryStream.Write(bytes5, 0, (int)bytes5.Length);
				}
				else
				{
					string str11 = o.i(this.c);
					byte[] numArray5 = Encoding.Default.GetBytes(str11);
					memoryStream.Write(numArray5, 0, (int)numArray5.Length);
				}
			}
			return memoryStream;
		}

		private void b(byte[] A_0)
		{
			int num = o.a(A_0, o.b);
			if (num == -1)
			{
				A_0 = o.b(A_0);
				num = o.a(A_0, o.b);
			}
			if (num == -1)
			{
				throw new MessageFormatException("Invalid message format.");
			}
			byte[] numArray = new byte[num];
			Array.Copy(A_0, 0, numArray, 0, (int)numArray.Length);
			this.a(numArray);
			if ((int)A_0.Length > num + 4)
			{
				byte[] numArray1 = new byte[(int)A_0.Length - num - 4];
				Array.Copy(A_0, num + 4, numArray1, 0, (int)numArray1.Length);
				Independentsoft.Email.Mime.ContentType contentType = this.ContentType;
				Independentsoft.Email.Mime.ContentDisposition contentDisposition = this.ContentDisposition;
				Independentsoft.Email.Mime.ContentTransferEncoding contentTransferEncoding = this.ContentTransferEncoding;
				if (contentType == null)
				{
					this.c = Encoding.Default.GetString(numArray1, 0, (int)numArray1.Length);
					return;
				}
				if (contentType.Type != null && contentType.Type.ToLower() == "text" || contentType.Type != null && contentType.Type.ToLower() == "text" && contentDisposition != null && contentDisposition.Type == ContentDispositionType.Inline)
				{
					Parameter item = contentType.Parameters["charset"];
					if (item != null && item.Value != null)
					{
						Encoding encoding = o.m(item.Value);
						this.c = encoding.GetString(numArray1, 0, (int)numArray1.Length);
						if (contentTransferEncoding == Independentsoft.Email.Mime.ContentTransferEncoding.QuotedPrintable)
						{
							this.c = o.a(this.c, encoding);
							return;
						}
						if (contentTransferEncoding == Independentsoft.Email.Mime.ContentTransferEncoding.Base64)
						{
							this.c = o.b(this.c, encoding);
							return;
						}
						this.c = encoding.GetString(numArray1, 0, (int)numArray1.Length);
						return;
					}
					this.c = Encoding.Default.GetString(numArray1, 0, (int)numArray1.Length);
					if (contentTransferEncoding == Independentsoft.Email.Mime.ContentTransferEncoding.QuotedPrintable)
					{
						this.c = o.a(this.c, Encoding.Default);
						return;
					}
					if (contentTransferEncoding == Independentsoft.Email.Mime.ContentTransferEncoding.Base64)
					{
						this.c = o.b(this.c, Encoding.Default);
						return;
					}
				}
				else if (contentType.Type != null && contentType.Type.ToLower() == "multipart")
				{
					Parameter parameter = contentType.Parameters["boundary"];
					if (parameter != null && parameter.Value != null)
					{
						IList<byte[]> numArrays = o.a(numArray1, parameter.Value);
						for (int i = 0; i < numArrays.Count; i++)
						{
							BodyPart bodyPart = new BodyPart(numArrays[i]);
							this.b.Add(bodyPart);
						}
						return;
					}
				}
				else if (contentType.Type == null || !(contentType.Type.ToLower() == "message"))
				{
					if (contentTransferEncoding == Independentsoft.Email.Mime.ContentTransferEncoding.QuotedPrintable)
					{
						this.c = Encoding.Default.GetString(numArray1, 0, (int)numArray1.Length);
						this.c = this.c.Replace("=09", "\t");
						this.c = this.c.Replace("=0D", "\r");
						this.c = this.c.Replace("=0A", "\n");
						this.c = this.c.Replace("=20", " ");
						this.c = this.c.Replace("=\r\n", string.Empty);
						return;
					}
					if (contentTransferEncoding == Independentsoft.Email.Mime.ContentTransferEncoding.Base64)
					{
						numArray1 = o.a(numArray1);
						this.c = Encoding.Default.GetString(numArray1, 0, (int)numArray1.Length);
						return;
					}
					this.c = Encoding.Default.GetString(numArray1, 0, (int)numArray1.Length);
				}
				else
				{
					if (contentType.SubType != null && contentType.SubType.ToLower() == "rfc822")
					{
						this.d = new Message(numArray1);
						return;
					}
					if (contentType.SubType != null && contentType.SubType.ToLower() == "delivery-status")
					{
						byte[] numArray2 = new byte[0];
						if (contentTransferEncoding == Independentsoft.Email.Mime.ContentTransferEncoding.Base64)
						{
							string str = Encoding.Default.GetString(numArray1, 0, (int)numArray1.Length);
							if (str != null && str.Length > 0)
							{
								numArray2 = Convert.FromBase64String(str);
							}
						}
						if ((int)numArray2.Length > 0)
						{
							try
							{
								this.d = new Message(numArray2)
								{
									Subject = (contentType.Parameters["name"] != null ? contentType.Parameters["name"].Value : "ATT")
								};
							}
							catch (MessageFormatException messageFormatException)
							{
								this.c = Encoding.Default.GetString(numArray1, 0, (int)numArray1.Length);
							}
						}
					}
					else if (contentType.SubType != null && contentType.SubType == "partial")
					{
						this.c = Encoding.Default.GetString(numArray1, 0, (int)numArray1.Length);
						return;
					}
				}
			}
		}

		private HeaderList b(HeaderList A_0)
		{
			Header item = A_0[StandardHeader.To];
			Header header = A_0[StandardHeader.Cc];
			Header item1 = A_0[StandardHeader.Bcc];
			Header header1 = A_0[StandardHeader.ReplyTo];
			if (item != null && item.Value != null)
			{
				this.g = o.e(item.Value);
				A_0.Remove(StandardHeader.To);
			}
			if (header != null && header.Value != null)
			{
				this.h = o.e(header.Value);
				A_0.Remove(StandardHeader.Cc);
			}
			if (item1 != null && item1.Value != null)
			{
				this.i = o.e(item1.Value);
				A_0.Remove(StandardHeader.Bcc);
			}
			if (header1 != null && header1.Value != null)
			{
				this.j = o.e(header1.Value);
				A_0.Remove(StandardHeader.ReplyTo);
			}
			return A_0;
		}

		/// <summary>
		/// Gets the attachments.
		/// </summary>
		/// <returns>Attachment[][].</returns>
		public Attachment[] GetAttachments()
		{
			return this.GetAttachments(false);
		}

		/// <summary>
		/// Gets the attachments.
		/// </summary>
		/// <param name="includeEmbedded">if set to <c>true</c> [include embedded].</param>
		/// <returns>Attachment[][].</returns>
		public Attachment[] GetAttachments(bool includeEmbedded)
		{
			IList<Attachment> attachments = new List<Attachment>();
			if (this.d != null)
			{
				string value = null;
				string str = null;
				if (this.d.ContentType != null)
				{
					Parameter item = this.d.ContentType.Parameters["name"];
					if (item != null && item.Value != null)
					{
						value = item.Value;
					}
					Parameter parameter = this.d.ContentType.Parameters["charset"];
					if (parameter != null)
					{
						str = parameter.Value;
					}
				}
				if (value == null && this.d.ContentDisposition != null)
				{
					Parameter item1 = this.d.ContentDisposition.Parameters["filename"];
					if (item1 != null && item1.Value != null)
					{
						value = item1.Value;
					}
				}
				if (value == null)
				{
					value = string.Concat(this.d.Subject, ".eml");
				}
				Encoding encoding = o.m(str);
				byte[] bytes = encoding.GetBytes(this.d.ToString());
				attachments.Add(new Attachment(bytes, value));
			}
			else if (this.c != null && (this.ContentDisposition != null && this.ContentDisposition.ToString().ToLower() != "inline" || this.ContentType != null && this.ContentType.Type != null && this.ContentType.Type.ToLower() != "text"))
			{
				string value1 = null;
				if (this.ContentType != null)
				{
					Parameter parameter1 = this.ContentType.Parameters["name"];
					if (parameter1 != null && parameter1.Value != null)
					{
						value1 = parameter1.Value;
					}
				}
				if (value1 == null && this.ContentDisposition != null)
				{
					Parameter item2 = this.ContentDisposition.Parameters["filename"];
					if (item2 != null && item2.Value != null)
					{
						value1 = item2.Value;
					}
				}
				if (this.ContentTransferEncoding != Independentsoft.Email.Mime.ContentTransferEncoding.Base64)
				{
					byte[] numArray = Encoding.Default.GetBytes(this.c);
					attachments.Add(new Attachment(numArray, value1));
				}
				else
				{
					byte[] numArray1 = o.g(this.c);
					attachments.Add(new Attachment(numArray1, value1));
				}
			}
			else if (this.c != null && this.ContentDisposition != null && this.ContentDisposition.ToString().ToLower() != "inline")
			{
				string str1 = null;
				if (this.ContentType != null)
				{
					Parameter parameter2 = this.ContentType.Parameters["name"];
					if (parameter2 != null && parameter2.Value != null)
					{
						str1 = parameter2.Value;
					}
				}
				if (str1 == null && this.ContentDisposition != null)
				{
					Parameter item3 = this.ContentDisposition.Parameters["filename"];
					if (item3 != null && item3.Value != null)
					{
						str1 = item3.Value;
					}
				}
				if (this.ContentTransferEncoding != Independentsoft.Email.Mime.ContentTransferEncoding.Base64)
				{
					byte[] bytes1 = Encoding.Default.GetBytes(this.c);
					attachments.Add(new Attachment(bytes1, str1));
				}
				else
				{
					byte[] numArray2 = o.g(this.c);
					attachments.Add(new Attachment(numArray2, str1));
				}
			}
			else if (this.b.Count > 0)
			{
				for (int i = 0; i < this.b.Count; i++)
				{
					Attachment[] attachmentArray = this.b[i].a(includeEmbedded);
					for (int j = 0; j < (int)attachmentArray.Length; j++)
					{
						attachments.Add(attachmentArray[j]);
					}
				}
			}
			Attachment[] attachmentArray1 = new Attachment[attachments.Count];
			for (int k = 0; k < attachments.Count; k++)
			{
				attachmentArray1[k] = attachments[k];
			}
			return attachmentArray1;
		}

		/// <summary>
		/// Gets the bytes.
		/// </summary>
		/// <returns>System.Byte[][].</returns>
		public byte[] GetBytes()
		{
			byte[] array = null;
			MemoryStream stream = (MemoryStream)this.GetStream();
			using (stream)
			{
				array = stream.ToArray();
			}
			return array;
		}

		/// <summary>
		/// Gets the name of the file.
		/// </summary>
		/// <returns>System.String.</returns>
		public string GetFileName()
		{
			if (this.Subject == null)
			{
				return string.Concat("Message-", o.a());
			}
			string subject = this.Subject;
			subject = subject.Replace(":", "_");
			subject = subject.Replace("*", "_");
			subject = subject.Replace("\\", "_");
			subject = subject.Replace("/", "_");
			subject = subject.Replace("?", "_");
			subject = subject.Replace("\"", "_");
			subject = subject.Replace("<", "_");
			subject = subject.Replace(">", "_");
			subject = subject.Replace("|", "_");
			subject = subject.Replace("\u001b", "_");
			subject = subject.Replace("\r", "_");
			subject = subject.Replace("\n", "_");
			subject = subject.Replace("\t", "_");
			if (subject.Length > 128)
			{
				subject = subject.Substring(0, 128);
			}
			return string.Concat(subject, ".eml");
		}

		/// <summary>
		/// Gets the stream.
		/// </summary>
		/// <returns>Stream.</returns>
		public Stream GetStream()
		{
			return this.a();
		}

		/// <summary>
		/// Opens the specified file path.
		/// </summary>
		/// <param name="filePath">The file path.</param>
		public void Open(string filePath)
		{
			FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
			using (fileStream)
			{
				this.Open(fileStream);
			}
		}

		/// <summary>
		/// Opens the specified stream.
		/// </summary>
		/// <param name="stream">The stream.</param>
		/// <exception cref="T:System.ArgumentNullException">stream</exception>
		public void Open(Stream stream)
		{
			if (stream == null)
			{
				throw new ArgumentNullException("stream");
			}
			byte[] numArray = new byte[32768];
			int num = -1;
			MemoryStream memoryStream = new MemoryStream();
			using (memoryStream)
			{
				while (true)
				{
					int num1 = stream.Read(numArray, 0, (int)numArray.Length);
					num = num1;
					if (num1 <= 0)
					{
						break;
					}
					memoryStream.Write(numArray, 0, num);
				}
				this.Open(memoryStream.ToArray());
			}
		}

		/// <summary>
		/// Opens the specified buffer.
		/// </summary>
		/// <param name="buffer">The buffer.</param>
		public void Open(byte[] buffer)
		{
			this.b(buffer);
		}

		/// <summary>
		/// Saves the specified stream.
		/// </summary>
		/// <param name="stream">The stream.</param>
		/// <exception cref="T:System.ArgumentNullException">stream</exception>
		public void Save(Stream stream)
		{
			if (stream == null)
			{
				throw new ArgumentNullException("stream");
			}
			byte[] bytes = this.GetBytes();
			stream.Write(bytes, 0, (int)bytes.Length);
		}

		/// <summary>
		/// Saves this message to the specified file.
		/// </summary>
		/// <param name="filePath">File path.</param>
		public void Save(string filePath)
		{
			this.Save(filePath, false);
		}

		/// <summary>
		/// Saves this message to the specified file.
		/// </summary>
		/// <param name="filePath">File path.</param>
		/// <param name="overwrite">True to overwrite existing file, otherwise false.</param>
		public void Save(string filePath, bool overwrite)
		{
			FileMode fileMode = FileMode.CreateNew;
			if (overwrite)
			{
				fileMode = FileMode.Create;
			}
			using (FileStream fileStream = new FileStream(filePath, fileMode, FileAccess.Write))
			{
				this.Save(fileStream);
			}
		}

		/// <summary>
		/// Returns a <see cref="T:System.String" /> that represents this instance.
		/// </summary>
		/// <returns>A <see cref="T:System.String" /> that represents this instance.</returns>
		public override string ToString()
		{
			byte[] bytes = this.GetBytes();
			string str = Encoding.UTF8.GetString(bytes, 0, (int)bytes.Length);
			return str;
		}
	}
}