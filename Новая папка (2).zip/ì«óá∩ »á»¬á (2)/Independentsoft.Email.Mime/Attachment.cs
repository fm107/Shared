using System;
using System.Collections.Generic;
using System.IO;

namespace Independentsoft.Email.Mime
{
	/// <summary>
	/// Class Attachment.
	/// </summary>
	public class Attachment
	{
		private string a;

		private byte[] b;

		private Independentsoft.Email.Mime.ContentType c = new Independentsoft.Email.Mime.ContentType("application", "octet-stream");

		private string d;

		private string e;

		private string f;

		private Independentsoft.Email.Mime.ContentDisposition g = new Independentsoft.Email.Mime.ContentDisposition(ContentDispositionType.Attachment);

		/// <summary>
		/// Gets or sets the content description.
		/// </summary>
		/// <value>The content description.</value>
		public string ContentDescription
		{
			get
			{
				return this.f;
			}
			set
			{
				this.f = value;
			}
		}

		/// <summary>
		/// Gets or sets the content disposition.
		/// </summary>
		/// <value>The content disposition.</value>
		public Independentsoft.Email.Mime.ContentDisposition ContentDisposition
		{
			get
			{
				return this.g;
			}
			set
			{
				this.g = value;
			}
		}

		/// <summary>
		/// Gets or sets the content identifier.
		/// </summary>
		/// <value>The content identifier.</value>
		public string ContentID
		{
			get
			{
				return this.d;
			}
			set
			{
				this.d = value;
			}
		}

		/// <summary>
		/// Gets or sets the content location.
		/// </summary>
		/// <value>The content location.</value>
		public string ContentLocation
		{
			get
			{
				return this.e;
			}
			set
			{
				this.e = value;
			}
		}

		/// <summary>
		/// Gets or sets the type of the content.
		/// </summary>
		/// <value>The type of the content.</value>
		public Independentsoft.Email.Mime.ContentType ContentType
		{
			get
			{
				return this.c;
			}
			set
			{
				this.c = value;
			}
		}

		/// <summary>
		/// Gets or sets the name.
		/// </summary>
		/// <value>The name.</value>
		public string Name
		{
			get
			{
				return this.a;
			}
			set
			{
				this.a = value;
			}
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.Attachment" /> class.
		/// </summary>
		public Attachment()
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.Attachment" /> class.
		/// </summary>
		/// <param name="filePath">The file path.</param>
		public Attachment(string filePath) : this()
		{
			this.Open(filePath);
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.Attachment" /> class.
		/// </summary>
		/// <param name="stream">The stream.</param>
		public Attachment(Stream stream) : this()
		{
			this.a(stream);
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.Attachment" /> class.
		/// </summary>
		/// <param name="buffer">The buffer.</param>
		public Attachment(byte[] buffer) : this()
		{
			this.b = buffer;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.Attachment" /> class.
		/// </summary>
		/// <param name="stream">The stream.</param>
		/// <param name="name">The name.</param>
		public Attachment(Stream stream, string name) : this()
		{
			this.a = name;
			this.a(stream);
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.Attachment" /> class.
		/// </summary>
		/// <param name="buffer">The buffer.</param>
		/// <param name="name">The name.</param>
		public Attachment(byte[] buffer, string name) : this()
		{
			this.b = buffer;
			this.a = name;
		}

		private void a(Stream A_0)
		{
			byte[] numArray = new byte[32768];
			int num = -1;
			MemoryStream memoryStream = new MemoryStream();
			using (memoryStream)
			{
				while (true)
				{
					int num1 = A_0.Read(numArray, 0, (int)numArray.Length);
					num = num1;
					if (num1 <= 0)
					{
						break;
					}
					memoryStream.Write(numArray, 0, num);
				}
				this.b = memoryStream.ToArray();
			}
			if (this.a != null)
			{
				Parameter parameter = new Parameter("filename", this.a);
				this.g.Parameters.Add(parameter);
			}
		}

		/// <summary>
		/// Gets the bytes.
		/// </summary>
		/// <returns>System.Byte[][].</returns>
		public byte[] GetBytes()
		{
			return this.b;
		}

		/// <summary>
		/// Gets the name of the file.
		/// </summary>
		/// <returns>System.String.</returns>
		public string GetFileName()
		{
			if (this.a == null)
			{
				return string.Concat("Attachment-", o.a());
			}
			string str = this.a;
			str = str.Replace(":", "_");
			str = str.Replace("*", "_");
			str = str.Replace("\\", "_");
			str = str.Replace("/", "_");
			str = str.Replace("?", "_");
			str = str.Replace("\"", "_");
			str = str.Replace("<", "_");
			str = str.Replace(">", "_");
			str = str.Replace("|", "_");
			str = str.Replace("\u001b", "_");
			str = str.Replace("\r", "_");
			str = str.Replace("\n", "_");
			str = str.Replace("\t", "_");
			if (str.Length > 128)
			{
				int num = str.LastIndexOf(".");
				string str1 = "";
				if (num > 124)
				{
					str1 = str.Substring(num);
				}
				str = string.Concat(str.Substring(0, 128), str1);
			}
			return str;
		}

		/// <summary>
		/// Gets the stream.
		/// </summary>
		/// <returns>Stream.</returns>
		public Stream GetStream()
		{
			if (this.b == null)
			{
				return null;
			}
			return new MemoryStream(this.b);
		}

		public void Open(string filePath)
		{
			FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
			using (fileStream)
			{
				this.a(fileStream);
			}
			this.a = (new FileInfo(filePath)).Name;
		}

		/// <summary>
		/// Saves the specified stream.
		/// </summary>
		/// <param name="stream">The stream.</param>
		/// <exception cref="T:System.ArgumentNullException">stream</exception>
		public void Save(Stream stream)
		{
			if (stream == null)
			{
				throw new ArgumentNullException("stream");
			}
			if (this.b != null)
			{
				stream.Write(this.b, 0, (int)this.b.Length);
			}
		}

		/// <summary>
		/// Saves this message to the specified file.
		/// </summary>
		/// <param name="filePath">File path.</param>
		public void Save(string filePath)
		{
			this.Save(filePath, false);
		}

		/// <summary>
		/// Saves this message to the specified file.
		/// </summary>
		/// <param name="filePath">File path.</param>
		/// <param name="overwrite">True to overwrite existing file, otherwise false.</param>
		public void Save(string filePath, bool overwrite)
		{
			FileMode fileMode = FileMode.CreateNew;
			if (overwrite)
			{
				fileMode = FileMode.Create;
			}
			using (FileStream fileStream = new FileStream(filePath, fileMode, FileAccess.Write))
			{
				this.Save(fileStream);
			}
		}

		/// <summary>
		/// Returns a <see cref="T:System.String" /> that represents this instance.
		/// </summary>
		/// <returns>A <see cref="T:System.String" /> that represents this instance.</returns>
		public override string ToString()
		{
			return this.a;
		}
	}
}