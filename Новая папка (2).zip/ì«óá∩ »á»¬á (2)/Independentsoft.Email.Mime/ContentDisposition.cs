using System;
using System.Collections.Generic;

namespace Independentsoft.Email.Mime
{
	/// <summary>
	/// Class ContentDisposition.
	/// </summary>
	public class ContentDisposition
	{
		private ContentDispositionType a = ContentDispositionType.Inline;

		private ParameterList b = new ParameterList();

		/// <summary>
		/// Gets the parameters.
		/// </summary>
		/// <value>The parameters.</value>
		public ParameterList Parameters
		{
			get
			{
				return this.b;
			}
		}

		/// <summary>
		/// Gets or sets the type.
		/// </summary>
		/// <value>The type.</value>
		public ContentDispositionType Type
		{
			get
			{
				return this.a;
			}
			set
			{
				this.a = value;
			}
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.ContentDisposition" /> class.
		/// </summary>
		public ContentDisposition()
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.ContentDisposition" /> class.
		/// </summary>
		/// <param name="type">The type.</param>
		public ContentDisposition(ContentDispositionType type)
		{
			this.a = type;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.ContentDisposition" /> class.
		/// </summary>
		/// <param name="contentDisposition">The content disposition.</param>
		public ContentDisposition(string contentDisposition)
		{
			this.a(contentDisposition);
		}

		private void a(string A_0)
		{
			if (A_0 != null)
			{
				string[] strArrays = A_0.Split(new char[] { ';' });
				for (int i = 0; i < (int)strArrays.Length - 1; i++)
				{
					int num = strArrays[i].IndexOf("\"");
					if (num > -1)
					{
						int num1 = strArrays[i].IndexOf("\"", num + 1);
						int num2 = strArrays[i + 1].IndexOf("\"");
						if (num2 > -1)
						{
							int num3 = strArrays[i + 1].IndexOf("\"", num2 + 1);
							if (num > 0 && num1 == -1 && num2 > 0 && num3 == -1)
							{
								strArrays[i] = string.Concat(strArrays[i], ";", strArrays[i + 1]);
								strArrays[i + 1] = "";
							}
						}
					}
				}
				if ((int)strArrays.Length > 0)
				{
					this.a = k.a(strArrays[0]);
				}
				for (int j = 1; j < (int)strArrays.Length; j++)
				{
					strArrays[j] = strArrays[j].Trim();
					if (strArrays[j].Length > 0)
					{
						int num4 = strArrays[j].IndexOf("=");
						if (num4 > -1)
						{
							string str = strArrays[j].Substring(0, num4);
							string str1 = strArrays[j].Substring(num4 + 1);
							str = str.Trim();
							char[] chrArray = new char[] { '\"', ' ' };
							Parameter parameter = new Parameter(str, str1.Trim(chrArray));
							this.b.Add(parameter);
						}
					}
				}
			}
		}

		/// <summary>
		/// Returns a <see cref="T:System.String" /> that represents this instance.
		/// </summary>
		/// <returns>A <see cref="T:System.String" /> that represents this instance.</returns>
		public override string ToString()
		{
			string str = k.a(this.a);
			for (int i = 0; i < this.b.Count; i++)
			{
				if (this.b[i].Name != null && this.b[i].Value != null)
				{
					string str1 = str;
					string[] name = new string[] { str1, "; ", this.b[i].Name, "=", this.b[i].Value };
					str = string.Concat(name);
				}
			}
			return str;
		}
	}
}