using System;
using System.Collections.Generic;
using System.Reflection;

namespace Independentsoft.Email.Mime
{
	/// <summary>
	/// Class ParameterList.
	/// </summary>
	public class ParameterList : List<Parameter>
	{
		/// <summary>
		/// Gets the <see cref="T:Independentsoft.Email.Mime.Parameter" /> with the specified name.
		/// </summary>
		/// <param name="name">The name.</param>
		/// <returns>Parameter.</returns>
		public Parameter this[string name]
		{
			get
			{
				if (name != null)
				{
					for (int i = 0; i < base.Count; i++)
					{
						if (base[i] != null && base[i].Name != null && base[i].Name.ToLower() == name.ToLower())
						{
							return base[i];
						}
					}
				}
				return null;
			}
		}

		public ParameterList()
		{
		}

		/// <summary>
		/// Removes the specified name.
		/// </summary>
		/// <param name="name">The name.</param>
		public void Remove(string name)
		{
			if (name != null)
			{
				for (int i = base.Count - 1; i >= 0; i--)
				{
					if (base[i] != null && base[i].Name != null && base[i].Name.ToLower() == name.ToLower())
					{
						base.RemoveAt(i);
					}
				}
			}
		}
	}
}