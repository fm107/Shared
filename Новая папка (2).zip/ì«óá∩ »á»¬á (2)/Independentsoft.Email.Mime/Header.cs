using System;

namespace Independentsoft.Email.Mime
{
	/// <summary>
	/// Class Header.
	/// </summary>
	public class Header
	{
		private string a;

		private string b;

		/// <summary>
		/// Gets or sets the name.
		/// </summary>
		/// <value>The name.</value>
		public string Name
		{
			get
			{
				return this.a;
			}
			set
			{
				this.a = value;
			}
		}

		/// <summary>
		/// Gets or sets the value.
		/// </summary>
		/// <value>The value.</value>
		public string Value
		{
			get
			{
				return this.b;
			}
			set
			{
				this.b = value;
			}
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.Header" /> class.
		/// </summary>
		public Header()
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.Header" /> class.
		/// </summary>
		/// <param name="name">The name.</param>
		/// <param name="value">The value.</param>
		public Header(string name, string value)
		{
			this.a = name;
			this.b = value;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.Header" /> class.
		/// </summary>
		/// <param name="name">The name.</param>
		/// <param name="value">The value.</param>
		public Header(StandardHeader name, string value)
		{
			this.a = k.a(name);
			this.b = value;
		}

		/// <summary>
		/// Returns a <see cref="T:System.String" /> that represents this instance.
		/// </summary>
		/// <returns>A <see cref="T:System.String" /> that represents this instance.</returns>
		public override string ToString()
		{
			if (this.a == null)
			{
				return "";
			}
			return string.Concat(this.a, ": ", this.b);
		}
	}
}