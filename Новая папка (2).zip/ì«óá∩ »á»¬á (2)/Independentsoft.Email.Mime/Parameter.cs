using System;

namespace Independentsoft.Email.Mime
{
	/// <summary>
	/// Class Parameter.
	/// </summary>
	public class Parameter
	{
		private string a;

		private string b;

		/// <summary>
		/// Gets or sets the name.
		/// </summary>
		/// <value>The name.</value>
		public string Name
		{
			get
			{
				return this.a;
			}
			set
			{
				this.a = value;
			}
		}

		/// <summary>
		/// Gets or sets the value.
		/// </summary>
		/// <value>The value.</value>
		public string Value
		{
			get
			{
				return this.b;
			}
			set
			{
				this.b = value;
			}
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.Parameter" /> class.
		/// </summary>
		public Parameter()
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.Parameter" /> class.
		/// </summary>
		/// <param name="name">The name.</param>
		public Parameter(string name)
		{
			this.a = name;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.Parameter" /> class.
		/// </summary>
		/// <param name="name">The name.</param>
		/// <param name="value">The value.</param>
		public Parameter(string name, string value)
		{
			this.a = name;
			this.b = value;
		}

		/// <summary>
		/// Returns a <see cref="T:System.String" /> that represents this instance.
		/// </summary>
		/// <returns>A <see cref="T:System.String" /> that represents this instance.</returns>
		public override string ToString()
		{
			if (this.a == null)
			{
				return "";
			}
			if (this.b == null)
			{
				return this.a;
			}
			return string.Concat(this.a, "=", this.b);
		}
	}
}