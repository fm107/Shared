using System;
using System.Collections.Generic;

namespace Independentsoft.Email.Mime
{
	/// <summary>
	/// Class ContentType.
	/// </summary>
	public class ContentType
	{
		private string a;

		private string b;

		private ParameterList c = new ParameterList();

		/// <summary>
		/// Gets or sets the character set.
		/// </summary>
		/// <value>The character set.</value>
		public string CharSet
		{
			get
			{
				Parameter item = this.c["charset"];
				if (item == null)
				{
					return null;
				}
				return item.Value;
			}
			set
			{
				if (value == null)
				{
					this.c.Remove("charset");
					return;
				}
				this.c.Remove("charset");
				Parameter parameter = new Parameter("charset", value);
				this.c.Add(parameter);
			}
		}

		/// <summary>
		/// Gets the parameters.
		/// </summary>
		/// <value>The parameters.</value>
		public ParameterList Parameters
		{
			get
			{
				return this.c;
			}
		}

		/// <summary>
		/// Gets or sets the type of the sub.
		/// </summary>
		/// <value>The type of the sub.</value>
		public string SubType
		{
			get
			{
				return this.b;
			}
			set
			{
				this.b = value;
			}
		}

		/// <summary>
		/// Gets or sets the type.
		/// </summary>
		/// <value>The type.</value>
		public string Type
		{
			get
			{
				return this.a;
			}
			set
			{
				this.a = value;
			}
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.ContentType" /> class.
		/// </summary>
		public ContentType()
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.ContentType" /> class.
		/// </summary>
		/// <param name="type">The type.</param>
		/// <param name="subtype">The subtype.</param>
		public ContentType(string type, string subtype)
		{
			this.a = type;
			this.b = subtype;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.ContentType" /> class.
		/// </summary>
		/// <param name="type">The type.</param>
		/// <param name="subtype">The subtype.</param>
		/// <param name="charset">The charset.</param>
		public ContentType(string type, string subtype, string charset) : this(type, subtype)
		{
			this.CharSet = charset;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.ContentType" /> class.
		/// </summary>
		/// <param name="contentType">Type of the content.</param>
		public ContentType(string contentType)
		{
			this.b(contentType);
		}

		private static string[] a(string A_0)
		{
			IList<string> strs = new List<string>();
			int num = A_0.IndexOf(";");
			while (num > -1)
			{
				int num1 = A_0.IndexOf("\"");
				int num2 = A_0.IndexOf("\"", num1 + 1);
				if (num1 >= num || num >= num2)
				{
					string str = A_0.Substring(0, num);
					A_0 = A_0.Substring(num + 1);
					strs.Add(str);
					num = A_0.IndexOf(";");
				}
				else
				{
					num = A_0.IndexOf(";", num2 + 1);
				}
			}
			strs.Add(A_0);
			string[] item = new string[strs.Count];
			for (int i = 0; i < (int)item.Length; i++)
			{
				item[i] = strs[i];
			}
			return item;
		}

		private void b(string A_0)
		{
			if (A_0 != null)
			{
				string[] strArrays = ContentType.a(A_0);
				if ((int)strArrays.Length > 0)
				{
					strArrays[0] = strArrays[0].Trim();
					string[] strArrays1 = strArrays[0].Split(new char[] { '/' });
					if ((int)strArrays1.Length == 1)
					{
						this.a = strArrays1[0];
					}
					else if ((int)strArrays1.Length == 2)
					{
						this.a = strArrays1[0];
						this.b = strArrays1[1];
					}
				}
				for (int i = 1; i < (int)strArrays.Length; i++)
				{
					strArrays[i] = strArrays[i].Trim();
					if (strArrays[i].Length > 0)
					{
						int num = strArrays[i].IndexOf("=");
						if (num > -1)
						{
							string str = strArrays[i].Substring(0, num);
							string str1 = strArrays[i].Substring(num + 1);
							str = str.Trim();
							char[] chrArray = new char[] { '\"', ' ' };
							Parameter parameter = new Parameter(str, str1.Trim(chrArray));
							this.c.Add(parameter);
						}
					}
				}
			}
		}

		/// <summary>
		/// Returns a <see cref="T:System.String" /> that represents this instance.
		/// </summary>
		/// <returns>A <see cref="T:System.String" /> that represents this instance.</returns>
		public override string ToString()
		{
			if (this.a == null || this.b == null)
			{
				return "";
			}
			string str = string.Concat(this.a, "/", this.b);
			for (int i = 0; i < this.c.Count; i++)
			{
				if (this.c[i].Name != null && this.c[i].Value != null)
				{
					string str1 = str;
					string[] name = new string[] { str1, "; ", this.c[i].Name, "=", this.c[i].Value };
					str = string.Concat(name);
				}
			}
			return str;
		}
	}
}