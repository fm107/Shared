using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Independentsoft.Email.Mime
{
	/// <summary>
	/// Class BodyPart.
	/// </summary>
	public class BodyPart
	{
		private HeaderList a = new HeaderList();

		private BodyPartList b = new BodyPartList();

		private string c;

		private Message d;

		private Independentsoft.Email.Mime.HeaderEncoding e;

		private string f = "utf-8";

		/// <summary>
		/// Gets or sets the body.
		/// </summary>
		/// <value>The body.</value>
		public string Body
		{
			get
			{
				return this.c;
			}
			set
			{
				this.c = value;
			}
		}

		/// <summary>
		/// Gets the body parts.
		/// </summary>
		/// <value>The body parts.</value>
		public BodyPartList BodyParts
		{
			get
			{
				return this.b;
			}
		}

		/// <summary>
		/// Gets or sets the content description.
		/// </summary>
		/// <value>The content description.</value>
		public string ContentDescription
		{
			get
			{
				Header item = this.a[StandardHeader.ContentDescription];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return item.Value;
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.ContentDescription);
					return;
				}
				this.a.Remove(StandardHeader.ContentDescription);
				Header header = new Header(StandardHeader.ContentDescription, value);
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the content disposition.
		/// </summary>
		/// <value>The content disposition.</value>
		public Independentsoft.Email.Mime.ContentDisposition ContentDisposition
		{
			get
			{
				Header item = this.a[StandardHeader.ContentDisposition];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return new Independentsoft.Email.Mime.ContentDisposition(item.Value);
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.ContentDisposition);
					return;
				}
				this.a.Remove(StandardHeader.ContentDisposition);
				Header header = new Header(StandardHeader.ContentDisposition, value.ToString());
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the content identifier.
		/// </summary>
		/// <value>The content identifier.</value>
		public string ContentID
		{
			get
			{
				Header item = this.a[StandardHeader.ContentID];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return item.Value;
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.ContentID);
					return;
				}
				this.a.Remove(StandardHeader.ContentID);
				Header header = new Header(StandardHeader.ContentID, value);
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the content location.
		/// </summary>
		/// <value>The content location.</value>
		public string ContentLocation
		{
			get
			{
				Header item = this.a[StandardHeader.ContentLocation];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return item.Value;
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.ContentLocation);
					return;
				}
				this.a.Remove(StandardHeader.ContentLocation);
				Header header = new Header(StandardHeader.ContentLocation, value);
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the content transfer encoding.
		/// </summary>
		/// <value>The content transfer encoding.</value>
		public Independentsoft.Email.Mime.ContentTransferEncoding ContentTransferEncoding
		{
			get
			{
				Header item = this.a[StandardHeader.ContentTransferEncoding];
				if (item == null || item.Value == null)
				{
					return Independentsoft.Email.Mime.ContentTransferEncoding.SevenBit;
				}
				return k.b(item.Value);
			}
			set
			{
				this.a.Remove(StandardHeader.ContentTransferEncoding);
				Header header = new Header(StandardHeader.ContentTransferEncoding, k.a(value));
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the type of the content.
		/// </summary>
		/// <value>The type of the content.</value>
		public Independentsoft.Email.Mime.ContentType ContentType
		{
			get
			{
				Header item = this.a[StandardHeader.ContentType];
				if (item == null || item.Value == null)
				{
					return null;
				}
				return new Independentsoft.Email.Mime.ContentType(item.Value);
			}
			set
			{
				if (value == null)
				{
					this.a.Remove(StandardHeader.ContentType);
					return;
				}
				this.a.Remove(StandardHeader.ContentType);
				Header header = new Header(StandardHeader.ContentType, value.ToString());
				this.a.Add(header);
			}
		}

		/// <summary>
		/// Gets or sets the embedded message.
		/// </summary>
		/// <value>The embedded message.</value>
		public Message EmbeddedMessage
		{
			get
			{
				return this.d;
			}
			set
			{
				this.d = value;
			}
		}

		/// <summary>
		/// Gets or sets the header character set.
		/// </summary>
		/// <value>The header character set.</value>
		public string HeaderCharSet
		{
			get
			{
				return this.f;
			}
			set
			{
				this.f = value;
			}
		}

		/// <summary>
		/// Gets or sets the header encoding.
		/// </summary>
		/// <value>The header encoding.</value>
		public Independentsoft.Email.Mime.HeaderEncoding HeaderEncoding
		{
			get
			{
				return this.e;
			}
			set
			{
				this.e = value;
			}
		}

		/// <summary>
		/// Gets the headers.
		/// </summary>
		/// <value>The headers.</value>
		public HeaderList Headers
		{
			get
			{
				return this.a;
			}
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.BodyPart" /> class.
		/// </summary>
		public BodyPart()
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="T:Independentsoft.Email.Mime.BodyPart" /> class.
		/// </summary>
		/// <param name="attachment">The attachment.</param>
		public BodyPart(Attachment attachment)
		{
			if (attachment != null)
			{
				if (attachment.ContentType != null)
				{
					this.ContentType = attachment.ContentType;
				}
				this.ContentID = attachment.ContentID;
				this.ContentLocation = attachment.ContentLocation;
				this.ContentTransferEncoding = Independentsoft.Email.Mime.ContentTransferEncoding.Base64;
				if (attachment.ContentDisposition == null)
				{
					Independentsoft.Email.Mime.ContentDisposition contentDisposition = new Independentsoft.Email.Mime.ContentDisposition(ContentDispositionType.Attachment);
					if (attachment.ContentID != null)
					{
						contentDisposition = new Independentsoft.Email.Mime.ContentDisposition(ContentDispositionType.Inline);
					}
					if (attachment.Name != null)
					{
						Parameter parameter = new Parameter("filename", string.Concat("\"", attachment.Name, "\""));
						contentDisposition.Parameters.Add(parameter);
					}
					this.ContentDisposition = contentDisposition;
				}
				else
				{
					Independentsoft.Email.Mime.ContentDisposition contentDisposition1 = attachment.ContentDisposition;
					if (attachment.ContentID != null)
					{
						contentDisposition1 = new Independentsoft.Email.Mime.ContentDisposition(ContentDispositionType.Inline);
					}
					if (attachment.Name != null)
					{
						Parameter parameter1 = new Parameter("filename", string.Concat("\"", attachment.Name, "\""));
						contentDisposition1.Parameters.Add(parameter1);
					}
					this.ContentDisposition = contentDisposition1;
				}
				byte[] bytes = attachment.GetBytes();
				if (bytes != null && this.ContentType != null && this.ContentType.Type == "text")
				{
					Encoding encoding = o.m(this.ContentType.CharSet);
					this.c = encoding.GetString(bytes, 0, (int)bytes.Length);
					return;
				}
				if (bytes != null)
				{
					this.c = Convert.ToBase64String(bytes, 0, (int)bytes.Length);
					this.c = o.i(this.c);
				}
			}
		}

		internal BodyPart(byte[] A_0)
		{
			this.b(A_0);
		}

		private void a(byte[] A_0)
		{
			string str = Encoding.Default.GetString(A_0, 0, (int)A_0.Length);
			string[] strArrays = o.b(str).Split(o.c);
			string str1 = null;
			string str2 = null;
			for (int i = 0; i < (int)strArrays.Length; i++)
			{
				if (strArrays[i].Length > 0)
				{
					if (strArrays[i].StartsWith(" ") || strArrays[i].StartsWith("\t"))
					{
						strArrays[i] = strArrays[i].Replace("\t", " ");
						str2 = string.Concat(str2, strArrays[i]);
					}
					else
					{
						if (str1 != null && str2 != null)
						{
							str2 = str2.TrimStart(new char[0]);
							str2 = o.a(str2, ref this.e, ref this.f);
							if (o.o(str1))
							{
								str1 = o.n(str1);
							}
							Header header = new Header(str1, str2);
							this.a.Add(header);
							str1 = null;
							str2 = null;
						}
						int num = strArrays[i].IndexOf(":");
						if (num > -1)
						{
							str1 = strArrays[i].Substring(0, num);
							if (str1.ToLower() != "content-disposition")
							{
								str2 = strArrays[i].Substring(num + 1);
							}
							else
							{
								str2 = strArrays[i].Substring(num + 1);
								str2 = (new Independentsoft.Email.Mime.ContentDisposition(str2)).ToString();
							}
						}
					}
				}
			}
			if (str1 != null && str2 != null)
			{
				str2 = str2.TrimStart(new char[0]);
				str2 = o.a(str2, ref this.e, ref this.f);
				if (o.o(str1))
				{
					str1 = o.n(str1);
				}
				Header header1 = new Header(str1, str2);
				this.a.Add(header1);
			}
		}

		internal Attachment[] a(bool A_0)
		{
			IList<Attachment> attachments = new List<Attachment>();
			if (this.d != null)
			{
				string value = null;
				string str = null;
				if (this.d.ContentType != null)
				{
					Parameter item = this.d.ContentType.Parameters["name"];
					if (item != null && item.Value != null)
					{
						value = item.Value;
					}
					Parameter parameter = this.d.ContentType.Parameters["charset"];
					if (parameter != null)
					{
						str = parameter.Value;
					}
				}
				if (value == null && this.d.ContentDisposition != null)
				{
					Parameter item1 = this.d.ContentDisposition.Parameters["filename"];
					if (item1 != null && item1.Value != null)
					{
						value = item1.Value;
					}
				}
				if (value == null)
				{
					value = string.Concat(this.d.Subject, ".eml");
				}
				Encoding encoding = o.m(str);
				byte[] bytes = encoding.GetBytes(this.d.ToString());
				Attachment attachment = new Attachment(bytes, value)
				{
					ContentID = this.ContentID,
					ContentLocation = this.ContentLocation,
					ContentDisposition = this.ContentDisposition,
					ContentDescription = this.ContentDescription
				};
				attachments.Add(attachment);
			}
			else if (this.ContentType != null && this.ContentType.Type != null && this.ContentType.Type.ToLower() == "message" && this.ContentType.SubType != null && this.ContentType.SubType.ToLower() == "rfc822")
			{
				string value1 = null;
				string str1 = null;
				if (this.ContentType != null)
				{
					Parameter parameter1 = this.ContentType.Parameters["name"];
					if (parameter1 != null && parameter1.Value != null)
					{
						value1 = parameter1.Value;
					}
					Parameter item2 = this.ContentType.Parameters["charset"];
					if (item2 != null)
					{
						str1 = item2.Value;
					}
				}
				if (value1 == null && this.ContentDisposition != null)
				{
					Parameter parameter2 = this.ContentDisposition.Parameters["filename"];
					if (parameter2 != null && parameter2.Value != null)
					{
						value1 = parameter2.Value;
					}
				}
				Encoding encoding1 = o.m(str1);
				byte[] numArray = encoding1.GetBytes(this.ToString());
				Attachment attachment1 = new Attachment(numArray, value1)
				{
					ContentID = this.ContentID,
					ContentLocation = this.ContentLocation,
					ContentDisposition = this.ContentDisposition,
					ContentDescription = this.ContentDescription
				};
				attachments.Add(attachment1);
			}
			else if (this.c != null && this.ContentType != null && this.ContentType.Type != null && this.ContentType.Type.ToLower() != "text")
			{
				string value2 = null;
				if (this.ContentType != null)
				{
					Parameter item3 = this.ContentType.Parameters["name"];
					if (item3 != null && item3.Value != null)
					{
						value2 = item3.Value;
					}
				}
				if (value2 == null && this.ContentDisposition != null)
				{
					Parameter parameter3 = this.ContentDisposition.Parameters["filename"];
					if (parameter3 != null && parameter3.Value != null)
					{
						value2 = parameter3.Value;
					}
				}
				if (this.ContentTransferEncoding != Independentsoft.Email.Mime.ContentTransferEncoding.Base64)
				{
					byte[] bytes1 = Encoding.Default.GetBytes(this.c);
					Attachment attachment2 = new Attachment(bytes1, value2)
					{
						ContentType = new Independentsoft.Email.Mime.ContentType(this.ContentType.Type, this.ContentType.SubType),
						ContentID = this.ContentID,
						ContentLocation = this.ContentLocation,
						ContentDisposition = this.ContentDisposition,
						ContentDescription = this.ContentDescription
					};
					attachments.Add(attachment2);
				}
				else
				{
					Attachment attachment3 = new Attachment(o.g(this.c), value2)
					{
						ContentType = new Independentsoft.Email.Mime.ContentType(this.ContentType.Type, this.ContentType.SubType),
						ContentID = this.ContentID,
						ContentLocation = this.ContentLocation,
						ContentDisposition = this.ContentDisposition,
						ContentDescription = this.ContentDescription
					};
					attachments.Add(attachment3);
				}
			}
			else if (this.c != null && this.ContentType != null && this.ContentType.Type != null && this.ContentType.Type.ToLower() == "text" && this.ContentType.Parameters["name"] != null)
			{
				string str2 = null;
				if (this.ContentType != null)
				{
					Parameter item4 = this.ContentType.Parameters["name"];
					if (item4 != null && item4.Value != null)
					{
						str2 = item4.Value;
					}
				}
				if (str2 == null && this.ContentDisposition != null)
				{
					Parameter parameter4 = this.ContentDisposition.Parameters["filename"];
					if (parameter4 != null && parameter4.Value != null)
					{
						str2 = parameter4.Value;
					}
				}
				byte[] numArray1 = Encoding.Default.GetBytes(this.c);
				Attachment attachment4 = new Attachment(numArray1, str2)
				{
					ContentType = new Independentsoft.Email.Mime.ContentType(this.ContentType.Type, this.ContentType.SubType),
					ContentID = this.ContentID,
					ContentLocation = this.ContentLocation,
					ContentDisposition = this.ContentDisposition,
					ContentDescription = this.ContentDescription
				};
				attachments.Add(attachment4);
			}
			else if (this.c != null && this.ContentDisposition != null && this.ContentDisposition.ToString().ToLower() != "inline")
			{
				string value3 = null;
				if (this.ContentType != null)
				{
					Parameter item5 = this.ContentType.Parameters["name"];
					if (item5 != null && item5.Value != null)
					{
						value3 = item5.Value;
					}
				}
				if (value3 == null && this.ContentDisposition != null)
				{
					Parameter parameter5 = this.ContentDisposition.Parameters["filename"];
					if (parameter5 != null && parameter5.Value != null)
					{
						value3 = parameter5.Value;
					}
				}
				if (this.ContentTransferEncoding != Independentsoft.Email.Mime.ContentTransferEncoding.Base64)
				{
					byte[] bytes2 = Encoding.Default.GetBytes(this.c);
					Attachment attachment5 = new Attachment(bytes2, value3)
					{
						ContentID = this.ContentID,
						ContentLocation = this.ContentLocation,
						ContentDisposition = this.ContentDisposition,
						ContentDescription = this.ContentDescription
					};
					attachments.Add(attachment5);
				}
				else
				{
					Attachment attachment6 = new Attachment(o.g(this.c), value3)
					{
						ContentID = this.ContentID,
						ContentLocation = this.ContentLocation,
						ContentDisposition = this.ContentDisposition,
						ContentDescription = this.ContentDescription
					};
					attachments.Add(attachment6);
				}
			}
			else if (this.b.Count > 0)
			{
				for (int i = 0; i < this.b.Count; i++)
				{
					if (this.b[i] != null && (A_0 || this.b[i].ContentID == null) && this.b[i].ContentType != null && this.ContentType.Type.ToLower() != "text")
					{
						Attachment[] attachmentArray = this.b[i].a(A_0);
						for (int j = 0; j < (int)attachmentArray.Length; j++)
						{
							attachments.Add(attachmentArray[j]);
						}
					}
				}
			}
			Attachment[] attachmentArray1 = new Attachment[attachments.Count];
			for (int k = 0; k < attachments.Count; k++)
			{
				attachmentArray1[k] = attachments[k];
			}
			return attachmentArray1;
		}

		private Stream a()
		{
			MemoryStream memoryStream = new MemoryStream();
			string str = "";
			Independentsoft.Email.Mime.ContentType contentType = this.ContentType;
			string str1 = null;
			if (contentType != null && contentType.Type != null && contentType.Type.ToLower() == "multipart")
			{
				contentType.Parameters.Remove("boundary");
				str1 = string.Concat("----=_NextPart_", o.b());
				contentType.Parameters.Add(new Parameter("boundary", str1));
				this.ContentType = contentType;
			}
			else if (contentType == null && this.b.Count > 0)
			{
				contentType = new Independentsoft.Email.Mime.ContentType("multipart", "mixed");
				str1 = string.Concat("----=_NextPart_", o.b());
				contentType.Parameters.Add(new Parameter("boundary", str1));
				this.ContentType = contentType;
			}
			else if (contentType == null)
			{
				contentType = new Independentsoft.Email.Mime.ContentType("text", "plain");
				this.ContentType = contentType;
			}
			for (int i = 0; i < this.a.Count; i++)
			{
				Header item = this.a[i];
				if (item != null && item.Name != null && item.Value != null)
				{
					if (!o.a(item.Name, item.Value))
					{
						string str2 = string.Concat(item.Name, ": ", item.Value);
						str2 = o.a(str2, 76);
						str = string.Concat(str, str2, "\r\n");
					}
					else
					{
						string str3 = "";
						string str4 = "";
						string value = item.Value;
						if (item.Name.ToLower() == "content-type" || item.Name.ToLower() == "content-disposition")
						{
							int num = value.IndexOf(";");
							if (num > -1)
							{
								str3 = value.Substring(0, num + 1);
								value = value.Substring(num + 1, item.Value.Length - num - 1);
							}
							int num1 = value.IndexOf("filename=");
							if (num1 > -1)
							{
								int length = value.IndexOf(";", num1);
								if (length == -1)
								{
									length = value.Length;
								}
								str3 = string.Concat(str3, value.Substring(0, 10));
								value = value.Substring(10, length - 10);
								value = value.Trim(new char[] { '\"' });
							}
							int num2 = value.IndexOf("name=");
							if (num2 > -1)
							{
								int length1 = value.IndexOf(";", num2);
								if (length1 == -1)
								{
									length1 = value.Length;
								}
								str3 = string.Concat(str3, value.Substring(0, 6));
								value = value.Substring(6, length1 - 6);
								value = value.Trim(new char[] { '\"' });
							}
						}
						string str5 = o.a(value, this.f, this.e);
						str5 = string.Concat(str3, str5, str4);
						string str6 = string.Concat(item.Name, ": ", str5);
						str6 = o.a(str6, 76);
						str = string.Concat(str, str6, "\r\n");
					}
				}
			}
			str = string.Concat(str, "\r\n");
			byte[] bytes = Encoding.Default.GetBytes(str);
			memoryStream.Write(bytes, 0, (int)bytes.Length);
			if (this.b.Count > 0)
			{
				string str7 = string.Concat("--", str1);
				string str8 = string.Concat("--", str1, "--");
				for (int j = 0; j < this.b.Count; j++)
				{
					string str9 = string.Concat("\r\n", str7, "\r\n");
					byte[] numArray = Encoding.Default.GetBytes(str9);
					memoryStream.Write(numArray, 0, (int)numArray.Length);
					byte[] bytes1 = this.b[j].GetBytes();
					memoryStream.Write(bytes1, 0, (int)bytes1.Length);
				}
				string str10 = string.Concat("\r\n", str8, "\r\n");
				byte[] numArray1 = Encoding.Default.GetBytes(str10);
				memoryStream.Write(numArray1, 0, (int)numArray1.Length);
			}
			else if (contentType != null && contentType.Type != null && contentType.Type.ToLower() == "message" && contentType.SubType != null && contentType.SubType.ToLower() == "rfc822" && this.d != null)
			{
				byte[] bytes2 = this.d.GetBytes();
				memoryStream.Write(bytes2, 0, (int)bytes2.Length);
			}
			else if (contentType != null && contentType.Type != null && contentType.Type.ToLower() == "text" && this.c != null)
			{
				Encoding @default = Encoding.Default;
				Independentsoft.Email.Mime.ContentTransferEncoding contentTransferEncoding = Independentsoft.Email.Mime.ContentTransferEncoding.SevenBit;
				if (contentType != null)
				{
					Parameter parameter = contentType.Parameters["charset"];
					if (parameter != null && parameter.Value != null)
					{
						@default = o.m(parameter.Value);
					}
				}
				Header header = this.a[StandardHeader.ContentTransferEncoding];
				if (header != null && header.Value != null)
				{
					contentTransferEncoding = k.b(header.Value);
				}
				if (contentTransferEncoding == Independentsoft.Email.Mime.ContentTransferEncoding.QuotedPrintable)
				{
					string str11 = o.c(this.c, @default);
					str11 = o.j(str11);
					byte[] numArray2 = Encoding.Default.GetBytes(str11);
					memoryStream.Write(numArray2, 0, (int)numArray2.Length);
				}
				else if (contentTransferEncoding != Independentsoft.Email.Mime.ContentTransferEncoding.Base64)
				{
					byte[] bytes3 = @default.GetBytes(this.c);
					memoryStream.Write(bytes3, 0, (int)bytes3.Length);
				}
				else
				{
					byte[] numArray3 = @default.GetBytes(this.c);
					string base64String = Convert.ToBase64String(numArray3, 0, (int)numArray3.Length);
					if (base64String.IndexOf("\r\n") == -1)
					{
						base64String = o.i(base64String);
					}
					byte[] bytes4 = Encoding.Default.GetBytes(base64String);
					memoryStream.Write(bytes4, 0, (int)bytes4.Length);
				}
			}
			else if (this.c != null)
			{
				Independentsoft.Email.Mime.ContentTransferEncoding contentTransferEncoding1 = Independentsoft.Email.Mime.ContentTransferEncoding.SevenBit;
				Header item1 = this.a[StandardHeader.ContentTransferEncoding];
				if (item1 != null && item1.Value != null)
				{
					contentTransferEncoding1 = k.b(item1.Value);
				}
				if (contentTransferEncoding1 == Independentsoft.Email.Mime.ContentTransferEncoding.QuotedPrintable)
				{
					string str12 = o.j(this.c);
					byte[] numArray4 = Encoding.Default.GetBytes(str12);
					memoryStream.Write(numArray4, 0, (int)numArray4.Length);
				}
				else if (contentTransferEncoding1 != Independentsoft.Email.Mime.ContentTransferEncoding.Base64)
				{
					byte[] bytes5 = Encoding.Default.GetBytes(this.c);
					memoryStream.Write(bytes5, 0, (int)bytes5.Length);
				}
				else
				{
					string str13 = this.c;
					if (str13.IndexOf("\r\n") == -1)
					{
						str13 = o.i(str13);
					}
					byte[] numArray5 = Encoding.Default.GetBytes(str13);
					memoryStream.Write(numArray5, 0, (int)numArray5.Length);
				}
			}
			return memoryStream;
		}

		private void b(byte[] A_0)
		{
			int num = o.a(A_0, o.b);
			if (num > -1)
			{
				byte[] numArray = new byte[num];
				Array.Copy(A_0, 0, numArray, 0, (int)numArray.Length);
				this.a(numArray);
			}
			if ((int)A_0.Length > num + 4)
			{
				byte[] numArray1 = new byte[(int)A_0.Length - num - 4];
				Array.Copy(A_0, num + 4, numArray1, 0, (int)numArray1.Length);
				Independentsoft.Email.Mime.ContentType contentType = this.ContentType;
				Independentsoft.Email.Mime.ContentDisposition contentDisposition = this.ContentDisposition;
				Independentsoft.Email.Mime.ContentTransferEncoding contentTransferEncoding = this.ContentTransferEncoding;
				if (contentType == null)
				{
					this.c = Encoding.Default.GetString(numArray1, 0, (int)numArray1.Length);
					return;
				}
				if (contentType.Type != null && contentType.Type.ToLower() == "text" || contentType.Type != null && contentType.Type.ToLower() == "text" && contentDisposition != null && contentDisposition.Type == ContentDispositionType.Inline)
				{
					Parameter item = contentType.Parameters["charset"];
					if (item != null && item.Value != null)
					{
						Encoding encoding = o.m(item.Value);
						this.c = encoding.GetString(numArray1, 0, (int)numArray1.Length);
						if (contentTransferEncoding == Independentsoft.Email.Mime.ContentTransferEncoding.QuotedPrintable)
						{
							this.c = o.a(this.c, encoding);
							return;
						}
						if (contentTransferEncoding == Independentsoft.Email.Mime.ContentTransferEncoding.Base64)
						{
							this.c = o.b(this.c, encoding);
							return;
						}
						this.c = encoding.GetString(numArray1, 0, (int)numArray1.Length);
						return;
					}
					this.c = Encoding.Default.GetString(numArray1, 0, (int)numArray1.Length);
					if (contentTransferEncoding == Independentsoft.Email.Mime.ContentTransferEncoding.QuotedPrintable)
					{
						this.c = o.a(this.c, Encoding.Default);
						return;
					}
					if (contentTransferEncoding == Independentsoft.Email.Mime.ContentTransferEncoding.Base64)
					{
						this.c = o.b(this.c, Encoding.Default);
						return;
					}
				}
				else if (contentType.Type != null && contentType.Type.ToLower() == "multipart")
				{
					Parameter parameter = contentType.Parameters["boundary"];
					if (parameter != null && parameter.Value != null)
					{
						IList<byte[]> numArrays = o.a(numArray1, parameter.Value);
						for (int i = 0; i < numArrays.Count; i++)
						{
							BodyPart bodyPart = new BodyPart(numArrays[i]);
							this.b.Add(bodyPart);
						}
						return;
					}
				}
				else if (contentType.Type == null || !(contentType.Type.ToLower() == "message"))
				{
					if (contentTransferEncoding == Independentsoft.Email.Mime.ContentTransferEncoding.QuotedPrintable)
					{
						this.c = Encoding.Default.GetString(numArray1, 0, (int)numArray1.Length);
						this.c = this.c.Replace("=09", "\t");
						this.c = this.c.Replace("=0D", "\r");
						this.c = this.c.Replace("=0A", "\n");
						this.c = this.c.Replace("=20", " ");
						this.c = this.c.Replace("=\r\n", string.Empty);
						return;
					}
					if (contentTransferEncoding == Independentsoft.Email.Mime.ContentTransferEncoding.Base64)
					{
						numArray1 = o.a(numArray1);
						this.c = Encoding.Default.GetString(numArray1, 0, (int)numArray1.Length);
						return;
					}
					this.c = Encoding.Default.GetString(numArray1, 0, (int)numArray1.Length);
				}
				else
				{
					if (contentType.SubType != null && contentType.SubType.ToLower() == "rfc822")
					{
						this.d = new Message(numArray1);
						return;
					}
					if (contentType.SubType != null && contentType.SubType.ToLower() == "delivery-status")
					{
						byte[] numArray2 = new byte[0];
						if (contentTransferEncoding == Independentsoft.Email.Mime.ContentTransferEncoding.Base64)
						{
							string str = Encoding.Default.GetString(numArray1, 0, (int)numArray1.Length);
							if (str != null && str.Length > 0)
							{
								numArray2 = Convert.FromBase64String(str);
							}
						}
						if ((int)numArray2.Length > 0)
						{
							try
							{
								this.d = new Message(numArray2)
								{
									Subject = (contentType.Parameters["name"] != null ? contentType.Parameters["name"].Value : "ATT")
								};
							}
							catch (MessageFormatException messageFormatException)
							{
								this.c = Encoding.Default.GetString(numArray1, 0, (int)numArray1.Length);
							}
						}
					}
					else if (contentType.SubType != null && contentType.SubType == "partial")
					{
						this.c = Encoding.Default.GetString(numArray1, 0, (int)numArray1.Length);
						return;
					}
				}
			}
		}

		/// <summary>
		/// Gets the bytes.
		/// </summary>
		/// <returns>System.Byte[][].</returns>
		public byte[] GetBytes()
		{
			byte[] array = null;
			MemoryStream stream = (MemoryStream)this.GetStream();
			using (stream)
			{
				array = stream.ToArray();
			}
			return array;
		}

		/// <summary>
		/// Gets the stream.
		/// </summary>
		/// <returns>Stream.</returns>
		public Stream GetStream()
		{
			return this.a();
		}

		/// <summary>
		/// Saves the specified file path.
		/// </summary>
		/// <param name="filePath">The file path.</param>
		public void Save(string filePath)
		{
			this.Save(filePath, false);
		}

		/// <summary>
		/// Saves the specified file path.
		/// </summary>
		/// <param name="filePath">The file path.</param>
		/// <param name="overwrite">if set to <c>true</c> [overwrite].</param>
		public void Save(string filePath, bool overwrite)
		{
			FileMode fileMode = FileMode.CreateNew;
			if (overwrite)
			{
				fileMode = FileMode.Create;
			}
			using (FileStream fileStream = new FileStream(filePath, fileMode, FileAccess.Write))
			{
				this.Save(fileStream);
			}
		}

		/// <summary>
		/// Saves the specified stream.
		/// </summary>
		/// <param name="stream">The stream.</param>
		/// <exception cref="T:System.ArgumentNullException">stream</exception>
		public void Save(Stream stream)
		{
			if (stream == null)
			{
				throw new ArgumentNullException("stream");
			}
			byte[] bytes = this.GetBytes();
			stream.Write(bytes, 0, (int)bytes.Length);
		}

		/// <summary>
		/// Returns a <see cref="T:System.String" /> that represents this instance.
		/// </summary>
		/// <returns>A <see cref="T:System.String" /> that represents this instance.</returns>
		public override string ToString()
		{
			byte[] bytes = this.GetBytes();
			string str = Encoding.UTF8.GetString(bytes, 0, (int)bytes.Length);
			return str;
		}
	}
}