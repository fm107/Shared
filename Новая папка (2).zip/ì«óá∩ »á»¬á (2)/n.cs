using Independentsoft.IO.StructuredStorage;
using System;
using System.IO;

internal class n
{
	private byte[] a = new byte[] { 208, 207, 17, 224, 161, 177, 26, 225 };

	private byte[] b = new byte[16];

	private ushort c = 62;

	private ushort d = 3;

	private ushort e = 65534;

	private ushort f = 9;

	private ushort g = 6;

	private ushort h;

	private uint i;

	private uint j;

	private uint k;

	private uint l;

	private uint m;

	private uint n = 4096;

	private uint o;

	private uint p;

	private uint q;

	private uint r;

	private uint[] s = new uint[109];

	internal n()
	{
	}

	internal n(BinaryReader A_0)
	{
		this.a(A_0);
	}

	private void a(BinaryReader A_0)
	{
		byte[] numArray = A_0.ReadBytes(8);
		for (int i = 0; i < 8; i++)
		{
			if (numArray[i] != this.a[i])
			{
				throw new InvalidFileFormatException("Invalid file format.");
			}
		}
		this.b = A_0.ReadBytes(16);
		this.c = A_0.ReadUInt16();
		this.d = A_0.ReadUInt16();
		this.e = A_0.ReadUInt16();
		this.f = A_0.ReadUInt16();
		this.g = A_0.ReadUInt16();
		this.h = A_0.ReadUInt16();
		this.i = A_0.ReadUInt32();
		this.j = A_0.ReadUInt32();
		this.k = A_0.ReadUInt32();
		this.l = A_0.ReadUInt32();
		this.m = A_0.ReadUInt32();
		this.n = A_0.ReadUInt32();
		this.o = A_0.ReadUInt32();
		this.p = A_0.ReadUInt32();
		this.q = A_0.ReadUInt32();
		this.r = A_0.ReadUInt32();
		for (int j = 0; j < 109; j++)
		{
			this.s[j] = A_0.ReadUInt32();
		}
	}

	internal void a(ushort A_0)
	{
		if (A_0 == 3)
		{
			this.d = A_0;
			this.f = 9;
			return;
		}
		if (A_0 != 4)
		{
			throw new ArgumentException("MajorVersion must be 3 or 4.");
		}
		this.d = A_0;
		this.f = 12;
	}

	internal void a(uint A_0)
	{
		this.k = A_0;
	}

	internal uint a()
	{
		return this.q;
	}

	internal void a(byte[] A_0)
	{
		this.b = A_0;
	}

	internal uint b()
	{
		return this.o;
	}

	internal void b(uint A_0)
	{
		this.q = A_0;
	}

	internal uint c()
	{
		return this.n;
	}

	internal void c(uint A_0)
	{
		this.r = A_0;
	}

	internal ushort d()
	{
		if (this.f == 9)
		{
			return (ushort)512;
		}
		return (ushort)4096;
	}

	internal void d(uint A_0)
	{
		this.l = A_0;
	}

	internal ushort e()
	{
		return this.d;
	}

	internal void e(uint A_0)
	{
		this.p = A_0;
	}

	internal uint f()
	{
		return this.k;
	}

	internal void f(uint A_0)
	{
		this.o = A_0;
	}

	internal ushort g()
	{
		return (ushort)64;
	}

	internal void g(uint A_0)
	{
		this.j = A_0;
	}

	internal byte[] h()
	{
		byte[] numArray = new byte[this.d()];
		MemoryStream memoryStream = new MemoryStream(numArray);
		using (memoryStream)
		{
			BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
			binaryWriter.Write(this.a);
			binaryWriter.Write(this.b);
			binaryWriter.Write(this.c);
			binaryWriter.Write(this.d);
			binaryWriter.Write(this.e);
			binaryWriter.Write(this.f);
			binaryWriter.Write(this.g);
			binaryWriter.Write(this.h);
			binaryWriter.Write(this.i);
			binaryWriter.Write(this.j);
			binaryWriter.Write(this.k);
			binaryWriter.Write(this.l);
			binaryWriter.Write(this.m);
			binaryWriter.Write(this.n);
			binaryWriter.Write(this.o);
			binaryWriter.Write(this.p);
			binaryWriter.Write(this.q);
			binaryWriter.Write(this.r);
			for (int i = 0; i < 109; i++)
			{
				binaryWriter.Write(this.s[i]);
			}
		}
		return numArray;
	}

	internal byte[] i()
	{
		return this.b;
	}

	internal uint j()
	{
		return this.p;
	}

	internal uint[] k()
	{
		return this.s;
	}

	internal uint l()
	{
		return this.l;
	}
}